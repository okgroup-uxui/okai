/* ===== 읏배구놀이터 ===== */

if(!window.__errQ){
  window.__errQ = [];
  (function(){
    function push(o){ (window.__reportErr || function(x){ if(window.__errQ.length < 10) window.__errQ.push(x); })(o); }
    window.addEventListener('error', function(e){ if(e && e.message) push({ msg:e.message, src:e.filename || '', line:e.lineno || 0 }); });
    window.addEventListener('unhandledrejection', function(e){ var r = e && e.reason; push({ msg:'Promise: ' + String(r && (r.message || r) || '알 수 없음'), src:(r && r.stack || '').split('\n')[1] || '', line:0 }); });
  })();
}

const LI_PATH = {
  chair:'<path d="M3 7.5V10.5C3 11.0523 3.4477 11.5 4 11.5H14C14.5523 11.5 15 11.0523 15 10.5V7.5M5 11.5V14.5M13 11.5V14.5M5.5 8.5V4.5C5.5 3.6716 6.1716 3 7 3H11C11.8284 3 12.5 3.6716 12.5 4.5V8.5H5.5Z"/>',
  camera:'<path d="M3 6C3 5.172 3.672 4.5 4.5 4.5H5.625L6.375 3.375H11.625L12.375 4.5H13.5C14.328 4.5 15 5.172 15 6V12.75C15 13.578 14.328 14.25 13.5 14.25H4.5C3.672 14.25 3 13.578 3 12.75V6Z"/><circle cx="9" cy="9.375" r="2.625"/>',
  clock:'<circle cx="9" cy="9.75" r="5.625"/><path d="M9 7.125V9.75L10.875 10.875M7.5 2.625H10.5"/>',
  calendar:'<rect x="3" y="4.125" width="12" height="11.25" rx="1.875"/><path d="M3 7.875H15M6 2.625V5.625M12 2.625V5.625"/>',
  calCheck:'<rect x="3" y="4.125" width="12" height="11.25" rx="1.875"/><path d="M3 7.875H15M6 2.625V5.625M12 2.625V5.625M6.75 11.25L8.25 12.75L11.25 9.75"/>',
  calOff:'<rect x="3" y="4.125" width="12" height="11.25" rx="1.875"/><path d="M3 7.875H15M6 2.625V5.625M12 2.625V5.625M7.5 10.125L10.5 13.125M10.5 10.125L7.5 13.125"/>',
  bag:'<path d="M3.75 6.375H14.25L13.56 13.965C13.49 14.738 12.842 15.33 12.066 15.33H5.934C5.158 15.33 4.51 14.738 4.44 13.965L3.75 6.375Z"/><path d="M6.375 8.25V5.625C6.375 4.175 7.55 3 9 3C10.45 3 11.625 4.175 11.625 5.625V8.25"/>',
  gift:'<rect x="2.625" y="6" width="12.75" height="3" rx="0.75"/><path d="M3.75 9V14.25C3.75 14.871 4.254 15.375 4.875 15.375H13.125C13.746 15.375 14.25 14.871 14.25 14.25V9M9 6V15.375M9 6C9 6 8.1 3 6.375 3C5.547 3 4.875 3.672 4.875 4.5C4.875 5.328 5.547 6 6.375 6M9 6C9 6 9.9 3 11.625 3C12.453 3 13.125 3.672 13.125 4.5C13.125 5.328 12.453 6 11.625 6"/>',
  subway:'<rect x="4.125" y="2.25" width="9.75" height="10.875" rx="3"/><path d="M4.125 7.5H13.875M6.75 10.125H6.758M11.25 10.125H11.258M6.75 13.125L5.25 15.75M11.25 13.125L12.75 15.75"/>',
  chart:'<path d="M3 15H15M5.25 12.375V9.75M9 12.375V5.25M12.75 12.375V7.875"/>',
  clip:'<rect x="3.75" y="3.375" width="10.5" height="12.375" rx="1.875"/><path d="M6.75 2.25H11.25V4.5H6.75V2.25ZM6.75 8.25H11.25M6.75 11.25H9.75"/>',
  trophy:'<path d="M5.625 2.625H12.375V7.125C12.375 8.989 10.864 10.5 9 10.5C7.136 10.5 5.625 8.989 5.625 7.125V2.625Z"/><path d="M5.625 4.125H3.375V5.25C3.375 6.493 4.382 7.5 5.625 7.5M12.375 4.125H14.625V5.25C14.625 6.493 13.618 7.5 12.375 7.5M9 10.5V13.125M6.375 15.375H11.625M7.125 15.375C7.125 14.135 7.965 13.125 9 13.125C10.035 13.125 10.875 14.135 10.875 15.375"/>',
  card:'<rect x="5.25" y="3" width="9.75" height="12.75" rx="1.875"/><path d="M3 5.25V13.875C3 14.703 3.672 15.375 4.5 15.375"/><circle cx="10.125" cy="7.5" r="1.5"/><path d="M7.875 12.375C8.25 11.25 9.075 10.5 10.125 10.5C11.175 10.5 12 11.25 12.375 12.375"/>',
  star:'<path d="M9 2.625L10.86 6.395L15.02 7L12.01 9.934L12.72 14.077L9 12.12L5.28 14.077L5.99 9.934L2.98 7L7.14 6.395L9 2.625Z"/>',
  checkCircle:'<circle cx="9" cy="9" r="6.75"/><path d="M6.375 9.188L8.25 11.063L11.625 7.313"/>',
};
const LI = new Proxy({}, { get:(_, k)=> LI_PATH[k] ? `<svg class="lic" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LI_PATH[k]}</svg>` : '' });

/* ===== 스플래시 (인트로) ===== */
const SPLASH_CHARACTERS = [
  "images/players/00-coach.webp",
  "images/players/01-no1.webp",
  "images/players/02-no3.webp",
  "images/players/03-no5.webp",
  "images/players/04-no6.webp",
  "images/players/05-no7.webp",
  "images/players/06-no8.webp",
  "images/players/07-no10.webp",
  "images/players/08-no11.webp",
  "images/players/09-no12.webp",
  "images/players/10-no14.webp",
  "images/players/11-no15.webp",
  "images/players/12-no16.webp",
  "images/players/13-no17.webp",
  "images/players/14-no19.webp",
  "images/players/15-no22.webp",
  "images/players/16-no31.webp",
  "images/players/17-no40.webp"
  ];
(function initSplash(){
  const splash = document.getElementById('splash');
  if(!splash) return;
  document.documentElement.style.overflow = 'hidden';
  window.__splashT0 = performance.now();
  const timers = [];
  function dismissSplash(){
    if(splash.classList.contains('hide')) return;
    timers.forEach(clearTimeout);
    splash.classList.add('hide');
    document.documentElement.style.overflow = '';
    setTimeout(()=> splash.remove(), 700);
  }
  splash.addEventListener('click', dismissSplash);
  window.__runIntro = function(players, meta){
    if(splash.classList.contains('hide')) return;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const [p1, p2] = players;
    const esc = v => String(v ?? '').replace(/[&<>"']/g, c=> ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
    const photo = p => p.src ? `<img src="${esc(p.src)}" alt="" decoding="async">` : '';
    const card = p => `
      <span class="sx-num">${esc(p.num)}</span>
      <div class="sx-photo${p.cut ? ' cut' : ''}">${p.src ? photo(p) : `<span class="nophoto">${esc(p.num)}</span>`}</div>
      <div class="sx-band"></div>
      <i class="sx-burst"></i>
      <div class="sx-name"><span class="pos">${esc(p.pos)}</span><b class="nm">${p.name ? `<span class="no">${esc(p.num)}</span>${esc(p.name)}` : `No.${esc(p.num)}`}</b></div>`;
    const el1 = document.getElementById('sx-p1'), el2 = document.getElementById('sx-p2');
    el1.innerHTML = card(p1); el2.innerHTML = card(p2);
    const load = document.getElementById('sx-load'), flash = document.getElementById('sx-flash');
    const at = (ms, fn)=> timers.push(setTimeout(fn, ms));
    const hit = el=>{
      el.classList.add('hit');
      flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go');
      splash.classList.remove('shake'); void splash.offsetWidth; splash.classList.add('shake');
      if(canVibrate()) navigator.vibrate(18);
    };
    if(reduce){ splash.classList.add('ph-p1'); el1.classList.add('in', 'hit'); load.style.width = '100%'; at(2600, dismissSplash); return; }
    at(0,    ()=>{ splash.classList.add('ph-p1'); el1.classList.add('in'); load.style.width = '35%'; });
    at(420,  ()=> hit(el1));
    at(1800, ()=>{ el1.classList.add('out'); el2.classList.add('in'); load.style.width = '70%'; });
    at(2220, ()=> hit(el2));
    at(3000, ()=>{ load.style.width = '100%'; });
    at(3700, dismissSplash);
  };
  timers.push(setTimeout(()=>{ if(!window.__introStarted) dismissSplash(); }, 4500));
})();

/* ===== 설정값 (CONFIG) ===== */
/* ===== 좌석 구역 데이터 ===== */
function zoneRange(level, start, end, color, extra){
  const out = [];
  for(let n = start; n <= end; n++){
    out.push(Object.assign({ id: `${level}-${n}`, label: `${level}-${n}`, level, color }, extra || {}));
  }
  return out;
}
const ZONES_DATA = [
  ...zoneRange('1', 1, 2, 'cyan'),
  ...zoneRange('1', 3, 6, 'green'),
  ...zoneRange('1', 7, 8, 'cyan'),
  ...zoneRange('1', 9, 9, 'yellow'),
  ...zoneRange('1', 10, 11, 'cyan'),
  ...zoneRange('1', 12, 15, 'green'),
  ...zoneRange('1', 16, 17, 'cyan'),
  ...zoneRange('1', 18, 18, 'yellow'),

  ...zoneRange('2', 1, 1, 'orange'),
  ...zoneRange('2', 2, 4, 'orange', { accessible: true }),
  ...zoneRange('2', 5, 5, 'orange'),
  ...zoneRange('2', 6, 12, 'purple'),
  ...zoneRange('2', 13, 13, 'red'),
  ...zoneRange('2', 14, 15, 'red', { accessible: true }),
  ...zoneRange('2', 16, 16, 'red'),
  ...zoneRange('2', 17, 22, 'purple'),
  ...zoneRange('2', 23, 23, 'charcoal'),

  ...zoneRange('3', 1, 2, 'brown'),
  ...zoneRange('3', 3, 3, 'brown', { gate: 'GATE 1' }),
  ...zoneRange('3', 4, 4, 'brown'),
  ...zoneRange('3', 5, 5, 'brown', { gate: 'GATE 2' }),
  ...zoneRange('3', 6, 7, 'brown'),
  ...zoneRange('3', 8, 9, 'forest'),
  ...zoneRange('3', 10, 10, 'forest', { gate: 'GATE 3' }),
  ...zoneRange('3', 11, 11, 'tan'),
  ...zoneRange('3', 12, 12, 'tan', { gate: 'GATE 4' }),
  ...zoneRange('3', 13, 14, 'tan'),

  { id:'HT', label:'하이테이블석', level:'S', color:'navy' },
  { id:'suite', label:'스위트박스', level:'S', color:'pink' },
];

const ZONE_COORDS = {
  '3-1':[20.3,12.43],
  '3-2':[32.3,12.01],
  '3-3':[39.3,7.12],
  '3-4':[42.7,12.01],
  '3-5':[60.1,7.12],
  '3-6':[64.7,12.01],
  '3-7':[76.7,12.43],
  '2-23':[21.9,16.68],
  '2-1':[32.3,16.68],
  '2-2':[33.7,17.96],
  '2-3':[43.9,17.96],
  '2-4':[62.9,17.96],
  '2-5':[64.3,16.68],
  '2-6':[74.5,16.68],
  '2-22':[11.5,22.85],
  '2-21':[12.3,34.54],
  '2-20':[12.3,54.94],
  '2-19':[12.3,65.99],
  '2-18':[12.3,76.2],
  '2-17':[22.1,83.42],
  '2-7':[85.5,22.64],
  '2-8':[84.5,34.54],
  '2-9':[84.5,54.94],
  '2-10':[84.5,65.57],
  '2-11':[84.5,76.2],
  '2-12':[74.5,83.42],
  '2-16':[32.3,83.42],
  '2-15':[33.7,82.36],
  'suite':[43.9,82.36],
  '2-14':[62.9,82.36],
  '2-13':[64.3,83.42],
  '1-1':[22.1,24.97],
  '1-2':[32.3,24.97],
  '1-3':[33.7,24.97],
  '1-4':[43.9,24.97],
  '1-5':[52.7,24.97],
  '1-6':[62.9,24.97],
  '1-7':[64.3,24.97],
  '1-8':[74.5,24.97],
  '1-18':[14.5,60.68],
  '1-9':[82.3,60.68],
  '1-17':[22.1,75.35],
  '1-16':[32.3,75.35],
  '1-15':[33.7,75.35],
  '1-14':[43.9,75.35],
  '1-13':[52.7,75.35],
  '1-12':[62.9,75.35],
  '1-11':[64.3,75.35],
  '1-10':[74.5,75.35],
  '3-14':[20.3,87.67],
  '3-13':[32.3,87.89],
  '3-12':[38.1,92.99],
  '3-11':[42.7,87.89],
  '3-10':[60.1,92.99],
  '3-9':[64.7,87.89],
  '3-8':[76.7,87.67],
  'HT':[5.1,27.95],
  'HT2':[5.1,81.93]
};

const ZONE_PATHS = {
  '3-1':[[37.5,12.01],[37.5,12.65],[20.3,12.65],[20.3,12.43]],
  '3-2':[[37.5,12.01],[32.3,12.01]],
  '3-3':[[37.5,12.01],[39.3,12.01],[39.3,7.12]],
  '3-4':[[37.5,12.01],[42.7,12.01]],
  '3-5':[[59.5,12.01],[60.1,12.01],[60.1,7.12]],
  '3-6':[[59.5,12.01],[64.7,12.01]],
  '3-7':[[59.5,12.01],[59.5,12.65],[76.7,12.65],[76.7,12.43]],
  '2-23':[[37.5,12.01],[37.5,16.47],[21.9,16.47],[21.9,16.68]],
  '2-1':[[37.5,12.01],[37.5,16.47],[32.3,16.47],[32.3,16.68]],
  '2-2':[[37.5,12.01],[33.5,12.01],[33.5,17.96],[33.7,17.96]],
  '2-3':[[37.5,12.01],[37.5,16.47],[43.7,16.47],[43.7,17.96],[43.9,17.96]],
  '2-4':[[59.5,12.01],[63.1,12.01],[63.1,17.96],[62.9,17.96]],
  '2-5':[[59.5,12.01],[64.1,12.01],[64.1,16.68],[64.3,16.68]],
  '2-6':[[59.5,12.01],[59.5,16.47],[74.5,16.47],[74.5,16.68]],
  '2-22':[[37.5,12.01],[32.5,12.01],[32.5,22.64],[11.5,22.64],[11.5,22.85]],
  '2-21':[[37.5,12.01],[32.5,12.01],[32.5,24.55],[12.5,24.55],[12.5,34.54],[12.3,34.54]],
  '2-20':[[37.5,87.89],[32.5,87.89],[32.5,75.77],[12.5,75.77],[12.5,54.94],[12.3,54.94]],
  '2-19':[[37.5,87.89],[32.5,87.89],[32.5,75.77],[12.5,75.77],[12.5,65.99],[12.3,65.99]],
  '2-18':[[37.5,87.89],[32.5,87.89],[32.5,76.2],[12.3,76.2]],
  '2-17':[[37.5,87.89],[37.5,83.63],[22.1,83.63],[22.1,83.42]],
  '2-7':[[59.5,12.01],[64.1,12.01],[64.1,22.64],[85.5,22.64]],
  '2-8':[[59.5,12.01],[64.1,12.01],[64.1,24.55],[84.3,24.55],[84.3,34.54],[84.5,34.54]],
  '2-9':[[59.5,87.89],[64.1,87.89],[64.1,75.77],[84.3,75.77],[84.3,54.94],[84.5,54.94]],
  '2-10':[[59.5,87.89],[64.1,87.89],[64.1,75.77],[84.3,75.77],[84.3,65.57],[84.5,65.57]],
  '2-11':[[59.5,87.89],[64.1,87.89],[64.1,76.2],[84.5,76.2]],
  '2-12':[[59.5,87.89],[59.5,83.63],[74.5,83.63],[74.5,83.42]],
  '2-16':[[37.5,87.89],[32.5,87.89],[32.5,83.42],[32.3,83.42]],
  '2-15':[[37.5,87.89],[33.5,87.89],[33.5,82.36],[33.7,82.36]],
  'suite':[[37.5,87.89],[37.5,83.63],[43.7,83.63],[43.7,82.36],[43.9,82.36]],
  '2-14':[[59.5,87.89],[63.1,87.89],[63.1,82.36],[62.9,82.36]],
  '2-13':[[59.5,87.89],[64.1,87.89],[64.1,83.42],[64.3,83.42]],
  '1-1':[[37.5,12.01],[32.5,12.01],[32.5,24.55],[22.1,24.55],[22.1,24.97]],
  '1-2':[[37.5,12.01],[32.5,12.01],[32.5,24.97],[32.3,24.97]],
  '1-3':[[37.5,12.01],[33.5,12.01],[33.5,24.55],[33.7,24.55],[33.7,24.97]],
  '1-4':[[37.5,12.01],[37.5,16.47],[43.7,16.47],[43.7,24.97],[43.9,24.97]],
  '1-5':[[59.5,12.01],[59.5,16.47],[52.9,16.47],[52.9,24.97],[52.7,24.97]],
  '1-6':[[59.5,12.01],[63.1,12.01],[63.1,24.97],[62.9,24.97]],
  '1-7':[[59.5,12.01],[64.1,12.01],[64.1,24.97],[64.3,24.97]],
  '1-8':[[59.5,12.01],[64.1,12.01],[64.1,24.55],[74.5,24.55],[74.5,24.97]],
  '1-18':[[37.5,87.89],[32.5,87.89],[32.5,75.77],[14.3,75.77],[14.3,60.68],[14.5,60.68]],
  '1-9':[[59.5,87.89],[64.1,87.89],[64.1,75.77],[82.7,75.77],[82.7,60.68],[82.3,60.68]],
  '1-17':[[37.5,87.89],[32.5,87.89],[32.5,75.77],[22.1,75.77],[22.1,75.35]],
  '1-16':[[37.5,87.89],[32.5,87.89],[32.5,75.35],[32.3,75.35]],
  '1-15':[[37.5,87.89],[33.5,87.89],[33.5,75.77],[33.7,75.77],[33.7,75.35]],
  '1-14':[[37.5,87.89],[37.5,83.63],[43.7,83.63],[43.7,75.77],[43.9,75.77],[43.9,75.35]],
  '1-13':[[59.5,87.89],[59.5,83.63],[52.9,83.63],[52.9,75.35],[52.7,75.35]],
  '1-12':[[59.5,87.89],[63.1,87.89],[63.1,75.77],[62.9,75.77],[62.9,75.35]],
  '1-11':[[59.5,87.89],[64.1,87.89],[64.1,75.77],[64.3,75.77],[64.3,75.35]],
  '1-10':[[59.5,87.89],[64.1,87.89],[64.1,75.77],[74.5,75.77],[74.5,75.35]],
  '3-14':[[37.5,87.89],[37.5,87.46],[20.3,87.46],[20.3,87.67]],
  '3-13':[[37.5,87.89],[32.3,87.89]],
  '3-12':[[37.5,87.89],[38.1,87.89],[38.1,92.99]],
  '3-11':[[37.5,87.89],[42.7,87.89]],
  '3-10':[[59.5,87.89],[60.1,87.89],[60.1,92.99]],
  '3-9':[[59.5,87.89],[64.3,87.89],[64.7,87.89]],
  '3-8':[[59.5,87.89],[59.5,87.46],[76.7,87.46],[76.7,87.67]],
  'HT':[[37.5,12.01],[37.5,16.47],[5.1,16.47],[5.1,27.95]],
  'HT2':[[37.5,87.89],[37.5,83.63],[5.3,83.63],[5.3,81.93],[5.1,81.93]]
};

const ZONE_GATE = {
  '3-1':"GATE 1",
  '3-2':"GATE 1",
  '3-3':"GATE 1",
  '3-4':"GATE 1",
  '3-5':"GATE 2",
  '3-6':"GATE 2",
  '3-7':"GATE 2",
  '2-23':"GATE 1",
  '2-1':"GATE 1",
  '2-2':"GATE 1",
  '2-3':"GATE 1",
  '2-4':"GATE 2",
  '2-5':"GATE 2",
  '2-6':"GATE 2",
  '2-22':"GATE 1",
  '2-21':"GATE 1",
  '2-20':"GATE 4",
  '2-19':"GATE 4",
  '2-18':"GATE 4",
  '2-17':"GATE 4",
  '2-7':"GATE 2",
  '2-8':"GATE 2",
  '2-9':"GATE 3",
  '2-10':"GATE 3",
  '2-11':"GATE 3",
  '2-12':"GATE 3",
  '2-16':"GATE 4",
  '2-15':"GATE 4",
  'suite':"GATE 4",
  '2-14':"GATE 3",
  '2-13':"GATE 3",
  '1-1':"GATE 1",
  '1-2':"GATE 1",
  '1-3':"GATE 1",
  '1-4':"GATE 1",
  '1-5':"GATE 2",
  '1-6':"GATE 2",
  '1-7':"GATE 2",
  '1-8':"GATE 2",
  '1-18':"GATE 4",
  '1-9':"GATE 3",
  '1-17':"GATE 4",
  '1-16':"GATE 4",
  '1-15':"GATE 4",
  '1-14':"GATE 4",
  '1-13':"GATE 3",
  '1-12':"GATE 3",
  '1-11':"GATE 3",
  '1-10':"GATE 3",
  '3-14':"GATE 4",
  '3-13':"GATE 4",
  '3-12':"GATE 4",
  '3-11':"GATE 4",
  '3-10':"GATE 3",
  '3-9':"GATE 3",
  '3-8':"GATE 3",
  'HT':"GATE 1",
  'HT2':"GATE 4"
};

const GATE_COORDS = {
  'GATE 1':[37.5,12.01],
  'GATE 2':[59.5,12.01],
  'GATE 3':[59.5,87.89],
  'GATE 4':[37.5,87.89]
};

const SAME_ORIGIN = /^https?:$/.test(location.protocol) ? location.origin : '';
const CONFIG = {
  DATA_MODE: 'local',
  API_BASE: '',
  STATS_API: SAME_ORIGIN,

  MATCH: {
    home: 'OK저축은행 읏맨',
    away: '상대팀',
    venue: '부산 강서실내체육관',
    date: '',
    start: ''
  },

  MATCH_PHASE: 'auto',

  LIVE_API: SAME_ORIGIN,
  LIVE_DEMO: {
    events: [
      { id:'demo-1', title:'읏맨 티셔츠 증정', place:'1층 OK저축은행 부스', limit:'선착순 3명', desc:'경기 시작 전까지 부스에 오셔서 이 화면을 보여주세요.', startsAt:'', endsAt:'' },
    ],
    prizes: [ { n:10, prize:'읏맨 응원 티셔츠', place:'1층 OK저축은행 부스' } ],
  },

  TIERS: [
    { key:'gold',   name:'골드', min:85 },
    { key:'silver', name:'실버', min:75 },
    { key:'base',   name:'기본', min:0  },
  ],

  RARE_RATIO: 0.7,

  MVP_CARD: { num:12, title:'MVP', until:'' },

  GAMES: [],

  MATCH_ID: '',

  VENUE_MAP_IMAGE: 'images/venue/map.webp',

  ZONES: ZONES_DATA,
  LEVEL_LABELS: { '1':'1층 코트사이드', '2':'2층 메인', '3':'3층 상단', 'S':'특별석' },
  ZONE_COLORS: {
    cyan:'#2CAFCB', green:'#50B33F', yellow:'#FABE06', orange:'#E84C11', purple:'#683E94',
    red:'#E61D16', charcoal:'#3C3D3F', brown:'#52331A', tan:'#BB701D', forest:'#2F7738',
    navy:'#0024BA', pink:'#E62A74'
  },

  SEAT_TOUR_BASE: 'https://cdn.kovo.co.kr/court-views/okMan/tour.html',
  SEAT_SCENE_MAP: {
    '3-12': 'OK3-11',
    '3-13': 'OK3-12',
    '3-14': 'OK3-13',
    'HT': 'OK2-21',
    'suite': 'OK2-15',
  },

  PREDICT_EVENTS: [
    { id:'first_point', q:'첫 득점 팀은 어디일까요?', options:['OK저축은행 읏맨','상대팀'] },
    { id:'first_block', q:'첫 블로킹을 성공시킬 선수는?', type:'player', candidates:null },
    { id:'set_score', q:'세트 스코어를 예측해보세요', options:['3:0','3:1','3:2','2:3 이하'] },
  ],

  SURVEY_QUESTIONS: [{"id": "1", "q": "오늘 경기장 좌석 안내는 찾기 쉬웠나요?", "type": "single", "options": ["매우 쉬움", "쉬움", "보통", "어려움"]}, {"id": "2", "q": "오늘 응원 분위기는 어땠나요?", "type": "single", "options": ["최고였어요", "좋았어요", "보통이었어요", "아쉬웠어요"]}, {"id": "3", "q": "다음에도 직관하러 오실 의향이 있나요?", "type": "single", "options": ["꼭 다시 올게요", "아마도요", "잘 모르겠어요"]}, {"id": "4", "q": "경기장 내 편의시설(매점·화장실 등)은 만족스러웠나요?", "type": "single", "options": ["매우 만족", "만족", "보통", "불만족"]}],

  /* ---------- 하단 탭 라벨 ---------- */
  NAV_LANG: 'ko',
  NAV_LABELS: {
    ko: { guide:'안내', pick:'이벤트', home:'홈', players:'플레이', survey:'설문' },
    en: { guide:'Guide', pick:'Pick', home:'Home', players:'Play', survey:'Survey' },
  },

  /* ---------- 선수 명단 ---------- */
  PLAYERS: [
    { num:1 , name:'김정호', pos:'OH', birth:'1997-03-01', figure:1 , photo:'images/players/face-1.webp', card:'images/players/card-1.webp', model:'', ability:{atk:84,srv:73,blk:56,dig:71,rcv:77,set:52}, season:{g:14,pts:196,atk:46.3,blk:0.23,ace:0.19,dig:1.71,rcv:32.2} },
    { num:3 , name:'정성현', pos:'L', birth:'1991-05-18', figure:2 , photo:'images/players/face-3.webp', card:'images/players/card-3.webp', model:'', ability:{atk:19,srv:32,blk:10,dig:91,rcv:90,set:66}, season:{g:22,pts:0,atk:null,blk:null,ace:null,dig:2.36,rcv:50.8} },
    { num:4 , name:'배하준', pos:'MB', birth:'2001-07-31', photo:'images/players/face-4.webp', card:'images/players/card-4.webp', model:'', ability:{atk:62,srv:50,blk:66,dig:30,rcv:15,set:30}, season:{g:0} },
    { num:5 , name:'김도훈', pos:'L', birth:'1998-04-19', figure:3 , photo:'images/players/face-5.webp', card:'images/players/card-5.webp', model:'', ability:{atk:21,srv:24,blk:10,dig:85,rcv:85,set:66}, season:{g:12,pts:0,atk:null,blk:null,ace:null,dig:2.67,rcv:46.3} },
    { num:6 , name:'김대환', pos:'S', birth:'2005-05-20', figure:4 , photo:'images/players/face-6.webp', card:'images/players/card-6.webp', model:'', ability:{atk:47,srv:66,blk:65,dig:67,rcv:49,set:84}, season:{g:9,pts:75,atk:38.3,blk:0.23,ace:0.21,dig:1.32,rcv:null} },
    { num:7 , name:'신장호', pos:'OP', birth:'1996-06-01', figure:5 , photo:'images/players/face-7.webp', card:'images/players/card-7.webp', model:'', ability:{atk:83,srv:89,blk:73,dig:51,rcv:37,set:42}, season:{g:13,pts:591,atk:48.8,blk:0.37,ace:0.38,dig:1.05,rcv:null} },
    { num:8 , name:'차지환', pos:'OH', birth:'1996-05-09', figure:6 , photo:'images/players/face-8.webp', card:'images/players/card-8.webp', model:'', ability:{atk:85,srv:72,blk:63,dig:74,rcv:78,set:52}, season:{g:11,pts:208,atk:43.4,blk:0.24,ace:0.17,dig:1.75,rcv:30.7} },
    { num:10, name:'페이즈', pos:'MB', birth:'2001-11-23', figure:7 , photo:'images/players/face-10.webp', card:'images/players/card-10.webp', model:'', ability:{atk:85,srv:73,blk:57,dig:72,rcv:73,set:48}, season:{g:12,pts:292,atk:47.1,blk:0.22,ace:0.19,dig:1.64,rcv:30.1} },
    { num:11, name:'박원빈', pos:'MB', birth:'1992-04-07', figure:8 , photo:'images/players/face-11.webp', card:'images/players/card-11.webp', model:'', ability:{atk:84,srv:64,blk:80,dig:43,rcv:28,set:53}, season:{g:10,pts:241,atk:53.4,blk:0.62,ace:0.11,dig:0.46,rcv:null} },
    { num:12, name:'전광인', pos:'OH', birth:'1991-09-18', figure:9 , photo:'images/players/face-12.webp', card:'images/players/card-12.webp', model:'', ability:{atk:95,srv:88,blk:85,dig:90,rcv:92,set:80}, season:{g:24,pts:230,atk:46.3,blk:0.24,ace:0.16,dig:1.83,rcv:39.5} },
    { num:14, name:'송희채', pos:'OH', birth:'1992-04-29', figure:10, photo:'images/players/face-14.webp', card:'images/players/card-14.webp', model:'', ability:{atk:86,srv:73,blk:57,dig:70,rcv:79,set:55}, season:{g:22,pts:196,atk:53.9,blk:0.23,ace:0.19,dig:1.44,rcv:31.2} },
    { num:15, name:'노재욱', pos:'S', birth:'1992-07-10', figure:11, photo:'images/players/face-15.webp', card:'images/players/card-15.webp', model:'', ability:{atk:47,srv:75,blk:56,dig:65,rcv:50,set:90}, season:{g:23,pts:65,atk:42.7,blk:0.24,ace:0.15,dig:1.32,rcv:null} },
    { num:16, name:'진상헌', pos:'MB', birth:'1986-04-22', figure:12, photo:'images/players/face-16.webp', card:'images/players/card-16.webp', model:'', ability:{atk:84,srv:65,blk:84,dig:50,rcv:25,set:55}, season:{g:18,pts:184,atk:58.0,blk:0.66,ace:0.09,dig:0.43,rcv:null} },
    { num:17, name:'박창성', pos:'MB', birth:'1998-09-21', figure:13, photo:'images/players/face-17.webp', card:'images/players/card-17.webp', model:'', ability:{atk:82,srv:67,blk:80,dig:45,rcv:25,set:47}, season:{g:21,pts:275,atk:55.4,blk:0.56,ace:0.09,dig:0.4,rcv:null} },
    { num:19, name:'진성태', pos:'MB', birth:'1993-02-03', figure:14, photo:'images/players/face-19.webp', card:'images/players/card-19.webp', model:'', ability:{atk:66,srv:52,blk:70,dig:40,rcv:24,set:44}, season:{g:7,pts:273,atk:59.1,blk:0.69,ace:0.11,dig:0.42,rcv:null} },
    { num:20, name:'윤경', pos:'OH', birth:'2006-08-30', photo:'images/players/face-20.webp', card:'images/players/card-20.webp', model:'', ability:{atk:68,srv:60,blk:48,dig:55,rcv:58,set:40}, season:{g:0} },
    { num:21, name:'백창진', pos:'L', birth:'2004-11-14', photo:'images/players/face-21.webp', card:'images/players/card-21.webp', model:'', ability:{atk:10,srv:15,blk:5,dig:62,rcv:60,set:50}, season:{g:0} },
    { num:22, name:'박인우', pos:'S', birth:'2003-02-16', figure:15, photo:'images/players/face-22.webp', card:'images/players/card-22.webp', model:'', ability:{atk:66,srv:60,blk:50,dig:64,rcv:66,set:48}, season:{g:6,pts:239,atk:42.0,blk:0.23,ace:0.16,dig:1.53,rcv:32.1} },
    { num:31, name:'김준호', pos:'OP', birth:'2002-10-04', figure:16, photo:'images/players/face-31.webp', card:'images/players/card-31.webp', model:'', ability:{atk:68,srv:62,blk:52,dig:62,rcv:65,set:50}, season:{g:8,pts:311,atk:42.1,blk:0.2,ace:0.2,dig:1.71,rcv:32.3} },
    { num:40, name:'러셀', pos:'OP', birth:'1993-08-25', figure:17, photo:'images/players/face-40.webp', card:'images/players/card-40.webp', model:'', ability:{atk:99,srv:99,blk:96,dig:85,rcv:37,set:85}, season:{g:24,pts:599,atk:47.6,blk:0.42,ace:0.43,dig:1.08,rcv:null} },
  ],
  MVP_CANDIDATES: null,

  /* ---------- 리그 순위 · 팀 기록 · 경기 결과 ---------- */
  TEAMS: [
    { id:'kal', name:'대한항공',     g:24, w:18, l:6,  pts:52, setRatio:1.92, atk:54.1, blk:2.41, ace:1.38, rcv:41.2 },
    { id:'hc',  name:'현대캐피탈',   g:24, w:17, l:7,  pts:49, setRatio:1.71, atk:53.2, blk:2.55, ace:1.29, rcv:38.9 },
    { id:'ok',  name:'OK저축은행',   g:24, w:15, l:9,  pts:44, setRatio:1.38, atk:52.6, blk:2.37, ace:1.41, rcv:37.6, us:true },
    { id:'kb',  name:'KB손해보험',   g:24, w:12, l:12, pts:35, setRatio:1.04, atk:51.0, blk:2.18, ace:1.22, rcv:36.4 },
    { id:'wc',  name:'우리카드',     g:24, w:9,  l:15, pts:28, setRatio:0.81, atk:49.8, blk:2.09, ace:1.17, rcv:35.1 },
    { id:'ss',  name:'삼성화재',     g:24, w:8,  l:16, pts:24, setRatio:0.69, atk:49.1, blk:2.02, ace:1.08, rcv:34.8 },
    { id:'kp',  name:'한국전력',     g:24, w:5,  l:19, pts:17, setRatio:0.52, atk:47.6, blk:1.94, ace:1.02, rcv:33.0 },
  ],
  RESULTS: [
    { round:'4라운드', date:'', home:'ok', away:'kb',  sets:['25-21','23-25','25-19','25-22'] },
    { round:'4라운드', date:'', home:'kal', away:'wc', sets:['25-20','25-18','25-23'] },
    { round:'4라운드', date:'', home:'hc', away:'ss',  sets:['22-25','25-21','25-17','26-24'] },
    { round:'4라운드', date:'', home:'kp', away:'ok',  sets:['25-23','21-25','19-25','25-22','12-15'] },
    { round:'4라운드', date:'', home:'wc', away:'hc',  sets:['20-25','25-23','22-25','21-25'] },
    { round:'3라운드', date:'', home:'ok', away:'kal', sets:['23-25','25-22','20-25','21-25'] },
    { round:'3라운드', date:'', home:'ss', away:'kb',  sets:['25-22','18-25','25-23','25-21'] },
  ],

  /* ---------- 홈 ---------- */
  ROULETTE: {
    BASE_SPINS: 1,
    MISSION_BONUS: 1,
    ONE_PER_PERSON: true,
    PRIZES: [
      { id:'soju',     img:'soju',     title:'읏맨 변온 소주잔',        desc:'(경품 수령처에서 교환)',            weight:14 },
      { id:'doll',     img:'doll',     title:'25cm 읏맨 봉제인형',      desc:'(경품 수령처에서 교환)',            weight:6 },
      { id:'miss1',    img:'miss',     miss:true,                                                               weight:20 },
      { id:'fan',      img:'fan',      title:'돈바람 부채',             desc:'(경품 수령처에서 교환)',            weight:14 },
      { id:'ticket',   img:'ticket',   title:'일반석 티켓 교환권\n(1인 2매)', desc:'(다음 홈경기 사용 가능)',      weight:10 },
      { id:'photo',    img:'photo',    title:'지정 선수 사진 촬영권\n(1인 1회)', desc:'(평일 홈경기 한정, 직접 방문 수령)', weight:4 },
      { id:'miss2',    img:'miss',     miss:true,                                                               weight:20 },
      { id:'signball', img:'signball', title:'선수 사인 배구공',        desc:'(경품 수령처에서 교환)',            weight:2 },
    ],
    WIN_NOTICES: [
      '<em>당첨 즉시 하단 버튼을 눌러 이미지 저장 또는 캡처해주세요.</em> 교환권은 <em>다음 날 저녁 11시 59분까지 다시 볼 수 있으며, 이후 파기</em>돼요. (교환권 재발행 불가)',
      '경품 수령처에서 직원에게 교환권을 보여주세요. (교환권으로 입장 불가)',
      '<em>교환은 이벤트 기간 중 홈경기가 있는 날에 한해 가능</em>하며, 기간 연장 및 분실 시 재발행이 안 돼요.',
      '중복 수령이 불가하며, 부정 참여 시 당첨이 취소될 수 있어요.',
      '유효기간이 지난 교환권은 사용할 수 없어요.',
      '당첨된 경품의 타인 양도 및 판매는 원칙적으로 금지예요.',
    ],
    VOUCHER_HOURS: 0,
  },
  APP: { title:'OK저축은행 앱 다운로드', desc:'앱에서 더 많은 혜택을 만나보세요.', ios:'', android:'' },
  GOODS: {
    url: '',
    title: '읏맨 공식 굿즈샵',
    desc: '유니폼과 응원 도구를 온라인에서 만나보세요.',
    image: 'images/banners/goods-2026-27.webp',
  },

  SUBWAY: {
    station: '체육공원역',
    scode: '316',
    alertAfter: '22:00',
    lines: [
      { tag:'3호선', dir:'구포 ∙ 연산 ∙ 수영 방면', updown:0, last:'23:41', prev:'대저', next:'강서구청', color:'#2F6FE4' },
      { tag:'3호선', dir:'대저 방면', updown:1, last:'24:36', prev:'강서구청', next:'대저', color:'#E8590C' },
    ]
  }
};

/* ===== 데이터 계층 ===== */
const TEST_MATCH = (new URLSearchParams(location.search).get('match') || '').replace(/[^\w-]/g, '').slice(0, 64);
const MATCH_KEY = TEST_MATCH || CONFIG.MATCH_ID || (()=>{ const t = new Date(); return new Date(t.getTime() - t.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); })();
const STORAGE_KEY = 'wm_guide_v1__' + MATCH_KEY;
const MATCH_REGISTRY_KEY = 'wm_guide_matches_v1';

function loadLocal(){ try{ return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }catch(e){ return {}; } }
function saveLocal(data){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  touchMatchRegistry();
}
let LOCAL = loadLocal();

/* ===== 실시간 서버 연결 ===== */
const LIVE = (function(){
  const base = String(CONFIG.LIVE_API || '').replace(/\/$/, '');
  const demo = !base;
  const DEMO_TOTAL = 'wm_demo_cheer_total__' + MATCH_KEY;
  let device = '';
  try{
    device = localStorage.getItem('wm_device') || '';
    if(!device){
      device = (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2) + Date.now()).replace(/[^\w]/g, '').slice(0, 20);
      localStorage.setItem('wm_device', device);
    }
  }catch(e){ device = 'anon' + Math.floor(Math.random() * 1e9); }

  const L = { state:[], total:[], win:[], optimistic:[], cheerreset:[] };
  const on = (k, f)=> L[k].push(f);
  const emit = (k, v)=> L[k].forEach(f=>{ try{ f(v); }catch(e){ console.error(e); } });
  let state = { events:[], total:0 };

  const NET_LABEL = { cheer:'응원 전송', refresh:'실시간 정보 불러오기', submit:'참여 기록 전송', spin:'룰렛', outbox:'못 보낸 참여 기록 다시 보내기' };
  const NET_LIMIT = { cheer:3, refresh:3, submit:1, spin:1, outbox:3 };
  const netFails = {}, netWaiting = [];
  function netFail(where, detail, httpStatus){
    if(demo) return;
    const n = netFails[where] = (netFails[where] || 0) + 1;
    if(n !== (NET_LIMIT[where] || 1)) return;
    const err = { msg:`[통신] ${NET_LABEL[where] || where} 실패${n > 1 ? ` (${n}회 연속)` : ''} — ${detail}`, src:'api/' + where, line:0 };
    if(httpStatus && window.__reportErr) window.__reportErr(err);
    else if(netWaiting.length < 5) netWaiting.push(err);
  }
  function netOk(where){
    netFails[where] = 0;
    if(netWaiting.length && window.__reportErr) netWaiting.splice(0).forEach(window.__reportErr);
  }
  const errText = e=> String((e && e.message) || e || '알 수 없음').slice(0, 80);

  async function refresh(){
    try{
      if(demo){
        state = { events:(CONFIG.LIVE_DEMO || {}).events || [], total:Number(localStorage.getItem(DEMO_TOTAL)) || 0, phase:'auto', mvp:undefined, start:'' };
      } else {
        const r = await fetch(`${base}/live/${encodeURIComponent(MATCH_KEY)}`);
        if(!r.ok){ const d = await r.json().catch(()=> ({})); netFail('refresh', `HTTP ${r.status}${d.error ? ' ' + d.error : ''}${d.reason ? ' — ' + String(d.reason).slice(0, 120) : ''}`, r.status); return; }
        const d = await r.json();
        netOk('refresh');
        state = { events:d.events || [], total:(d.cheer || {}).total || 0, phase:d.phase || 'auto', mvp:d.mvp || null, start:d.start || '', content:d.content || null, epoch:Number(d.epoch) || 0, opponent:d.opponent || '', home:d.home || null, privacy:d.privacy || null };
      }
      if(!demo && (Number(LOCAL.cheer_order) || 0) > (state.total || 0) && !pending && !sending){
        delete LOCAL.cheer_order; delete LOCAL.cheer_count; delete LOCAL.cheer_wins; saveLocal(LOCAL);
        optimistic = state.total || 0;
        emit('cheerreset', state);
      }
      emit('state', state);
    }catch(e){ netFail('refresh', errText(e)); }
  }

  const BATCH_MS = 1500, FIRST_MS = 350;
  let pending = 0, timer = null, sending = false, lastSent = 0, backoff = 0;
  let optimistic = 0;
  function schedule(){
    if(timer) return;
    const since = Date.now() - lastSent;
    const wait = backoff || (since >= BATCH_MS ? FIRST_MS : BATCH_MS - since);
    timer = setTimeout(flush, wait);
  }
  function tap(n){
    n = n || 1; pending += n;
    optimistic = Math.max(optimistic, Number(LOCAL.cheer_order) || 0) + n;
    emit('optimistic', optimistic);
    schedule();
  }
  async function flush(){
    timer = null;
    if(sending){ schedule(); return; }
    const n = pending;
    if(!n) return;
    pending = 0; sending = true; lastSent = Date.now();
    try{
      let res;
      if(demo){
        const from = (Number(localStorage.getItem(DEMO_TOTAL)) || 0) + 1, to = from + n - 1;
        localStorage.setItem(DEMO_TOTAL, to);
        const won = LOCAL.cheer_wins || [];
        const p = ((CONFIG.LIVE_DEMO || {}).prizes || []).find(p=> p.n >= from && p.n <= to && !won.some(w=> w.n === p.n));
        res = { total:to, from, to, win: p ? { n:p.n, prize:p.prize, place:p.place, code:Math.random().toString(36).slice(2, 6).toUpperCase(), at:Date.now() } : null };
      } else {
        const r = await fetch(`${base}/live/${encodeURIComponent(MATCH_KEY)}/cheer`, {
          method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify({ device, count:n }),
        });
        if(!r.ok){
          const d = await r.json().catch(()=> ({}));
          const err = new Error(`HTTP ${r.status}${d.error ? ' ' + d.error : ''}${d.reason ? ' — ' + String(d.reason).slice(0, 120) : ''}`); err.status = r.status; throw err;
        }
        res = await r.json();
        netOk('cheer');
      }
      backoff = 0;
      if(res && res.total){ state.total = res.total; optimistic = Math.max(optimistic, res.to || 0); emit('total', res); }
      if(res && res.win){
        LOCAL.cheer_wins = [...(LOCAL.cheer_wins || []), res.win]; saveLocal(LOCAL);
        emit('win', res.win);
      }
    }catch(e){
      pending += n;
      netFail('cheer', errText(e), e && e.status);
      backoff = Math.min(8000, backoff ? backoff * 2 : 1000) + Math.random() * 400;
    }
    finally{
      sending = false;
      if(pending) schedule();
    }
  }
  document.addEventListener('visibilitychange', ()=>{ if(document.hidden && pending && !demo){
    try{ navigator.sendBeacon(`${base}/live/${encodeURIComponent(MATCH_KEY)}/cheer`, new Blob([JSON.stringify({ device, count:pending })], { type:'text/plain' })); pending = 0; }catch(e){}
  }});

  const OUTBOX = 'wm_outbox__' + MATCH_KEY;
  const readBox = ()=>{ try{ return JSON.parse(localStorage.getItem(OUTBOX)) || {}; }catch(e){ return {}; } };
  const writeBox = b=>{ try{ Object.keys(b).length ? localStorage.setItem(OUTBOX, JSON.stringify(b)) : localStorage.removeItem(OUTBOX); }catch(e){} };
  async function post(type, data){
    const r = await fetch(`${base}/live/${encodeURIComponent(MATCH_KEY)}/submit/${type}`, {
      method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify({ device, data }),
    });
    const d = await r.json().catch(()=> ({}));
    return r.ok ? { ok:true, ...d } : { ok:false, error:d.error || 'http_' + r.status, status:r.status };
  }
  async function submit(type, data, opts){
    if(demo) return { ok:true };
    const queue = !opts || opts.queue !== false;
    let res;
    try{ res = await post(type, data); }catch(e){ res = { ok:false, error:'network', detail:errText(e) }; }
    if(res.ok) netOk('submit');
    else if(res.error === 'network' || !res.status || res.status >= 500 || [400, 404, 405, 429].includes(res.status)) netFail('submit', `${type} · ${res.status ? 'HTTP ' + res.status + ' ' : ''}${res.error}${res.detail ? ' (' + res.detail + ')' : ''}`, res.status);
    const retry = !res.ok && (res.error === 'network' || res.error === 'busy' || res.status >= 500 || res.status === 429);
    const b = readBox();
    if(res.ok){ if(b[type]){ delete b[type]; writeBox(b); } }
    else if(retry && queue){ b[type] = { data, t:Date.now() }; writeBox(b); res.queued = true; }
    return res;
  }
  let flushing = false;
  async function flushOutbox(){
    if(demo || flushing || (navigator.onLine === false)) return;
    const b = readBox(); const types = Object.keys(b); if(!types.length) return;
    flushing = true;
    try{
      for(const type of types){
        let res; try{ res = await post(type, b[type].data); }catch(e){ res = { ok:false, error:'network' }; }
        if(res.ok) netOk('outbox'); else netFail('outbox', `${type} · ${res.status ? 'HTTP ' + res.status : res.error}`, res.status);
        const cur = readBox();
        if(res.ok || (res.status && res.status < 500 && res.status !== 429)){ if(cur[type] && cur[type].t === b[type].t){ delete cur[type]; writeBox(cur); } }
        else break;
      }
    } finally { flushing = false; }
  }
  setTimeout(flushOutbox, 5000);
  setInterval(flushOutbox, 15000);
  window.addEventListener('online', ()=> setTimeout(flushOutbox, 800));

  async function checkin(ans){ return submit('checkin', ans); }

  function beacon(type, data){
    if(demo) return;
    try{ navigator.sendBeacon(`${base}/live/${encodeURIComponent(MATCH_KEY)}/submit/${type}`, new Blob([JSON.stringify({ device, data })], { type:'text/plain' })); }catch(e){}
  }

  async function spin(bonus){
    try{
      const r = await fetch(`${base}/live/${encodeURIComponent(MATCH_KEY)}/spin`, {
        method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify({ device, bonus:!!bonus }),
      });
      const d = await r.json().catch(()=> ({}));
      if(r.ok) netOk('spin');
      else if(d.error !== 'no_spins') netFail('spin', `HTTP ${r.status} ${d.error || ''}`.trim(), r.status);
      return r.ok ? d : { ok:false, error:d.error || 'http_' + r.status };
    }catch(e){ netFail('spin', errText(e)); return { ok:false, error:'network' }; }
  }

  (function visit(){
    if(demo) return;
    const KEY = 'wm_visit__' + MATCH_KEY;
    try{ if(sessionStorage.getItem(KEY)) return; }catch(e){}
    setTimeout(async ()=>{
      try{
        const r = await fetch(`${base}/live/${encodeURIComponent(MATCH_KEY)}/visit`, {
          method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify({ device }),
        });
        if(r.ok) try{ sessionStorage.setItem(KEY, '1'); }catch(e){}
      }catch(e){}
    }, Math.random() * 4000);
  })();

  setTimeout(refresh, 0);
  (function loop(){ setTimeout(()=>{ if(!document.hidden) refresh(); loop(); }, demo ? 60000 : 20000 + Math.random() * 10000); })();
  document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) refresh(); });
  async function nickCheck(name){
    if(demo) return { available:null };
    try{
      const r = await fetch(`${base}/live/${encodeURIComponent(MATCH_KEY)}/nick?name=${encodeURIComponent(name)}`);
      if(!r.ok) return { available:null };
      const d = await r.json();
      return { available: typeof d.available === 'boolean' ? d.available : null, error:d.error || '' };
    }catch(e){ return { available:null }; }
  }

  const tapBuf = {}; let tapTimer = null;
  const TAP_KEY = /^(checkin|seat_guide|seat_view|games|predict|mvp|survey|card:\d{1,3})$/;
  function count(key){
    if(demo || !TAP_KEY.test(key)) return;
    tapBuf[key] = (tapBuf[key] || 0) + 1;
    if(!tapTimer) tapTimer = setTimeout(()=> flushTaps(false), 10000);
  }
  function flushTaps(leaving){
    clearTimeout(tapTimer); tapTimer = null;
    const keys = Object.keys(tapBuf); if(!keys.length) return;
    const taps = {}; keys.forEach(k=>{ taps[k] = Math.min(50, tapBuf[k]); delete tapBuf[k]; });
    const url = `${base}/tap/${encodeURIComponent(MATCH_KEY)}`, body = JSON.stringify({ device, taps });
    try{
      if(leaving && navigator.sendBeacon) navigator.sendBeacon(url, new Blob([body], { type:'text/plain' }));
      else fetch(url, { method:'POST', headers:{ 'Content-Type':'application/json' }, body, keepalive:true }).catch(()=>{});
    }catch(e){}
  }
  document.addEventListener('visibilitychange', ()=>{ if(document.hidden) flushTaps(true); });
  addEventListener('pagehide', ()=> flushTaps(true));

  const sentErr = new Set();
  window.__reportErr = o=>{
    if(demo || !o || !o.msg || o.msg === 'Script error.' || sentErr.size >= 5) return;
    const k = o.msg + '|' + o.line; if(sentErr.has(k)) return; sentErr.add(k);
    const view = (document.querySelector('.view.active') || {}).id || '';
    try{
      navigator.sendBeacon(`${base}/live/${encodeURIComponent(MATCH_KEY)}/error`, new Blob([JSON.stringify({
        device, msg:String(o.msg).slice(0, 300), src:String(o.src || '').replace(/[?#].*$/, '').slice(-200), line:o.line || 0,
        view:view.replace('view-', ''), ua:navigator.userAgent.slice(0, 160) })], { type:'text/plain' }));
    }catch(e){}
  };
  (window.__errQ || []).splice(0).forEach(window.__reportErr);

  return { on, tap, count, checkin, submit, refresh, nickCheck, spin, beacon, flushOutbox, get state(){ return state; }, get device(){ return device; }, demo };
})();

function touchMatchRegistry(){
  try{
    const reg = JSON.parse(localStorage.getItem(MATCH_REGISTRY_KEY)) || {};
    reg[MATCH_KEY] = {
      id: MATCH_KEY,
      label: `${CONFIG.MATCH.home} vs ${CONFIG.MATCH.away}` + (CONFIG.MATCH.date ? ` · ${CONFIG.MATCH.date}` : ` · ${MATCH_KEY}`),
      updatedAt: Date.now()
    };
    localStorage.setItem(MATCH_REGISTRY_KEY, JSON.stringify(reg));
  }catch(e){}
}
touchMatchRegistry();

/* ===== 관리자 콘텐츠 ===== */
const CONTENT = (function(){
  const KEY = 'wm_content__' + MATCH_KEY;
  const DEF = {
    predict: JSON.parse(JSON.stringify(CONFIG.PREDICT_EVENTS)),
    survey: JSON.parse(JSON.stringify(CONFIG.SURVEY_QUESTIONS)),
  };
  let cur = null, sig = '';
  try{ cur = JSON.parse(localStorage.getItem(KEY)) || null; sig = JSON.stringify(cur); }catch(e){}
  const swap = (arr, next)=> arr.splice(0, arr.length, ...next);
  function toConfig(c){
    c = c || {};
    const pq = Array.isArray(c.predict) && c.predict.length ? c.predict.map((x, i)=> ({
      id: x.id || 'q' + (i + 1), q: x.q, type: x.type === 'player' ? 'player' : undefined,
      options: x.type === 'player' ? undefined : (x.options || []).filter(Boolean),
      candidates: x.candidates || null, pool: x.pool === 'all' ? 'all' : undefined, ai: x.ai !== false, aiKind: x.aiKind || undefined,
    })).filter(x=> x.q && (x.type === 'player' || x.options.length >= 2)) : null;
    swap(CONFIG.PREDICT_EVENTS, pq && pq.length ? pq : DEF.predict);
    const sq = Array.isArray(c.survey) && c.survey.length
      ? c.survey.map((x, i)=> ({ ...x, id:x.id || String(i + 1), type:x.type || 'single', options:x.options ? x.options.filter(Boolean) : x.options }))
          .filter(x=> x.q && (x.type === 'nps' || (x.type === 'grid' ? (x.rows || []).length && (x.cols || []).length >= 2 : (x.options || []).length >= 2))).slice(0, 25) : null;
    swap(CONFIG.SURVEY_QUESTIONS, sq && sq.length ? sq : DEF.survey);
  }
  toConfig(cur);
  const hooks = [];
  LIVE.on('state', st=>{
    if(!('content' in st)) return;
    const next = st.content || null, s2 = JSON.stringify(next);
    if(s2 === sig) return;
    sig = s2; cur = next;
    try{ next ? localStorage.setItem(KEY, s2) : localStorage.removeItem(KEY); }catch(e){}
    toConfig(cur);
    hooks.forEach(f=>{ try{ f(cur || {}); }catch(e){ console.error(e); } });
  });
  const ver = k => { const c = cur || {}; return Array.isArray(c[k]) && c[k].length && c[k + 'Ver'] ? Number(c[k + 'Ver'].v) || 0 : 0; };
  return { get:()=> cur || {}, onChange:f=> hooks.push(f), ver };
})();

(function initPrivacy(){
  const pop = document.getElementById('privacy');
  const open = ()=>{ pop.classList.add('show'); document.documentElement.style.overflow = 'hidden'; };
  const close = ()=>{ pop.classList.remove('show'); document.documentElement.style.overflow = ''; };
  document.addEventListener('click', e=>{ if(e.target.closest('[data-privacy]')){ e.preventDefault(); e.stopPropagation(); hapticTick && hapticTick(); open(); } }, true);
  document.getElementById('pv-close').addEventListener('click', close);
  if(CONFIG.SEAT_OCR_API || CONFIG.LIVE_API) document.getElementById('pv-photo').textContent = '티켓 사진은 좌석 번호를 읽는 데만 서버로 보내고 저장하지 않아요';
  pop.addEventListener('click', e=>{ if(e.target === pop) close(); });
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && pop.classList.contains('show')) close(); });
  let sig = '';
  LIVE.on('state', st=>{
    const p = st.privacy || {}; const x = JSON.stringify(p); if(x === sig) return; sig = x;
    if(p.retention) document.getElementById('pv-retention').textContent = p.retention;
    const ex = document.getElementById('pv-extra'); ex.textContent = p.extra || ''; ex.hidden = !p.extra;
  });
})();

LIVE.on('state', st=>{
  const opp = (st.opponent || '').trim();
  if(opp === (window.__adminOpponent || '')) return;
  window.__adminOpponent = opp;
  if(opp){ const el = document.getElementById('mb-away'); if(el) el.textContent = opp; }
  window.__aiPredictRefresh && window.__aiPredictRefresh();
});

LIVE.on('state', st=>{
  if(!st.epoch) return;
  const K = 'wm_epoch__' + MATCH_KEY;
  let prev = 0; try{ prev = Number(localStorage.getItem(K)) || 0; }catch(e){}
  if(prev === st.epoch) return;
  try{ localStorage.setItem(K, String(st.epoch)); }catch(e){}
  if(!prev && !Object.keys(LOCAL).length) return;
  try{
    [STORAGE_KEY, 'wm_content__' + MATCH_KEY, 'wm_demo_cheer_total__' + MATCH_KEY].forEach(k=> localStorage.removeItem(k));
    sessionStorage.removeItem('wm_visit__' + MATCH_KEY);
  }catch(e){}
  LOCAL = {};
  location.reload();
});

const INTRO_CARDS = { dir:'images/players/', from:1, to:40 };
(function introCards(){
  if(!document.getElementById('splash')) return;
  const tryLoad = src => new Promise(res=>{ const im = new Image(); let done = false;
    const end = ok=>{ if(!done){ done = true; res(ok ? src : ''); } };
    im.onload = ()=> end(true); im.onerror = ()=> end(false); im.src = src; setTimeout(()=> end(false), 1500); });
  async function pickTwo(){
    const nums = PLAYERS.filter(p=> p.card).map(p=> p.num);
    for(let i = nums.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [nums[i], nums[j]] = [nums[j], nums[i]]; }
    const got = [];
    const t0 = performance.now();
    for(let i = 0; i < nums.length && got.length < 2 && performance.now() - t0 < 2500; i += 4){
      const batch = nums.slice(i, i + 4);
      const srcs = await Promise.all(batch.map(n=> tryLoad((playerByNum(n) || {}).card || `${INTRO_CARDS.dir}card-${n}.webp`)));
      batch.forEach((n, k)=>{ if(srcs[k] && got.length < 2) got.push({ n, src:srcs[k] }); });
    }
    return got;
  }
  async function go(){
    window.__introStarted = true;
    const cards = await pickTwo();
    if(cards.length < 2){ window.__introStarted = false; return; }
    const two = cards.map(({ n, src })=>{
      const p = playerByNum(n);
      return { num:n, name: p ? playerName(p) : '', pos: p ? ((POS[p.pos] || {}).ko || p.pos) : 'OK저축은행 읏맨', src };
    });
    const wait = 1100 - (performance.now() - (window.__splashT0 || 0));
    if(wait > 0) await new Promise(r=> setTimeout(r, wait));
    const date = (document.getElementById('mb-date') || {}).textContent || '';
    window.__runIntro && window.__runIntro(two, { date: /입력 필요/.test(date) ? '' : date });
  }
  setTimeout(go, 0);
})();

async function postData(path, body){
  if(CONFIG.DATA_MODE === 'api'){
    const res = await fetch(`${CONFIG.API_BASE}/matches/${MATCH_KEY}/${path}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) });
    return res.json();
  }
  LOCAL[path] = body; saveLocal(LOCAL); return body;
}

// 이미지 저장 — iOS는 공유 시트(이미지 저장), 안드로이드는 바로 다운로드,
// 카카오톡 · 네이버 같은 앱 안 브라우저는 다운로드가 막혀서 이미지를 띄우고 '길게 눌러 저장'을 안내해요
const UA = navigator.userAgent || '';
const IS_IOS = /iPhone|iPad|iPod/i.test(UA) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const IN_APP = /KAKAOTALK|NAVER\(inapp|Instagram|FBAN|FBAV|Line\/|DaumApps|everytimeApp|; wv\)/i.test(UA);
function showSaveSheet(blob, title){
  let sh = document.getElementById('save-sheet');
  if(!sh){
    sh = document.createElement('div'); sh.id = 'save-sheet'; sh.className = 'save-sheet'; sh.setAttribute('role', 'dialog'); sh.setAttribute('aria-modal', 'true');
    sh.innerHTML = `<div class="save-sheet__box"><p class="save-sheet__t"></p><img class="save-sheet__img" alt=""><p class="save-sheet__d">이미지를 <b>길게 눌러</b> ‘이미지 저장’을 선택해주세요</p><button type="button" class="btn full save-sheet__close">닫기</button></div>`;
    document.body.appendChild(sh);
    sh.addEventListener('click', e=>{ if(e.target === sh || e.target.closest('.save-sheet__close')) sh.classList.remove('show'); });
  }
  sh.querySelector('.save-sheet__t').textContent = title || '이미지 저장';
  const img = sh.querySelector('.save-sheet__img');
  const r = new FileReader(); r.onload = ()=>{ img.src = r.result; }; r.readAsDataURL(blob);   // data 주소라 길게 눌러 저장이 돼요
  sh.classList.add('show');
}
async function saveImage(blob, fname, title){
  if(!blob) return;
  if(IN_APP){ showSaveSheet(blob, title); return; }
  const file = new File([blob], fname, { type:'image/png' });
  if(IS_IOS && navigator.canShare && navigator.canShare({ files:[file] })){
    try{ await navigator.share({ files:[file], title }); return; }
    catch(err){ if(err && err.name === 'AbortError') return; }
  }
  try{
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = fname;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=> URL.revokeObjectURL(a.href), 4000);
  }catch(err){ showSaveSheet(blob, title); }
}

// 진동 — 사용자가 화면을 한 번이라도 누른 뒤에만 (그 전엔 브라우저가 막고 콘솔에 오류를 남겨요)
function canVibrate(){ return !!navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive); }
function hapticTick(){ if(canVibrate()) navigator.vibrate(8); }

/* ===== 경품 응모 ===== */
const RAFFLE_KEY = 'raffle_nick';
function hasEnteredRaffle(){ return !!(LOCAL[RAFFLE_KEY] && LOCAL[RAFFLE_KEY].nickname); }

function escHtml(v){ return String(v ?? '').replace(/[&<>"']/g, c=> ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }

/* ===== 선수 데이터 헬퍼 ===== */
const POS = {
  OH:{ ko:'아웃사이드 히터', chip:'아웃사이드' },
  OP:{ ko:'아포짓',          chip:'아포짓' },
  MB:{ ko:'미들 블로커',     chip:'미들 블로커' },
  S: { ko:'세터',            chip:'세터' },
  L: { ko:'리베로',          chip:'리베로' },
};
const OVR_WEIGHTS = {
  OH:{ atk:.30, srv:.15, blk:.10, dig:.15, rcv:.25, set:.05 },
  OP:{ atk:.45, srv:.20, blk:.20, dig:.10, rcv:0,   set:.05 },
  MB:{ atk:.30, srv:.10, blk:.45, dig:.05, rcv:0,   set:.10 },
  S: { atk:.05, srv:.15, blk:.10, dig:.15, rcv:.05, set:.50 },
  L: { atk:0,   srv:0,   blk:0,   dig:.45, rcv:.45, set:.10 },
};
const PLAYERS = CONFIG.PLAYERS;
function isDefenseQ(ev){ return !!ev && (ev.aiKind === 'dig' || /디그|수비|리시브/.test(String(ev.q || '').replace(/\s/g, ''))); }

const FIGURE_URLS = SPLASH_CHARACTERS;
function figureSrc(p){ return Number.isInteger(p.figure) && FIGURE_URLS[p.figure] ? FIGURE_URLS[p.figure] : ''; }
function cardSrc(p){ return p.card || figureSrc(p) || p.photo || ''; }
function tierOf(p){
  const o = playerOvrToday(p);
  if(typeof o !== 'number') return CONFIG.TIERS[CONFIG.TIERS.length - 1];
  return CONFIG.TIERS.find(t=> o >= t.min) || CONFIG.TIERS[CONFIG.TIERS.length - 1];
}
function playerTier(p){ return tierOf(p).key; }
function isRare(p){
  if(typeof p.rare === 'boolean') return p.rare;
  const maxG = Math.max(0, ...PLAYERS.map(x=> (x.season && x.season.g) || 0));
  return !!maxG && ((p.season && p.season.g) || 0) >= maxG * (CONFIG.RARE_RATIO || 0.7);
}
function isMvpCard(p){
  const m = CONFIG.MVP_CARD || {};
  if(m.num == null || String(m.num) !== String(p.num)) return false;
  return !m.until || new Date() <= new Date(m.until + 'T23:59:59');
}
function playerName(p){ return p.name || `${p.num}번 선수`; }
function playerByNum(num){ return PLAYERS.find(p=> String(p.num) === String(num)); }
function playerOvr(p){
  if(p.noRecord && !Object.keys(p.ability || {}).length) return OVR_MIN;
  const w = OVR_WEIGHTS[p.pos] || OVR_WEIGHTS.OH; const a = p.ability || {};
  return Math.max(OVR_MIN, Math.round(Object.keys(w).reduce((s, k)=> s + (a[k] || 0) * w[k], 0)));
}
const OVR_MIN = 60;
/* ===== 시즌 초반 능력치 보정 ===== */
const FULL_SETS = 30;
function seasonSets(season, sets){
  if(sets != null && Number.isFinite(+sets)) return +sets;   // 기록 서버의 출전 세트 수
  const s = season || {};
  if(s.sets != null && Number.isFinite(+s.sets)) return +s.sets;
  return (+s.g || 0) * 3.5;
}
function blendAbility(base, live, season, sets){
  const w = Math.max(0, Math.min(1, seasonSets(season, sets) / FULL_SETS));
  const out = {};
  for(const k of ['atk', 'srv', 'blk', 'dig', 'rcv', 'set']){
    const b = base && base[k] != null ? +base[k] : null, l = live && live[k] != null ? +live[k] : null;
    out[k] = l == null ? b : b == null ? l : Math.round(l * w + b * (1 - w));
  }
  return out;
}
/* ===== 오늘의 운세 ===== */
const FORTUNE = (function(){
  const ZODIAC = [[1,20,'물병자리'],[2,19,'물고기자리'],[3,21,'양자리'],[4,20,'황소자리'],[5,21,'쌍둥이자리'],[6,22,'게자리'],
                  [7,23,'사자자리'],[8,23,'처녀자리'],[9,23,'천칭자리'],[10,23,'전갈자리'],[11,22,'사수자리'],[12,22,'염소자리']];
  const ANIMALS = ['원숭이','닭','개','돼지','쥐','소','호랑이','토끼','용','뱀','말','양'];
  /* ---------- 운세 문장 목록 ---------- */
  const VIBES = {
    top:[
      '하늘이 돕는 날! 뭘 해도 술술 풀리는 기분이에요.',
      '오늘은 주인공 기운이 가득해요. 어깨 쫙 펴고 다녀도 좋아요.',
      '웃을 일이 줄줄이 기다리는 날. 표정 관리는 미리 연습해 두세요.',
      '오늘 운세 그래프는 위로만 쭉쭉! 자신감 풀충전 상태예요.',
      '행운의 여신이 오늘따라 이쪽만 쳐다보고 있어요.',
      '바라던 일이 생각보다 빨리 이뤄질 수 있는 날이에요.',
      '기분이 붕 떠오르는 하루. 신나는 일 하나쯤은 꼭 생겨요.',
      '오늘만큼은 뭘 골라도 정답! 직감을 믿어 보세요.',
      '주변에서 "오늘 무슨 좋은 일 있어?" 소리를 들을지도 몰라요.',
      '반짝반짝 빛나는 날. 거울 볼 때마다 기분이 좋아질 거예요.',
      '오늘은 운이 먼저 마중 나오는 날이에요.',
      '하루 종일 콧노래가 절로 나올 것 같은 날!',
      '오늘은 작은 소원 하나쯤 이뤄질 것 같은 기분이에요.',
      '좋은 소식이 연달아 들려오는 행운의 날이에요.',
      '무엇을 시작해도 첫 단추가 예쁘게 끼워지는 날이에요.' ],
    good:[
      '기분 좋은 일이 하나둘 생기는 날이에요.',
      '작은 행운이 꼬리에 꼬리를 무는 하루예요.',
      '말 한마디로 분위기 메이커가 될 수 있는 날이에요.',
      '느낌이 좋은 날! 미뤄 둔 일을 시작하기 딱이에요.',
      '오늘은 타이밍 운이 좋아요. 신호등도 초록불로 맞춰 줄지도?',
      '은근히 운이 따라 주는 날. 소소한 행운을 놓치지 마세요.',
      '웃는 얼굴에 복이 굴러오는 하루예요.',
      '하루가 생각보다 매끄럽게 흘러가요.',
      '칭찬받을 일이 생길 것 같은 예감이에요.',
      '마음먹은 대로 착착 풀리는 날이에요.',
      '오늘은 기다리던 소식이 들려올 수도 있어요.',
      '평소보다 한 뼘 더 즐거운 하루가 될 거예요.',
      '오늘은 뭔가 잘 풀릴 것 같은 예감이 맞아떨어지는 날이에요.',
      '기분 좋은 우연이 하나쯤 찾아오는 날이에요.',
      '마음이 가벼워서 발걸음까지 경쾌한 하루예요.' ],
    fine:[
      '평범한 듯 소소한 재미가 숨어 있는 날이에요.',
      '천천히 가도 괜찮아요. 오후로 갈수록 운이 좋아져요.',
      '오늘은 웃음이 보약! 많이 웃을수록 운이 올라가요.',
      '무난하게 흘러가지만 작은 서프라이즈가 하나 숨어 있어요.',
      '잔잔한 하루. 그래서 더 편안하고 좋아요.',
      '예상 못 한 곳에서 피식 웃게 될 일이 생겨요.',
      '오늘은 꾸준함이 행운을 부르는 날이에요.',
      '조금만 여유를 가지면 하루가 훨씬 즐거워져요.',
      '기대 안 한 곳에서 작은 기쁨을 만나요.',
      '마음 편히 즐기면 운도 따라오는 날이에요.',
      '오늘은 익숙한 것들 속에서 반짝이는 순간을 찾게 돼요.',
      '해야 할 일을 하나씩 해내는 뿌듯함이 있는 날이에요.',
      '소소하지만 확실한 행복이 곳곳에 숨어 있어요.',
      '오늘은 천천히 걸을수록 좋은 게 많이 보여요.',
      '평온한 하루 속 작은 웃음이 큰 힘이 돼요.' ],
    calm:[
      '오늘은 쉬엄쉬엄, 나를 아껴 주는 날이에요.',
      '조용히 충전하기 좋은 하루. 맛있는 걸로 기분 업!',
      '무리하지 않아도 괜찮아요. 내일의 행운을 모으는 중이에요.',
      '오늘은 느긋하게! 서두르지 않는 게 최고의 전략이에요.',
      '천천히 숨 고르는 날. 작은 휴식이 큰 힘이 돼요.',
      '운이 잠깐 낮잠 자는 날. 대신 마음은 편안해요.',
      '기대를 살짝 내려놓으면 오히려 좋은 일이 찾아와요.',
      '쉬어 가도 괜찮은 날. 좋아하는 간식 하나 챙겨요.',
      '조용한 하루가 내일의 반짝임을 준비하고 있어요.',
      '오늘은 평소 루틴대로! 익숙한 게 가장 든든해요.',
      '마음을 비우면 오히려 채워지는 게 많은 날이에요.',
      '오늘은 일찍 쉬는 게 내일의 행운을 키워요.',
      '따뜻한 차 한 잔처럼 잔잔하게 흘러가는 하루예요.',
      '조급함은 내려놓고, 좋아하는 것 하나에 집중해 봐요.',
      '오늘의 쉼표가 내일의 느낌표가 돼요.' ],
  };
  const TIPS = [
    '점심 메뉴는 제일 먼저 떠오른 걸로 고르면 성공이에요.', '좋아하는 노래 한 곡이 기분을 확 끌어올려 줘요.',
    '오늘 찍는 사진은 인생샷이 나올 확률이 높아요.', '오랜만에 친구에게 안부를 물으면 반가운 소식이 들려요.',
    '평소보다 물 한 잔 더! 몸도 마음도 가벼워져요.', '큰 소리로 한 번 웃으면 하루가 술술 풀려요.',
    '주황색 물건을 하나 챙기면 운이 두 배가 돼요.', '오늘은 엘리베이터보다 계단이 행운을 불러와요.',
    '잠깐 하늘을 올려다보면 기분이 맑아져요.', '새로운 길로 돌아가 보면 작은 발견이 있어요.',
    '처음 마주친 사람에게 웃어 주면 좋은 일이 생겨요.', '미뤄 둔 정리를 5분만 해 보세요. 마음까지 개운해져요.',
    '단 음식 한 입이 오늘의 비타민이에요.', '휴대폰은 잠시 내려놓고 주변을 둘러보세요. 재밌는 게 보여요.',
    '좋아하는 사람에게 칭찬 한마디 건네 보세요.', '신발 끈을 단단히! 오늘은 발걸음이 행운을 불러요.',
    '창문을 열고 바람 한 번 쐬면 기분 전환 완료.', '오늘 떠오른 아이디어는 꼭 메모해 두세요.',
    '기지개 한 번 쭉! 몸이 가벼우면 운도 가벼워요.', '즐겨 찾던 가게에 가면 반가운 일이 생겨요.',
    '오늘은 "좋아요!"라고 먼저 말하는 사람이 이겨요.', '사진첩 속 옛날 사진이 웃음을 줄 거예요.',
    '따뜻한 음료 한 잔이 행운의 시작이에요.', '오늘은 가방을 가볍게! 마음도 가벼워져요.',
    '모르는 노래를 하나 들어 보면 새 최애곡이 될지도 몰라요.', '응원하는 마음을 크게 표현할수록 기운이 돌아와요.',
    '평소 안 먹던 메뉴에 도전하면 의외의 맛집을 만나요.', '잠들기 전 오늘 좋았던 일 하나를 떠올려 보세요.',
    '오늘은 오른쪽부터 시작하면 일이 순조로워요.', '좋아하는 향을 맡으면 기분이 한층 좋아져요.',
  ];
  const MONEY = {
    high:[
      '재물운도 반짝! 깜짝 선물이나 뜻밖의 득템이 있을지도 몰라요.', '지갑이 두둑해지는 기운이 있어요. OK! 오늘은 저축하기 딱 좋은 날.',
      '주머니 속에서 잊고 있던 돈을 발견할 것 같은 예감!', '오늘 산 물건은 오래오래 효자템이 될 거예요.',
      '금전운이 쨍하게 맑아요. 꾸준한 저축이 더 빛나는 날이에요.', '이벤트나 경품 운이 좋은 날! 응모할 게 있다면 오늘이에요.',
      '생각지도 못한 쿠폰이나 할인이 찾아와요.', '돈이 들어오는 문이 활짝 열린 날이에요.',
      '아끼는 만큼 행운이 쌓여요. 저금통이 웃는 날!', '득템 레이더 작동 중! 마음에 드는 물건이 착한 가격으로 보일 거예요.',
      '오늘은 작은 투자보다 큰 저축! 통장이 웃는 날이에요.', '뜻밖의 보너스 같은 일이 생길지도 몰라요.',
      '공짜 행운이 굴러들어오는 날! 시식 코너도 놓치지 마세요.', '오늘은 선물을 받을 운이 강해요.', '아껴 둔 돈이 빛을 보는 날이에요.' ],
    mid:[
      '재물운은 무난해요. 계획에 없던 지출만 살짝 조심!', '소소한 득템 운이 있어요. 숨은 쿠폰을 잘 챙겨 보세요.',
      '돈 쓸 일과 아낄 일이 반반인 날. 균형만 잘 잡으면 OK!', '오늘은 필요한 것만 사면 만족도 최고예요.',
      '작은 할인에도 기분이 좋아지는 날이에요.', '지갑 사정은 평온해요. 마음 편히 하루를 즐기세요.',
      '가계부 쓰기 좋은 날! 숫자가 예쁘게 맞아떨어져요.', '친구에게 한턱 쏘면 더 큰 기쁨으로 돌아와요.',
      '오늘의 소비는 경험에 쓰면 후회가 없어요.', '모으는 재미가 쏠쏠한 날. 쌓인 포인트를 확인해 보세요.',
      '오늘은 가성비보다 가심비! 작은 사치가 행복을 줘요.', '지갑을 열기 전 한 번만 더 생각하면 완벽해요.',
      '용돈 기입장이 생각보다 훈훈한 날이에요.', '오늘은 나눠 먹는 간식이 더 맛있어요.', '살까 말까 할 땐 하루만 미뤄 봐요.' ],
    low:[
      '재물운은 잠시 쉬어 가요. 충동구매는 내일로 미뤄 두세요.', '오늘은 지갑을 꼭 닫아 두는 게 행운이에요.',
      '장바구니에 담아 두기만 하고 결제는 내일 하기!', '오늘은 아끼는 게 버는 거예요.',
      '소비 요정이 유혹하는 날. 단호하게 거절해 보세요.', '지갑보다 마음을 채우는 하루로 만들어 봐요.',
      '공짜로 즐길 수 있는 것에서 행복을 찾아보세요.', '큰 지출은 잠깐 보류! 내일 다시 생각해도 늦지 않아요.',
      '영수증은 꼼꼼히 확인! 작은 실수를 막아 줘요.', '오늘의 저축은 미래의 나에게 주는 선물이에요.',
      '지갑 대신 마음의 여유를 두둑하게 채워 봐요.', '오늘은 무지출 챌린지 도전하기 딱 좋은 날!',
      '할인 문구에 흔들리지 않기! 오늘의 미션이에요.', '작은 동전도 모이면 큰 행운이 돼요.', '오늘은 쓰는 재미보다 모으는 재미를 느껴 봐요.' ],
  };
  const PEOPLE = {
    high:[
      '인연운이 활짝! 반가운 얼굴을 우연히 마주칠지도 몰라요.', '마음이 콩닥콩닥, 기분 좋은 연락이 올 수 있는 날이에요.',
      '오늘은 말하는 것마다 호감도 상승!', '새로운 사람과 금방 친해질 수 있는 날이에요.',
      '오랜 친구와 웃음이 끊이지 않는 하루가 될 거예요.', '내 편이 되어 줄 사람이 생각보다 가까이 있어요.',
      '누군가 나를 떠올리며 웃고 있을지도 몰라요.', '오늘 만난 사람과 의외의 공통점을 발견해요.',
      '주변에 좋은 기운이 몰리는 날. 사람 복이 터져요!', '고맙다는 말을 많이 듣게 되는 날이에요.',
      '반가운 사람이 먼저 손을 내밀어 줄 것 같아요.', '오늘은 대화마다 웃음꽃이 피어요.',
      '좋은 사람들 사이에서 에너지가 충전되는 날이에요.', '한 번 본 사람과도 오래 본 사이처럼 편해져요.', '내 이야기에 귀 기울여 주는 사람이 있어요.' ],
    mid:[
      '주변 사람들과 케미가 좋은 날. 먼저 인사하면 운이 두 배!', '따뜻한 말 한마디가 좋은 인연을 불러와요.',
      '가족과의 대화에서 힘을 얻는 날이에요.', '단톡방이 유난히 시끌벅적할 것 같아요.',
      '오늘은 들어 주는 사람이 되면 사이가 더 깊어져요.', '오랜만에 연락 온 사람이 반가운 소식을 줄지도 몰라요.',
      '함께 밥 먹는 사람과 더 가까워지는 날이에요.', '작은 배려가 큰 감동으로 돌아와요.',
      '옆 사람과 하이파이브 한 번이면 둘 다 운이 올라가요.', '웃음 코드가 맞는 사람을 만나는 날이에요.',
      '오늘은 같이 걷는 사람이 행운을 나눠 줘요.', '함께 응원하는 사람들과 마음이 통하는 날이에요.',
      '안부 인사 하나가 하루를 따뜻하게 만들어요.', '소소한 수다가 큰 위로가 되는 날이에요.', '오늘은 칭찬을 주고받기 좋은 날이에요.' ],
    low:[
      '오늘은 나에게 집중하는 날. 셀프 칭찬 한 번 해 주세요.', '가까운 사람에게 고마움을 전하면 운이 따라와요.',
      '혼자만의 시간이 오히려 꿀맛인 날이에요.', '오해가 생기면 바로 웃으며 풀어 보세요.',
      '오늘은 말보다 미소가 더 잘 통해요.', '조용히 곁을 지켜 주는 사람이 유난히 소중한 날이에요.',
      '서운한 마음은 맛있는 걸로 달래 보세요.', '오늘은 메시지보다 직접 얼굴 보는 게 더 좋아요.',
      '먼저 다가가면 생각보다 반갑게 맞아 줘요.', '나를 위한 작은 선물이 필요한 날이에요.',
      '오늘은 내 마음의 소리에 귀 기울여 봐요.', '조용한 응원이 더 크게 들리는 날이에요.',
      '먼저 건넨 미소가 하루를 바꿔 줘요.', '혼밥도 꽤 근사한 하루예요.', '가끔은 거리를 두는 것도 좋은 배려예요.' ],
  };
  const LUCKY_ITEMS = ['주황색 응원 막대', '따끈한 어묵', '시원한 아이스크림', '치킨 한 조각', '하이파이브', '셀카 한 장', '큰 박수 세 번',
    '줄무늬 양말', '동전 지갑', '좋아하는 펜', '손거울', '이어폰', '머리끈', '귀여운 키링', '초콜릿 한 조각', '따뜻한 커피',
    '우산', '손수건', '스티커', '응원 수건', '모자', '물병', '사탕', '메모지', '운동화', '작은 쿠션', '향긋한 핸드크림', '책갈피'];
  const LUCKY_COLORS = ['주황', '하늘색', '민트', '보라', '금색', '하양', '연두', '분홍', '네이비', '베이지', '레몬색', '코랄', '라벤더', '버건디', '회색'];
  const LUCKY_TIMES = ['오전 10시', '점심 직후', '오후 3시', '해 질 무렵', '저녁 7시', '밤 9시', '경기 시작 직전', '아침 첫 커피 타임'];
  const EMOJI_RULES = [
    [/좋은 일이 생길 확률/, '⏰', 'lucky'], [/행운의 아이템|행운을 부르는|챙기면|소품/, '🍀', 'lucky'], [/럭키 넘버|행운의 숫자/, '🔢', 'lucky'],
    [/사진|셀카|인생샷/, '📸'], [/노래|최애곡|콧노래/, '🎵'], [/커피|음료|차 한 잔|물 한 잔/, '☕'],
    [/점심|메뉴|맛집|간식|맛있는|밥|시식|나눠 먹/, '🍜'], [/단 음식|초콜릿/, '🍫'], [/향/, '🌸'],
    [/계단|새로운 길|발걸음|신발|걸을/, '👟'], [/하늘|바람|창문/, '🌤️'], [/메모|아이디어/, '📝'], [/정리|가방/, '🧺'],
    [/쿠폰|할인|득템|포인트|가성비|가심비/, '🏷️'], [/선물|보너스|경품|이벤트|공짜/, '🎁'], [/저축|저금|통장|동전|모으/, '🐷'],
    [/지갑|지출|구매|결제|소비|장바구니|영수증|가계부|용돈|무지출|한턱/, '👛'], [/재물|금전|돈/, '💰'],
    [/단톡|연락|안부|메시지|소식/, '💬'], [/칭찬|고맙|고마움/, '👏'], [/하이파이브/, '🙌'], [/가족/, '🏠'],
    [/혼자|혼밥|나에게|나를 위한|내 마음/, '🫶', 'people'], [/콩닥|호감|인연|사람|친구|케미|대화|수다|미소|함께/, '💗', 'people'],
    [/쉬엄|휴식|충전|낮잠|느긋|여유|일찍|쉼표|천천히|잔잔|평온|루틴/, '🛋️'], [/웃/, '😆'],
    [/소원|여신|기다리던/, '🌟'], [/반짝|빛나|거울/, '✨'], [/주인공|자신감|정답|직감/, '😎'], [/우연|서프라이즈|발견/, '🎉'],
  ];
  const EMOJI_DEFAULT = { vibe:'✨', tip:'💡', money:'💰', people:'💗', lucky:'🍀' };
  function dropToday(t){
    return t
      .replace(/오늘 찍는/g, '지금 찍는').replace(/오늘 산 /g, '이번에 산 ').replace(/오늘 만난/g, '새로 만난').replace(/오늘 떠오른/g, '문득 떠오른')
      .replace(/오늘의 행운 아이템/g, '행운 아이템').replace(/오늘의 럭키/g, '럭키')
      .replace(/(^|[.!?] )오늘(은|의)? /g, '$1').replace(/ 오늘은 /g, ' ').replace(/ 오늘 /g, ' ')
      .replace(/^(\S)/, c => c);
  }
  function emojiFor(t, kind){ const m = EMOJI_RULES.find(([re, , k])=> (!k || k === kind) && re.test(t)); return m ? m[1] : EMOJI_DEFAULT[kind] || '✨'; }
  const BANDS = [
    { key:'top',  name:'대길', min:92, bonus:3 },
    { key:'good', name:'길',   min:80, bonus:2 },
    { key:'fine', name:'소길', min:65, bonus:1 },
    { key:'calm', name:'평',   min:0,  bonus:0 },
  ];
  const AB_LABELS = { atk:'공격', srv:'서브', blk:'블로킹', dig:'디그', rcv:'리시브', set:'세트' };
  const pad = n=> String(n).padStart(2, '0');
  const todayKey = ()=>{ const t = new Date(); return `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())}`; };
  function hash(str){ let h = 2166136261; for(let i = 0; i < str.length; i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed){ return ()=>{ seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const shuffleCache = {};
  function shuffled(key, arr){
    if(shuffleCache[key]) return shuffleCache[key];
    const a = arr.slice(), rr = rng(hash(key));
    for(let i = a.length - 1; i > 0; i--){ const j = Math.floor(rr() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return shuffleCache[key] = a;
  }
  function josa(w, a, b){ const c = String(w).charCodeAt(String(w).length - 1); return c >= 0xAC00 && c <= 0xD7A3 && (c - 0xAC00) % 28 ? a : b; }
  function parseBirth(b){
    const m = String(b || '').trim().match(/^(?:(\d{4})-)?(\d{1,2})-(\d{1,2})$/);
    if(!m) return null;
    const y = m[1] ? +m[1] : null, mo = +m[2], d = +m[3];
    return mo >= 1 && mo <= 12 && d >= 1 && d <= 31 ? { y, mo, d } : null;
  }
  function zodiac(mo, d){
    let z = '염소자리';
    ZODIAC.forEach(([m, day, name])=>{ if(mo > m || (mo === m && d >= day)) z = name; });
    return z;
  }
  const cache = {};
  function of(p){
    const day = todayKey();
    const k = p.num + '|' + day;
    if(k in cache) return cache[k];
    const b = parseBirth(p.birth);
    if(!b){ return cache[k] = null; }
    const r = rng(hash(`${p.num}|${b.mo}-${b.d}|${day}`));
    const birthday = new Date().getMonth() + 1 === b.mo && new Date().getDate() === b.d;
    const luck = birthday ? 100 : 60 + Math.floor(r() * 40);
    const band = BANDS.find(x=> luck >= x.min);
    const w = OVR_WEIGHTS[p.pos] || OVR_WEIGHTS.OH;
    const pool = Object.keys(w).filter(x=> w[x] >= 0.1);
    const lucky = pool[Math.floor(r() * pool.length)];
    const boost = Math.round(2 + (luck - 60) / 10);
    const rank = Math.max(0, PLAYERS.findIndex(x=> x.num === p.num));
    const dayPick = (name, arr, off = 0)=> shuffled(name + '|' + day, arr)[(rank * (off % 2 ? 11 : 13) + off) % arr.length];
    const pick = arr => arr[Math.floor(r() * arr.length)];
    const tier = ()=>{ const v = birthday ? 100 : luck + (r() - 0.5) * 30; return v >= 80 ? 'high' : v >= 62 ? 'mid' : 'low'; };
    const first = birthday ? pick(['생일 축하해요! 오늘의 주인공은 바로 나. 최고의 하루가 될 거예요.', '생일 축하해요! 오늘은 세상이 다 내 편이에요.', 'Happy Birthday! 축하 메시지가 쏟아지는 하루가 될 거예요.'])
                           : dayPick('vibe-' + band.key, VIBES[band.key]);
    const mt = birthday ? 'high' : tier(), pt = birthday ? 'high' : tier();
    const mids = [['tip', dayPick('tip', TIPS)], ['money', dayPick('money-' + mt, MONEY[mt], 3)], ['people', dayPick('people-' + pt, PEOPLE[pt], 5)]];
    for(let i = mids.length - 1; i > 0; i--){ const j = Math.floor(r() * (i + 1)); [mids[i], mids[j]] = [mids[j], mids[i]]; }
    if(r() < 0.22) mids.pop();
    const item = pick(LUCKY_ITEMS), color = pick(LUCKY_COLORS), num = 1 + Math.floor(r() * 99), time = pick(LUCKY_TIMES);
    const LUCKY_FORMS = [
      ()=> `행운의 아이템은 ${item}, 행운의 컬러는 ${color}!`,
      ()=> `오늘의 행운 아이템은 ${item}, 행운의 숫자는 ${num}이에요.`,
      ()=> `${color} 소품을 하나 챙기면 운이 올라가요. 행운의 숫자는 ${num}!`,
      ()=> `행운을 부르는 건 ${item}. 오늘은 ${color}${josa(color, '이', '가')} 잘 어울려요.`,
      ()=> `${time}에 좋은 일이 생길 확률이 높아요. 행운의 컬러는 ${color}.`,
      ()=> `${item}${josa(item, '을', '를')} 챙기면 하루가 더 즐거워져요.`,
    ];
    const luckyLine = pick(LUCKY_FORMS)();
    const rows = [['vibe', first], ...mids, ['lucky', luckyLine]];
    let sawToday = false;
    rows.forEach(row=>{ const t = row[1]; if(sawToday) row[1] = dropToday(t); if(/오늘/.test(t)) sawToday = true; });
    const parts = rows.map(([kind, t], i)=> `${birthday && i === 0 ? '🎂' : emojiFor(t, kind)}\u00A0${t}`);
    const line = parts.join(' ');
    return cache[k] = {
      luck, band, birthday, line, parts, lucky, luckyLabel:AB_LABELS[lucky], boost,
      zodiac: zodiac(b.mo, b.d), animal: b.y ? ANIMALS[b.y % 12] + '띠' : '',
      date: day,
    };
  }
  return { of };
})();
function playerAbilityToday(p){
  const a = Object.assign({}, p.ability || {});
  const f = FORTUNE.of(p);
  if(f && typeof a[f.lucky] === 'number') a[f.lucky] = Math.min(99, a[f.lucky] + f.boost);
  return a;
}
function attackBonus(p){
  if(p.pos !== 'OH' && p.pos !== 'OP') return 0;
  const atk = (p.ability || {}).atk || 0;
  return Math.max(0, Math.min(4, Math.floor((atk - 70) / 5)));
}
function hexBonus(p){
  const a = p.ability || {}, vals = ['atk', 'srv', 'blk', 'dig', 'rcv', 'set'].map(k=> a[k] || 0);
  const m = Math.min(...vals);
  return m >= 70 ? 7 : m >= 65 ? 5 : m >= 60 ? 3 : 0;   // 여섯 능력치가 고르게 높은 '육각형' 선수 우대
}
const SCORE_FLOOR_GAP = 5;
const SCORE_MIN = 60;   // 오늘의 점수 최저점
function playerScoreParts(p){
  const f = FORTUNE.of(p), base = playerOvr(p), bonus = attackBonus(p), hex = hexBonus(p);
  const mixed = f ? Math.round(base * 0.5 + f.luck * 0.5) : base;
  // 육각형 선수 보장 — 여섯 능력치가 고르게 높으면 운세가 낮은 날에도 이 점수 아래로 안 내려가요
  const hexFloor = hex >= 5 ? 85 : hex >= 3 ? 80 : 0;
  let total = Math.min(99, Math.max(SCORE_MIN, hexFloor, base - SCORE_FLOOR_GAP, mixed + bonus + hex));
  if(f && f.birthday) total = 100;   // 생일 당일은 100점 특별 카드
  return { base, luck: f ? f.luck : null, bonus, hex, total };
}
function playerOvrToday(p){
  return playerScoreParts(p).total;
}

function pickBoxHtml(p){
  const src = p.card || p.photo || figureSrc(p) || '';
  return `<span class="pick-player__box" aria-hidden="true">
    <b class="pick-player__no">${p.num}</b>
    ${src ? `<img class="pick-player__img${p.card ? '' : ' is-face'}" src="${src}" alt="" loading="lazy" draggable="false">` : ''}
    <span class="pick-player__n">${p.name ? playerName(p) : '#' + p.num}</span>
  </span>`;
}

/* ===== 하위 메뉴 토글 ===== */
function panelSlide(panels, target, dir){
  panels.forEach(p=> p.classList.remove('slide-next', 'slide-prev'));
  if(target && dir && !matchMedia('(prefers-reduced-motion: reduce)').matches) target.classList.add(dir > 0 ? 'slide-next' : 'slide-prev');
}
const TOGGLES = {};
document.querySelectorAll('.seatmode-toggle[data-toggle]').forEach(root=>{
  const name = root.dataset.toggle;
  const btns = Array.from(root.querySelectorAll('.seatmode-btn'));
  const thumb = root.querySelector('.seatmode-thumb');
  const scope = document.getElementById(root.dataset.target);
  root.style.setProperty('--n', btns.length);
  function set(key, silent){
    const i = btns.findIndex(b=> b.dataset.key === key);
    if(i < 0) return;
    const prev = btns.findIndex(b=> b.classList.contains('active'));
    btns.forEach((b, j)=>{ b.classList.toggle('active', j === i); b.setAttribute('aria-selected', j === i); });
    thumb.style.transform = `translateX(calc(${i} * (100% + 6px)))`;
    const panels = Array.from(scope.children).filter(p=> p.classList.contains('seatmode-panel'));
    panelSlide(panels, panels.find(p=> p.dataset.key === key), !silent && prev >= 0 && prev !== i ? i - prev : 0);
    panels.forEach(p=> p.classList.toggle('active', p.dataset.key === key));
    TOGGLES[name].current = key;
    if(!silent) document.dispatchEvent(new CustomEvent('wm:toggle', { detail:{ toggle:name, key } }));
  }
  btns.forEach(b=> b.addEventListener('click', ()=>{
    if(b.classList.contains('active')) return;
    hapticTick(); set(b.dataset.key);
  }));
  TOGGLES[name] = { set, current:(btns.find(b=> b.classList.contains('active')) || btns[0]).dataset.key };
});

/* ===== 탭 네비게이션 ===== */
const tabButtons = Array.from(document.querySelectorAll('.tabbar__btn'));
const VIEW_TOGGLE = { pick:'pick', players:'players' };

const NAV_LANG = (new URLSearchParams(location.search).get('nav') || CONFIG.NAV_LANG || 'ko') === 'en' ? 'en' : 'ko';
document.body.classList.toggle('nav-en', NAV_LANG === 'en');
tabButtons.forEach(btn=>{
  const label = (CONFIG.NAV_LABELS[NAV_LANG] || {})[btn.dataset.view];
  if(label) btn.querySelector('span').textContent = label;
});

function slideClass(target, dir){
  document.querySelectorAll('.view.slide-next, .view.slide-prev').forEach(v=> v.classList.remove('slide-next', 'slide-prev'));
  if(target && dir && !matchMedia('(prefers-reduced-motion: reduce)').matches) target.classList.add(dir > 0 ? 'slide-next' : 'slide-prev');
}
function navigate(view, sub){
  const idx = tabButtons.findIndex(b=> b.dataset.view === view);
  if(idx < 0) return;
  const prevIdx = tabButtons.findIndex(b=> b.classList.contains('active'));
  tabButtons.forEach((b, i)=>{ b.classList.toggle('active', i === idx); b.setAttribute('aria-current', i === idx ? 'page' : 'false'); });
  slideClass(document.getElementById('view-' + view), prevIdx >= 0 && prevIdx !== idx ? idx - prevIdx : 0);
  document.querySelectorAll('.view').forEach(v=> v.classList.toggle('active', v.id === 'view-' + view));
  if(sub && VIEW_TOGGLE[view] && TOGGLES[VIEW_TOGGLE[view]]) TOGGLES[VIEW_TOGGLE[view]].set(sub, true);
  if(view === 'guide' && sub === 'lastrain') setTimeout(()=> window.__openSubway && window.__openSubway(), 120);
  window.scrollTo({ top:0 });
  const appEl = document.getElementById('app'); if(appEl) appEl.scrollTop = 0;
  document.dispatchEvent(new CustomEvent('wm:nav', { detail:{ view, sub: VIEW_TOGGLE[view] && TOGGLES[VIEW_TOGGLE[view]] ? TOGGLES[VIEW_TOGGLE[view]].current : (view === 'guide' ? sub || null : null) } }));
}
tabButtons.forEach(btn=>{
  btn.addEventListener('click', ()=>{
    if(btn.classList.contains('active')) return;
    hapticTick();
    navigate(btn.dataset.view);
  });
});

if(TEST_MATCH){
  const tag = document.createElement('div');
  tag.className = 'test-tag'; tag.setAttribute('role', 'status');
  tag.textContent = `테스트 경기 · ${TEST_MATCH}`;
  document.body.appendChild(tag);
}

function fmtMatchDate(d, withTime){
  const p = n => String(n).padStart(2, '0');
  return `${d.getMonth() + 1}.${d.getDate()} (${'일월화수목금토'[d.getDay()]})${withTime ? ` ${p(d.getHours())}:${p(d.getMinutes())}` : ''}`;
}

/* ---------- 구단 브랜드 ---------- */
const TEAM_BRANDS = [
  { keys:['OK저축은행','읏맨'],          short:'OK저축은행', nick:'읏맨',        logo:'images/teams/okman.webp',  color:'#FF571F', init:'OK' },
  { keys:['대한항공','점보스'],          short:'대한항공',   nick:'점보스',      logo:'images/teams/koreanair.webp', color:'#0B4EA2', init:'KAL' },
  { keys:['현대캐피탈','스카이워커스'],  short:'현대캐피탈', nick:'스카이워커스', logo:'images/teams/hyundai.webp',   color:'#0C2340', init:'HC' },
  { keys:['삼성화재','블루팡스'],        short:'삼성화재',   nick:'블루팡스',    logo:'images/teams/samsung.webp',   color:'#1C4DA1', init:'SF' },
  { keys:['KB손해보험','KB손보','스타즈'], short:'KB손해보험', nick:'스타즈',     logo:'images/teams/kb.webp',        color:'#FFBC00', ink:'#3B2F00', init:'KB' },
  { keys:['한국전력','빅스톰','KEPCO'],  short:'한국전력',   nick:'빅스톰',      logo:'images/teams/kepco.webp',     color:'#E2231A', init:'KE' },
  { keys:['우리카드','우리WON'],         short:'우리카드',   nick:'우리WON',     logo:'images/teams/woori.webp',     color:'#0067AC', init:'WO' },
];
const findTeamBrand = name=> TEAM_BRANDS.find(b=> b.keys.some(k=> String(name || '').includes(k))) || null;

(function bindTeamBrands(){
  function crestFallback(crest, b, raw){
    const init = b ? b.init : (String(raw || '').trim().slice(0, 2) || '?');
    crest.innerHTML = '<span class="mb-init"></span>';
    const s = crest.firstChild; s.textContent = init;
    if(b){ s.style.setProperty('--team', b.color); if(b.ink) s.style.setProperty('--team-ink', b.ink); }
  }
  function apply(side){
    const nameEl = document.getElementById(`mb-${side}`), crest = document.getElementById(`mb-${side}-crest`), nick = document.getElementById(`mb-${side}-nick`);
    if(!nameEl || !crest) return;
    const raw = nameEl.textContent.trim(), b = findTeamBrand(raw);
    if(b && raw !== b.short){ nameEl.textContent = b.short; return; }
    if(nick) nick.textContent = b ? b.nick : '';
    const want = b && b.logo ? b.logo : '';
    if(crest.dataset.logo === want + '|' + raw) return;
    crest.dataset.logo = want + '|' + raw;
    if(!want){ crestFallback(crest, b, raw); return; }
    const img = new Image(); img.alt = ''; img.decoding = 'async';
    img.onerror = ()=> crestFallback(crest, b, raw);
    img.src = want;
    crest.replaceChildren(img);
  }
  ['home', 'away'].forEach(side=>{
    const el = document.getElementById(`mb-${side}`); if(!el) return;
    new MutationObserver(()=> apply(side)).observe(el, { childList:true, characterData:true, subtree:true });
    apply(side);
  });
})();

(function renderMatchbar(){
  document.getElementById('mb-home').textContent = CONFIG.MATCH.home;
  document.getElementById('mb-away').textContent = CONFIG.MATCH.away;
  document.getElementById('mb-venue').textContent = CONFIG.MATCH.venue;
  document.getElementById('mb-date').textContent = CONFIG.MATCH.date || (TEST_MATCH ? fmtMatchDate(new Date(), false) : '경기 일시 입력 필요');
})();

/* ===== 안내 · 좌석 찾기 · 티켓 촬영 ===== */
(function initSeatFinder(){
  const grid = document.getElementById('zone-grid');
  const levelTabs = document.getElementById('level-tabs');
  const detail = document.getElementById('zone-detail');
  let selectedZoneId = '';

  const COLOR_LABELS = { cyan:'하늘색', green:'초록색', yellow:'노란색', orange:'주황색', purple:'보라색', red:'빨간색', charcoal:'진회색', brown:'고동색', tan:'황토색', forest:'진초록색', navy:'남색', pink:'분홍색' };
  let currentLevel = '1';

  Object.keys(CONFIG.LEVEL_LABELS).forEach(lv=>{
    const b = document.createElement('button');
    b.className = 'subtab__btn' + (lv === currentLevel ? ' active' : '');
    b.dataset.level = lv;
    b.textContent = ({ '1':'1층', '2':'2층', '3':'3층', 'S':'특별석' })[lv] || CONFIG.LEVEL_LABELS[lv];
    b.addEventListener('click', ()=>{
      if(lv === currentLevel) return;
      hapticTick();
      currentLevel = lv;
      document.querySelectorAll('#level-tabs .subtab__btn').forEach(t=> t.classList.toggle('active', t.dataset.level === lv));
      renderZoneGrid();
    });
    levelTabs.appendChild(b);
  });

  function renderZoneGrid(){
    grid.innerHTML = '';
    grid.dataset.level = currentLevel;
    CONFIG.ZONES.filter(z=> z.level === currentLevel).forEach(z=>{
      const b = document.createElement('button');
      b.className = 'zone-btn' + (z.id === selectedZoneId ? ' active' : '');
      b.dataset.zone = z.id;
      const dotColor = CONFIG.ZONE_COLORS[z.color] || 'transparent';
      b.innerHTML = `<span class="dot" style="background:${dotColor}"></span>${z.label}${z.gate ? '<span class="tag">GATE</span>' : ''}`;
      b.addEventListener('click', ()=> applySeatSelection(z.id));
      grid.appendChild(b);
    });
  }
  renderZoneGrid();

  const LEVEL_SHORT = { '1':'1층', '2':'2층', '3':'3층', 'S':'특별석' };
  const GATE_LABELS = { 'GATE 1':'GATE 1 (위쪽 왼쪽)', 'GATE 2':'GATE 2 (위쪽 오른쪽)', 'GATE 3':'GATE 3 (아래쪽 오른쪽)', 'GATE 4':'GATE 4 (아래쪽 왼쪽)' };
  const routeModal = document.getElementById('route-modal');
  const routeTrack = document.getElementById('route-track');
  const routeSteps = document.getElementById('route-steps');

  function computeNearestGate(zone){ return ZONE_GATE[zone.id] || 'GATE 1'; }

  const gateIconSvg = `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V5a2 2 0 0 1 2-2h6l4 4v14"/><path d="M5 21h12M15 12v.01"/></svg>`;
  const stairsIconSvg = `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21v-4h4v-4h4v-4h4V5h6"/></svg>`;

  const routeMapImg = document.getElementById('route-map-img');
  const routeLine = document.getElementById('route-line');

  const routeWalker = document.getElementById('route-walker');

  let routeRafId = null;
  function drawRouteLine(pts){
    if(routeRafId){ cancelAnimationFrame(routeRafId); routeRafId = null; }
    routeLine.classList.remove('flowing');
    routeLine.style.transition = 'none';

    const len = routeLine.getTotalLength();
    const durMs = Math.min(4500, Math.max(1500, len / 22 * 1000));
    const hasWalk = pts && pts.length > 1 && len > 0;
    routeWalker.classList.toggle('show', hasWalk);

    if(len <= 0){
      routeLine.style.strokeDasharray = '';
      routeLine.style.strokeDashoffset = '';
      routeLine.classList.add('flowing');
      return;
    }

    routeLine.style.strokeDasharray = String(len);
    routeLine.style.strokeDashoffset = String(len);

    const startTime = performance.now();
    function step(now){
      const t = Math.min(1, (now - startTime) / durMs);
      const eased = 1 - Math.pow(1 - t, 2);
      const drawnLen = len * eased;
      routeLine.style.strokeDashoffset = String(len - drawnLen);
      if(hasWalk){
        const pt = routeLine.getPointAtLength(drawnLen);
        routeWalker.setAttribute('cx', pt.x);
        routeWalker.setAttribute('cy', pt.y);
      }
      if(t < 1){
        routeRafId = requestAnimationFrame(step);
      } else {
        routeRafId = null;
        routeLine.style.strokeDasharray = '';
        routeLine.style.strokeDashoffset = '';
        routeLine.classList.add('flowing');
        routeWalker.classList.remove('show');
      }
    }
    routeRafId = requestAnimationFrame(step);
  }
  const routePinGate = document.getElementById('route-pin-gate');
  const routePinSeat = document.getElementById('route-pin-seat');
  if(CONFIG.VENUE_MAP_IMAGE) routeMapImg.src = CONFIG.VENUE_MAP_IMAGE;

  function openRouteModal(zone){
    hapticTick();
    const gateId = computeNearestGate(zone);
    const gateLabel = GATE_LABELS[gateId] || gateId;
    const levelShort = LEVEL_SHORT[zone.level] || '';
    const dotColor = CONFIG.ZONE_COLORS[zone.color] || 'var(--brand)';

    document.getElementById('route-modal-label').textContent = `${zone.label} 가는 길`;
    routeModal.classList.add('show');

    const seatXY = ZONE_COORDS[zone.id];
    const gateXY = GATE_COORDS[gateId] || ZONE_COORDS[gateId];
    if(seatXY && gateXY && CONFIG.VENUE_MAP_IMAGE){
      document.getElementById('route-map').style.display = 'block';
      routePinGate.style.left = gateXY[0] + '%';
      routePinGate.style.top = gateXY[1] + '%';
      document.getElementById('route-pin-gate-label').textContent = gateId;
      routePinSeat.style.left = seatXY[0] + '%';
      [routePinSeat, routePinGate].forEach((pin, i)=>{ const x = (i ? gateXY : seatXY)[0]; pin.classList.toggle('edge-l', x < 16); pin.classList.toggle('edge-r', x > 84); });
      routePinSeat.style.top = seatXY[1] + '%';
      document.getElementById('route-pin-seat-label').textContent = zone.label;
      const pathPts = ZONE_PATHS[zone.id];
      const finalPts = (pathPts && pathPts.length) ? pathPts : [gateXY, seatXY];
      const pointsAttr = finalPts.map(p => p.join(',')).join(' ');
      routeLine.setAttribute('points', pointsAttr);
      drawRouteLine(finalPts);
    } else {
      document.getElementById('route-map').style.display = 'none';
    }

    routeTrack.innerHTML = `
      <div class="route-node">
        <div class="route-icon gate">${gateIconSvg}</div>
        <span>${gateId}</span>
      </div>
      <div class="route-line"></div>
      <div class="route-node">
        <div class="route-icon">${stairsIconSvg}</div>
        <span>${levelShort}</span>
      </div>
      <div class="route-line"></div>
      <div class="route-node">
        <div class="route-icon seat" style="background:${dotColor}"></div>
        <span>${zone.label}</span>
      </div>
    `;
    const htNote = zone.id === 'HT' ? '<li>하이테이블석은 코트 왼쪽 끝 <b>위(GATE 1 쪽) · 아래(GATE 4 쪽)</b> 두 곳에 있어요. 아래쪽 자리면 <b>GATE 4</b>로 입장하세요.</li>' : '';
    const levelStep = zone.level === '3' ? '이 층 표지판을 따라 이동하세요.'
      : zone.level === 'S' ? `${zone.label} 안내 표지판을 따라 이동하세요.`
      : `계단으로 ${levelShort}까지 이동하세요.`;
    routeSteps.innerHTML = `
      <li><b>${gateLabel}</b>로 입장하세요.</li>
      <li>${levelStep}</li>
      <li><b>${zone.label}</b> 구역 표지판이 보이면 도착이에요.</li>${htNote}
    `;
  }
  document.getElementById('route-modal-close').addEventListener('click', ()=>{
    routeModal.classList.remove('show');
  });

  function zoneDetailHtml(zone){
    const levelLabel = CONFIG.LEVEL_LABELS[zone.level];
    const colorLabel = COLOR_LABELS[zone.color];
    let html = `<b>${zone.label}</b> · ${levelLabel}${colorLabel ? ` · 배치도상 ${colorLabel} 구역` : ''}`;
    if(zone.gate) html += `<br>${zone.gate} 바로 ${zone.level === '3' && parseInt(zone.id.split('-')[1], 10) >= 8 ? '아래' : '위'} 구역이에요.`;
    if(zone.accessible) html += `<br>휠체어석이 포함된 구역이에요.`;
    return html;
  }

  function applySeatSelection(zoneId){
    if(/^HT\d?$/i.test(String(zoneId || ''))) zoneId = 'HT';   // 예전 하이테이블석 1 · 2 → 하나로
    const zone = CONFIG.ZONES.find(z=>z.id===zoneId);
    if(!zone) return;
    hapticTick();

    if(zone.level !== currentLevel){
      currentLevel = zone.level;
      document.querySelectorAll('#level-tabs .subtab__btn').forEach(t=> t.classList.toggle('active', t.dataset.level === zone.level));
      renderZoneGrid();
    }

    selectedZoneId = zoneId;
    document.querySelectorAll('.zone-btn').forEach(b=> b.classList.toggle('active', b.dataset.zone===zoneId));
    ['seat-guide-submit', 'seat-view-submit'].forEach(id=>{ const b = document.getElementById(id); if(b) b.disabled = false; });

    detail.innerHTML = zoneDetailHtml(zone);
    requestAnimationFrame(()=> detail.classList.add('show'));
  }

  const seatModal = document.getElementById('seat-modal');
  const seatModalIframe = document.getElementById('seat-modal-iframe');
  const seatModalLabel = document.getElementById('seat-modal-label');
  function openSeatModal(src, label){
    hapticTick();
    seatModalIframe.src = src;
    seatModalLabel.textContent = label || '';
    seatModal.classList.add('show');
  }
  function closeSeatModal(){
    seatModal.classList.remove('show');
    seatModalIframe.src = 'about:blank';
  }
  document.getElementById('seat-modal-close').addEventListener('click', closeSeatModal);

  document.getElementById('seat-guide-submit').addEventListener('click', ()=>{
    const zone = CONFIG.ZONES.find(z=>z.id===selectedZoneId);
    if(zone) openRouteModal(zone);
  });
  document.getElementById('seat-view-submit').addEventListener('click', ()=>{
    const zone = CONFIG.ZONES.find(z=>z.id===selectedZoneId);
    if(!zone) return;
    const sceneId = CONFIG.SEAT_SCENE_MAP[zone.id] || `OK${zone.id}`;
    const src = `${CONFIG.SEAT_TOUR_BASE}?startscene=${encodeURIComponent(sceneId)}`;
    openSeatModal(src, `${zone.label} 시야`);
  });

  const seatmodeThumb = document.getElementById('seatmode-thumb');
  document.querySelectorAll('.seatmode-btn[data-mode]').forEach((btn, i)=>{
    btn.addEventListener('click', ()=>{
      if(btn.classList.contains('active')) return;
      hapticTick();
      document.querySelectorAll('.seatmode-btn[data-mode]').forEach(b=>b.classList.toggle('active', b===btn));
      seatmodeThumb.style.transform = i === 0 ? 'translateX(0)' : 'translateX(calc(100% + 6px))';
      const mode = btn.dataset.mode;
      const sp = [document.getElementById('seatmode-manual'), document.getElementById('seatmode-photo')];
      panelSlide(sp, mode === 'manual' ? sp[0] : sp[1], mode === 'manual' ? -1 : 1);
      document.getElementById('seatmode-manual').classList.toggle('active', mode==='manual');
      document.getElementById('seatmode-photo').classList.toggle('active', mode==='photo');
    });
  });

  const photoInput = document.getElementById('seat-photo-input');
  const photoCamera = document.getElementById('seat-photo-camera');
  if(IS_IOS){
    const cam = document.querySelector('label[for="seat-photo-camera"]'), pick = document.querySelector('label[for="seat-photo-input"]');
    if(cam) cam.hidden = true;
    if(pick){ pick.textContent = '티켓 촬영 · 사진 선택'; pick.classList.remove('ghost'); }
  }
  const photoDrop = document.getElementById('photo-drop');
  const photoPreview = document.getElementById('photo-preview');
  const photoPreviewImg = document.getElementById('photo-preview-img');
  const photoNote = document.getElementById('photo-note');
  const OCR_URL = CONFIG.SEAT_OCR_API || (CONFIG.LIVE_API ? String(CONFIG.LIVE_API).replace(/\/live\/?$/, '').replace(/\/$/, '') + '/seat-ocr' : '');

  document.getElementById('photo-retake').addEventListener('click', ()=>{
    photoInput.value = ''; if(photoCamera) photoCamera.value = '';
    photoPreview.style.display = 'none';
    photoDrop.style.display = 'flex';
    photoNote.innerHTML = '';
    (IS_IOS ? photoInput : (photoCamera || photoInput)).click();
  });
  photoNote.addEventListener('click', e=>{
    if(e.target.closest('[data-go-manual]')) document.querySelector('.seatmode-btn[data-mode="manual"]').click();
  });

  photoInput.addEventListener('change', onPhoto);
  if(photoCamera) photoCamera.addEventListener('change', onPhoto);
  async function onPhoto(e){
    const file = e.target.files && e.target.files[0];
    if(!file) return;
    photoPreviewImg.src = URL.createObjectURL(file);
    photoPreview.style.display = 'block';
    photoDrop.style.display = 'none';
    if(!OCR_URL){ photoNote.innerHTML = manualHint('사진 인식을 준비 중이에요.'); return; }
    photoNote.innerHTML = '<span class="photo-note__busy" aria-live="polite">티켓에서 좌석 정보를 읽고 있어요…</span>';
    try{
      const seat = await recognizeSeatFromPhoto(file);
      if(seat && seat.zone && CONFIG.ZONES.some(z=> z.id === seat.zone)){
        applySeatSelection(seat.zone);
        const zone = CONFIG.ZONES.find(z=> z.id === seat.zone);
        const extra = [seat.row && `${seat.row}열`, seat.seat && `${seat.seat}번`].filter(Boolean).join(' ');
        photoNote.innerHTML = `<b class="photo-note__ok">✓ ${zone.label || zone.id}구역${extra ? ' ' + extra : ''}</b>으로 확인했어요. 아래에서 좌석 안내 · 시야를 볼 수 있어요.`
          + ` <button type="button" class="photo-note__link" data-go-manual>다른 구역이에요</button>`;
      } else {
        photoNote.innerHTML = manualHint('티켓에서 구역을 찾지 못했어요. 구역 번호가 잘 보이게 다시 찍어 보세요.');
      }
    }catch(err){
      // 원인 코드도 작게 보여줘요 (현장 문의 · 점검용) — not_configured: 서버 AI 키 없음 · ai_401: 키 오류 · HTTP 404: 서버에 기능 없음
      const code = String(err && err.message || '').slice(0, 24);
      const why = /not_configured/.test(code) ? '사진 인식을 준비 중이에요.' : /abort/i.test(code) ? '인식이 오래 걸려서 멈췄어요. 다시 찍어 보세요.' : '인식에 실패했어요. 잠시 후 다시 찍어 보세요.';
      photoNote.innerHTML = manualHint(why) + (code ? ` <small class="photo-note__code">(${escHtml(code)})</small>` : '');
    }
  }
  function manualHint(msg){ return `${msg} <button type="button" class="photo-note__link" data-go-manual>구역 직접 고르기</button>`; }

  async function shrink(file, rotate = 0){
    try{
      const bmp = await createImageBitmap(file, { imageOrientation:'from-image' });
      const k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
      const w = Math.round(bmp.width * k), h = Math.round(bmp.height * k);
      const side = rotate % 180 !== 0;
      const c = document.createElement('canvas'); c.width = side ? h : w; c.height = side ? w : h;
      const g = c.getContext('2d');
      g.translate(c.width / 2, c.height / 2); g.rotate(rotate * Math.PI / 180);
      g.drawImage(bmp, -w / 2, -h / 2, w, h);
      return await new Promise(res=> c.toBlob(b=> res(b || file), 'image/jpeg', 0.85));
    }catch(e){ return file; }
  }
  async function askOcr(blob){
    const form = new FormData();
    form.append('photo', blob, 'ticket.jpg');
    const ctrl = new AbortController(); const t = setTimeout(()=> ctrl.abort(), 20000);
    try{
      const res = await fetch(OCR_URL, { method:'POST', body:form, signal:ctrl.signal });
      if(!res.ok){ let code = 'HTTP ' + res.status; try{ const j = await res.json(); if(j && j.error) code = j.error; }catch(e){} throw new Error(code); }
      return await res.json();
    } finally { clearTimeout(t); }
  }
  const okZone = r => r && r.zone && CONFIG.ZONES.some(z=> z.id === r.zone);
  async function recognizeSeatFromPhoto(file){
    const first = await askOcr(await shrink(file, 0));
    if(okZone(first)) return first;
    photoNote.innerHTML = '<span class="photo-note__busy" aria-live="polite">사진 방향을 바꿔서 한 번 더 읽어 볼게요…</span>';
    const side = await Promise.allSettled([90, 270].map(async d=> askOcr(await shrink(file, d))));
    const hit = side.map(x=> x.status === 'fulfilled' ? x.value : null).find(okZone);
    if(hit) return hit;
    const flip = await askOcr(await shrink(file, 180)).catch(()=> null);
    return okZone(flip) ? flip : first;
  }

})();

/* ===== 이벤트 · 경기 예측 ===== */
(function initPredict(){
  const list = document.getElementById('predict-list');
  const submitBtn = document.getElementById('predict-submit');
  const statusEl = document.getElementById('predict-status');
  const selections = {};
  const saved = LOCAL['predictions'];

  let builtVer = 0;
  function build(){
  builtVer = CONTENT.ver('predict');
  list.innerHTML = '';
  CONFIG.PREDICT_EVENTS.forEach(ev=>{
    const card = document.createElement('div');
    card.className = 'card predict-card';
    let optsHtml;
    if(ev.type === 'player'){
      const cands = ev.candidates && ev.candidates.length
        ? PLAYERS.filter(p=> ev.candidates.includes(p.num))
        : PLAYERS.filter(p=> p.pos !== 'L' || ev.pool === 'all' || isDefenseQ(ev));
      optsHtml = `<div class="pick-grid">${cands.map(p=> `
        <button class="pick-player" data-opt="${p.num}" aria-label="${playerName(p)}">
          ${pickBoxHtml(p)}
        </button>`).join('')}</div>`;
    } else {
      optsHtml = `<div class="opt-grid">${ev.options.map(opt=> `<div class="opt" data-opt="${opt}"><span>${opt}</span><span class="check"></span></div>`).join('')}</div>`;
    }
    card.innerHTML = `<p class="q">${ev.q}</p>${optsHtml}`
      + (ev.type === 'player' ? `<button class="fortune-link" type="button" data-fortune>선수 운세 보고 오기<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>` : '');
    const fl = card.querySelector('[data-fortune]');
    if(fl) fl.addEventListener('click', ()=>{
      hapticTick();
      const sel = selections[ev.id] || (card.querySelector('.ai-rec') || {}).dataset?.opt;
      const cands = ev.candidates && ev.candidates.length ? PLAYERS.filter(p=> ev.candidates.includes(p.num)) : PLAYERS.filter(p=> p.pos !== 'L' || ev.pool === 'all' || isDefenseQ(ev));
      const num = sel ? Number(sel) : (cands[0] || {}).num;
      window.__openPlayerCard && window.__openPlayerCard(num, cands, { back:true });
    });
    card.querySelectorAll('[data-opt]').forEach(optEl=>{
      optEl.addEventListener('click', ()=>{
        if(LOCAL['predictions']) return;
        hapticTick();
        card.querySelectorAll('[data-opt]').forEach(o=> o.classList.remove('selected'));
        optEl.classList.add('selected');
        optEl.classList.remove('pulse'); void optEl.offsetWidth; optEl.classList.add('pulse');
        selections[ev.id] = optEl.dataset.opt;
      });
    });
    list.appendChild(card);
  });
  }
  build();

  if(saved) lockPredictUI(saved);

  CONTENT.onChange(()=>{
    if(LOCAL['predictions'] || Object.keys(selections).length) return;
    build();
    window.__aiPredictRefresh && window.__aiPredictRefresh();
  });
  window.__predictPreselect = num=>{
    if(LOCAL['predictions']) return;
    const i = CONFIG.PREDICT_EVENTS.findIndex(ev=> ev.type === 'player');
    if(i < 0) return;
    const card = list.querySelectorAll('.predict-card')[i];
    const el = card && card.querySelector(`[data-opt="${num}"]`);
    if(el){
      if(!el.classList.contains('selected')) el.click();
      if(window.__pqGoto) window.__pqGoto(i);
      else setTimeout(()=> card.scrollIntoView({ behavior:'smooth', block:'center' }), 120);
    }
  };

  submitBtn.addEventListener('click', async ()=>{
    if(Object.keys(selections).length < CONFIG.PREDICT_EVENTS.length){
      submitBtn.textContent = '모든 항목을 골라주세요';
      submitBtn.style.animation = 'optPulse .4s var(--ease-spring)';
      setTimeout(()=>{ submitBtn.textContent = '예측 제출하기'; submitBtn.style.animation = ''; }, 1400);
      return;
    }
    LOCAL['predictions'] = Object.assign({}, selections); saveLocal(LOCAL);
    await postData('predictions', selections);
    LIVE.submit('predictions', {
      answers: selections,
      text: Object.fromEntries(CONFIG.PREDICT_EVENTS.map(ev=> [ev.id, ev.type === 'player'
        ? `#${selections[ev.id]} ${playerName(playerByNum(selections[ev.id]))}` : String(selections[ev.id])])),
      questions: CONFIG.PREDICT_EVENTS.map(ev=> ({ id:ev.id, q:ev.q })),
      ver: builtVer,
    });
    lockPredictUI(selections);
  });

  function lockPredictUI(data){
    document.querySelectorAll('#predict-list .predict-card').forEach((card, i)=>{
      const ev = CONFIG.PREDICT_EVENTS[i];
      const chosen = String(data[ev.id]);
      card.querySelectorAll('[data-opt]').forEach(o=>{
        o.style.pointerEvents = 'none';
        const isChosen = o.dataset.opt === chosen;
        o.classList.toggle('selected', isChosen);
        o.style.opacity = isChosen ? '1' : '0.5';
      });
    });
    submitBtn.setAttribute('disabled', 'true');
    submitBtn.textContent = '제출 완료';
    statusEl.classList.add('show');
    showPredictDone();
  }
  function showPredictDone(){
    const panel = list.closest('.seatmode-panel'); if(!panel || panel.querySelector('.predict-done')) return;
    panel.classList.add('is-done');
    const done = document.createElement('div');
    done.className = 'survey-done predict-done';
    done.innerHTML = `<span class="result-ic">${LI.checkCircle}</span>
      <h3>예측을 제출했어요</h3>
      <p>경기가 끝나면 정답과 결과를 알려드릴게요.</p>
      <button class="btn full" type="button" data-predict-home style="margin-top:20px;">홈 화면으로 이동</button>`;
    (document.getElementById('pq-head') || list).after(done);
    done.querySelector('[data-predict-home]').addEventListener('click', ()=>{ hapticTick(); navigate('home'); });
  }

})();

/* ===== 이벤트 · 경기 단계 ===== */
(function initMatchPhase(){
  const urlPhase = new URLSearchParams(location.search).get('phase');
  const forced = ['before', 'live'].includes(urlPhase) ? urlPhase
               : (['before', 'live'].includes(CONFIG.MATCH_PHASE) ? CONFIG.MATCH_PHASE : '');
  let start = CONFIG.MATCH.start ? new Date(CONFIG.MATCH.start) : null;
  let current = null;

  const cdEl = document.getElementById('predict-countdown');
  const predictPanel = document.querySelector('#pick-panels .seatmode-panel[data-key="predict"]');
  const mvpBtn = document.querySelector('.seatmode-toggle[data-toggle="pick"] .seatmode-btn[data-key="mvp"]');
  const predictBtn = document.querySelector('.seatmode-toggle[data-toggle="pick"] .seatmode-btn[data-key="predict"]');
  const note = document.createElement('p');
  note.className = 'phase-note';
  document.querySelector('.seatmode-toggle[data-toggle="pick"]').after(note);

  const livePhase = ()=>{ const p = (LIVE.state || {}).phase; return p === 'before' || p === 'live' ? p : ''; };
  let adminStart = false;
  const phase = ()=> forced || livePhase() || (start && Date.now() >= start.getTime() ? 'live' : 'before');
  window.__matchPhase = phase;
  LIVE.on('state', st=>{
    if(!st.start && adminStart && !CONFIG.MATCH.start){
      adminStart = false; start = null;
      if(window.__applySchedule) window.__applySchedule(STATS.games);
    }
    if(st.start && !CONFIG.MATCH.start){
      const d = new Date(st.start);
      if(!isNaN(d)){
        start = d; adminStart = true;
        if(!CONFIG.MATCH.date){
          document.getElementById('mb-date').textContent = fmtMatchDate(d, true);
          if(TEST_MATCH) document.getElementById('mb-venue').textContent = CONFIG.MATCH.venue;
        }
      }
    }
    current = null; apply();
  });

  const origSet = TOGGLES.pick.set;
  TOGGLES.pick.set = (key, silent)=>{
    if(key === 'mvp' && phase() === 'before'){ flashNote(); key = 'predict'; }
    origSet(key, silent);
  };
  mvpBtn.addEventListener('click', e=>{
    if(phase() === 'before'){ e.stopImmediatePropagation(); flashNote(); }
  }, true);

  let noteTimer = null;
  function flashNote(){
    note.textContent = 'MVP 투표는 경기가 시작되면 열려요.';
    note.classList.add('show'); clearTimeout(noteTimer);
    noteTimer = setTimeout(()=> note.classList.remove('show'), 2200);
  }

  const timeUp = ()=> !!(start && !isNaN(start) && Date.now() >= start.getTime());
  function apply(){
    const ph = phase(), pc = ph !== 'before' || timeUp();
    const key = ph + '|' + pc;
    if(key === current) return;
    const first = current === null;
    current = key;
    const before = ph === 'before';
    cdEl.textContent = before && !pc ? '경기 시작 전' : '예측 마감';
    if(before && !pc) setTimeout(()=> typeof tick === 'function' && tick(), 0);
    cdEl.classList.toggle('blink', before && !pc);
    mvpBtn.classList.toggle('locked', before);
    mvpBtn.setAttribute('aria-disabled', before);
    predictPanel.classList.toggle('closed', pc);
    if(pc && before){
      predictBtn.querySelector('.phase-done') || predictBtn.insertAdjacentHTML('beforeend', '<span class="phase-done">마감</span>');
    } else if(!before){
      predictBtn.querySelector('.phase-done') || predictBtn.insertAdjacentHTML('beforeend', '<span class="phase-done">마감</span>');
      origSet('mvp', true);
    } else {
      predictBtn.querySelector('.phase-done')?.remove();
      origSet('predict', true);
    }
    if(!first) document.dispatchEvent(new CustomEvent('wm:phase', { detail:{ phase: ph, predictClosed: pc } }));
  }
  apply();
  setInterval(apply, 15000);

  const p2 = n => String(n).padStart(2, '0');
  function tick(){
    if(phase() !== 'before') return;
    if(timeUp()){ apply(); return; }
    if(!start || isNaN(start)){ cdEl.textContent = '경기 시작 전'; return; }
    const left = Math.max(0, Math.floor((start.getTime() - Date.now()) / 1000));
    if(left >= 86400){ cdEl.textContent = `D-${Math.floor(left / 86400)}`; return; }
    cdEl.textContent = `${p2(Math.floor(left / 3600))} : ${p2(Math.floor(left % 3600 / 60))} : ${p2(left % 60)}`;
    if(left === 0) apply();
  }
  tick();
  setInterval(tick, 1000);

  window.__applySchedule = (games)=>{
    if(games && games.length){
      const t0 = new Date(); t0.setHours(0, 0, 0, 0);
      const todayG = games.find(x=> new Date(x.date + 'T00:00:00').getTime() === t0.getTime());
      window.__homeToday = !!(todayG && todayG.home);
      window.__matchRound = todayG && todayG.round ? todayG.round : '';
      const nh = games.filter(x=> x.home && new Date(x.date + 'T00:00:00') > t0).sort((a, b)=> a.date < b.date ? -1 : 1)[0];
      window.__nextHome = nh || null;
      window.__applyDayMode && window.__applyDayMode();
    }
    if(!games || !games.length || CONFIG.MATCH.start) return;
    if(TEST_MATCH) return;
    const keepStart = adminStart;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const day = g=> new Date(g.date + 'T00:00:00');
    // 홈경기 없는 날 — 매치 카드는 다음 홈경기 기준
    if(document.body.classList.contains('no-game')){
      const nh = window.__nextHome;
      if(nh){
        const d = day(nh);
        if(!window.__adminOpponent) document.getElementById('mb-away').textContent = nh.opponent;
        document.getElementById('mb-date').textContent = `${d.getMonth() + 1}.${d.getDate()} (${'일월화수목금토'[d.getDay()]})${nh.time ? ' ' + nh.time : ''}`;
        document.getElementById('mb-venue').textContent = CONFIG.MATCH.venue;
        if(!keepStart) start = new Date(`${nh.date}T${nh.time || '19:00'}:00`);
        window.__matchHome = true;
        current = null; apply();
        return;
      }
    }
    const g = games.find(x=> day(x).getTime() === today.getTime());
    if(!g){
      // 일정표에 오늘 경기가 없는데 운영하는 날(테스트 · 일정 미등록) — 다음 원정 경기 정보를 빌려오지 않고 홈경기로 보여줘요
      if(!keepStart){
        start = null;
        document.getElementById('mb-date').textContent = `${today.getMonth() + 1}.${today.getDate()} (${'일월화수목금토'[today.getDay()]})`;
      }
      document.getElementById('mb-venue').textContent = CONFIG.MATCH.venue;
      window.__matchHome = true;
      current = null; apply();
      return;
    }
    if(!keepStart) start = new Date(`${g.date}T${g.time || '19:00'}:00`);
    const d = day(g);
    if(!window.__adminOpponent) document.getElementById('mb-away').textContent = g.opponent;
    if(!keepStart){
      document.getElementById('mb-date').textContent =
        `${d.getMonth() + 1}.${d.getDate()} (${'일월화수목금토'[d.getDay()]})${g.time ? ' ' + g.time : ''}`;
      document.getElementById('mb-venue').textContent = g.home ? CONFIG.MATCH.venue : '원정 경기';
    }
    window.__matchHome = !!g.home;
    current = null; apply();
    window.__aiPredictRefresh && window.__aiPredictRefresh();
  };
})();

/* ===== 설문 ===== */
// 보기 순서 섞기 — 기기마다 다르지만 같은 사람에겐 늘 같은 순서 · '기타 · 해당 없음 · 모름'은 맨 뒤에 그대로
const SV_PIN = /^(기타|해당\s?없음|없음|모름|잘\s?모르겠|선택\s?안\s?함)/;
function svOrder(items, key){
  let h = 2166136261; const seed = String(LIVE.device || '') + '|' + key;
  for(let i = 0; i < seed.length; i++){ h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  const rnd = ()=>{ h = (Math.imul(h ^ (h >>> 15), 2246822507) + 0x6D2B79F5) >>> 0; return h / 4294967296; };
  const idx = items.map((_, i)=> i), free = idx.filter(i=> !SV_PIN.test(String(items[i]))), pin = idx.filter(i=> SV_PIN.test(String(items[i])));
  for(let i = free.length - 1; i > 0; i--){ const j = Math.floor(rnd() * (i + 1)); [free[i], free[j]] = [free[j], free[i]]; }
  return [...free, ...pin];
}
(function initSurvey(){
  const body = document.getElementById('survey-body');
  const progress = document.getElementById('survey-progress');
  const sub = document.querySelector('#view-survey .pagesub');
  const qs = CONFIG.SURVEY_QUESTIONS;
  const TXT_MAX = 200;
  let pos = 0, builtVer = 0;
  let A = {}, OTHER = {}, MEMO = {};

  function start(){
    builtVer = CONTENT.ver('survey');
    const d = LOCAL.survey_draft;
    if(d && d.ver === builtVer && d.n === qs.length){ A = d.A || {}; OTHER = d.OTHER || {}; MEMO = d.MEMO || {}; pos = d.pos || 0; }
    else { A = {}; OTHER = {}; MEMO = {}; pos = 0; }
    far = pos;
    if(sub) sub.textContent = `오늘 직관은 어떠셨나요? ${qs.length > 8 ? '2~3분' : '1분'}이면 충분해요.`;
    render();
  }
  function saveDraft(){ LOCAL.survey_draft = { ver:builtVer, n:qs.length, A, OTHER, MEMO, pos }; saveLocal(LOCAL); }

  let far = 0, sentSig = '';
  function noteProgress(){ far = Math.max(far, pos); }
  function sendProgress(){
    if(LOCAL['survey'] || !Object.keys(A).length) return;
    const list = visible(), q = list[Math.min(far, list.length - 1)];
    const data = { ver:builtVer, reached:far + 1, n:list.length, last:q ? q.id : '', answered:Object.keys(A).length };
    const sig = JSON.stringify(data); if(sig === sentSig) return;
    sentSig = sig; LIVE.beacon('survey_progress', data);
  }
  document.addEventListener('visibilitychange', ()=>{ if(document.hidden) sendProgress(); });
  window.addEventListener('pagehide', sendProgress);
  document.addEventListener('wm:nav', e=>{ if(e.detail.view !== 'survey') sendProgress(); });

  function condOk(c){
    if(!c) return true;
    const a = A[c.id]; if(a == null || a === '' || (Array.isArray(a) && !a.length)) return false;
    const vals = Array.isArray(a) ? a : [String(a)];
    if(c.in) return vals.some(v=> c.in.includes(v));
    if(c.notIn) return !vals.every(v=> c.notIn.includes(v));
    return true;
  }
  const visible = ()=> qs.filter(q=> condOk(q.cond));
  function answered(q){
    const a = A[q.id];
    if(q.type === 'multi') return Array.isArray(a) && a.length > 0;
    if(q.type === 'grid') return !!a && (q.rows || []).every((_, r)=> a[r] != null);
    if(q.type === 'nps') return typeof a === 'number';
    return a != null && a !== '';
  }

  function optHtml(q){
    const a = A[q.id];
    if(q.type === 'nps'){
      return `<div class="nps" role="radiogroup" aria-label="${escHtml(q.q)}">${Array.from({ length:11 }, (_, n)=>
        `<button type="button" class="nps__b${a === n ? ' selected' : ''}" data-n="${n}" role="radio" aria-checked="${a === n}">${n}</button>`).join('')}</div>
        <div class="nps__l"><span>0 ${escHtml(q.low || '')}</span><span>10 ${escHtml(q.high || '')}</span></div>`;
    }
    if(q.type === 'grid'){
      const done = (q.rows || []).filter((_, r)=> a && a[r] != null).length;
      const rowOrder = q.shuffleRows ? svOrder(q.rows, q.id + ':rows') : q.rows.map((_, r)=> r);
      return `<p class="qhint">항목마다 하나씩 골라주세요 <b>${done}/${q.rows.length}</b></p>` + rowOrder.map(r=> [q.rows[r], r]).map(([row, r])=> `
        <div class="sg">
          <p class="sg__t">${escHtml(row)}</p>
          <div class="sg__c" role="radiogroup" aria-label="${escHtml(row)}" style="--n:${q.cols.length}">${q.cols.map((c, ci)=>
            `<button type="button" class="sg__b${a && a[r] === ci ? ' selected' : ''}" data-r="${r}" data-c="${ci}" role="radio" aria-checked="${!!(a && a[r] === ci)}">${escHtml(c)}</button>`).join('')}</div>
        </div>`).join('');
    }
    const multi = q.type === 'multi';
    const sel = multi ? (a || []) : [a];
    let h = multi ? `<p class="qhint">${q.max ? `최대 ${q.max}개까지` : '여러 개'} 고를 수 있어요${q.max ? ` <b>${sel.length}/${q.max}</b>` : ''}</p>` : '';
    const opts = q.shuffle ? svOrder(q.options, q.id).map(k=> q.options[k]) : q.options;
    h += `<div class="opt-grid">${opts.map(o=> `<div class="opt${multi ? ' multi' : ''}${sel.includes(o) ? ' selected' : ''}" data-opt="${escHtml(o)}" role="${multi ? 'checkbox' : 'radio'}" aria-checked="${sel.includes(o)}" tabindex="0"><span>${escHtml(o)}</span><span class="check"></span></div>`).join('')}</div>`;
    if(q.other && sel.includes('기타')) h += `<input class="glass-input sv-text" data-other maxlength="${TXT_MAX}" placeholder="기타 내용을 적어주세요" value="${escHtml(OTHER[q.id] || '')}">`;
    if(q.comment) h += `<textarea class="glass-input sv-text sv-memo" data-memo maxlength="${TXT_MAX}" rows="3" placeholder="더 하고 싶은 말이 있으면 적어주세요 (선택)">${escHtml(MEMO[q.id] || '')}</textarea>`;
    return h;
  }

  function render(focus, still, tapped){
    const list = visible();
    if(pos >= list.length) pos = list.length - 1;
    const q = list[pos];
    const last = pos === list.length - 1;
    body.innerHTML = `<div class="survey-q active${still ? ' still' : ''}" data-id="${escHtml(q.id)}">
      <div class="qnum">${pos + 1} / ${list.length}${pos === 0 ? ' · <button class="data-link" type="button" data-privacy>데이터 안내</button>' : ''}</div>
      <p class="qtext">${escHtml(q.q)}</p>
      ${optHtml(q)}
      <div class="survey-nav">
        ${pos > 0 ? '<button class="btn ghost" data-nav="prev">이전</button>' : ''}
        <button class="btn" data-nav="next"${answered(q) ? '' : ' disabled'}>${last ? '제출하기' : '다음'}</button>
      </div>
    </div>`;
    progress.style.width = `${Math.round(((pos + 1) / list.length) * 100)}%`;
    if(focus){ const el = body.querySelector(focus); if(el){ el.focus(); const v = el.value; el.value = ''; el.value = v; } }
    if(tapped){ const el = body.querySelector(tapped); if(el && el.classList.contains('selected')) el.style.animation = 'optPulse .4s var(--ease-spring)'; }
  }
  function flashHint(text){
    const h = body.querySelector('.qhint'); if(!h) return;
    const keep = h.innerHTML; h.textContent = text; h.classList.add('warn');
    setTimeout(()=>{ if(h.isConnected){ h.innerHTML = keep; h.classList.remove('warn'); } }, 1600);
  }

  body.addEventListener('click', async e=>{
    const wrap = body.querySelector('.survey-q'); if(!wrap) return;
    const q = qs.find(x=> x.id === wrap.dataset.id); if(!q) return;
    const nav = e.target.closest('[data-nav]');
    if(nav){
      if(nav.dataset.nav === 'prev'){ hapticTick(); pos = Math.max(0, pos - 1); saveDraft(); render(); window.scrollTo({ top:0 }); return; }
      if(!answered(q)) return;
      const list = visible();
      if(pos < list.length - 1){ hapticTick(); pos++; noteProgress(); saveDraft(); render(); window.scrollTo({ top:0 }); return; }
      return submit(list);
    }
    const o = e.target.closest('.opt'), n = e.target.closest('.nps__b'), g = e.target.closest('.sg__b');
    if(o){
      const v = o.dataset.opt;
      if(q.type === 'multi'){
        const cur = A[q.id] || [];
        if(cur.includes(v)) A[q.id] = cur.filter(x=> x !== v);
        else if(q.max && cur.length >= q.max){ flashHint(`최대 ${q.max}개까지 고를 수 있어요`); if(canVibrate()) navigator.vibrate([10, 30, 10]); return; }
        else A[q.id] = [...cur, v];
      } else A[q.id] = v;
      hapticTick();
    } else if(n){ A[q.id] = Number(n.dataset.n); hapticTick(); }
    else if(g){ A[q.id] = { ...(A[q.id] || {}), [g.dataset.r]:Number(g.dataset.c) }; hapticTick(); }
    else return;
    qs.forEach(x=>{ if(x.cond && !condOk(x.cond)) { delete A[x.id]; delete OTHER[x.id]; delete MEMO[x.id]; } });
    saveDraft();
    const pickedOther = o && q.other && o.dataset.opt === '기타' && (A[q.id] === '기타' || (Array.isArray(A[q.id]) && A[q.id].includes('기타')));
    const tapped = o ? `.opt[data-opt="${CSS.escape(o.dataset.opt)}"]` : n ? `.nps__b[data-n="${n.dataset.n}"]` : `.sg__b[data-r="${g.dataset.r}"][data-c="${g.dataset.c}"]`;
    render(pickedOther ? '[data-other]' : null, true, tapped);
  });
  body.addEventListener('input', e=>{
    const wrap = body.querySelector('.survey-q'); if(!wrap) return;
    const id = wrap.dataset.id;
    if(e.target.matches('[data-other]')) OTHER[id] = e.target.value.slice(0, TXT_MAX);
    else if(e.target.matches('[data-memo]')) MEMO[id] = e.target.value.slice(0, TXT_MAX);
    else return;
    clearTimeout(body._t); body._t = setTimeout(saveDraft, 400);
  });
  body.addEventListener('keydown', e=>{
    if((e.key === 'Enter' || e.key === ' ') && e.target.matches('.opt')){ e.preventDefault(); e.target.click(); }
  });

  async function submit(list){
    const out = [];
    list.forEach(q=>{
      const a = A[q.id];
      if(q.type === 'grid') q.rows.forEach((row, r)=> out.push({ id:`${q.id}:${r}`, group:q.id, type:'grid', q:`${q.q} · ${row}`, a:q.cols[a[r]], score:a[r] + 1 }));
      else {
        const x = { id:q.id, type:q.type, q:q.q, a };
        const other = (OTHER[q.id] || '').trim(), memo = (MEMO[q.id] || '').trim();
        if(other && (a === '기타' || (Array.isArray(a) && a.includes('기타')))) x.etc = other;
        if(memo) x.memo = memo;
        out.push(x);
      }
    });
    const btn = body.querySelector('[data-nav="next"]'); if(btn){ btn.disabled = true; btn.textContent = '보내는 중…'; }
    LOCAL['survey'] = A; delete LOCAL.survey_draft; saveLocal(LOCAL);
    await postData('survey', A).catch(()=>{});
    LIVE.submit('survey', { answers: out, ver: builtVer });
    renderDone();
  }

  CONTENT.onChange(()=>{
    if(LOCAL['survey'] || Object.keys(A).length) return;
    start();
  });

  if(LOCAL['survey']) renderDone(); else start();

  function renderDone(){
    progress.style.width = '100%';
    body.innerHTML = `<div class="survey-done">
      <span class="result-ic">${LI.checkCircle}</span>
      <h3>설문에 참여해주셔서 감사해요</h3>
      <p>다음 경기에서 더 나은 직관 경험으로 찾아올게요.</p>
      <button class="btn full" id="survey-home" style="margin-top:20px;">홈 화면으로 이동</button>
    </div>`;
    document.getElementById('survey-home').addEventListener('click', ()=>{ hapticTick(); navigate('home'); });
  }
})();

/* ===== 이벤트 · MVP 투표 ===== */
(function initMVP(){
  const list = document.getElementById('mvp-list');
  const note = document.getElementById('mvp-note');
  let voted = LOCAL['mvp_voted'];
  const counts = LOCAL['mvp_counts'] || {};
  let picked = null;
  const candidates = () => (CONFIG.MVP_CANDIDATES && CONFIG.MVP_CANDIDATES.length)
    ? PLAYERS.filter(p=> CONFIG.MVP_CANDIDATES.includes(p.num))
    : PLAYERS;

  window.__mvpRefresh = ()=>{ if(!voted && list.querySelector('.mvp-grid')) renderPicker(); };
  function renderPicker(){
    list.innerHTML = `
      <div class="mvp-grid">${candidates().map(p=> `
        <button class="pick-player${picked === p.num ? ' selected' : ''}" data-num="${p.num}" aria-label="${playerName(p)}">
          ${pickBoxHtml(p)}
          <span class="pick-player__p">#${p.num} · ${POS[p.pos] ? POS[p.pos].chip : p.pos}</span>
        </button>`).join('')}
      </div>
      <button class="btn full mvp-confirm" id="mvp-confirm" ${picked ? '' : 'disabled'}>
        ${picked ? `${playerName(playerByNum(picked))}에게 투표하기` : '선수를 골라주세요'}
      </button>`;
    note.textContent = '경기 중 오늘의 MVP에게 투표해 주세요. 선수 한 명에게만 투표할 수 있어요.';
    watchBar(document.getElementById('mvp-confirm'));

    list.querySelectorAll('.pick-player').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        hapticTick();
        picked = +btn.dataset.num;
        list.querySelectorAll('.pick-player').forEach(b=> b.classList.toggle('selected', b === btn));
        btn.classList.remove('pulse'); void btn.offsetWidth; btn.classList.add('pulse');
        const c = document.getElementById('mvp-confirm');
        c.removeAttribute('disabled');
        c.textContent = `${playerName(playerByNum(picked))}에게 투표하기`;
      });
    });
    document.getElementById('mvp-confirm').addEventListener('click', async ()=>{
      if(!picked || voted) return;
      if(canVibrate()) navigator.vibrate(25);
      counts[picked] = (counts[picked] || 0) + 1;
      voted = picked;
      LOCAL['mvp_counts'] = counts;
      LOCAL['mvp_voted'] = voted;
      saveLocal(LOCAL);
      await postData('mvp_counts', counts);
      LIVE.submit('mvp', { num:picked, name:playerName(playerByNum(picked)) });
      render();
    });
  }

  let barIO = null, barEl = null, barOn = false, barRaf = 0;
  const fab = document.querySelector('.cheer-fab'), phrase = document.querySelector('.cheer-phrase');
  function placeFab(){
    barRaf = 0;
    if(!fab) return;
    if(!barOn || !barEl){ fab.style.bottom = ''; if(phrase) phrase.style.bottom = ''; return; }
    fab.style.bottom = '';
    const base = parseFloat(getComputedStyle(fab).bottom) || 0;
    const r = barEl.getBoundingClientRect();
    const need = innerHeight - r.top + 12;
    const fr = fab.getBoundingClientRect();
    const hit = fr.left < r.right && fr.right > r.left;
    const b = hit ? Math.max(base, need) : base;
    fab.style.bottom = b + 'px';
    if(phrase) phrase.style.bottom = (b + 78) + 'px';
  }
  const queueFab = ()=>{ if(barOn && !barRaf) barRaf = requestAnimationFrame(placeFab); };
  addEventListener('scroll', queueFab, { passive:true, capture:true });
  addEventListener('resize', queueFab);
  function watchBar(el){
    if(barIO) barIO.disconnect();
    barEl = el; barOn = false; placeFab();
    if(!el || !('IntersectionObserver' in window)) return;
    barIO = new IntersectionObserver(([e])=>{ barOn = e.isIntersecting; placeFab(); });
    barIO.observe(el);
  }

  function renderResult(){
    watchBar(null);
    list.innerHTML = `
      <div class="mvp-grid mvp-voted">${candidates().map(p=> `
        <div class="pick-player${p.num === voted ? ' selected mine' : ''}" aria-label="${playerName(p)}${p.num === voted ? ' (내 투표)' : ''}">
          ${pickBoxHtml(p)}
          <span class="pick-player__p">${p.num === voted ? '<span class="mine-badge">내 투표</span>' : `#${p.num} · ${POS[p.pos] ? POS[p.pos].chip : p.pos}`}</span>
        </div>`).join('')}
      </div>
      <button class="btn full mvp-confirm" disabled>투표 완료</button>`;
    note.textContent = `${playerName(playerByNum(voted))} 선수에게 투표했어요. MVP는 경기가 끝나면 발표해요.`;
  }

  function render(){ voted ? renderResult() : renderPicker(); }
  render();

  window.__mvpPreselect = (num)=>{
    if(voted) return;
    picked = num; renderPicker();
    const el = list.querySelector(`.pick-player[data-num="${num}"]`);
    if(el) setTimeout(()=> el.scrollIntoView({ behavior:'smooth', block:'center' }), 120);
  };
})();

/* ===== 막차 안내 · 토스트 ===== */
(function initSubway(){
  const SW = CONFIG.SUBWAY;
  const listEl = document.getElementById('subway-list');
  const noteEl = document.getElementById('subway-config-note');
  const toastEl = document.getElementById('subway-toast');
  const toastDesc = document.getElementById('toast-desc');
  let toastDismissed = false;
  let TT = null;
  let ttSource = '';

  const pad = n => String(n).padStart(2, '0');
  const fmt = min => { const h = Math.floor(min / 60), m = min % 60; return h >= 24 ? `${pad(h - 24)}:${pad(m)} (익일)` : `${pad(h)}:${pad(m)}`; };
  const toMin = hhmm => { const [h, m] = String(hhmm).split(':').map(Number); return h * 60 + m; };
  function nowSec(){ const d = new Date(); let s = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds(); if(d.getHours() < 4) s += 86400; return s; }
  const lastOf = l => (TT && TT[l.updown] && TT[l.updown].length) ? Math.max(...TT[l.updown]) : toMin(l.last);

  const SW_TRAIN = '<svg viewBox="0 0 32 24" fill="none"><rect x="1" y="2" width="30" height="17" rx="6" fill="currentColor"/><rect x="5" y="6" width="9" height="6" rx="1.6" fill="#fff" opacity=".92"/><rect x="18" y="6" width="9" height="6" rx="1.6" fill="#fff" opacity=".92"/><circle cx="8" cy="21" r="2" fill="#6C7080"/><circle cx="24" cy="21" r="2" fill="#6C7080"/></svg>';
  listEl.innerHTML = SW.lines.map((l, i)=> `
    <section class="st-card" data-i="${i}" style="--dc:${escHtml(l.color || '#BB8C00')}" aria-live="polite">
      <div class="st-card__head">
        <span class="st-line">${escHtml(l.tag)}</span>
        <b class="st-station">${escHtml(SW.station)}</b>
        <span class="st-kind">지하철</span>
      </div>
      <p class="st-dir"><b>${escHtml(l.dir)}</b><span class="st-dir__arrow" aria-hidden="true">→</span></p>
      <div class="sw-track" aria-hidden="true">
        <span class="sw-rail"></span>
        <span class="sw-end l"><i></i><small>이전역</small><b>${escHtml(l.prev || '')}</b></span>
        <span class="sw-stop"><i></i><b>${escHtml(SW.station.replace(/역$/, ''))}</b></span>
        <span class="sw-end r"><i></i><small>다음역</small><b>${escHtml(l.next || '')}</b></span>
        <span class="sw-train in" data-in hidden>${SW_TRAIN}<small data-in-l></small></span>
        <span class="sw-train out" data-out hidden>${SW_TRAIN}<small data-out-l></small></span>
      </div>
      <div class="st-foot">
        <p class="st-eta" data-eta>도착 정보 확인 중…</p>
        <p class="st-next" data-next></p>
      </div>
    </section>`).join('');
  noteEl.textContent = '';

  function render(){
    const now = nowSec();
    SW.lines.forEach((l, i)=>{
      const card = listEl.querySelector(`.st-card[data-i="${i}"]`); if(!card) return;
      const etaEl = card.querySelector('[data-eta]'), nextEl = card.querySelector('[data-next]');
      const times = TT && TT[l.updown];
      const last = lastOf(l);
      card.classList.toggle('soon', last * 60 - now <= 30 * 60 && last * 60 - now >= 0);
      const inEl = card.querySelector('[data-in]'), outEl = card.querySelector('[data-out]');
      if(!times || !times.length){
        etaEl.textContent = '도착 정보 준비 중';
        nextEl.textContent = `막차 ${fmt(last)}`;
        card.classList.add('idle'); inEl.hidden = outEl.hidden = true;
        return;
      }
      card.classList.remove('idle');
      const gone = times.filter(t => t * 60 < now - 20);
      const dep = gone.length ? gone[gone.length - 1] * 60 + 20 : null;
      const since = dep == null ? Infinity : now - dep;
      outEl.hidden = since > 300;
      if(!outEl.hidden){
        outEl.style.setProperty('--x', String(50 + 50 * Math.min(1, since / 180)));
        card.querySelector('[data-out-l]').textContent = since < 60 ? '방금 출발' : `${Math.floor(since / 60)}분 전 출발`;
      }
      const up = times.filter(t => t * 60 >= now - 20);
      if(!up.length){ etaEl.textContent = '오늘 운행이 끝났어요'; nextEl.textContent = `막차 ${fmt(last)}`; inEl.hidden = true; return; }
      const left = up[0] * 60 - now;
      const m = Math.ceil(left / 60);
      etaEl.textContent = left <= 30 ? '곧 도착해요' : `${m}분 후 도착 예정`;
      etaEl.classList.toggle('now', left <= 60);
      inEl.hidden = false;
      inEl.style.setProperty('--x', String(Math.max(0, 50 * (1 - left / 300))));
      card.querySelector('[data-in-l]').textContent = left <= 30 ? '곧 도착' : `${m}분 후`;
      const after = up.slice(1, 3).filter(t => t !== last).map(fmt).join(' · ');
      nextEl.textContent = `${after ? '다음 ' + after + ' · ' : ''}막차 ${fmt(last)}`;
    });

    if(SW.alertAfter && !toastDismissed && now >= toMin(SW.alertAfter) * 60){
      const lines = SW.lines.map(l => ({ l, last:lastOf(l) })).filter(x => x.last * 60 >= now);
      const tag = (SW.lines[0] || {}).tag || '지하철';
      toastDesc.textContent = !lines.length ? '오늘 지하철 운행이 끝났어요.'
        : lines.length === 1 ? `${tag} 막차는 ${fmt(lines[0].last)}까지 있어요.`
        : `${tag} 막차는 ${lines.map(x => `${x.l.dir.replace(/\s*방면$/, '').split('∙').pop().trim()} 방면 ${fmt(x.last)}`).join(', ')}까지 있어요.`;
      toastEl.classList.add('show');
    }
  }

  async function loadTimetable(){
    if(!CONFIG.LIVE_API || LIVE.demo) return;
    try{
      const r = await fetch(`${CONFIG.LIVE_API}/live/_/subway?scode=${encodeURIComponent(SW.scode || '')}`);
      const d = await r.json();
      if(d && d.lines){ TT = d.lines; ttSource = d.source || ''; }
      noteEl.textContent = d && d.lines ? `${SW.station} 열차 시각표 기준이에요. 실제 도착은 조금 다를 수 있어요.` : '';
    }catch(e){}
    render();
  }

  document.getElementById('toast-close').addEventListener('click', ()=>{ toastDismissed = true; toastEl.classList.remove('show'); });
  document.getElementById('toast-action').addEventListener('click', ()=>{
    toastEl.classList.remove('show'); toastDismissed = true;
    navigate('guide', 'lastrain');
  });

  render();
  loadTimetable();
  setInterval(render, 1000);
  setInterval(loadTimetable, 10 * 60 * 1000);
})();

/* ===== 응원 버튼 ===== */
(function initCheerFab(){
  const btn = document.getElementById('cheer-fab');
  const badge = document.getElementById('cheer-badge');
  const phraseEl = document.getElementById('cheer-phrase');
  if(!btn) return;

  const CHEER_KEY = 'cheer_count';
  let count = LOCAL[CHEER_KEY] || 0;

  const ORDER_KEY = 'cheer_order';
  const short = n=> n >= 100000 ? `${(Math.floor(n / 1000) / 10).toLocaleString()}만` : n.toLocaleString();
  function renderBadge(){
    const n = Number(LOCAL[ORDER_KEY]) || 0;
    if(n > 0){
      badge.textContent = short(n);
      badge.classList.add('show');
      btn.setAttribute('aria-label', `응원하기 · 오늘 전체 ${n.toLocaleString()}번째 응원`);
    }
  }
  renderBadge();
  LIVE.on('cheerreset', ()=>{
    count = 0; badge.classList.remove('show'); badge.textContent = '';
    btn.setAttribute('aria-label', '응원하기');
  });

  const PHRASES = ['가자 읏맨!','파이팅!','오늘 이긴다!','읏맨 파이팅!','다 덤벼!','불꽃 응원 중!'];
  const BIG_PHRASES = ['우리가 읏맨이다!','끝까지 간다 읏맨!','부산의 자존심 읏맨!','오늘 승리는 읏맨 거!','읏맨 사랑해!'];
  const COLORS = ['#FFD339','#FFC815','#FFB431','#FFE066','#F5B800'];
  const HOLD_MS = 600;
  const HINT_KEY = 'cheer_hold_hint';
  let phraseTimer = null, holdTimer = null, holdFired = false;

  function burstConfetti(x, y, opt = {}){
    const n = opt.count || 14, base = opt.dist || 46, spread = opt.spread || 64;
    const smin = opt.sizeMin || 5, sr = opt.sizeRange || 5;
    for(let i = 0; i < n; i++){
      const p = document.createElement('span');
      p.className = 'cheer-particle';
      const angle = Math.random() * Math.PI * 2;
      const dist = base + Math.random() * spread;
      const dx = Math.cos(angle) * dist;
      const dy = Math.sin(angle) * dist - 24;
      const size = smin + Math.random() * sr;
      p.style.setProperty('--dx', dx + 'px');
      p.style.setProperty('--dy', dy + 'px');
      p.style.setProperty('--rot', (Math.random() * 360) + 'deg');
      p.style.width = size + 'px';
      p.style.height = (size * (0.8 + Math.random() * 0.4)) + 'px';
      p.style.left = x + 'px';
      p.style.top = y + 'px';
      p.style.background = COLORS[Math.floor(Math.random() * COLORS.length)];
      document.body.appendChild(p);
      setTimeout(()=> p.remove(), 1000);
    }
  }

  function showPhrase(text, big, ms){
    phraseEl.textContent = text;
    phraseEl.classList.toggle('big', !!big);
    phraseEl.classList.remove('show'); void phraseEl.offsetWidth;
    phraseEl.classList.add('show');
    clearTimeout(phraseTimer);
    phraseTimer = setTimeout(()=> phraseEl.classList.remove('show'), ms);
  }

  function addCount(){
    count++;
    LOCAL[CHEER_KEY] = count; saveLocal(LOCAL);
    LIVE.tap(1);
  }
  LIVE.on('optimistic', n=>{
    badge.textContent = short(n); badge.classList.add('show');
  });
  LIVE.on('total', res=>{
    LOCAL[ORDER_KEY] = Math.max(Number(LOCAL[ORDER_KEY]) || 0, res.to || res.total); saveLocal(LOCAL);
    renderBadge();
    badge.classList.remove('bump'); void badge.offsetWidth; badge.classList.add('bump');
  });

  function center(){
    const r = btn.getBoundingClientRect();
    return [r.left + r.width / 2, r.top + r.height / 2];
  }

  const ballEl = document.getElementById('cheer-ball');
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const IDLE = 0;
  let ang = 0, vel = IDLE, charging = false, spinRaf = 0, lastT = 0;
  function spin(t){
    const dt = lastT ? Math.min(3, (t - lastT) / 16.67) : 1; lastT = t;
    if(charging && !calm) vel = Math.min(48, vel + 1.6 * dt);
    else vel = IDLE + (vel - IDLE) * Math.pow(0.955, dt);
    ang = (ang + vel * dt) % 360;
    if(ballEl) ballEl.style.transform = `rotate(${ang.toFixed(1)}deg)`;
    btn.classList.toggle('fast', vel > 14 && vel <= 30);
    btn.classList.toggle('faster', vel > 30);
    if(!charging && vel < 0.05){ vel = 0; spinRaf = 0; btn.classList.remove('fast', 'faster'); return; }
    spinRaf = requestAnimationFrame(spin);
  }
  function kick(v){ vel = Math.min(60, Math.max(vel, IDLE) + v); if(!spinRaf){ lastT = 0; spinRaf = requestAnimationFrame(spin); } }
  if(ballEl) ballEl.style.transform = 'rotate(0deg)';

  function cheer(){
    kick(calm ? 0 : 16);
    addCount();
    btn.classList.remove('tapped'); void btn.offsetWidth; btn.classList.add('tapped');
    if(canVibrate()) navigator.vibrate(25);
    const [x, y] = center();
    burstConfetti(x, y);
    if(count >= 3 && !LOCAL[HINT_KEY]){
      LOCAL[HINT_KEY] = true; saveLocal(LOCAL);
      showPhrase('꾹 누르면 더 크게!', false, 1600);
    } else {
      showPhrase(PHRASES[Math.floor(Math.random() * PHRASES.length)], false, 1100);
    }
  }

  function megaCheer(){
    addCount();
    charging = false; kick(calm ? 0 : 40);
    btn.classList.remove('charging', 'tapped'); void btn.offsetWidth; btn.classList.add('mega');
    setTimeout(()=> btn.classList.remove('mega'), 700);
    if(canVibrate()) navigator.vibrate([30, 40, 60]);
    const [x, y] = center();
    burstConfetti(x, y, { count:30, dist:70, spread:110, sizeMin:7, sizeRange:6 });
    setTimeout(()=> burstConfetti(x, y, { count:18, dist:40, spread:80, sizeMin:5, sizeRange:5 }), 160);
    showPhrase(BIG_PHRASES[Math.floor(Math.random() * BIG_PHRASES.length)], true, 1900);
  }

  function cancelHold(){
    clearTimeout(holdTimer);
    charging = false;
    btn.classList.remove('charging');
  }
  btn.addEventListener('pointerdown', (e)=>{
    if(e.button !== undefined && e.button !== 0) return;
    holdFired = false;
    btn.classList.add('charging');
    charging = true; kick(0);
    holdTimer = setTimeout(()=>{ holdFired = true; megaCheer(); }, HOLD_MS);
  });
  ['pointerup','pointerleave','pointercancel'].forEach(ev=> btn.addEventListener(ev, cancelHold));
  btn.addEventListener('contextmenu', e=> e.preventDefault());
  btn.addEventListener('click', (e)=>{
    if(holdFired){ holdFired = false; e.preventDefault(); return; }
    cheer();
  });
})();

/* ===== 현장 이벤트 · 응원 당첨 ===== */
(function initLiveEvents(){
  const box = document.getElementById('live-events');
  const list = document.getElementById('live-event-list');
  const pop = document.getElementById('ev-pop');
  const popBody = document.getElementById('ev-pop-body');
  const winLink = document.getElementById('cheer-win-link');
  const PIN = '<svg viewBox="0 0 24 24" fill="none"><path fill="currentColor" fill-rule="evenodd" d="M12 1.5C7.3 1.5 3.5 5.2 3.5 9.9c0 5.6 6.4 11.2 7.6 12.2.5.4 1.3.4 1.8 0 1.2-1 7.6-6.6 7.6-12.2 0-4.7-3.8-8.4-8.5-8.4Zm0 5.25a3.25 3.25 0 1 0 0 6.5 3.25 3.25 0 0 0 0-6.5Z"/></svg>';
  const esc = v=> String(v || '').replace(/[&<>"]/g, c=> ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));
  const hm = v=>{ const d = new Date(v); return isNaN(d) ? '' : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const live = e=>{
    const now = Date.now();
    if(e.active === false) return false;
    if(e.startsAt && now < new Date(e.startsAt).getTime()) return false;
    if(e.endsAt && now > new Date(e.endsAt).getTime()) return false;
    return true;
  };
  const card = e=> `<div class="ev-card">
      <div class="ev-top">${e.limit ? `<span class="ev-limit">${esc(e.limit)}</span>` : ''}${e.endsAt ? `<span class="ev-time">${hm(e.endsAt)}까지</span>` : ''}</div>
      <p class="ev-title">${esc(e.title)}</p>
      ${e.place ? `<p class="ev-place">${PIN}${esc(e.place)}</p>` : ''}
      ${e.desc ? `<p class="ev-desc">${esc(e.desc)}</p>` : ''}
    </div>`;

  function render(st){
    const events = (st.events || []).filter(live);
    box.hidden = !events.length;
    list.innerHTML = events.map(card).join('');
    const seen = new Set(LOCAL.seen_events || []);
    const fresh = events.filter(e=> !seen.has(e.id));
    if(fresh.length && !pop.classList.contains('show')){
      popBody.innerHTML = fresh.map(card).join('');
      pop.classList.add('show');
      if(canVibrate()) navigator.vibrate([20, 40, 20]);
      LOCAL.seen_events = [...seen, ...fresh.map(e=> e.id)].slice(-50); saveLocal(LOCAL);
    }
  }
  LIVE.on('state', render);
  setInterval(()=> render(LIVE.state), 30000);
  document.getElementById('ev-pop-ok').addEventListener('click', ()=> pop.classList.remove('show'));

  const cw = document.getElementById('cw-pop');
  function showWin(w){
    document.getElementById('cw-n').textContent = Number(w.n).toLocaleString();
    document.getElementById('cw-prize').textContent = w.prize || '';
    document.getElementById('cw-place').textContent = w.place ? `수령 장소 · ${w.place}` : '';
    document.getElementById('cw-code').textContent = w.code || '----';
    cw.classList.add('show');
    if(canVibrate()) navigator.vibrate([40, 60, 40, 60, 80]);
  }
  function renderWinLink(){
    const wins = LOCAL.cheer_wins || [];
    winLink.hidden = !wins.length;
    if(wins.length) winLink.textContent = `응원 이벤트 당첨 교환권 보기 (${wins.length})`;
  }
  LIVE.on('win', w=>{ showWin(w); renderWinLink(); });
  winLink.addEventListener('click', ()=>{ const w = (LOCAL.cheer_wins || []).slice(-1)[0]; if(w) showWin(w); });
  document.getElementById('cw-ok').addEventListener('click', ()=> cw.classList.remove('show'));
  renderWinLink();
})();

/* ===== 홈 · 직관 미션 ===== */
(function initMissions(){
  const cardEl = document.getElementById('mission-card');
  const listEl = document.getElementById('mission-list');
  const subEl = document.getElementById('mission-sub');
  const ringFg = document.getElementById('mission-ring-fg');
  const ringLabel = document.getElementById('mission-ring-label');
  if(!listEl) return;

  const MISSION_ICON = { checkin:LI.calCheck, seats:LI.chair, predict:LI.chart, survey:LI.clip, mvp:LI.trophy, fortune:LI.star, raffle:LI.gift };
  const MISSION_DEF = {
    checkin: { icon:MISSION_ICON.checkin, label:'출석체크' },
    seats:   { icon:MISSION_ICON.seats,   label:'좌석확인' },
    fortune: { icon:MISSION_ICON.fortune, label:'오늘의선수' },
    survey:  { icon:MISSION_ICON.survey,  label:'설문조사' },
    predict: { icon:MISSION_ICON.predict, label:'경기예측' },
    raffle:  { icon:MISSION_ICON.raffle,  label:'경품응모' },
  };
  const DEFAULT_ORDER = ['checkin','seats','fortune','survey','predict','raffle'];
  const RAFFLE_NEED = 5;
  const MISSIONS = DEFAULT_ORDER.map(id=> ({ id, ...MISSION_DEF[id] }));
  const JUMP = { seats:['guide'], predict:['pick','predict'], survey:['survey'] };
  const LOCK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
  const isLive = ()=> window.__matchPhase && window.__matchPhase() === 'live';
  const CIRC = 2 * Math.PI * 17;
  ringFg.style.strokeDasharray = `${CIRC}`;

  function isDone(id){
    switch(id){
      case 'checkin':    return !!(LOCAL.checkin && LOCAL.checkin.done);
      case 'seats':      return !!LOCAL.visited_seats;
      case 'fortune':    return !!LOCAL.fortune_seen;
      case 'raffle':     return hasEnteredRaffle();
      case 'predict':    return !!LOCAL.predictions || !!LOCAL.mvp_voted;
      case 'survey':     return !!LOCAL.survey;
      case 'mvp':        return !!LOCAL.mvp_voted;
      default:           return false;
    }
  }

  function burstConfettiAt(x, y){
    const colors = ['#FF571F','#FF7A4E','#FFD339','#161C26','#ffffff'];
    for(let i = 0; i < 22; i++){
      const p = document.createElement('span');
      p.style.cssText = 'position:fixed; z-index:60; border-radius:2px; pointer-events:none;';
      const angle = Math.random() * Math.PI * 2;
      const dist = 60 + Math.random() * 120;
      const dx = Math.cos(angle) * dist;
      const dy = Math.sin(angle) * dist - 40;
      const size = 5 + Math.random() * 6;
      p.style.width = size + 'px'; p.style.height = size + 'px';
      p.style.left = x + 'px'; p.style.top = y + 'px';
      p.style.background = colors[Math.floor(Math.random() * colors.length)];
      p.style.setProperty('--dx', dx + 'px');
      p.style.setProperty('--dy', dy + 'px');
      p.style.setProperty('--rot', (Math.random() * 360) + 'deg');
      p.style.animation = 'cheerFly 1s var(--ease-out) forwards';
      document.body.appendChild(p);
      setTimeout(()=> p.remove(), 1050);
    }
  }

  function celebrateComplete(){
    if(canVibrate()) navigator.vibrate([30,40,30]);
    const rect = cardEl.getBoundingClientRect();
    burstConfettiAt(rect.left + rect.width / 2, rect.top + 30);
    const banner = document.createElement('div');
    banner.className = 'mission-complete-banner';
    banner.textContent = '오늘 직관 미션 완료! 끝까지 함께해주셔서 감사해요';
    cardEl.appendChild(banner);
    requestAnimationFrame(()=> banner.classList.add('show'));
    setTimeout(()=>{ banner.classList.remove('show'); setTimeout(()=> banner.remove(), 350); }, 3600);
  }

  const baseDone = ()=> MISSIONS.filter(m=> m.id !== 'raffle' && isDone(m.id)).length;
  window.__raffleState = ()=>{ const d = baseDone(); return { need:RAFFLE_NEED, done:Math.min(RAFFLE_NEED, d), open:d >= RAFFLE_NEED }; };

  let lastHtml = '';
  let prevDone = null;
  let prevRaffleOpen = null;
  let raffleCelebrate = false;
  document.addEventListener('raffle:cardclose', ()=>{
    if(!raffleCelebrate) return; raffleCelebrate = false;
    const el = listEl.querySelector('[data-mission="raffle"]'); if(!el) return;
    if(!document.getElementById('view-home').classList.contains('active')) navigate('home');
    setTimeout(()=>{
      el.scrollIntoView({ behavior:'smooth', block:'center' });
      setTimeout(()=>{
        el.classList.remove('stamp-wait');
        el.classList.add('stamp-new', 'celebrate');
        el.insertAdjacentHTML('beforeend', '<span class="mission-item__burst" aria-hidden="true"></span>');
        try{ canVibrate() && navigator.vibrate([0, 260, 40, 80, 60]); }catch(e){}
        setTimeout(()=>{ el.classList.remove('celebrate'); const b = el.querySelector('.mission-item__burst'); if(b) b.remove(); }, 1600);
      }, 450);
    }, 250);
  });
  function render(){
    const doneList = MISSIONS.map(m=> isDone(m.id));
    const doneCount = doneList.filter(Boolean).length;
    const raffleOpen = baseDone() >= RAFFLE_NEED;

    const html = MISSIONS.map((m, i)=>{
      const locked = m.id === 'raffle' && !doneList[i] && !raffleOpen;
      const ready = m.id === 'raffle' && !doneList[i] && raffleOpen;
      const live = m.id === 'predict' && isLive() && !LOCAL.predictions;
      const label = live ? 'MVP투표' : m.label;
      const icon = live ? MISSION_ICON.mvp : m.icon;
      return `
      <li class="mission-item ${doneList[i] ? 'done' : ''}${locked ? ' locked' : ''}${ready ? ' ready' : ''}" data-mission="${m.id}" role="button" tabindex="0"
          aria-label="${label}${doneList[i] ? ' 완료' : locked ? ' — 미션 ' + RAFFLE_NEED + '개를 채우면 열려요' : ready ? ' — 열렸어요! 눌러서 응모하세요' : ''}">
        ${ready ? `<span class="mission-item__new" aria-hidden="true">OPEN</span>` : ''}
        ${doneList[i] ? `<span class="mission-stamp" aria-hidden="true"><small>MISSION</small><b>완료</b></span>` : ''}
        ${locked ? `<span class="mission-item__lock" aria-hidden="true">${LOCK_SVG}</span>` : ''}
        <span class="mission-item__icon">${icon}</span>
        <span class="mission-item__label">${label}</span>
      </li>`;
    }).join('');
    if(html !== lastHtml){ listEl.innerHTML = html; lastHtml = html; }
    if(prevDone){
      MISSIONS.forEach((m, i)=>{
        if(doneList[i] && !prevDone[m.id]){
          const el = listEl.querySelector(`[data-mission="${m.id}"]`);
          if(!el) return;
          const cardOpen = m.id === 'raffle' && document.getElementById('rf-card') && document.getElementById('rf-card').classList.contains('show');
          if(cardOpen){ el.classList.add('stamp-wait'); raffleCelebrate = true; return; }
          el.classList.add('stamp-new'); try{ canVibrate() && navigator.vibrate([0, 260, 40]); }catch(e){}
        }
      });
    }
    prevDone = Object.fromEntries(MISSIONS.map((m, i)=> [m.id, doneList[i]]));
    if(prevRaffleOpen === false && raffleOpen && !LOCAL.raffle_unlock_seen){
      const el = listEl.querySelector('[data-mission="raffle"]');
      if(el){
        el.classList.add('unlock-new');
        el.insertAdjacentHTML('beforeend', '<span class="mission-item__burst" aria-hidden="true"></span>');
        setTimeout(()=>{ el.classList.remove('unlock-new'); const b = el.querySelector('.mission-item__burst'); if(b) b.remove(); }, 1800);
        try{ canVibrate() && navigator.vibrate([0, 80, 60, 120]); }catch(e){}
      }
      LOCAL.raffle_unlock_seen = true; saveLocal(LOCAL);
    }
    prevRaffleOpen = raffleOpen;

    { const total = MISSIONS.length, need = RAFFLE_NEED, base = baseDone();
      subEl.textContent = doneCount >= total ? `${doneCount}/${total} 완료 · 모든 미션 완료!`
        : base < need ? `${doneCount}/${total} 완료 · 경품응모까지 ${need - base}개`
        : `${doneCount}/${total} 완료 · 다 하면 룰렛 +1`; }
    ringFg.style.strokeDashoffset = `${CIRC * (1 - doneCount / MISSIONS.length)}`;
    ringLabel.textContent = `${Math.round((doneCount / MISSIONS.length) * 100)}%`;

    if(doneCount === MISSIONS.length && !LOCAL.mission_celebrated){
      LOCAL.mission_celebrated = true; saveLocal(LOCAL);
      celebrateComplete();
    }
  }

  let hintTimer = 0;
  function flashHint(text){
    let el = cardEl.querySelector('.mission-hint');
    if(!el){ el = document.createElement('p'); el.className = 'mission-hint'; el.setAttribute('role', 'status'); cardEl.appendChild(el); }
    el.textContent = text; el.classList.add('show');
    clearTimeout(hintTimer); hintTimer = setTimeout(()=> el.classList.remove('show'), 2400);
  }
  function runMission(item){
    const id = item.dataset.mission;
    if(item.classList.contains('done')){
      if(id === 'raffle'){ hapticTick(); window.__showRaffleCard && window.__showRaffleCard(); }
      return;
    }
    hapticTick();
    if(item.classList.contains('locked')){ flashHint(`미션 ${RAFFLE_NEED}개를 채우면 경품응모가 열려요 (지금 ${Math.min(RAFFLE_NEED, baseDone())}/${RAFFLE_NEED})`); return; }
    if(id === 'checkin'){ openCheckin(); return; }
    if(id === 'raffle'){ window.__openRaffle && window.__openRaffle(); return; }
    if(id === 'fortune'){
      const ranked = PLAYERS.map(p=> ({ p, f:FORTUNE.of(p) })).filter(x=> x.f).sort((a, b)=> b.f.luck - a.f.luck);
      const top = (ranked[0] || { p:PLAYERS[0] }).p;
      navigate('players', 'squad');
      window.__openPlayerCard && window.__openPlayerCard(top.num, PLAYERS, { back:true });
      return;
    }
    if(id === 'predict' && isLive() && !LOCAL.predictions){ navigate('pick', 'mvp'); return; }
    if(JUMP[id]) navigate(...JUMP[id]);
  }
  listEl.addEventListener('click', e=>{ const item = e.target.closest('.mission-item'); if(item) runMission(item); });
  listEl.addEventListener('keydown', e=>{
    if(e.key !== 'Enter' && e.key !== ' ') return;
    const item = e.target.closest('.mission-item'); if(item){ e.preventDefault(); runMission(item); }
  });

  /* ---------- 출석체크 ---------- */
  const CK_ICON = {
    man:'data:image/webp;base64,UklGRjAUAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSGIHAAABH8agbSNJ5/R0/Dm/FCIiD3cI8hyUR3Ai+ZwgLjJ0aojMOx9hecSan3KXjxQjuUM+Eg4iSVKk7p45ePIvePBeQUT/JwAPM52YZe4tq+juhcWC7r5CZko7UvgtaQn/ZRNHVNqhAnxiyD69b4Et9aQVNXB3Xmi6V2YdgCWeha/btlW7zbat9TG3pchCk1hhuJiZmflPMDNfv+E6TslxcnbhGV8KM6PZshJZjiVHLHmvOcIw1xwXX6VExATwfzhNCBx3f9EkIXA8/wOQaHjuJM/+gmTyhudO0cmAPaODfZa31laX1wFk7v4skrID9O8Z6j/P8ubq4jKYAkvQ9+63XDI6BLB19szC0WMPLgJYctRkgNGXX3jR+L49vQAri4dv6YMUlYyRL1wzBeQMZgC+OnfHIycW13jmwOj5l79hZlAAOYMZcM0XRjCFlOADV117LV0ZAsfdlQDWjp1ceILh8ekLBwAalyTAyd659tqrPgApIGPwu7PX/m1WPH/HncRzN0iI5z/7t2tnvzuIhSOmLpcjXlTPjnBk4sUUrsunUCyC8UlyoqUpMzEOCsSdwT6cFju7B3EPQ9DX40arzXv6QHH0SqLlknqicEc0VLBBuAcgkRBVFAmpfpmGimZy7WQkXLWQY5jqlhFyqunCyDWT04tTVacXV7VE7wCismKgF9WK/kEy1c0M9lPl1DA+iVQficlxmlQbJdIVE4gqi4krEqgmZvDKtw1R8aG3voJGVgtZ5vyPvJ6seinzho/OkE01kLpc9PEP9IGouJy+D3ziIrpS6ywz8dGPDdKIylvD4Mc+MkG2dskZft/H99OYqL6sYf8n3jeMq02ZV39wL41EiFLD3g++mtymzqWX0pgRplnDpZd22qNd0wlEqII03VFbdqBrhGtdOKc2uDWnCHuhkbeAh7qKSt2HKU+6ez55VJ7m75ZKSyu/IRN25jcrqTDjj0c7TVxN5+gfsbISVyICF1eSyhK/Vo4s69eoLGzOPDK3OaNoMbGP4PeNo5KM6d7oeqexkmBPB0UmOnspfDdO6M7uskRPfD2oJDDCNwr3+Ly0nfh2ShtBsYltvCSjP75Nihbq4pE53bN4SXBuh+B3lkpbje90aZsr0a2sUfpJPDJnjsLFowT/GCrtOB6Zc7y8RYJfLA0Wt5LH5WlzkcKdswvkuDILy3hhWjqOx+WcWFZpKT8a23xOhQEn6MTVYY7iM8c25FG5No6RSxNHVgl89QheGtqYw6Ny5jbUAu4n8PsRLTwU2SFaeXRbHpNr+2gbnKWjcR09g7fAVg/RxNRwaM1aQOIgFpNxkEQLM8e3kkfkaes4uR0Hl4iJpYPtcFs5QtCHV8zbALojqjtES3VXVkTKd7dFeb/H5PuzWmHNR39pHpHbLz/apBak/PEf9qOIRP+PPt6k4ownnMCbs1hhpsNL5Lgyy0dkZYnbEYGL21FRxusaEbqa12IlJf1STWyNfmGpoMRFf7AcW7Y/XEQq6ZPXOsH7tZ8sCX4y20TXzP6YkjtXyKJzvaxTjjhvlPCd0fNQKTCwC0UHuwYoeJf4B1C7Str2fwR8q6TVDTw6Z2OtHGf7JOE7J7fxUlB+0HN0jT+YRbGJ91+bU2wpX/t+UjnG6NWu2ORXj2LlkPjidLbILE9/kUTBYvLTHpt/ehKVhHjncFZcysPvQJRlPW/D43Le3mOFoXxgAkUlJg5kUbroFzmmjPoRbWxW6GQpGM8dVhraKZYeRpxLFkhuesRDS6gdOMvX3fraHtwtiKyU1m+9fhmnrS5ueftbXn+JEaT5oTvvvAU57XXpRkb2X/zNIa+fa+VXR4ZBclqdE2cPsU6I69dDItP2BgnH6+dyw7vU0N27hNhFVHMrhi0quhnDZk22YtiqyWYMm/UQ3Ri6yCsBGzFsUNHNGDZrsh7Dek02Ytioyea/JrZqsoTXz1mqyQpWP2OlJptr8tq51jZrsnGG6mXObNTDWTtVv4ZTa3gtsJ2F+jkLO0YtPTFHgHMkrwXOone8bt7xRZxqZg4uUf2lg+SK2PwiXjdncd4qAvlup/J+V6aut0l1k26jqs4D8/KaueYfxGtCYmSoUb3UDI2QqGqH5grVTFd06dQFOz3ecdVK3hl/3KhNszlJvZjcbKoDJ4eVa5U1fJL6prwwiuokRhdyqg96bCu5aiRPW4+JKj+w26iy9T1AneUz+3KN8v4ZV52AmUGpNtLgDPUWg7jXxZ1BVDN6sLoYu6gZOOvn8Ho45zZw6u4sL4PXwWF5Caf2xokjpOzt85w4cgKj+i7mbjxNapp2NSRO3ziHvH5gMPnV34/QSKgVjnvi91+dAiNGJZj54HsuA7xBkopxdycJODg7A0mEaQYjr3zj2/b38cwuCPSSODh0eObm4zfd9sBZzAjVrAvpsisuGR/bs4dyl5dPLRx++GADHSNcU3aAfSMDQ4P9/cO9vZ1OT8ckhFzgcsc9d3e63e3tJ9bXV1fWzp4BkHkmZpMa53kL8UId53kruWdCl4TccZyXUgjJcXf+3yZWUDggqAwAAFBCAJ0BKrAAsAA+YSqRRaQioZWaTdxABgSxhDgAy2jFUQS27u3iw51sn/C+rHlrvVT5nPOl9M3RUepP6AH7Hdal/ZvOZ6gDghvwa8Tv89zAHtplppD98bgRwAfUvv8dS9VjoB/yr/E+rH/cePT82/0vsEfyz+v9br9r/ZA/WlDSYrfGYVx7RJMNonelo7QR///4Xm2W8JD/Mz0KVwEeGd/1K52W84G+IDWrjDol91Vf6bjSkp1flShmR0q5b5dwNB70sWtGbF6TBVXOEar1FO4rsU+E74jI/l4jvUPy+S9GIxQ3u8L4NVnwl9dOrkrNpJsOkRT+rMXTnCueFqd6RTRgqhnbk2/5LPmlCzPlVF+AJD6AhZlbVwPr1659JG/t0aqkDpgkVkCcki3rIFGgP1vbhN3Qs5uP7AD+zXc3cnJW4AVABXemg4RETqrNjFgBOp4XSRuupSb5L04q4hhn+/lwP6yWDZAot3XzwVRwcftEgbC579Lb7dZPPbsqmPMlgjET1FAZ7J129YUCNjpGzOEvDBFYxDe5BwtFbztZS5qQkpIB6PiNARAN0JZF1DaHcpBVba1i/yBAMwiFFhA4VXRat+pFDlyLapT+znT/s4vcVzzPlWARDLJxPirz1/zH7tUGPeU6U8veDjPX/0igCkK0eMB5rAFZWcWerIHFuS5oH3ghb720SO5etBwq/405mBaq8pn/+bmqTJgAAP7cLAn//VLGpBTV955m3srEDwHnvcjd/jwlQZopu0wfSYYJet88rM3QsrWz9JketJRxSmm2UBvYL07EMUJRVObzK52K9tk+qN0rTedGP97rNXIlqOc48YaR46UbD+SB/J81W9SMgLNR7A/nme6ktPRxuJm6Qevu28LpfoVUUIKoP6CwCUgC5DOd1Xtm3SewRYXaHfcY7L7wQA5WQxXpYE/TVu/dTXvdT6YLuw9bgvecb99ARRJ3DM+UnlrFsPr33Ja0mdyJOmMKnDl1amoLslYf/p2+ww9183zH3S6lnn/iZV3yRJxeDWiC+lRv/Jd5zN/9o9gfocSqp05o7/Xe61YOMSjd8TsNZ4/K5s+4ZzbFXl1Ai9Zw+8aFVl8uSNrs7NXBZmp5ncPGzqTF3e12GqSzxsb2D5SGdsjbdhY7cSNK7IE3RmiAJp6nEpe3mpbb9nKHS3uccCHr37jC4c8216QMuP93ufBqamy1irtxcw9/nTIN9MUyasQHP8QUoXqhjY5VLEGSHL47rkk4BYkAWv3uU9/oAgsB1dKnAd2bFh1HR/zVim7M/kwbxPCo0ld77EuJcvX6RrUT/PnMjaRXHQVhwHiLuOZvbVidxyUA+VQcU6ZerayLgrNbzrRsfk7nCc2IU/B0vVv9lVvoe9rqqX/177CZ7GwAn/6Bs1HVIoEmmLLdgwb1TB1qEWtkWREt8K0jbKiLXlO0SYFw9qqfgiQkLTSPz/MKvdUnnV5ribQQQo5AXq31jf90b4pKa+5CWi1qmsAKdr1HyNKUTWpLIQqZUelJXFKx7Fi2NxrBKEri0MjmHBpL9K75Z3vuMpRmCWVuHAczdZkh/GOn+QH8ttYchzbCMqDL71HhSmb29KeiLUTCmpXtBPEqbK2vC+k8OMhAsb9+NBhN+HrHMuTLu/MaCD7LDAoggDD5gFlonUBrDd4WsxNAu51nJegJyZuTNqwHjNy+NFdiKAw4qKPLxd4A0/a1atrwLP2C6UcpdOszkXWlcUjcKL74JX6nY/BRZHTYrzqH8WYknzMAzCpcVLE9zci/E43VA1vXhkdLLNtYFOJdboH1D53HLFFybCpen3vDfPfvLgasILxLzt6YFLFOuw9XqThdumo2rZnzU/igVHbJw3ZxoRioUTxqseTGBZjb3gpKPVDBCx+HXUPr7wbpFOpcwq9QZEZEPh2hGXYsTToN7Nf4l9X3QJ4hNfymJzVjBlR9FF+mCBU4sznZSPrSa24NBZ09/tyfEvZLoNxtAphmy/cN32VyM3xsdU8WUyxE+4rW69lx20fyL4jF0SN/7xFzuuIidxfurHyV+JHb/QcFKbUjHfbiENfGt/zKWQqz33DsXFdtDS6hI84mBaQcYTKru+QjVb98GErpRNC+6CLpBuduFK2qRm0CVQkeGeoUh6IAn3j0FCExE0THuNOiITKSel3fXyAR8+L3Dq1uG7v9kW8LUeUV/bZQWELrJa750OcXYSIDrPPbJCkKpEduHJkJZEYs0B8aQjCEC3hafnivdWsfe0iB+iDV564N/WhG2GX985uA/heE4aQV7pzCEa2NFvqkg6i7WFopPj9MgCQOsK9KpOT4lken14b+inl+PPIrxK6K/NczLMVULNfsxS3kXd+hW1CZa9vzlY/JRQe8rdqFG6gs1IR0z7kmw4t7COZ8M1xSJH5oBvJPVn5mp1oaMF736ug9gP/5PmdRj5QAc/TQccT4NqXO8f2nW7Jb4MAu/+O83NT2bMXyfX44a7L0jZqIa8WH3daiTA1FJQRoiC+5cCukuj10O0vvS91fa7kavoCXuA5sn2z9ETvAbnuzZtLtfsAY/OAfmbu+7BKfpkuu7XPFwvJatZ93jsfUj3B9nxp9PNWsVcd9PnNmqIYobpvr+Oexci7+5sXrLASNu/y8jAsY1esMxzySJ8Q2SE64IhrMuCScXpAuVJdLTKHEFiY0md0wbu4l+9rpemr5qAdJv5D6m5PmTBNoJmX/pb+ZyssV29KK+qqaxVUsNpIlIqeZFivxXdyO/Oay4AXrxVmEp1lxbI8IljLiy4r9djPHYtYsqoqWpWLYbpWBecVhfcMody3aUTqOhNg9WcWZ5XqaKOXKMPnyTN/SHsmlIBWe2ELey9Px/mqxexhhu9ZjVx2r/EqKWgV0kup/rXGo1JtjMv5jGmf7jFgmzzc976j6HXmsig1L87h/WAoWL8dfHQkodhmDHU30fiq/5Sh5Ctn8P0uJMccBETsD98e5zlQmMGYeYv1ecUVdXbkT+XDVt8rCtaGSIBFER4WWxi/4d+N3mb/NA0I0GLq7QAtO8nSExKRWVZl/wKO9sHcXNPkGHZMHBZVR9ipS96NO+UKc73V6Zgb+2UshEJDCku/JyADNJEl+pYQC7cWDpdjs22Y5Fuqmkc/rSw1RxtwLU7kT3LOuX5V6jFsArvn2A10Xja6k/qJ90ra/jMlBf4YD8wGjYE+peCHk5IsSHxdWrAtb40OIOEHgOJnxxN2gjp73tZ01FlSEeYKazX+yOReTHV0UQzVx34SjF9zxCLaUQ/0Rx5wX74onW0esH4RzOTpSNzQ/xxmPFpDo6EvIulSLIhxcO2CjNeakVYdt9zLNyOii2QvfYRyPQbm2NmNIRVtFSjh6pOLqaslg1bfss0gKV1dOwr+x7aPs9L2/ln3LvAb1P3In8vIKngzDeQ/2wpAh0v98C1V1pu7T1z/4FXZRQGXLM3+a2UUHDaa7Wn4DcB2ff/vBf+v5CNZKm7ahUc/Ra7qSQSTqGM1NIUWVqyA8PWFpmLSKF94nkdF8oJAdcVYnwV6OZKB/t1c0XmmtzEYb9jtPs/2PO+93esmk5PBSuOcQEcjQuuxxk4R/bVil5Xl9WrdhiaR8hzLgL8m7l9MtcfqFl5mWKF3wxz2R8Do31S604p6E2DM7rc7S9VJCQeCmmRAM9tWxchfNmqOZSgfHZHs167B3pTgS+G3uZEYIGTj5pO+/nazRAyfQFk1dee4OjY9vQYluOtQ4uQnIU/rjClWdHDsdJOvjl8+zltY3KlGVPNnveo6Rt0OOpPxKJntzpLq6M8F0Z9ekkEGFX/1kbmNtcsUM8s975wUABUeBJQ0fnuQmdk0u4d9q1TeLpyxbDveLrbKuqbA0DYvVmIxuREDWFRwjUAwc/dJGyUkz7fuL6jRy/b3tt/aYrwKZz93ZW89sCWgqDMBsGwykBdfhAK6FcbAyRvtVnN5JIUrCpiLbDjuIwBocZnNUhQhqw2y2mgyoaETN5KsPZSglR1qm1rWDLVZtor+/srRgpXQf/aG12PQyXKbhwBVSYkkcfcliOz1vwnvfK/DDhHeHnpETgAnHcCzZz/o9XIY+nfcGSCcFkrfSKD26LiDyIRyB5Fuhwpgdb5Pj58j9B3a+ald36PrrPXm8xeUhsQN9PvUq89gJF3wlS0o2LNIL/UrCjj1xiUDv+Xf+n4/tjk1ADrdGIbuQD9QceyEgmaGLFQpuObrQHajZTkWMhjETf1PZS86KY2P0LLOtWugCLAuLxoyDXBFuhIDIWkVNy+mIotHOinLZLORHPvikaBHCd2Az684RLJ1l0KF7cogHCAb2LtxdIG7M7P56sAAAAA==',
    woman:'data:image/webp;base64,UklGRr4VAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSJkHAAABoEVtmyG7+v6/OnaObdu2bdu2Gdt2jm3btm1bcVJV/3cR1fRM191ZKyImAP/7KeoKpyIi6gqnkjtaKOZTC80XcQIAC6+76/GX9xk6rO+VJ+2+/iIAIE6ypADQZMtO9344mfM45eP7u27TBIDLDlFAN+nz5UySDN6HEIL3gSRnfdVnE4GoZIUC7shHSDL6YJxHiz6QtIcPBUQzwkH3f4u0YMaEZsHIF3cDXC6IYJ37SfPG5OaNvH01iGSBAmf+zRhZW4uRf5wCaAY4LHAj6VlCT163IFzlKVZ8jTGylDHyzdXhKs5hnc/oWVrP77eHkyorsNkvDCxx4KSjIFJZ4rDVzwwsdSQ7CZxUkzjs/DsDSx6NNy8MddUjqsAJ0xlZ/sDP9gNEVaQy1DVRAIuMJCPrMZD37AoA0sRpwxNVxext1+n+A81Yn2b0r1+y/oIAoKrSwLTA7Cvved6YN0gGY916kvzopsv2WhIACm1Q6oCmK594y4e/B5IWjfVsMRrJ8NMLnTZoCThpQA7ASuc+FTi794ENMHrP2V+5eBVAtcGIAza49meSMcZobJgWYzTylwlrAa6RiAM2vclIH9iIoydnjVwF0IYhgqVGTyVjZKOOkfz5ggJFg3CQk34mAxu7J59dH6qNoMDSd5LB2Ohj5D+nA1J3otjhKwZjFUZybEto3eHkKfSsyBj5+KJwdSUOncjI6vR8eXFoHYmiNy2ySj3fXAxaN1LgagZjtQY+3QpSLw4nMRqrdhZvdq5OFFtPM2P1Bl4ErQuVRb5iZAVbnLIZXB2I4joGVnLgiy1VyqfYnZEVHXg6tHQizd+pLrNvFxApm8NxNKsqBp6PomQirV6wwOqyN9qKlsth2xhZ4dF2hCuXYDhDlQWOhpQLTb6mVZnx+2YotWILX3V+a2iZClzKyEqPvAxFmRxuoa82z1vhSqRo9SpDtQW+2hJSppV+Yqy2yJ9XhJbHYYtgVm1mYQu48hTYj54V73kgivIozsqB86Fl6sVQdYGDIeUBrmOsusi7UOrHcuA1V6biveoz/tSsPIIWv9Gqjpy+CKQ8i03PgbhJeRQbB1a/8XC48hzGDIzsWp4CXRirz/Ou8jjcQ199ge+2g5RD0eEjxuozTtsUrhwOW88wqz4Gno6iLJfQMwvuVZRS0ORVxhwgJy8BKYVsxkw0ng1XBofrGfIg8FUnUjsnq/9lMQ8sztgFRc1EMYSemeh5q4jUTFaZZJYLZrPWhdZKcQMjszHytpo5bD09Wj6YTd0Crjba9BEGZqTnHU5rotiHkVlpcStoTZq/mRuRj0Bq4HAUI/PSzG8Ll0yk5YsMmUHPm1STOewYAnPTbNKqcKkENzFmBwMvhSYSLPwXLT/M3kFqh2NpzBDOXAeS6jr6DKHxQhRJBG3fYsgRz9vgkjis9Q8tRyLfagtNUWAXBubJn6ulUZxMnyU02xpFmq4MeeK5fxrBqHw5BS4FcCNjrlwCTXNXrgR2SnVPvnRPdWe+dEt1E0OeeF6ZRjAqX85L1YU+V46CS+Fwcq4E7oIiRYFdGbLEOGNDuBQO606i5Ujkl0tCUyjav8uYI55PFYKkDrfQ50jgYBRpCpxByxHGfeHSCFaYSssP4x/tkf7FHIm8B8kVlzDkR+BJoqkctrSYHWZhfbhUiuV/ZcyNyK+WgKZb+MP8CHytHSTdgu8z5MerbWux9HeMuRH52aLQVA7rzTLLDdr0teBSqRzNwOwMPByaSnArY35E3gBJJGj3Ky0/jD+3hqRx2N/yJO4Fl6bAaAZmaOBQFEkEbd7IlReaQVI4rDeVliPGP1aFS1HgIHpmaeDOKFIIOuWK52nQFMB1DHkS2BuSRJ5kzJWJidxbtDyJvB1piw/z5Z7sujOReytXAq9LJE8z5spASBLclCueF0BTKHrS58r+KFI4HJspxpkbw6UosHWwLAn8bDFICsVS3zDmiOeDoklE9WH6HInsggJJC3RmzBCj3wqaRrHxLFqOfNEEkgZw71vMj8C+ECRWXMqQH3HmJnCpHFb7xyw3PJ9qLpJKVG6iz41ox6FAcodtZ1pmRPu0jUg6CB5gzAyeDEUNFRtPi5YTgW+3kprAYTh9RljknnCoqcpiXzHmQ+D1UKkNFHswWi5EfrWYCmosDt3oM8Hi9B3hUHNxze6kz4PIs6EooaDtUwxWfRbYG4pSKhZ8ir7yLHKIc1IOKFrfxhirLZBdIIKyOjTpQXqrLgucdAJEUF4R7PMFGa2aLJJvbAonKLMoFh0yk/SxeqInJ3VpA4eyK7Dh7VNJH82qwyx6cvL1awCK8osCm4/5iSSjD9GswVkMPpDkj6M2BJygLlWBZY+894/I2aP33oeG7L33gbPbnw8ctSygirpVB6D9bl3ueO27qWzwM3584+4eey8AwCnqWlUAoNWy62+/7zHnXHJ19z4DBg8dNnzEiJEjR40aPXrMmLHjxo0bN2H2iRMnTpwwYcL48ePGjhkzetSI4UMHD+rfr0+vnt27de3cudMcO3fu0q17j959+/UfOHDQ4MGDB/br1eXy8088YKeNVmiL2VVR/6KFQyW6wgkapqhzhXOqKuXXlDLPqqquKJwK/qcSAFZQOCD+DQAAcEYAnQEqsACwAD5hKpFGpCIhoafxHQCADAljO39YBogAyr3FVEyzLm33BGNjf1abcTzOeb95wm+degB0uH+H/5mCl9yP+n5e5BhyDM53lBqEezODx1HzCPYz6N32ur14N9gDg5vCfYD/mn+S9V3+28dH53/mPYG/mv9b9KbqRP17RHPASM2yE0WPUwcavYR3bWFdPrAa3Uefdpuzct/QMP+Lw5vOzvf7+2jqMkuWDFTvm9hCdqoVo8Z6KU4kPuvF8BlVdsYRueS63/pC4+Zce/eV5UiFZuYhzYldZBHZW//aLxbE7tdgJsP/mNqFB1fZY+iooR21l6BRxXLFkjDI9XWoQEzmGJju079d0FBrh8tFWvCkp4rbBjuEWv1WA1NZautimEThM+Emlv0+yCN92OuH0nP0pC3obOoZ2lQH8az9tc/80reikEiFih3SnxtqtxSa8P3Yv2Eci+0maXIILP4rTHk5u6lUzAGUC9goTpAqt/g3g8VT8XAurCpkTn+oajOxuG+H7FkqDcEy9F7we+R/urWyicDgYJ5zYk4Tnf8pjGIoo6T7wdcrlBGmkw9hLMGytawEtFEmb6mxiW9Iqohiy+2gqJg2c8bgQ4xi5GYmFwaEwOlaCwjv5aLHHpQzhtBcsr/Pp2culRKkB2nTK906hWOZUZqLSXrxXrN2GWK49EDgcEZdZJRXtHLYXF1X1/N/p8TczdUh8Trdv2hLVBMChT7WSEVXdoXpom68QvT904l/Gh2k56UFlAAA/twsA67hC0B+D6dpBvnrffAUxhf0ZI1aKzmqPAtid9dZgcZFVb/MyCeFoIvzeh36X9MgNG1a8hRSZGlyytiEFLhwIIHAEjFnxGK7e8TwSD7IvZjlMjr5HtZh9fW+GUldSwPR/c8oxCANuXdDjvKQpmL2mzSP6FfCl+bB94V129f958gtR31rK7/fE6zVkUVuvCcrB1PUu1xRKzz4UIkqnDF2yTYT8VstBQBp3QPCf892KzjJnN5+1TuVetymVikR+QF79aLLI/NW7BYfEG7a3jCeBubwV6zn8zzX/3op21+Hyf7nbrvvewYt5OwLzk+WpJRwhj2UXdXcO9dKOmDEbZgmg4jfY505odscXAPg82VC5ItNjOuSSJ5iR4ULII0WPVweyHl/jENlsCR6L32l77XjsMy39WlC3yHvNjum/+MQoY//z0aZockexF5bbAspwvbz50hdMzBxzUswLZxHN4FDZaNSyN1GjFJw++a8YE5Ph+Os3py6tpjQxsG727mxZ3eIj2Mcs91u5LTogSovrrZd71dBf3iTvP07P8XJOWr/Cgstn0e3d0p7m1NCNwvC0W1UAeo9n1kFkpI/NFLFNIuqr01UJcstIun37VjjUU7Wjwwyq1paU/oDOMiid4ruzKoeIGHfdF3uQLtoPMDgbreyuMXr/7NO9/Vgplgx07KeKdmA91q1xRjgXCUn8pdgHJ9Bd1TEb7YuAwHq9d5T7StCmDLmwd5S6Dn+ZYD/zSBL/LAtum5O7b9CjULRyPT6MX/aH9ryop4x4ISTYqMzpKUN2Kjoxwzana6kB/j31cCMZ48ZZyf5VHrjl51NC6J2gAJj7x/0HueD4Xe9W9/hw2k5uEwHozbexCnwww2B1FYIg1UUgeNwIeCkRbQyI/IGqABm5/ZwIu5tuqQFGGM6rN48lks72dnrwj3fjXxj/ONUskok8O7kZyY5JB66Jpbzw6pvSCZ7LXE76wMGt1GhhJ0eBxFaQ9BhycZXAC/qzJE2mKOwaiLTu7rEGHHSOTnV87mmMJdtKiF4Ms3DjsTZNXhRZzeyQAzfdcdpYdn7X7IC7BNSrAIkDa7C+lfYoFgvOHye2GK/+gC5dHkUbWnmkDCIM1q4LcMfy0pioQYOBSGH/P6ngRDUCsl6XKOhcGetqn5CMzQNW4MtkForHqNUed8xqgIEgMyt9dqFFT3JramXDwd+ZAT0Yip+GmtJc8BtEt2Hbf+9ecx6PEx1PGR9KiWqbXR5WTGQvoTutjdVZ+46ujcZV5b9eOZazfd0bmAbZGsFoR1s/A8rn+ShDPFd6hAvRk1/qPgeGvlBLfs5tjq16kli1HSrGBv/tYJAbLNd3sziRRMhYwic/JoTmRdV9uu3+oGE/J3gdigh7W9msnlQGfviwuwzNaFYdvzKwAvo0M5R0ZkZAiAKIy3ciuGsCiGiOb05U7+zZbF0EGvrVDIevP9SOxa5l3X5mLeOfp+rrB0KDr/wSc9u51ABybB0bYTw6LYFLexawUVGxa99xjGGfVkZ/Jn0sdI+P9tbzTHRZWNoqHGSGeJev3UV0TGqg2OgKdW33ohw+vbBYeagLBlUQ4R5yOdtpCqX5PZuE40fE2U9Nrk6+Kwi3Yxi95EBdwzUerXYUisnAqZgADnbisP3Z6P3Kfr2JX9I//v/z24ISef99qAjrkORvDMdnZRwAmPCUzWkv4MJgl7g/Yj8BFSF3Bz86jp6Jj8Hvrlw/ujVYpxUe4TflDEKqa1xn4eosqm8/aSeIggPvWUoJXilbPEa1sOVHPnjn80PhN5G3PoRMtrkLuMohKj691MITHUsmTtLWRQ5V7k7ngd08t5lNr+b+i9kAyDvBSvKe9RxWtJTXOV7MC5lr8450b1+cBEAbryuVgf4BtqfctHfqnRw8dA9Is87cFMr+D+bmQ58pdnL4AvRONDngi6j/tcDDH0+JBu21u9ZKc7EsFvTHtjyrJx/b+vNOYgJZ7k/NVQ+3WiT2yS3HIp1eh+IxqMymvGNgeFKLWr3d/Wm4AMufiqYmfd6I/bxSSoGiUe+ONFvABSD0dkK+8CMJCfCIvgkzYwjnr9F7qBJIsXYBFb9kxvSEQj+l0k0yvsHdeq48Z9UMgv9HaAS3LdWH15ipZ8l/BlhZSf01beijkekLngNjZd/5AW7a7UKvO1eXdZSK8svZtrls3Ib/fWBYw+rgf/OSWnf897sBQxMsaFLbh1JAFjdjYFHdjYMKp8z0Ph+kNW3fdjWKD4ZyiPnuhGXcT/xPdGlCNW7U17pQYyZSRgOj/2ZGZUOe7/N/WdvJtjYk+mP6GOSO1a7whVIdu7nMMBKK74Bhmor7xqxlA7UgiDNqXT89ed4CRQMKOaChABt7LWEsfelB0jNJM/PO2KSz167gGJIZS41kyh1mYRbpzl477q+/FA75xzzPTgaMumKLCKIrszoiiUr95wLdq456BnhZn3VIEI+eQFo22KNUJMEwdZ451zprrbTAI9wj18H4thXSQLvbN4lSqGR38pqmPjijfkQGxMg4eM2bvsTL/1WPu6h3xCpvnUlbGtYF5Cwu41hJWvGeadGH9o0wuPf0gt5h+hnr6nwje6pB+oe4pPOzjVTNsn0Db3d9s5vudZFo7jWooB/VucaOjr8j2wpuLYECfuee0Y0FLGnXg4yCeVCOhycY4yN008ZSbU2fZv/elPZvd3q7EbeMe/1GXFBlp04q4M640qd19CIWkUWyd7Jjx6H6XGPPU3uCcir7s3F+qv9X8Go2fDyZTn28MPDNgC5cpLL33Qv3vRVP4bgYlYhTBwAkYqrHUC3njojD2X6Dzwoy5/tDsENPEkBceE3b/k3UzknnGkSuh3mRUp1RhZU4GChcskpvSpiyamc9LgwoKjyPrTir6YUPVXZZE0sl1zkphTKizyZcAE+6P58BEpsuPrUc0b/fGxpBn4/24dy/9J404zyr+jSsWNOaHYR7t+02ry9D9uE6qWZ5SEpn+WyUlhTLAN46ODLtokA7Zix1zEFqlHEoIc04N+07lybFNIvMk0J0wp0en7IYqwQgelYAqQSBZVx8kV8g8nb03MsuaAYua4sCdRAykGN2zxYUN+v3FZEPaiqG47hZtNgh9DZaaz2YuUvHjrywqcOMHfee0NeHhfm6fVT2wuEkMzRMAJUyrgSe7A+tlUBApy/cOoI6kzt7e4uhH9F7c7T3RnOZRbj9+IP32KRyJ4+ipA+QrNG6y3EcWfGFLUosFJ16QjyfWkVl1MEIq9OtSEO82trlEvm4rK7FfXOphzfhduw9qMRBNKG+1nvFrl0FdL95oV9mYOHk0dRSfX6kUiuhnz+C7Ra7xyJbWyH7tl1zgEEUoE4uHTznAVARHGnzgjwrYn2ohHr/MsAQ1ve6L/HLmT/p4KZXS2t9HHqn0A4gG8lgqv8WgXtz8c9aH1Tv/84jbWon2VsIhVrfPredXKlLNX41l/RiENIbALOhHCqKQzSk/ilrFuUC+rAhjlix9q50p/5b7Q57rwYOrmX6HL/RVdia1uPKUT6A56jDClJ1dChEGgKpdHurnxdRv13iVK66XgUDOa4DXlRvkvUzxDoe+z/h2Y44tqX+LWBpyjhR9FyHgfG1Df8r/yTeK7Te0M1T5deqp06yK6TjCF+NeaOqOdSuC/oRK50MispnKio4uKclxbS6cT3RgPAWX4OGDJ4yQljbV2H5Y8AQmwAFq/jL2FoTqSmGOreeAjxp5lyxwJwUY0hJ9bbN9gypx4yAz+2my3oqGG7R6V1vPvg5T29I5rPe8/6nD2ZipwANNt8g5EjTn7ZFDxQNOCyYimKRuru0BNTfRWB6+MlUwkGnb3m/lLCxyWP7fCw5GjydBS6+zOtWmg35dNjLDLAdSKpjL5V65izhLoFbeotE0gwALxyZvbBIKyjiqKneOJnZGQkCSEL1qeFLpI0gJKY/Fx0bAJCer4s95URGA/DUXWcPW0Ox/z0tf5z3Q927eorcpciyd3/9gmFOpCq2SJxh4ceYy/OLZ5KqxSvYAAA',
    headphone:'data:image/webp;base64,UklGRpAcAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSOUOAAAB8IZt2zHL8f+d13U/1T3dqxXbtm3bYzvoaNjh2EZs2046Y8bJpyfsGM1PGqu56rmv63xR91Or6n6q5t1sW0RMAP7Hp2gIRdDKUBRBVf5r0dAI6Kg0CpX/MkSDIjmw9rb7HvuFr53zvR/9+Aff+sbxHz5gxw2WQVKCyn8L2hAAGLX9F35552NvLuIwh6Y9ff8Fp+y9DFqL0P9EFQDW3v/ch6cvYdLKsixja1mWkcnmnH/+/OiNRwBQlX4mBQDscOZd77LVYxnNne27xbJ0ts579CcHjgBQaL8SBWTzs55ZSDJGc2cX3S1Gks1Xf7vbABBE+pAGYODTd0WSsTRm6bEkyb9/bXVAQr+RAKx65kskzZwZu5uR7523KRCkn6gCG/xwJumlM/8YyaWX7wpI6BsBWO3n75FmznqakQtv2AYI0hcCsMq5s8nSWeeSbF68ORCk50mAnvQyacaau5Gzf7wsRHucAnv+hSydvbAkX/sUEHpawLhfDNGMPdKMvHMDqPQsCdj5KdLYXXe3Nt29K6QbZ3wS0B6lwAmDjM7Ou8Vm6Rxu2SzNO0dG8rejUPQkxQfOI40ddjeLTC75/3emPv/Mk088PeWVt2YtYjKamXeIbpy8OkIPKrDaIzRnR72MbLWXHzh/0if22WzlUUg2lt9w9w+d/qs7nl3EViutI2Tky9sj9BzFxs8xOjvoHkkufeeh7xy20QoF0qKqKqhcZr19vnbr1AUko3knaJx3BIL0loDtX2fJDlpJcsH95+4zgGRoFEFFkBTRUDQKJMN2p900jWS0DjBy8Weg0ksC9pvDyOF7JJuPT9xMAIiqiqCjIqqqALDORx9YRJY+PBrjqQjSOwIOnMPIYZuR71+1NwA0gqD7WiiATX/2Cuk2LDo5CaFnBOw7j5HDLsnZP9oMgKogU1EVYLWJL5HRh0MzfhWhRyi2n03jMD2S03+8KhAUmUsBjJ74PGk+DLrzCwg9QbD2m4wcphnL8zYGNKCGGoDlJs0kbRg0W3ggtAeIjPorI9v3SD68I1AI6hqANS4eonl7dE7bAFo7Cfg1S7Zvzjc/C6iixqrAvv8gY3uM/MvYIHULOMqjt2fklatCFDWXgNHnLqS1x8gfQmsmWOktOtuOfOdjQCGofwB2fYzubdGbe0HrFXA5I9v1yAfXhSp6ogSM/S1pbUU+NVa1TgEHLY3ejpE/baBAzwzAZ+cytuORZyLUSGTkYzS2aRw6HqLooRqwxxuMbdB9/nqQ+gScSGebxjlHIAh6a4FNXmBsg8arobVRXXGqWxvGuQchCHptwJrPMrbhvnRnhLoEfI2R1e6LDkOBHhyw/quMVYy8TbUmgglvulW5+WdQoCcX2Po9WhW9uRO0HopTaayOPAuF9CYEHDJkXmW8qS4yMMXbKHk5FD07YCLNK5yDW0LrUODD7l5h/NuASO9CgfMYKxj5U4Q6aHEbS6aNszaEooeLDvydVmF8fXlofooNF9Mron8Yip6u2PR9txSNH5JafJPGdOSVKKS3ocBExiq/F5Kf4EmvMHtvdVH0eAmNP9FSzjlrQXJTbLeYXsFToOj5ip2WuqecJ6DIrYFJjEwap4wR6X1QXMOYYMkboZKXaLiLZSr68SjQBwN2WExPGF9fBZqXYo23aQnj1Ami/QCKu2gJGvdCyCtgHxorvo+APnEwPRU5CZqX4huMKS7dUKQ/CEZOoSWM9yBzwa20hPFBQZ+A4hyWCec7jcwgU+mJkicioE8W2GOJe2rxppCcBKsNppyDO/QPwbjnGFtIPw4hJ8XeZSrymTHQfoECN7BMGM9AkVPAZ+lM3YaAvhnwdXqi5EVo5FTgXFrC+AMU/UNxCNMl74Tm1MB5LBPk5xD6h2CjZiryTwGSUYHr2zgA2k/GDdJTT03ISRR3V8VtIP0DGPlOyvjSqtCMBA9XDa3fXxpTqt5YKyvIHxhTS1ftL+FJWurd9fIKf6paslKfeaxq2gaZ/bGNlfvME1XvZYbJLFNDa/eX4ll66q11shLcX9XcvL+MmFr16uo5IeDWKtsV2j8Eo2anIv+zQlYNXFnFo/rLCour/jUaklGBXzAmnMcj9JMtIpMlHxHJ6+u0hPGH/URxKKtuQoGMAz7KdMkbUPSPgIn0RORv0MhJsesQvSXyL6LSNwr8hpYwno4iJ8FK81PGl1aC9gsJuJ+xxWlHQXMCMDXlHNwOoW9gzNNVizbN7m5aCyOPRdEvFJvOoKemj0Deih8wJkpOQugXBQ5yTxj/jOw+VBF5NfpmgYksmfotJK+A7cy9xfjkSEifEJzHmIj8AjQvxepv0Fqcg8v1C0HxaIVxV4S8BI3JLFtIbtI/Bl6htxhnrgvNCwGXt7EntF9MeD8V+dg4SGYN+Q2bFfv3j+UWMhk5eUR+uKSNPfvHMu/TU4+PUs2rwNpv0io2gvSLgZdoLe6LDkWQjCRgpxfobHXOmtA/9F7GFjrnfRIiGeGzc2hMRt4d+gUCzmaZoJE/bUAzEcWPSGPV8SjQN3ZZ7J6gG28fB8kj4Hd0Y9rs3dWh/QLa+KPHFFnyj+NFclCcwuisjPwJFMMWkV4gIsMLOIZtMPIaaAYBm84xZ2XJ55ZRaU9CQKvWTQUANGh7UFzL0iu85EcQuiaCC1iyssmpG0PRrhYAMLDG8oDWS4Dxa05QAEWQtmTsIywrGP3J0SJdw8qz3VNufHZzKNKiQQCM3P7Eu2YtXXTftpA6CVa+eO7S+X85c89lAIiqpCAYdyvdUnTuA+2W4kgaq29ZEYqkFArgA/v/4m9LmJy9NaQ+ohOeYPqZyz6yHAAUmoCi+B7pKfNf5vADT7kvORtQJBXAOkdf9lZJsjQnm5zc0PoE/JBNp1vpJGff/dlNFVBpgQg+PJue4p8QuncFE+48C6pIClY88eZpJBmjs9Vtya4IdRFZZqpFtnosSXLBA2dtjEoJOHDQPDUF0r1rKsijtIGkyinTSEZzZ3XJs+pT4PDonmh1iyTn/mYUpAUhrD2Llno+h195giVvLjShOIO00th+5B9HQGoS8FM22b6XkbylqMA3aUz9G6F7X2CK3txGFIBi7bkW2cFyfWg9BKOfpQ2DpEUejQBAZdkXq/wqaPc2GvKU8RoIgAIfMfcOGE+qi2IbdrTpv0SjBV+iMcWPd08Q7mdMuA9uDm35DNmZh+pzLq0j/F2LyMjnK9ynrQjpFgp8NEZvYeT5CEARdl3SoRlrQGsh8s/OGE/TkUCBz9A8EflzaPdERj/rMWE+Z10JBbDi9I7Q7NMo6qDYdC69A87moUARZODvLNlqPmcLCei+4ku0BCN/DMGyx79ozk42ealoHQpMZOwE3Wd+bz0AR9CYjLwaARmKjH2FlnCfvULj1GfZaePU5aD5iejNLNnpd368Gv5S5c0tITkg4DTGBMkHniajd4jGveugWHW6e4e8JKfdMMR0yRsgyFKx4utuKSc9suPGn9dCjqSx4xZZ7bZoTynyQMC3WUFzdtE4RaUGuNy7QLpVRN6vikxFVn6fWToX7wjNDqNfZ1faPgjZQHEuYw6MPAuN3AIOaNJzMD4CQa4iY66nZVHygREimRX4CUvm6Hx8PWguKhfRmKVzzgbQvEQG/s6YBY3/XkY0jwJ7NEvPg5GflJCXYqvF7nmwyYkIeQSczZKZGm+GZCYTGZlp9HsUkoXgt/k4Z45H3oLJtFyMj4/MJOD7+dDtWAk5CVadT88lcnKRSYGPMmYTeSGyCvgcnbmW/BkUWSo2nEnL55lx0IwU17HMxng0ijxEZTJjLu5xd4R8FCtPpeVifGt1aB4ocDYtF5Y8C5pPwME05hp5JwIyFWwdma3xn4J8BT9jzMZ5smQDhCn0XJxD60OyQXieng2XrgvNRvETxlzoPA0hF8W2xmyN/xDkG3CQ5RN5Tz4Fvk3LpuSZ0HwUK09lzMX4zlrQPETkj4y5uDd3R8gHAdexzMUjP4Qij4BN36flEvnMBGhGBT5Pz4Ulz4fkUeDzjMznQhTIWLDafHouztfHQLKAXO/50I9FyAnAo54Nyd3zECwzm56Lc+Z45K1yCmM25j9DyEFxOPM13grJK2Drxea5RD42QnMIuMRjNpGfkpCXYOCfjLk452+P0D2RMVNoubjP3QiaFwr8LB+WPA1F9wrss9g9l5IPjxBkHnBwk57PXUGkawHnsGSukd9CIzfBmDfzIeeuhq4JRvyJlotzyc7Q3KC42i0b44dFu6VYf6kzV+MLhSA/OZoZ+Q3I4HhaRr+G1gCrz6Jnw9cniHTtfs9p3zqI6G0sc3FvHoaiO4JVpzEb42vL1wEFTmX0TFjyJwjdKfCxaMy15BWiqKFii3nMJvLfA5CuBJzPZjbmn0NRB6g8RsuF3twS2g3FMs/TcjHOXBtai4DvZWQ8Xbq0ixvzeRSKWgp2oGf0R0h3vsucTqvPmOdpuTjnrAnpguDJjBg3ro3iVyyzcX4eRecUmy+g5xL5j5GQeqDAMe6eCUteiSAda+A0GnNt8jsIqKlipTdouUQ+vwI6p3Izy1yczf1R1AWK2zwberktQqcUy/0fLZfIFwZE6iOfomcTuVs31nwzH/PLEFBbwSqD2VhctBm0U4IxT1rMhTxUtD4Q3MSyHXe35PDcmrwziHQKAWezaT48j2Zm7u5tmL8+FlKjgJ0XsWnuFstm6az29jyWJJ9ZH4qOi4y5kWQsfRhtemyW0dy9jDwRijorJka2GQdnvPLopecedwG9yi2SbL56zgR0VVB87qmFJKN5lflfDpl03n3/eW/uENu9tFCpFQSH3Tt96eAbj91z2feOP2zr5dC6XtNa3Eonaf/42YENQLsCAbDD2Q8OkmQZvaXkJ9A6ZpP9P3vOBbf//eU5Q3P+ciIgqLkC626xyerjkBZRLeRiDsVYGsnBP5++7QAAFXRZVICwyWfumE2SZYxNPjMQgoogPXqVjbbcaBREUPuAdNEoggoAiKxwP1tfvvHLawJAEZClNgBgmQ9d/KST5MtbQwFANBSNQpAs0AtFg6oI2hWM/uQFV5x1wCoAoEGQragKgHG7nnLJ5aesAkG7IqpBBb1akA5BkL2EAmlFP5UgokFRUwlBJCj+RyYAVlA4IIQNAABQQQCdASqwALAAPmEqkUWkIqGVaS5MQAYEs6I7kLiT/v16Ndunz2PoA3gD0AOkh+6P2dM1b/qH4m/rd5c/4T8gP3C9ifxr7V/T5GP5r9LPC/a/38+z/oBevv0nv5dVP2S/AewB/IP594xvikfcf9T7An8k/rH+8/yn5gfSr/W/+H/L/mB7VvzT/F/+3/R/AF/Hf57/z/7h7Svrq/bT2H/1V+/9JwItfGZ6umQr1FH71WuTOE42kl3nma56HLwrR/Pxb3X6PQAfZRdIv+0lgybsEaYF4diwFGOYVosGWVTwVi1XAj2gs8U2zZUHzHqyNjOqLxeO2CHtuIEz9w2jblQ9RibFKYvncKBuXSt+SuQqUEeIoe/7Rj8TWNHcF7zVey8XeC2HdV7MvuOXCjcbdMNNwa0Sm4CiAzfQ+LHV3ffEXyUBIjRQBPgKDEGl/UvKEDZcOT7LM+2e+TbgUzROlahq+dU9EHRivpMRju7aHSOB5XsxgIUzg7noYAA4ufTpfGfQ0mCxDgjhD9iAxxkmHhMcNx70qUpomxv9Kfi2Byhd6IZFNPU5OSYLJfGFtiAU5XK4orWvJllOnu/jETXAj/qCFXESzSuuBNV/49vq+V3nzQSG1FZDUSsJQvzkVQwvSRBGSIQfb9xvwn+NqZwASCsAQ7JyXXpmp4oOCjgnR/NViCT9lVmIuBT6lnpu++NdP531OAAA/v1uSMeHIRlB4JW5WZLl3y7olDXACintyyGZBpNFoiBVei1dyKKJzA7ZLsNJFcXOGPWxHf6txsrBzYnOL19iVIyyplOCvdxJGaX2N/9GzojEw/w/1wCb2LNRWTPgzhHnB9zp10JeU9xMOSAIPyaoirdath9scOrvKvdH5NbiTOU+apff4XejI0iiqAWOtnWD2my/8i2ANr+LDDnI6oJ7ADBdBBP5uVA37iMmCuIQk232jZLTyYBQKpzhKVb2iHIEp0WLqyFo0i/Lj3E+uZ0bol4d/9Ic3WtoGoWmphZ3KXgcEZhAoiNICIPH3KGyDUycPDdVcKhQsYjXYucmuLh/Slsdys7YDDbvQPt2ugXxg1psVWdyr0aaZgBYUmWyGE6W95MSwexWDCpqVM8UVZUmt8O7Zi54+J8bBxdaiG4ulcNWDMeXTirkIrGr1fexeLbxcyxetqkSGfxrAcziDbTEPZ9pPXd7wrzjJZ1BDsgaetkSSj4x0IcgCLP3U3WXX2HgLD+iCAGSLYFJ9FxP422nJ71qdKGCJyOXyWAC8pm67sLcSdj+NXR8iewPJ2mhuBW6blFEUwJvT2kibCrJX73D3y0ZSRBfQW1vodb3afvvpmBbLpsDGFP2EMNSiq8Ih5waagkqxEkuAnuWiodUxF8xdXzRTlrKB1Izvz1zJ6N4lAb7mfzxrLJbyoVecrGOtNI7ZWIh9DJWerEHi2bRMwwerXeQNyOiorHOS+Ls79PypkhFmCnpf+xIdIUBCWzMdjGAf55+jGb7jFm7vMgB0CW2I3MW7C9Ixbknig8lsnEo0Ekjlu0XQzfN+V+P76m/sVfccew+pbvrOEBBVuU9LxXPosktHsT7CYPQChSe5ZkY+bzkdSCpzwpxKQlwVQELsM2tO4oBLIxpDYTiZstmgOT5kWK+vFbRgLIpMTowktXY9TfGzuCLyCDBtfvBKMvZR6XjMcuyV5KcjrpumGfYodNxv+Ehe0BwsWWTJsmcY353/JS7ckOHialASAb5jl021z5xiVlfm2SwFL3H03g+11UflgzZGYt4/5Bh5+1nHEDo62r6AAhkR06llveI9WZIkl7dnp3X7gi16Lf+/qFt+NAM+qkS2S6X+luxlbxdmesTntYftTjjICdclqenL1U3gTD0FzTaVIu6sABQpg9s+/qdlHzP0D5Cvvdt3hvFPgc11f2i4X/wgrIC6Wp8QkDT1d1PEw4w8MOToEodXYnDL9PXdgearTdmt+V8+/gFkvdncntErkvtUFwxi8IbcnbE4a2D6i/01LrhMvfVYwuuMQ6YaKp49B7dXmdVKp7jlYjSCerrQKOnxLTJScA/Fho4vrbhm+a9u6I4Pm9CzcqxE6bqbTM3rsuLoBpx3Lx2OLuDAiR2r0AVXAz6wdlp1SthjPz2Fuo6ge6gcltTHBXeCj2YeekLjtnI2G7ogocF7D2cFV86vqTJZIqqnMvpCICwQM4a8GMjRLrxYSdpee5RtqiLvUxZUR1US0z4YMklcNKwE5IX0AFUvG8r5rffB3wBUCPUrb+rb03h8dudN1BN0l7T5yWaOj9gDw8YlnJ1d0BNJRvbaCIckULEFcPqgH4GsVNBn/yFrCkAOPz0lafeeKl2jP/s2JDUdIfi/8FuxfBFTaJb6nJfVkleDS6i6KotsibGzQC8EzgVmi3eCtgOmwsy2/ysa6qSRu986Y/QgSblkwak0p4czXFzlyOktVm7SMmZqoskc9jv/dTT01vFffIxHzyQJmjnSday2feXos8L6gATTB5euFTKYU4x2dClWetj/6TUSWY30x8DZO1aTOLy1X1izqoJRVZd3t1HbYap/ivGNlLvmPb6vSi34dHTnjEroA6+T4Sl4rg/1qkpmJtMPLW28OeEji9tdtF4IgYvAb2nggHeEmgdp6ui+KWrI3Ao/KfyFjEm7kJ3/6ll8x3GDPTcIAAjcBlXJO3zTnCCD8n8jUTDnwacbqcIFRZpq9PKURDYjXauu0R3IeUuL69cjat3X+mg/EKkby2/rnP2PAcNfPBYXv5M+aqaho7OKvdaOucwkXLrpx+pxop26YIV2FRDAc+JrnKn8Un/+5Tt/6r3ZymsV4PVGnkMojZjqDyvCR/QleLVKSwTVe8/p1M2bbdweudy0OeiF5VnuZzjyH3LtDtbLP+DvWUqqN2yvmVWhknvnIQaOZwK7eCnZEFU0ay0rg3h752TNylfejtQGr/s//FxG18jlqsg/cJOMJFo5USMsmqnb+GkA6ka2KHOGTYMwEHVrCcrS55xje3n3i3VAu9OA5vE6OD4LCGtQHwt/3YmZ7f8MmKH5PQGGpSawMW7SfIByWQbVOZlyCmbEwM9XHrnJBMtzVpphgQGv2TIPw8s3up7DO732PVv7nuX+oUQGi1xsjns79/0TO17+WGcGi/3HOFo6vjMqShGcRbb3R7dnTmRZ9YMd+Ay60VfxVnAZEmW3lPFlE+3psD3p7pmujTrZxNFO0OIuOhy2Sdt1MX87MrBzxmjuFybRR1hr0TaQKJBzGmkz6HtsCxun1+jMCbMcXxlxWE1KK/R15dwusp8107NKc66ATs+Bfr7aRRiybYzPhNKOTfMlcQj4bgRzaPZ2eV+tZz03NdSeD3AgtE5VZVwK/2PdbUuBuMUPBAx90NEWdY/0+mDUdx99XykbdTr9qHtGyfJPOmuPNW1L4lK25KJ0/7fsif1fnT2k2LdHMdEfClcIDFKO35CZIXP7GyK8wrX8xQWlgNIpfkGmZ71rqa15X++vS04UOK8S8goWz+VcTOZv4u+eUAGXWE5ojMcayexGI0R+N7OIXUqB6dOQHDIKZOkv0gpSan0M/XshpO8bZXLtdr60dxFwRY81Ck4r/Hrl8s+U1UBOasrZBf89l1jpj8zW7grfae9wnqnlq5bIWhSTB8JH7g5SOk4q8DmWQ0McY+Z7UylFf95PZ5bEXVi3HN19AcdUkPrw7mklmyIZmZUdJkPr5mfY78OaAM48JTQuGpiYuG+ZHRNBdos90GvIevK2TXM5mwdiM0XRJ6ddpd459NfqMyouQCWlrD+VPllJQmEQmjSiNoYs7oCp3FLa/hzAQ37bCSHz640VN6PIjqR3LOGyBkus58C+eqGySTa5seS9KEwPgZ7PifF+1yaiRul6Hd48bv2EiYKIAfI9GKKKn57mM1IhPMwwKoh2ZQ9wJMk06Q3Jy1KL+15AtuoONEJNGqXx/vRq6oIn7RoGgDsRvAXFRHWnHIitBwQWow2w9XxgeQwxARY16+L5U36ZezHYBOiVesv0Sr/0RbRBysd4MwISk4xGltH6voK41k6+BcGwGkv4C+9jRnAtZaV5qPHiad7y8//+c61d9rcuKa2gLv0Ymrp26JeE/7bJ/ekcTSAHhUL4EaKNylo/+d1AHtZhyxGS3tMfR7WCx25S7aElqDsUyC3qarATr92LfO5bFukkDwgq1nUFNbrVsjsK1HLuWDgXYETtZ2UHx8sG+w9rNIXqIh97DrIRxnRGLKHAK3UFJJ1E3ZejSXRkasUnPotIou/jJfk9WSyC9LWdU8+f+hHj2o+V3N3LJRK72FHneTj0ibsgiM9+oDLsMpdjiLybyqf/w21/85vlPrmdxfo/k4lexQBR/4ApZ8w0lYvVW6OgAM0MRZ/AOy2qC+7AZHyIzXFjDaD8TS7v27Y50IiX82R61HRaGy17HaP/bmOqbg+Zq/2BhNcPdppsGmL+O6O0P9DQWJHviGWPc1LUFu8gbZzBGVU4Yau+fODfY0V3AVaXMQncxmVJzPnM0LHe3Nw80AbNIXfXySmYclXmZqJkqKlNoBJLft4/T6bvamvnuYs2ZjfewaM/naTP1KzQBPKdwSpotWW8lMLWjnK6xwAeKmJavCz9IMO4Ed5kcHnyg/oCNNIcIAA',
    hug:'data:image/webp;base64,UklGRkAQAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSLIGAAAB8IVte5lt27at25Yex+nzsm3bxpBt27Zt27Zt27ZttKfZZFsHzuPE0SS9rptTREwA/henOKddiXPafaKucE6dK5xKlrRAl6qCMZ2TbpFCMa5aSG5EAfRdfLPjrnvkxVeeuuPsXVaeDoDqhBIFgCkXX3OzvQ7ebbPVF54MAFRy4gCseOFrwzmuX96xfX+gkAlSAJj7qAc+GsGuB79/3wGzAHDZEEXvzV8ZRbL2Pozp60Dy5+NnAXT8FOi7xXNDSbLu0pPk4MfX6oRqHhyw5oskvTeOo4XayF+O7A03Pg6y7askQx2MXZuvA8mnNwZcDhwmubSmD8bxN0++uQJUxkUUcz1M+mAcXwuBvGEGOEmew+LvkZ4TOHgO2wciYxNghz8YPCesN363HjR1DmsOoDdO+ECeKyJdCXAy6TnhPf3+UEmaw9pD6dmtIfAKp12I9ryGFtidgTwVmjKHlYfRs5vN8yy4MRQX0xu7N9Q8Ai5dgll+ZGC3m+ducIDDYfTG7rbAneBSJdrjCdZsoIXBi0IVq432xu4PNmwxaKIU+9GzkYGv9lKZ5EsGNtHzlZ6qSRKZqTJrBmvuC1xEz2YGHoE0KS5jYEODfdd3/mEhNMSsnBaSIMXclTWGgXudR8+mBp4KlyCH4+jZXPtzOJvr7YcZoMkR9PnIQoMa7rkVXHIUy9LYZLMmBbsP6VWcwNCopg+ZBpKeZ5PGtaCJEfT5JmWBR8MlRjF/SUtXzbtQJMZh1ZFpexaSmALrW8o8X++ApGZTWtI+mDg9G5NJe79/ahxWq9P2WpEaxRKDUlbzOUhiBFP9xJAuzztQIDGCt1MWeHRyoLjSEkauA03PRkzZ4GkgaRBXFB1F4VzR2THjIFqqvN2HBIpTjO8NrJPFbeGicwDQY9719jr10ptuu/POW6+9/NiH6BPl+css0MgUkEX2fejnYcYcel4Nh6hFIZs97Dmm+XqsIV30K0GjUmDVF0n6YGbMYLDXEbei5+mBVhtz6bkDXEyKKR+lBeYz2PfTQSNSTPcma2NGPS+CQ7yCSV6lZ06NI5aNSVzHHRzNrAZ7AYJ4FXuytsxwK9F4FDNVNGY18JvJEZHDBfTMa80z4RCtYpafLeTFOHSxmBz2oGdegz0BQcxPWMgNNxaNqX/JzAZ+2R8Sj2ABn5uah8IBgMShWM0yE+yHacS5QgFooTFswtzwWHQIADgAcNI0hy0y4/lRfwBL7HDGPY/dftLWcwMqzVJsmBfjqCUxxW7PDGbXv16/ICANW8WyEkadsuT5v5Osax98XZMjjyqgTRLMMiorHPRsIM0buw6evLUfpEFAj+9oOSHpjeNsNW8vtEmCG+iz4o3jazWPhEpzHDa0vExIC0MXFtccxcQfms8bPa+GNAcO+zFkzmzQlJDmiPT7hCFvJLeENgcOa9Fb3oKdjaJBoriAdd4872gURPs+S5+1mg81C4IZPqTP250Ng2Km91lnLPBMuGZBMeOLDCFbxm0ahwKT3ED6bA2aGtI0CLDPAHrLkucNEDRfBIs8QnrLj/lhS8FFACg6tv+GGQ48EQ5xKjDpSb+YZSbwoQ6RSCAK3MKQF7MBc8MhXu35aW7obQfReBRLDKdlxvi2IN4CB9AzO/Uy0FhEcBvr3NDzdBSxKKb+iiFDL/aAROKwogVm1zh4AbhIVA6nzw89t4gGeJaWI7sYEodgqoFZCnzTIU6HjUOWjGWfSApcwJpZHjULJAZBz5dyFZaHxuCw4CBanrhBLFuxZpaNO8LFILiKIVcHxIHOr2l5Cjw+CsVixkwHno4iAodDaJnyPD+SB+izdVkMimm/ZsjWNTEUWM0HZuv6GBRHs87XzREI3FMM+bo1immGMduet0eg2JD5rqNwuNxCxu5onkjHO/RtymGxgbSM3dm8DuzMmi1KBFe2LPR9l6FdzTiC1qYUK9LYrnZgaFlHta5zW9eVreua1nVp6zq1dR3QujaitawFW5Zgit9o7ap4gL5NweEQ1i1rqaG0NiXa+bL5NgWHXWitStDva1qbgsPOrFuVaP9X6NsUFEuPMGtTcNib3tqUOL2EdZuCiFxJCy0KosXZZN2iIIJtfiFDaE0QwVzXGel9WwIcsPStPzGvkUEBzL79gxZaE6AOWIN1iwI6OzZoWQXW//87bLTlc7SlYF3m9Z7oHFYa8ldZVVVZlmVVlV1XZZdVVZZlWZVlVZZlWVVVVZZVVZVjrcqqrMoxq7KsyrKsyrKqyqosy7Kqyqoqq6oqy7KsqrLrP4ZdGx3g+vTOaZ9O/A2XvCbhv1IDVlA4IGgJAACwNwCdASqwALAAPmEqkUWkIqoV+lWUoAYEsYQ4AMa8CNnw9T424D54n0if5PfQP2x9hrpMf7J/3/UV/t///6wDgXlja4m9Lvju9H7QN9U+wD/MP6j6SXst9An9gEICp322r4l8cx9mFUoeZMu288gsnxEiDMcG4XqZghq+UH5BPA8UBmqgNEqdTCPuMZ81peKhlNlTiumMqCwqApOVI3zvJlrzzA5vlip7qKiw4J2gHMiBuxzRdOXxEZV3BQmCNi7YPzQgSwOwLJ8uO0GlL8hPT3fX3R+QfV5JdFUQi+on+fjbXsIuivNzlWMEUJgbsEY3Hy8aVB7xAoMwYV2Jy2lfl//fEbZZ3rnc+Y94LjZkYWSknpJed4KPwkcvjX7KhTx17D7AU8VADQrYAjK0vaYpzvrgq1/JqZQd9ayuJkfu7TJrqz8AXlG5SgQxqwuGcm2YW9F9yc5X6WKXkx5/dMr5a3hGYdNjqk+YQfXJtxs4YXvwenWNUK+r5AbtqCxVa0Lj2l6vgAmnHKxyxC0Og4mfduP/7mR/x0fg9kH1CEIbzAaNtVjCrQcXmooIBJiOwm7Lfoy4J9ltnrvkt8voWp4HwqtOqf0AAP7cLAEe4eIi+jOyMhXd62CzbAVIG+yAjypacKgcOwG4qdU+YrO/hsTc73p8xtWfY7kOncqnTLSe1unbWvwAMtMkmz2+GWtgGtVDZNfqKeewXzcx3NO3SJb/5PHOrslmDRE+b3Isvmrjf7ZUQfak8bFnbrsVAxuU/NWdXVUm/0QBvls6FdtiP0XfTt+LYknUf3hc+yhu9gr56IBkerNL4UwI3LofdBMbKk7SujtAAofxsHOqm89uHSTYC/+YOP4HxLZta6BZpY/uigtj4Bmu3zULSaDF35U3iAzFd5CMUdP9OqM3i2Pb31RhEwarZwxb7NRk8i4z/xKwoFjEfP+slyylIB8DtmNebmebE5wjlRAtdGo/qA8ZreAAea8v+5YbzZwnq7WNHvlcxbnbTfFcy3iBIt46G6dF/LguulqKaqyTNy3kG9TANkGy2oFgBqjpMupjZin8U/RoHs9OxIHGpmDaZrlQhcuP786k9NpHYJjexDarGU/NT+b3ZO2RKn1WX94ZdgBsrjUgS3DC9d7LPewFXZk+9I1rtNr001n5sPJulElh7A5zXBIvn5UT7aXIdh8f5Yq7NzpegEJag1wpLK3pfnGOgAVqm8SiG9LjI9G69sTTBqntG7sXOp9ncxZb/50ylAoC4WBIMN3VMxFxbom5jDanBI3aoXw5kkg4BnuLpqIXVkDOa8TzTDK6UXNUZFUnS9f42ADPP8T6dr351JjzthBQ7+rQTzAM9n9YD2Fy7FnTvsy2xZ9l71HpqrxJ3+JfjvqONxK/eW3kGAgMPRCeCfWKNcxgdAVtXpvBBbIHzonnGn8nyI/IEL0qH9XKdPh4jA4LEiKqWrjlV/DkdBOpJibcYt4kXtFhbHl1aeeUkmR37QOiakn80rrKq6Gc1Ae7Tof0rxlSxlkcBJ8mRRAbB/GZSy+CemywjLOVA4lEu5uGLxSgrnvG02YAUAQz+GoMuqoczb2XqmDGwPQcf1mDQLnOQJwCSV+lq7BXaOJbBiLW2ZDH097breEKazxUUJ6b9YM6eQPoL+FWD/zaivKUWHV2waBRzszgQd4OEgvfCxuZmLR/39sukzjTbHM8nTNF8d06VppzAAYGv95YwyNTmauCxNfFGM5AtL/h4PxXlf1scvfLfKg23xmuzSdUk5qnZ3fIPHBC+QpZff9ThSYRr8GYyOTVcuPXB5MeBCfgs0CUJC7dEdrTdyqML5YcSR2M2onILTTxtq37xrY1P0UunI13IA7txH2oYrozxutEEngoeUoDTpSu3hye5lJ1NUINBcAgW7DoJwJ70/SYDtjXZ1xMVM+wfS/Z73Fca9T0LEPaUeLmISuNQzP9bPjjBWKZIerBPutEjRUbLDY5MTMvuAHVONGN7JzdqwXkL7pS8HeEy6qmS75EKC8x8r7nH2awQZEfNQoOKMESeGCaTvld/tIWt9ob4lZyuGyYfYdoZE03+DsH8zOiOzaf13nJf0OZRmp9o1XftWyUCqd2JEKvchSxhbXmB0HnRTcF00XsyZdlMccizWTtJiD4R1jvxKzKANs7OrneKYramqPslvkkVMFpPFF9DG6eRLba0ha+dQez2cEKjA+ODv5Nnf4JFw1F4sU3PUKVmAR8L8R3l8mCCSU0wcvYVEtbf7aDJewQPVO0EYwem1uRvNLouX2vnxNkCKPfDc6tweIUf2E39I3SYEcJYLr9Njc+fCqsv11gVRm+5h3ORUS7g5sFU1McU2hrYlaMiGE9I0G/UqV+JGuT4ZgA3VuNJblk4a9ePBrNCCjRtDwYXrHpSWDWCfr09WFeOlSKAB7mCIGkWSJYi8rD3KMJx/fMAurJ5sck4xze1yELciigfCK3azKYLHFd0J+/EsCjD1vUpdHzWHTsRB/yEonAgelqgBf5PtlE6k9pOxwIYHkJavBu8phnKxXwUgPCfW/HqHwj2qewOND2g2D/Guwp8+BYusJNaF3QDupX8tUhGjA8LJyk/4uEDsGKmBiUfqAXmp7mfdIkaJIYEBJWptvKyI3JvEvp27ZgsyaBHnDEZq4ma5Lx7WWkVpss5U3/5GSGkQu/g4BJRYqJieydHQP5DGObYAKFrftSm81f883VxlwYX9sGlpQYkaNYHdeTd7w2cdVgYhJ6/uxHnEkqfnsD9tN5JP/WBDnRp6pyt4GDuHAdJzIw7d5ZICq8qh6H70+uVKfDXkzLSk77cRckTWKrQnOrA8/NpCtxRGUbng29v6s2zo3HkLwZ53bi/KnxjPNOZj6y6MXhf3BzvCw0uMs5udP7lEMYl/C2fCRvccVFSB5pkdWirlSluYLTwXGCvHH3cic+cHHy//EC1lQSA9fz1XQZoVpMq92gBCWnvTvGsDVQLQnFy1lSHl1s1Vxqq3NkAN1AZDAak3cUUTWNr4w6By7iy5aC4ebmJc6GgVoHQAXlWVYI5ej0e5JurLf6bwI8LoMH4vqrY6EBqSZCteDJC3LariS9cqD1vWL82scum8+jUNqgWerSzta2cdczaNRXW7xAHRP5qnx7oFr0Y8QJMDGf0RCTIljeI8ThpZ6mZezZoDbi7AIjr0dHmX5XMmYVSxQ3rSAJudttaXy3f3MwJiAE9GTi3+uhYAAAAA==',
    heart:'data:image/webp;base64,UklGRqgRAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSJ4HAAABsIBtkyHJ1h8RtTi2bdu2bdu2bdu2bftc2zrm4mjneCoj/otFdSGv742ICcD//f/vtSIi+rciIg0TER21iLSSFoYxtUKlGWqFYEy1MGkXMQWAgeNPNe+yq66x6nLzTjXBIACQQmonVgDAwAmmX2q97XbbY9et11pkqvEMAAptDTUAmGntQ278zgeJI09DvnfLEevNDgBqNRITAJOsuNdVrwwJjrr/zSfP2XaRAoBaG0gByFxHP/U2q/zghdMWLQDTuhiAibe+49clRxoj5cg//f6Fyw8ATJumCky3y4v9JKM/eYxGeCqdZPrpwXMBojUQBXTlK4eTZJk8OLrhZUnSf33YXIBoowpg5rNfI+nJg2Menpzk8BuWBFR6ZUCx7fMkmVKwykhOcvi1CwHWHAWmPeMTsnT2Mkrym7sWBkx6IQrb7MdkpGAvoyS/unoWQBtSAHu+TiZnrz2R31w2HaDVGbD8k2SkYK89kUOOGABrghjmfJxMwTqGkx/sbrCKxDDxeV/Tg/VM5EsLQaV2Amw9hO6sa5Tko3NBpQoDVv8FWbK2nvjproDWTCGnkc46R+Kw7QEdM8XAU75lCtbZyfMUWivFOLcwgjVP5KXjwcbEMMvTpLPm4bxrfGiNBIPvYRmsvTtfmRU2WmJY7R16sPZR8oGxIfXRgXexn40s+eaKUBmVKvb4iiUb2c97B2pdRHExSzY0sW9HqIxMgNPIxIaWvAQq9TDsyxRNoZMnCexvDOPeQg82NRL3htVCscQXHmyuB68fF4UVhpleYAo2N/zzxaA1UBn3F0xsdMlXFgKAtV9nyUYn/nRs1RrgdCY2PHHERRttfUswseGJJ6F3igW/8WganQySwaaHfzEPtFeCx+hsfpRkGWy+835IjwxrR0QLkBFsw4hyFVhPRAY9zcSMTHxwgPZEZcXkzErvX1y0F4L7mBu8Cb1QzN7HyIvgR9NDqitwPBMz03kwispExv1OfpR8epBIVYbFUkRuRHw+D7QqxeFMzM7EPcSqAl6k54fzQUhlk33KyI/gkHFQsWE9z5P+ZaHVDMCJTMzQ4AGwagx3scyRktdgQCWCsb7LlCdPqUgViunfoOdI4i8mgVZhWOhLRo44P5i9mgIrMpijwa8XhVWzPss8Ca5YjWGrTGHJtVBUs0u+bFDVnvmycXZtVNVO+bJeNQU2z5XE1apamylLInxpWBWGZcnIEo5YoKr5PssT55szQKtQTPMneo4k/nBcSBWCQS8z5UjJh6CVoMAdLPPkIhSo6AR6jgR3h1Wj2NAZ+RH8dnFINYJp+vLkg8Go/sc54nwIlSvOjpQfiftBqzKsSc+OiG8XhVWlmOYdem4k/nh8SFWiuJVlbpS8AAUqL7ATI/Iion8NWHWCKYYyM5x/GIBeKm6m58ap0J7IKpEZ7J+3RxjnR0w5kfjwAEFPDYdkRXhsg6I3KtN8GJEPHr8bX6Q3UFxIzwgeAkWvZPbPI3LB44NJeweVq5hyoeTxMPTcMH9feB54vDe9aO+guJopE3gCFDUUmWlEZIHH2xOJ1AGKk5kyIJx7wVAPmeq18O5L/PHYIvWAYTem7nOuDUVdxV6kd13inRDU1rDE5ym6zX34rND6wHAOU8fxYChqLDLhb+ld5nxlgEqdoFjDPbrLvW9RKGothotYdlfJo2CoueiEv6J3lfOFwSp1g2Kprzy6yeOTuaCof4EjmaKLouQuMDRQ1B6jd5HzRpg0AYpp3qR3T+IvJxRBMw1r9Ht0TfhnS8DQVMPh9K5x7gpDcxW3MXVLyYthaLDIJD9i6pLEZ8ZWaRIUc33I6A7n69NC0WzDal95dIXHiKVgaLphD3p0Q3hsCUPzDWcydUKUPBKGFhQrbmXZAVHycjFpAwgGPcXUfon3mwjaUTH5j1m2XcmXJxRFWypm+D1Tuzl/NjkU7WmY522mNkt8bVYo2tSwxBB6eznfmR+GdjUs/zFTWyUOXQKGtjWs8Rm9nZzDV4ChfQus3Udvo8RPV0WBNjas+xm9fZwfrwZDOxdYp4/eNs4Rq6NAWxtWG8ayXUoOWQmG9jasOIypTRKHLAdDmxdY9A2W7VHy9YVRoN0N8/yWqS0Sfzs3DG1fYOYfM7VD4o9nRoH2N0z0JFMbJD41EQxdqBj7NkY0LZx3jANFNxqK88hoVpAXDoChKwXY/1umJiX2HwwIulMUG3/M1JzEEVtCBJ1qWOo1ejQk8e3lYejaAjO9wBSNSPzubCjQvYbBV9O9fu68ZTwYutiAI0qmuiXyJIGhm8WwyXCmeiX2bQcVdLZhwZ/Soz6R+NulYIION0x0Oxl1CefDU8DQ7Qoc9S1TPRJ5psHQ9SpY7z2mOpT8ZFuIIgMLzPECw3vlzp8uChNkoWGcC8jUGydvmgSGXFRg66FMUV0kjtgHUOSjKOZ+hvSqPPjjJSCCrFQMPOkbpqjEycvGhwkyU4FVfkGmMfPgW1sAhvwUxUQX9zPF6EUi75wOKsjSAljrR2TyUXki/7QtUCBXRTHhEcPJMkVEeEl+ed7UEEXGGjDt2a9xlEOvnR8okLeiwHTb3vSbT/teu2/POQBVZK8UAAaMM+5AAKbIYjWM1BQZLYL/VA9WUDgg5AkAABA6AJ0BKrAAsAA+YS6RRqQipCgp1MpJAAwJYgDSbkxcfop+v/IXoq+ze/XRho07l56XmAfph+sPYQ8xf7P/t57unpC/tnqAf0P0oP9z7B39k9QD9o/TR/b74G/29/dn4Av2L//fsAegB6AHqH8Tfw3zmauEn/yYHFjpSsefqof3vjE+r/YD/Vj0wPYH6JP64muAboF8PoM6LNvj9C+Y8EZTHWDt2gUs0QZrD7e4euBFmIMOwOSFaV1hFljP3QPAWdJb/2fAuJNnnDOTRT073SdkcETv7OE7JF5Ozm9PxnrjRk0oZ4KMG6Mg0iT9Z5+UeFGq6Xu6LQVnz/JDDW5zUe5CewGzmMVfrH5YR6TlXIVESIZBQ/mY/AGeaIT3xxORiBgdpRJvfdf0pnnvggnUAxH2c6ccQLSYLsbQFo2OhfFM18v+/rvBkcSWjkhb7JSrMSt4zzcVpIWXI/pBk76OLr/TjY0G3YNMdnyem7/TyxnjN1PPe3pRCANqELFvkaHRzvR4uV+CW/LSv90Qgm8kgP+TRqDzN4YGLKh2pCF6U3iXozqX6eanamXQ2MdQuM7Nm3iXzIie1Q1we92ztatb3XfGDT6xGhpQS9l7rFip01Zp8KZ/1fO1JVAAAP79bkgAAAP3z8sIWtwtQHdHPKrR5v1NzcC7oVFr60ff01gSe6AK4srw7Uu2+HOC+YPqyT0d4YIKdYKqvqh7vZ+vmoSPRkOycELwt1Gbbo1v1kP5i+JQ431Hna5ee3aGD9cf9DvnQEffyAj9K5fPJj0vNlGg9BTPQkED/6r/J1jTB7fCX2zOEI/+LQU78TiDVC5SGQ0pXQB8m2TSru9KSWY87QsZOSfAM3gWU/ISXW36m1+FgCgsHpkiimcQcIAsCjoPwTHD/3BdQNSXRYjENcchi93GDqFblYo4VnAjDEnM2pa+eUwl+Ub1m4WoUZSwXzloTxkOyy0URy8Mn7K7cGaHQX+gcbQ5rF1MwPw60579Mv30eJw36hpdVRFtlQO3r51ohtfsPKw/2MLnvYWqrWHAvigTL48A2BkAHCjGsrMa00llEtVL/OF52gjp2QEyOQamlyh4bxaLCx2QM1a8utEX5rRpEE+WijvPRqU205SXoJKWdhFL+30nJPNNVgGXY0knTgOiDUeTfcL6hg2kPeUKctZZ5VDh0gX8847pgU9WLtT34Hx12ANbgjf7AIK5l6r1wW8den/onbmLE6lkhwo2knA6EF8AyPItjU0D5A/5cDLcr5p7gySSfEIk1/+aG6bZYfhRvi7wD8wBIBwfP0pSTOUrbGJfbvHKzGgU++PeTEvYsmXtr+zWFG0Hi5YOySg99eKZUTeS9rjCZeBq0oRsVA9ZXiXOxJVEYR1HRhHX/SoU0oJHceZ+K1dBOzoBLufzou+MDXDapp51xpsBlBkrNuyGDi/zhMy3ZLmgyR76D6VJe4YkAUVdEdqZGnUc5/IS5Vygmh4Y0upG5U/hYJkfwoWg4SMWWudketlSDNJOCqIWYI3SKjRKXumRyIQyeNpPKwOmprmd4ap3NyX/LLlN4VSh84U4+PbHjoBZr/lIq4lPsqQx0OfcucQYA8vZVAPC2yf1eyUHvttGLGk/uL3IZcm/rdrAUO4s7n6ivJyZCXCSV7EjwiB7jAwpDAy9nhJKoPivSScQS2SPsjBuTJCnzuEF98ppnXpjLk3KgDWXCsasQtBd2efgA9gcp9kEDzU+VFSbyIRwlLm71JGtSn87viCBe2EVYuvfY5I/0Pypi7M4TpjzwDdBNf5CAMek6t4Yp6ymHUStXtDF6b0eeeXK3otNBzVB4oUcUKy4ujnYsE/alxoTSksyp+rgzcyU1sdMsmyUR9AJxPBPbslD8y0ObRsVgeXHtwp4T5euxgNIdkbjnj1zseP8W2XqxOIqFjc2rV2EfwpDv7N2SOJW2Q1+PoAHp0a42nEzzvGaJFjXbM+Bm9ZBRWCBbjP7WVUkpb3gtb62lIxSWOuAXeiF8YD5Q8z3SF2fzNiXIjuScRNKbnmH7P7rKEI1tJlPP6jtQ3eyuD0hv/ubvmLEtatdnq196NK6ANmHN536R5vzizaGfEpL5yRlfc/7BBr7ngPhYINXMgprwOqKrOfzjO5UdIG9q0EjnZ7T5+wYXv6mhS2FH5ExE4XWi4lOcG6H8JyOPH6ooZPcfG89bm058mxhSiJnFM+FCjVRqCRMEaZ65zbxASEx+JiLls17wq7HRgGrxrh81aZw22ehpiMVpxQ7MBIexEBMoeoJRPnVAxcmHLzOAzzjarTKt56oqngLYIltmbn432FFGNhjSV9YhbteKygw/7t8y/tQ1P4ctBPDvyZJEdJ7eTsFGPTUjC6VPxFkA7hH/96nJlK/LGssUecDKjDbwXDglT8R2gn6Gf4Ln25hZnawpQMb63/WaI90Kr52oO4TTBGWJuRT5vKCx+i25gd+dbE4IN2/pmAZidlVj+Sule4c8UmqQIsWY/VFMDdv6Gu3+ns41EIurO8sxWePz+FNdq/HHR6FMPwsNxDZSjGAPVmr0qqu2rSe57XDwd27fDlMaCtLix9E6MLOmrYPF9aR/HLiQEwld8qIwhjmt/koVuEV2x3PgjGCC3AtfSCtwULYdECTa13L2f8zLVmktvnK7nywzTpJjJ8SxDB0I8dcCO9/up8MljhKqqkJM9W5VlQoPABzPRd6LSxBqr+zYuRNk59labK7CoDCuGwMSx0+6khgJjnfeFJP2hH6LJKu/1S5tW0Ayt51h2cYs9xYkSiz1aiOoLJ+AjNv7mNPlFtyfpM8nJGIouNhz1Bfh6CHHQmWNIKmdO41X2bsK5CnKy818NpkYx//IXDmVsD69oqd4PoSjX7Xiakv0ISgXpdiPSjhpgzn3+y94xWMvxe6fDy/6a3koABz3oTsxtnZpbqrGY26RQ7EJr3yEbRwTdddt09/C095RQwRqtLk48ihNmDQi2LMYiK0GVTN+uQzZoz33/h6VyuAgKxy8gLtTwbM6plX2QLUX6cjV1zGckEyWJHKnpE82rH7ujiP7I+MJaAYD9UKFAHRGQy1noz9xV4x941sRPmqoGd0lPKoOFFiQPbgvL/uvYzZhs3C4/YxKcUt5Sr2L4pqyd/+XSMN+LMQE0k9kLykJeaObUFrE2SvrSOy/9/LfwbWz7BlBzQxkC5WPpJeUnOLMeB2gAQyP/X0nTUzAAArsIxU8ULgbRuVlzIQXh/Z689IiV2m4eqbGOcF5/dWmHw4dz3tQtwG/bMq2cqTKUfGQrIilVbOSS6OQ8QthA/K4m2aC3HUMvjg6JzmaiWsjMWAsA9TPCbkrXL2a6rAl7TCCcJvzYY/bpwSYEZegLZR17aaRaH5kG0nmOZ9ywB2AgXHAAAAAA==',
    house:'data:image/webp;base64,UklGRkgRAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSPUFAAABZ8agbSNJ58zxJ73PHYSIyMd3IRnKZJsgfyOCsSVZmeQ7lC2YJv96kWBESn4kHAZA2zYgSJec/w9WI7njgIj+TwD+PXmD6MnKDIn2TBJpt8QL2r2mfSG1aO+hXWITIqIXLNJklai9KOcm2KQ2AFzRMt5ycgYAkWT2aCDLNLEbtrBtOyRJet7vj6jm2DbXtm3b9h7Ztm3btq2xbdsz1ZnxvwfVk4iM/z9aRMQE8H///wfgSClqKrHRVE2Z9gY3yEcek6OOJO7ytH2C7uhP/x3VkNlvPzCi+zi4fhJr6BRAllpClePM1SCx0uY67KLFNHk6BSMmNYyQSjb/zAhNgjVexi6VlO55qzWTXPmXv02jhhHTCo2RSpUf9FqmfImbiWwymgZr3GGXKXObnGOS0apbMrFEl830AiMVCdZHTJRYR57ERASzNAa7SEpMm7Cux5C77JkANirSXAVNCjFjkRpcFwZyNjO3s6lKiRQh5igttUjFsWeHyGau9lhkl2aWRqCgQWLeahOhKnAm0UvnRHZh8kwkhHshIgiVZYZGJiH6qoSLByLTWxOU1TMQqxA9DtqCRHg8VXQEptcZYZcg7JxpphqzBOoXIpAGT9Gx5iY33/PGaCLRLCPTdyOyB04de9z/PtslmCJxNxD9Ny2hQRPbPfkB66FzElOuEgspEnnABPvfcSe6QAxmJqHhMjtuxziJQQ0aPFAWbZMjGNpMYA0TF4EYXom2kYeIYy+VGWIbxkOk04+UGWaJZkkamsg/QAx5Zw/N3w6KbsBM26JBafjIdckDhgjwkCS+TMegmwANh1h9XMrDhoiG4QwdiBh6QzcYkXiX8uABadUgKKLjIFPIbvEi8pgddlK4EKtatFjqWHfrZ9+NYgrACxQduzz25Q/akU6lwDRCCyNW3euhu+EsCipSwovCznfagTERFNUoo4UQO+1IDlFc0bYsYqbdFAclNvYCBOddS8GbhHoWcf6FFFwY3C9xCC4Y0CTUp2C/5SgcEu7VGyNTeoF6k9j55xVAk+jRQw/KVKCNewJv/XcV0CyhnrQHyFWAIfVBbLEttdgkUg9g86YWhPYl5idWRy1gvraZ5gem8HkCOOixND24JheOmGD87/dGzM1cuozLZS79C/b1dAd9fi2a3+XnFk3XvPhgrm/87/dEzA3x6n/nckGs/vKnowsBzgc9goa5J+51EEUPffLjz2McmPS5tdL8gu1+kLqCSW4/+6TnLQEcsyOih4lXUHIJR77Bk/dafdkfv4noY3DLUXK5CJwjs82aC64j6KXY/CoKLlaGOkiZnmpziq4VENj0NHGHTV2y/ud08KHKBRPumbnuBERFm0uoanFBtovmnpljr0hUtHXaseTCuV/JP0QuXL+lP/0zMqV3r7zHbZyK1/O7Yur6tlR15C23rivYdg2qKbF+DRWoHkETFSB6vaGrgF6Lq66rK7jwGlxVcelFlN+9kv5ZAT33H6yqkk45SF3x3CfS6HsdVT2OPxyUupoi8i77OwrnfiFutJldtr7LbIlcMvcNi1GWXa5FNKefSePO1QQc/7sriNSNBdqYN5KrhQu+/43jr6ahyFqM4JzPvv2DX9p+3Zol2c5eyehEXIBlLQRKrGxTgJGEiPji8Bl/+vDULQIotalj8syYEnaX4MVYqSkiRxG04VRiYaZ3ETJnnR4xFMX8DXXluHArVFNYT6KpqnF8opVqKth7Z0dNabz57qimMLuQqwq2xZW1ltp2dV3eJ0VqZhelMBdF6ocim7leWQr0jCNBkeeHWdph3203XbeUyLnLzrYNGIzyHqgITstfP+aUczagecnc+O533qFlrmUQwOjcP/3uCGsuYrcX3DUAG29MU0mU0gLyH3ZDczBb3WA75xC16By6wVZ4dlyWGDWiJj0mXcass844l0jUZnDuGcqzifF3qdTvjGMmyum+uEbM/SLLM4huzxs4aiR8gz1PSt0MYN/1o9RVCKP1+/6MWZrdtUSVLrE7ns2pvx7FCi+EPIHwRuRZyD3TityeNqufUbEz+a+1AFZQOCAsCwAAMD0AnQEqsACwAD5hKpJGpCIhrSpQe+GgDAlmCHAHIDoze5cPpB+E/K320bK/hvv/zV6AeyX+R93fw1/3Hs28wb9Kf9//Xevv5jf17/Yn3pfxV90f+H9QD+4f5H0wPYm/q//W9hX9oPTB/bj4N/21/bL2jv/p7AHoAcMV/UPxA/Wbscla9Kz8xbze8+WoR/K/691gP3D9iP9okJJZXXHqr9Ek24g3zm5ALksrrdAehSjD5WjvkrB0034jlDezyYDRpBbJSDC+o0BYRE34cUmOXpeMrPn1j5sr27A9djDA0VK0soZtkamUJr6VOj+SBCebe8mZyQAOU5eLw1CcHH+7F5nuCqH5i/v673oOBXRvjpkWFPDWWUIRmVx6JuEeg4MfHfA48rSQgr+wBIiVKTPzqXVMW/9M1S94MZ2uVLSy4wHhs4x/oea1N1jigAkYLRYBjYya2boKWbqYbRqPZXXzwwvhlMzoyMepSp92KimLzDtQ1hSeuWq1WDA/bnLBgXxYabcC98vosqlB5ciHH2AsOyDi+D7sbWb1RdB9YXtf5pZAj2AchMKe+PvvXPdlHdVIiZmrX/pINbV91a0KHEy1g/5vnJo71NpyUc3e0mvRbP+1iWQQcbHef09UCQB8cJ4DE5C+z3BUc/qGohhWg6lLEp8AAP7ZHwAAAAH0is83lhzbZOS6E4QAx6vs5+ZymWZDjJU+T+CjSAAeUuo9WAdzjronxyoA7sRidPnV8BPZwKNRV1V9qMcERmQUpr1pRdvFl9+WXduz85xaSVO43mN8SGzc8nc9LS7BAQxiRl8p9KHk7/ZWaKSQcjoFRv9+GL1//qdaHWKafp6rrfaAvoCk+BkIjAwhq6lKaHCnrTeKILHRpHC6hDPnv+XMXf3WW5xhoZ7S/9Umj3ixB9hGi/RQluFpUek6nAS4hoyC0s6YjphqLiEsXBuGQI1Uoj4KMr/sMN9Ss1LyTukNpCgj/fXUpKJcLq4uosbUOA4frpIwsLjNXHrXQslw/EsfexXpslRe71OBrYkl3fze0QrnyQh71IocO/Im0ZdzLooAO81ljqRu4hMMsr9NnOi0r12eMYp8lhVgB3WLEER1mAgF/5/8KHwfiQ6SYPw175qCm4aivO/L/pcvvxqNZcz0Ukexyu5M+sRBHXjwiX5MuyXeGZI1FKArWHa5atoWs5Oi8KT3uGuPBHUz7A9lVAuJ0i/Bb5UVHZd4UCclZOG+uxNv5x3WGVsOT2R6FtXWhBb1uaJISfnlv35AqgiqepiMuuY3iTQ/6WHjAxpPTJOaMbuqgUsIeVfPUT4wq6E3vF87liwlqIj2dJK9rODFgeMA7PEedvkWewWMiucfVr6O6wkEMQ15/VJwXfr7U3xnySsThc3FDBu36/kVXuDcJ3c+9aaY5UHqfL8z7gnQZPfSmV5vrLwU6XWgzjco2n2dJ3Ki2E8HFcrbZIqaUakDSb0O+xtdu7iGrFTBR/SqOpkhGJ+O+jWgvGEMcnwqga1BvPvgKpUN/Pav5plPoG5nEjEv0xpcwxC95w1Bb83Kk/fSau4cVOvZh8cy5l7sZ4gJNtsskEy6nxy6jnbJCfyBpB5wXy0PXsCB0SVDzfAFklXQ59Lufpk72u/TsUGYErUH4RJ4+lfDlEs7XRWYT3tW5q6UN5MHl5/81ieYMiRdOG2XdgU58RxMRg6FXIzLMj0yf7GpZvleq5tMv+QwvafLWKye3N6XFIeO/mf47bLXAcLCBWuLPMJcTE5sP9iUBSLuAAOWkX9xd6tqk4fOAAqVUUTy6FMsSiOfOJtG9EEpCvFbgFB/9HjoufvVmyvMOEyCcdUJ9ppkIgrpihRwIAq9V5GVEnEhmrB3v0RacGUqyffyC7yFAluJJ8M8CVHvlKP/XoXA8zilnCZChKroRiSzdbzUEW00C4syh9RUoq4J70FN/kuQ7VQKmgw9CKmZBZUiAewNr/VQPrS5L1EYVDjU/UM6FecqcAELgbj/TUW5HEMubRHh1ytkfO9AA7TM4Extu3VWXobAs98Wyy7SCSIVLuuIVm3cAXrmhu2wRXWkJl/NhCggb++ha8j4eLKDNcGyUAkaxOQ3eJrtMuGY8YWDvBbmWDa8VuU7Ov4Us/n5eK/1tNXtzcMetH+vIXmFowfB8N8aNTP/5jmb6o0CHU80dAaU5ILN3vxjSXgsCJPK3ARhp2Hl7q/iU8eEgknvX3tkvBefw2aFnjZMnD+3OEX6HYwvzoxK1cghwlf57qENSMk6RanyL0GBwxjRWBy5Xrcc57fDRROTNcSbbBrxdvuz/vuX7ROnNdTMsC0kXnWlEuV+kADy/3KEnT6E9lDxcoVABGCSHoi64SU4PAfhz/583XVz2KBJMMkvs7q2e9c4rszKepUJYWq+8Zo5qX/2Q0nmEb2QpJDVf59IcFbjbyZwKfJk+7FPXJdiICV0id/JLNSfsykGJL2Oe1QmvnvWritejyDdBU63zO7gmDUi2M8JcpoOUAJov95lykKfnVsTrs3/tg9oC2RkBfuPiU9joufxcwlx5iP15l/xyBjKKEGz3UTCB8HrnuiXu8Zpg4fii75wqQfmKTs3tSIcDTgMYeWXk2kdpg6DZWhd1yzFJeCsXzEuOJG3SP233vF9MfnCxuFFCn/mMZqONlo0aqF67x3MbaYwa5do5ddQwqqhhrQ3nd+sOKUqmCdqkHaumy4LLFxDk6xyF+UPgAfSQGOg9jPdhE3oqewrCjcshs7cwU7shPwMC64iuem8NMfKxlm6wR7Etmu6EDQDBO+OVPJVM/9hMnwgpuWutB9SAWV4fIowUL8mGVYwgaibiGFDeST53HDvzroM6II0DYXzDBBeaUIRG1t7DwLEXtQOSOM9mv56/7JNZfGGpqGw6DcFx8iN9kHI3Yuny5nC0NdhrUkD3rjleQCH4P1iUB1iEfo31vK/WXvJcc7eFGMOkW4QkZCTaYzwUWJZMpmJxm+BVztRYZ2xZrw+wkwgagKOwvrEE/QlRA3zhSRnyOJi1LKcwWxCtx2LdeFGITpILE/8+kNHXY4SJsXE5+8gUlQm7BuCfV1hqCuhpuXBVaKCKaJSlrT8ck+/aPLPpabu7gftzP34txlN52FoSas4H387ln+/lM/UdpoRjPyO0pSDCwkLLUNa10EtCyVgFxHUOMBoJtSsJx3PgBGIlrk/ebFS+FGUTv5yQHV81BfffEupLSLBYuxfu7l9/FWLBU1Nvhvp5kNKtAeucTtWiQhhyRsCV4V4A/NOORmy0sCP0sXMnDjUyJiiVRJbA8jES5QbJH3XUYT45mzxelwHqsN4fbP8Wu0EEOpV2e/vDi+yhpPfAOQpvPP+fyzBFfJy6Vb6FwvM2O/OUBJF+3lQoCceEJfy5INsxeC0dDRUV+g56gmEuXmhXdYDsVRCERcIgbAzm6ZQXUWjx6aKQLYXKP35S/skwwKn8cKG+hfRURf8wO7QBpv1Unr/T8te7sZUgsPSnwlgwPVLdktph/NErdq7ZaGBIJyTUAD3ydSS7jzDdWpX8Lz3V6ghHFuj89HDCAMnx5xgghWRy8oXXA9cZwaSdwC+h74bKlKx7hekj//pYWW+8wVkafYSZ1/THpFyAQxhoGfBHYb48O3HezNGjXcFYn0OAI7k+unfbOQ5NkrKPIMZ4gN/z2zwJePvAY6uwPKP5NPCbYQ0154ZKAHspmEVT9A7iLcLI3isb4R8X7/0V9ccXC0mVPvjN9lC5qQpG3NkLUN8Ap4p7s214pvIXFf5UVhjjiNCb74oiaACpt+w5ZrxXgYMZZFchBN1miVpGVA7OsVNqYyVEGhjjfpQAA==',
    briefcase:'data:image/webp;base64,UklGRgAJAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSDgDAAABoIPtnyHZ+v3//z7WtW3zOLq2YiNVZNuKNztGem2Htm1bU/WvX9I1W9PPnbq+ExETgJH//xIUtaZpGlOpIVFV9KmqUjdqADBrz8OOO+WUYw/bcxYAmNaLGDBj/uUPv/1NIMnwzdsPXz5vBmBSJ2LANuc9zdbkntj69HnbACYVIoINbvqITO6esu6eyI9u3AAi1WHAqe+TwTluD+T7pwJWGYb1VpLRWdQjuXI9WFUYdn2OMbF4inxuV1hFGBZ+zMCBBn68EFYNitmf0tl3au2Lzk9nQytBscW7DOw39hJJpl7sh4HvbgGtApGJjzIynzyR/OW7b38mmTzlGPnoRJEaUFzJwHwk+cR1J+47e/Y+J173BMmYY+CV0AowzP7VPefsrVw4DdlpC1f26Dn3X2fDhp/gHjqzzmcPBtA0ZmpNA+CQZ+kZOu+BDD3FIUzMBq5eC6qCrKhi7dUMGSYeAh1yYs2djBnn0gkwjNMwYSk9E3mHmQw3w94/JG9LfHQKFONWTHmUqc3TD3vBhpviAga2evpqexgKGrb/KnkLAy+ADjVB80TyDM+HoajhAmY8PTEB8nsknVXZ9De2J364hqoUVV3zI6YW8rdNRaWzXRGboN0xPYbZyBuhUlhxI2OGR6t1RyeYDE4UHb+YnokLMMAFMeO8GB1XGZACk4+4eGzZ8q6uWPQ6U0vib7ctXrG88Iolt/3G1JL4+qIVy7u6bOziwycDOhDBpNNeiazI+PJpk6ADMGz/EMle6LL3E8MAYz8eutwj+dB2sGKCXd5l9MSKTB75zi6QQoI1n2NgdQY+vyakjOFWBlZo4C2wIoodv3KvEfevdoSWOZuRVRp5dhnIvcnrxNO9gqKTPmCqk8QPJpUQzPihXn6YASmxxo/18uMaI/+N/Dfy38h/uRnf18v3M0oAk96vl/cnoajck7xOPN0jRRRnMdRJ4FnQEobtv3avEfevt4eVgOJm9mok8GYoiorMep6xPiKfW0OkDBQ7vMUYU02kGPnmDlCUVmz5IOkhRq/CGIOTD24FRXmFnfkkq/LJMxsoBqnAzAPOGlu2ogqXj521/0xAMeAGldlg8GIqtSBqgv9+BFZQOCCiBQAAkCUAnQEqsACwAD5hLJRHJCIkoaSR6xCQDAllbvKOBVEmZ05nMB8/fo9GW3i8wHQM8oDrWPQA8G74S/22/cj4AP19//+s+VO/wfoJM+D1H7A36m9CT7IH67ledDEH+3KohyrIRHpQlZO8fcAaF2OVa7HiXkAPVYBKiguGOvTEeXAVGkR8Z7n8V96ptJvG2cqxJiF/CDMxWJ7yZj+pFs+T0h7By/ugyHX1AW/vJ+DMjYhVAxUV/+YVAysjrMuxA+i/T/J3mCvEn7rz9LuP21H/X7txr2hlqHrsgvyU6IJYgfU/l383+cHPuccDiJQiRU5Z4JgsQ47PZV9wx4a6WSRcVKRLEUM5lprL5/cPgx/sDY2fydlLN4DLvsu7wwhCP/rsa3cOZr3iPlxrcjjS7ZYv6ZYCVUgAAP78+EAAAAC1/5dQ/ivC7a1ssNZu26MVxk4kDBc1JcK9BgiQKudxlGG9/BtMKe6tA7amdg/94GrKIcJgeC7jtF96AGFlubH+p9+bnuz9MtskO7iCaO+7T8AWdQhsGRnhXx72RGMMXsh25vJ1GQDGQCfOkywfNRhliGEV1sAWXyjwVmIYGSAAEeW9eu3UQVaQACVafqgG88l49UNHPDpkz0OQl+A9zVe/7Q75kbp0W00oNtzeD8L8BGEl0YEPjr9DOZTDJ5nQ5A5WXPOXZITv8dkon4woXY+dS+9emd8zt6UATOvHJReKPS9tLE5/MILqe+vklAL/v4SuoCg8L5ifnTW2MH9CmMfb9h+NG5F6+YgNKKXD38SCt9ZcIeWCEDRS8t9m5cESDp2WEl1eEaoS1jCd/Ee+ztugGOxzcNXLKYApr4TUurS8eg6E+t0zzQjSrpExR0140nvAqovBozWqa4vzV01q0VMJEc7pQBd7Nt58b7tuNCzoozotjxsd9NysokdhfnHGUTU5jyI/ip9T512yJAbghvtFPABmhX2ONhKn5sbAqAIm/4JRFjrLI6hyNNX2Nv3AaC99fySDrgBrwtMFSIofe+bnrf/pWZBgM1CW1szfWIeq72Jb9ymFtLykGUmudkenKz3z/zR9Cr8mqgcNPdh1oN65nymkXg04a/utiAwCdnZocg5pIh6wksSNxpqX7CWuwmtFilMEvW6jdlao8rDNp6wxVne9ddR26bkGwSxEUyXqWhWUYcHjrbcPVXQz1WMQMVsWzcEirFAOSISkU5PJA4vwp1qQoQ15Wt3P05VT1+eOmygxsq/pzSZ3jR+3/J/NRmHi82rqBqbOgvJCBFtDOrU9q3htDznISrVdsXwlj1bCuNRHqe5uQucJmNh1gGKk7hB8kzY5eutl2jZwKDLjpW7fRLDLYiymdYfCJI/YKAFtjecXbH6ynstDZxQKyTptN7tw6/FzqupN4B4dIiPeigWdIxZ/zTwePIGWSGCwdrvklMbFIvrbRqnpNjwR2L6UxKB4P4ajQLqIKp6aHMcqogZT2Ri+QOKTfQhmwKS9IV9elFT0a+0uwSop5e2943ig/KXHXT7hjG9G5cPxFfUQtj6fRG93SuD3L0FBTrgfaStkn0XA7iHnfIkx9ZmoGy6LqbUR0Ks6Na4tvN8oLjUlNTSbdpxAQTQZukPZ/BEOagKahU1bkpa1OB7ASkSrj20wiGEIeC2E54yaC6HCRms0JAMODvSgGOY77ukWCgDqK9J7HrwXSCxU0creVSx8nO39HzksXM/HFqEJjhu+NN0GwqTaJlHrC2Oyb3GQIg5h+NqWHbo1l/XszmnCljm9LS2LO8ycoVpNuJNxF7vDhiaEPIhv444L+DJeRv/IASr/y4WWD7BUvJTRK3/stf60/nxiVU3Imx/kCNJLKhUvaW2QCogtcmoxmlC/SniTL/jdXCsJcOSXM5zOs8efap9S1Ca0xnlIQUFA5bjXxugFMar9XyILiroAAAA=',
    volleyball:'data:image/webp;base64,UklGRgQTAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSOgHAAABsEbbtmnr0Vxrn/s5VRVb7/ti+8a2UTZj27Zt27b1KbaNzxUnr95Za88fLzj33LN3/UprETEB+FlP0VAUQVWkn6hCNASVLBENLcVPD4r+2gqaE6JB8b1D51hyzc3+vPNBJ1945bXXXXneLnMAMy+y0GxD8L0aVHJAW+g/tP2vk24e/e7X/PGP/vm2Nz6b/NaoW07657JD0L+laRNVANKzzsEPTejl93pZlmZm7m4lf2zv+AcPXbdHAKhKqrQAICsdfMc49o9Wmkf++MjSo7uVFtl/3B0HryQACk2QqALD2se8+i1JM4+RHY7RzUh+++qx7WFAUEmLFAAWO3AUSVrprK2XRpIjD1gYQCEJCcDQDW77L+nukTWP7k5OuXWDoUBIhARg2L/HkCyNXWolyTH/GgoESYACg7d+hXSP7OLoTr78n8GANp0q8OtnSHN2vRv57K8B1UYLQPtuMjob0SN5dxsIzaWKGY7vozsb0519J8wIlYYKwGYvkxbZoNHIVzcHQhOJYrozI42Na4xnTwuVxhHBqi+QzgZ28oXVINIwCtmzl8aGNvbuIdBGCZj6CtLY2EZeOQ20QQKGj6RFNng0PjYzpDEKLP4GSzZ8Hx+duqUNUWDVcTQ2fskFoNIIAWtMoDGBfvg6AdoAijU+ozOFkbx/UYSuUyz0MZ1pLJ2frI7QdcUjNKYylpyyCkJXScBKjEyo89MlEbpIIAscGJNC49s90K5RDL7usy+ZWOeYqaFdIlpcxwSXvLlQ6Y6Aw2gxJofGwxG6ImDz0iITHK3cHKELFMPH05lk57geaO1EB9xLZ6Kd9wxQqVvA3jQm27gnQs0Uy3zlni73L5eC1kp0wJN0Jtz5WEulTgF70Jl0527QGilGTPbU+eQRonW6isbEG69EfRSruzP57mtAayISHqalz/hoEKlHwK+jx/RFj79GqIXIwKfozEDjmIEidQj4IyOzMPL3CDUQGTQ2eh54HDtQpHMFtogx5kGMcQsUHRMp7qIxE433tkQ6pWgzMhsj29DOXUHPB+flHVMZPikvJs0N7UyB3WnMSOd2aHVEMPgxljnxP57eIcXSFpmR0T9fR4oOHU7LCn7zT2hHpHiJnhP9t4Z2QLHMd4x54XHi7JDqCuxNY2Y6d0dRmSiuYV9ulPH2QqQytB6k5UbkhLmhlUlxL8vcoHNDhKrQwr607LB4LKQqwSK3RcbciByFyqV4lpHZGfnZ9JBqFKtEY47YOtBqCuxGzxA6d0VRTQsXsMyRkhegVYmI3E/Lk3sgUgmmfj5PjM/9CpUoRnxCzxHn+PkQqgho9zHmSGTZrqbABjRmqXFtFFUE/I5lnpTcsqpt8mVrhCoUe+XLgdBqjqblifFUSBWCc/PlElR8ea44r63qWnqu3Pj/wuW0XLmmGsG5uWK8pBrF0flyKqSavVjmSckDoFUEbJMvWyNU87t82RJFFQXWp+WJce1qAtp9jDkSWbYRqlCM+ISeI87x81UjmPp5Wo4Yn/sVpBKR+/Kk5D2QStDCBSzz5EK0UGmB3eg54twdRTWKdY0xPyJtbWg1guk/y5PPpodUA2B0noxC5YJjo+WHxWMgVQVsxAxxboBQlWLu8Yy54ZwwF7QqkeIOlrlR8vZCpCoU2J+WG8b9UaDygGW/Y8yLyG+XgVYHCS/R88L5QhB0UHE4LTcOg3ZmqTLmRbSlOiMy6LFoOVHyscGQTqDADswK4+4o0FGRqd+l54NzUo9oZ6DYihnpvByKTgfsE2PMhch2DaDYl7lgvLcl0rlCTqDnQYxxCxSoAW6Olgcexw4UqYFiM8Y8iPwdAmooGDiWlgPGMQNE6oCAX0eP6Yset0JALUXCI7T0GR8NIvWAYnX39LmvAUVdFVfRUme8CooazTPFPW3uk0dIjRCwB1PH3aGoseiAJ+kpcz4+QKVOUCz7lXu63L9cGop6B+zLMl0l90JAzUUH3ktPlfHeASp1g6JnHD1NkZ/0QFH/gM1Liynq7X1rRQR0Y8BhtPQ431poGgi6UrS4iWVyLN4CKLpU8aux9NQ4N5OArlUMf4eWlpL3tgRdHLDER/SUON8bAe0mBKw4mZ4O55SVoOjugLU+o6fC+cV6UHR7gfW+oKfB+eVGKND9AWtPpKXAOGV9BDRhgVXH0ZrPOHFNFGjGAou/zrLp+vjqYijQlAE9I2mxyaLxybmgaM6AqS8jrbmMvGJqFGhSBfb4jtZUxt7dBYpmFcGqL5DeRE4+vypE0LSimPbsSGseYzxjWgRBAwdg81dIi00SjXx5EyCgmUUx4/F9dG8Od/adMANU0NgBaN9NRm8Gj+Q9bSCgyVWBXz9DmnefG/n0rwFVNLwCg7d+mXSP3RTdyRf/PRhQNL8EYNi/xpAsrVusJDnqH0OAIEhjAIZucNsUMrq7x3pFdyen3LbBUCAgnVIAWOSAkfxeq4dF0ksjyZEHLAygECRVVIFhyx505yOHHMU+8xg7FJ00I/ntq8e2hwGqgvRqge+d4T72j1aaxwpidCuNfNbI8XcctJIAKBSJFlURxaA1DnlwfC+/18uyNDN3dzMry9LZ/9sTpllvp3WHCwBVQeIFAIYs+8+Tbxn17jes8Nt3R950+GL4/pYiByUovnfIHEuusclfdjvizEuvveWWay898/Bd/7zJGkvNMRiAiGpQQUZqaCkqD4UiT0VDKIKqfJ+ohiIEFfysJ1ZQOCD2CgAAED0AnQEqsACwAD5hKJBFpCKhpau0DHCwDAllANARDhKl6u3O8wHm+ehveAPQA/VX04fYX/tv/M/af4Bf2h//+a+fRL4MN9ArlqCG6eiovFPoAfyr++/871ac/n57/r/YC/l39o/6/Xu9Bz9bUmwhq4lH+OuZnyXheJXFE6vQSVS7jd+9oWx3GvYUC8Nj7Eyd6xR34pv7OwpwBqF1Zdy9W78QbtsphtmKaZyD/C2GPR2dQxYvZ3sv7HP//LTgH/3mWrhdqLFX4NhHZrDlooM6NgFjbS0XM3n2yegiQoVcmIfn6vPz1zviCxhVK/QpdLw2QcYWd1CuJsJiTjZGZMZLrPSrS+bLLgljlO4f1CjDyz18pvdp8rh2ZPeLdw3FhScGnb6OgRufWo8AF69OwYzWI4Upqpt6zqC14RdFVGo/fY/9UhM0N+4ZttSKqt2YZYU7qFI5qpo2h/2A4WtbZ6hhdN5CJygaMww5LxODlJR0r7dQE8J+jC+UdseHlB5h8KSvWpqNN7JPbZaxuNKCOdqo2uXAT4+5NU0DxSTMU/YDmkJQL4Y5Zeh8hhrBYK1BXaU637Pa8bFFvdGzU13QA9FF8SJq3hkyWZSC0xUHh/3fcc+oHbPnfjd3IMNsLs4KvpwcVsXi3uvoCK/0NRW+P1/IeoAA/v206Cs/7YUOTopCnkv1MQxpekh7xFTxMSb+30CcI3oK3/gYbdjttRQ6zZvwMyeBv/PkjzpfG5nNzE+lY9WfxKzq7DXoDO3lBaIceXKA5CiodXkzDYwVJ8autuwh6Jzx9HITUS6Pk2BKxR1OoPTsM9u/uOyQa/uTIc9qp43dYeXaJZvMRefurSvGdHWuPdZzFmfjWnORPaVaaKJv33i7+HcY9BsIxwDHivSk73xP+rf//A3f/9pTb04lMb6Xqj4epzTqFzo0IIf+A5zJZVQWPRtu2zOZcqELj9a/gvKHihYVLGHL6MF/C+RmVTFDGIw0LahxztSqGPxK7WjelrrzLRAuiaW2i8AP9oGhyqkTN9XHO/PLcP35xwaLkeKJYTL1sE2uYuFsZaI+lHp6Cjv+RXL51+Gwxomm3wRj2nTdw7PM4W3heiymEtvDPP+ADdrZr0EHrlbzfPu6wAL332VJ8zRz6wHdE/8ZScCZZwll9L2hPrlTTLGbYnHkmveo5AATnLz21ZDLNsrtAiT7i+wbrvja0/7y1b/VPeILxQ1wvZMzjWvaSZec84w8Nb43va05X9iKGmAbZXByFUcUT/UAfcIYeRkII86OhdJ8oVxh+aGil4jQOdk2yUR8kwFByo7lfnss9Atju2FhkheYu0qbMyrDr0HeJ4T9K//LddrFCpHnj7FUE4TGQnNOkCo4Xp1btyDBsLFLuwrEM90zaIv7/9KskJ8LGMdnXvOCB51jEHDewNt2E+6FzfWmeIG+7AsBdYKyK3qQsH2BBid7MCUwacEs+Ej9VHkcdZwaetzoNwWb80kozfmFH1HW24odJC4DtMeP9O7X9U3jmQEDtNUChv/uwb53eOpT8v8NhpmXsFc/GF4+F+bTfLHVwQVTD5Ge1KSd6cOnMXp2AiXERgDAfRLTs/xFwTAhjPcnQM4zmjXBic7o/csweajMwE0nBeYjYDwa3h8QTU2ql0lqV8FWbZpQm5S6O+pB5rcS92T37wiPE4gYH0r0ca5Orl1qGHVgEYqaPC6c3ljXZXQPiu9Gu8YKXiwn3rfhTHnsOVfc7BX+gR16XmCu3UpMwfN2AgIIIIzgebFISbXiSylOITHSlGR8zau5RBJdoIbwFic8mtpn2m2EHz1JT57RTC6LvXUnYYv44ZzAaBJkvnyeIjYS5saLV0T5c9VSB9ynZFdclAYuNVH38AdHMUDpcDLt0j3+kdvD1rdRCYItOzcF0NRpFTYFzIWfNOJRWks9aBb3PpydbVtTvm7/CxFgSzPSHrhNGhxxIVvNdaqKCuCT7NexMR+Z2UyPJ/octlDEtWpSmIbx7ilAijz6vz4liudNhhfW3sXGRbrcZ3hPAORQp+CQ5Za5jzBC8LS0LUqIINk41Vm9VOnZKAw5ssdvesSHhRjFljBhPh10q96aLCrmDfLusvEOmjae/ljHAMvSE6ScveoSW/C15odpHkg5ucANzvCgqVOUnZ4AqrPMc4z6vOmT6fe9R/uEp+GeHoRCe3ffohQ365WCRcZMtrL+miGf0nl0iF/IJq5WslWvM7iZ3UsL9sKJEwuJAn24RxYPvSCz5vseSIte6xwMjAj7iR4UML/0JtwaM9hLY0EKA91184KNUTV9803xCSNmcHa/TTFZi+5/nBaYPavEvOsg/sY/3/Y4AUesYa1ZdailutMcaMWlJZZakB+wqjIS5VaFtz3aMg7YSLbMTRHENYkPHTmVbl0u3WnTc4/jZo3p/oQNSdzQ+KZZ+hawjCsZwpqWEaTtsbPnEZsZdEiVks2WFwgxYnHWU0yMCVYHBmNUCgBbT85R5tQ5hIO37Y3Izau65QqQ8fk/Hrj/0o6XuEPh9JfQZh2KPNTkuSQgT4rPcJZ/1Lu0khL/dBKhp4UDUX7g4e/Ay73L3OJv3uvsWHvBkfwFWh4Ud6gVRgyzrThQymv6TIwiaQIL2jk3kMrQ6NaSBzoh+tVGBKtO7/9r2zH05hzkVYsHrn55AHH8SVgafWDYOqRgWL7VAxuhEk9PUw+Ja9W/h/XBhFhK/507GabzPBOq5V6zhxz2oMoe2tTquuyzDnN7Fc/vY3c0cqfOFYaNS/ovl+0wFBqQsDObMBjbcv3U384m7ycd6OsVdsaw3x11vsi6AZKEZdjF0KNUcOfMdQGRY4e89Q15FR1T6ums1mK3+rXTJ1VKlzqbFyGYmImstEBPePfI1E44ljakOhAhYne2IpmSlo87EAYFxWYnKD/ssx4naMJvDzDkolhdtChKkyJFViizkDnATcarCEYj3uXwwrQuY9g2yNOpYtPF7UD8sWYODkxTlUn9R6+Q+Ofble5cOB2xK5UEbAZpNkLxFX8apawVY3Da096oX/VDPgx+mfbuPvemSqHfDJ4cN0npOlIQaGqN4lj/hIIJCXzJufklTPsm76G8BNXhXtDy1OsXk++KfXN+RfpqXyHSgQ5yDT+o6vT7s8WECPoLb0YKM5VOkxNyKjvPVFht3pY0XI77dRV1y3CfCiXckFEo13/Qnz+AgaL+xba84s0mc63/i+hD6onDoI9eLBQ131jnXeE+Ev5CN+XuhKiQAL/69xukYsjG0OQML3iTGek3wUhqto92Iv1GV8e+BOOU8a/MEbBY7NIqxujNtCxc34Mj4lgj9VrIAF9ce+tBwJby8dC1o1K4gnENbNgEuniCmq1KVGu/rpSuL1q6cIvSyUHmnYcXLFgWU7xnIoFEtv2Z81ZfRfcUfPzuCO579OV/9FXzntTIzFc8ZpGbKhIFkDBiCyD3upQMRBJ+wuXWZipbv4wLCkAAmvUp7sF4hFedbz97J7mA3Meemz+ihJ1roqs9XwCV90FJdymLByH3358mpxQPG8C2E4k88MTi2JrtU2V9r3qYF+ZVW1ys/3eynIsM5defryTiLRjfbAT4t1QxMYnWdzsZRu7J1C9/OsMkY8/j12e11Gnm086hdPj3rKhFsAL8rglv7Sxw4lhLiohsTIWNM7AyrnWu3q8kewrNIcF6MFNpAt6HvvsqwGzM/XoXB+5ajCgs5iIz4uSu79H4sWfCyv5YPNAKKG6+1lJhlRemXXyH/rPCGAAAAA==',
    party:'data:image/webp;base64,UklGRl4lAABXRUJQVlA4WAoAAAAQAAAArwAArwAAQUxQSK0PAAABsIZt2yHN0f08b/Uwtscz2VlvbNu2bTtrxbatRTKxbTtZBbsxBl8y6vd9nvtHV1X3V109//Y4ImIC8H8yVVUqJhqC9i4NAJBVShQAQo8SBeYbvTgArY4C49ZYZSFAehKw2o1vfvLvBw9uQKsiGHnjF+S7JyikB6n+scncxxeHVENl5LukOXl16EGKX5ExmcXE1+ZVqYRgApvmbom7I/SagOWmJWNu5CnQKgjGz3QnyeSPq0pvkYBzGJlv9ulckApk2J3MMf5zYWiPwZCnPBU4m2sjVOK3TCxYpPfM+xatBLevRANXMeYkvjQQ0mtme56pRNywCqK4uyDyfih6jOJyxiL7ekFIBTD4OaacxGuR9RgErJei5yVeCUX/Kxb9Fy3H+EeEXgPBZbRk7hb5yTCpQsBPphQ49+tFOvQm5v9rGSgqmGFNGvN9fWjPad3jha+n971/zkJQVDFgF8aC5jhIDxIAP1p9+bkARSUFv2fKcU6cDb1ZBQCCoKq30XKML4ceBdEQBJXN3i5xE2aBBfNPpedE/hI666NY1ZkfuQ2yjojMUgQcQs9xby6P0J6EAGRaYyGIhCAVynAlU47xgyWgbSmAhgLQmhJFrkplRBrPFEQ+mkHaCZjjwLuff/bWrQRSSwL87IDzLjhsGUCrohj3Ba3gMmRoU7Hy28y9fwloDQlmv6CPJGdcuzCkU5o1GlmjESQvw5ZMzHUehNBGwPKTaSmlZHxjMUi3iYi0ITL7Q2RMKTpfWgTaCVFBsagAUJzBmOOcuTS0nMjQVxiZ2+Rlqt0lGQBkUkpxPptOkt7kBO1EADB6599ccOn5J283DEAGwaB36AUfD0Cbis2ZmO/p+7HQblIgm3duAFoi4Ed9yZifuA20LcXgbR/9lvnfPLzdHNCA5VhovAHS1sVuBTTu0lWKhU+8563X/7r/EGiZQxlZ5K/OodKGYNUnSDI2m81Eki9uCcjZtLzEnRHaENzNMv7LblJs+CFzn/sRtEBwkaciJt8ToVzAIdOYzJ2t7pbIywY33i9wnzgW2obiL+WO7CLF6lPYTGYx8YPhkKJLSxnfHCxSRnEcmVg+Ge8+ypy5kfc0BG0dX4prdI9gyDtMzI28TVRyFMczlqBxZ2gJxc5Mxnbd6Cw0HoGsvfHTzfIS355TpFsUO9CZb/bdUgg5AStNNy/jLwxUKRAZ840bO+gsdE4aDmlHFH9iTE56NG6NgG7NcIWnAkbugyxHdMD9TCXc48bIChQ3M7GjXmA+AYK2RYdcTzJGksdD0UV3MZbwXyLkIGAd9xKMvDFoXsByU90LPKXkRcXOTUXbgwCHvOHktGc2g6KbbvFU1OQRyPIguJdWwr1vNLTgTEbmO1utncR354R0ACKYc60dt1tBoejigGNpBW5p/RIBqzfL0HhsnmDO15jynHz9yTed1tYvkaGzAbmKbhYM/849L/G1OUQKRAfex1TC/fWAVsUPms5c94nbZxi0wbNMpYzfjoJ2CJJlWRB0t+JYRnN3N3IzKIozbOPuJThjZWjORkx5xqMgGTD7XfRyl0NR46LZ2cxvHgxFWRn8rlsRE09BlrMPLY/fLxYU0sB879JK+PSfSK1BgO1e6bM08aHVoFJKcSzLPT0U0nJYgfODeSAAMqzTdC9IvA6KehcBfrbFpmMBRXnFmD73IvrUnyK07FNi6jANkBCw+rQi86nLINQcRNEqijZFwt8ZSyTuA23ZkCmHxtOADMDmk+ks4JVQ9EANQdF+hv2ZShhvgbQsOdPz3NPRs6GxzHksv0Fv6LBi3ERakfOjBgDB7C96yqGTr933XB/pJZz79DAIni4346cQIOCPjHmkk2RiWeOvEXqX4g9egs7dEQDFj/rMCphicrZxXm9bi14i8QxkABTnMxW1b7yyCiJaXkTqQrBIH70o8u9QAVTm/zdTP9zQXxIaAe1rI9OaGPIcrSjx+SEQAIq1Z9I6lXhTf4hqAIAB84348UqbbLfLLjttvd6y44fNNxAAROtAcA1TkfGDJaAAELDjDMYOGa/tnGYAMM/ah130wHuTWXbie49c/etdlgKk+5DhV2wWOft+itCCDFt+STMvcEtlLumUBCAbfcA9H81gq6dkrcmcuZNf3hYqXdfA3owl3FcpQMD4O0gyxRiTs6zx9M4EARbd754mSaZmMmdZtxSbTvKX0K7LsDnpBYzcEFkeFNjgrj7mT33xlE/pOc7jOyEBGH/BhyTNzNlZ92TcGNoFIqoqBQFrziy3dQkogGG7nHL1DVedsuePMaKvxB7QdiQAv7h8BpkS+9f4DKRqEjJBqzaC5iwzpdyuCEUQRdkVaSxcty0FFj5nMmnG/nafuAS0UioAMOeCC80zAK2iA+Rn39LK7FsKgISskTWykGFjj0VLQsoF6F6fkJEVdPYtW60AzL/HZQ+89M57rz91x/kHrTAYAH7xTbn92ikO2IJFk+YuJwFjJ5DJWY2JwyAVEix82jcsO/Ozv+/9U4ycWG7vzi2VzFuSPdEopcCOnzM5O+glSyQ+DkF1FWv8k2SMKVlKMTpJzrjr0u9ZMnKnTokOfpAzSNpM7o+A4oCBZ5KJbXuKTWOxxWYyp0dyHWh1FGtMYXSWdbdE0sttgawzUCz9BZMl8vYGpEix4L00Z3l3M7bG7yZ+9dU3k6cac52MR0BRWZX5PmBk+x4TS3riOh2DYun7SE46Y3YICgN++BYjy3skye+fufLk3TdY4afjxo7/xSqb7HnChfe8P5XfTlgfggrhVCb2tzMuh9ApCLKltt1gOCAoVKz8CRNLu5H8+NotRs2GdsP8o8YPFyiqK5jvE7MKfPWDfkBAqwoKFSt8ycjSiUx37DI7AGgjC0FbQ8gaAbkBFc6wnbn3W+IbC6h2DqKqimLBfB8wsawbZ163LABVFbQroqqCap3KJivwygAE7Vy7GU5iYtlE3rsSIJmgDgV6O1P/ucdHVgZCNUTxsJfxxE/2EKgK6lEwz1u0/muN5ywC0Upg4IssYc47RkAUtakYPZ1eiUS+vyMQKgDVxz0WGO2XAUFQJ2swsaKJvHEJiOZobocynMKCxIlbQRR1qjiEVhWa8+OdgABIQK5KRwTDv2V00pr89zIIgpq5tEJkIq+eH0GBJbb77W+3GwZIJ6DY6nsyGfnyOATUrOCZStGc76wNDPrVVyT59e8GQzoBxUq3TyM/Om1eBNSsYOgn9CqRiTNOnOc2Mpkl8vZBIp2AQsYs/4uFAQWksCYCftZXNRr5AZOTpDd5OrQjCGgd2FBBWQ1ZFlS6bTuvHN1pzDeb9AOETog2GijUxsBBgwYNCCiULKh0TwO/ZGL1ncWRB7UlIQhaZxu76tYH/f7iW+994oVXXn3p6Qf/ftXpR++83s8WRK4G7QoJuIaxC8pGPwtSSjIB0Bix7Wl3vfpZk52c+P5jVx6ywuwAEIJ0AQY+ztRl55VRBYDx21309kzmpmZMyQpTijE6W+3re49bYyEAoloxxeIf07qLRyLkBQXw45Mf+JqtFpM5O+hmKTlb37txz4UABK1UwFLm3k3O6UvniAow5oBnppKMydnvbtFITrp928UAlQoptmZiNyderwpIBmCj674hadFYUbfoJD+8aAVAqvSr7nL+d25RUWDe3V9KZDJntd0SOfXS2SGVAW6ldZV9fwgUmOeId0hGZzdaJB+cW7Q679C7iU6egNkP+w+ZzNmt3uQpqIpg/sldRicve5lMxm52mzIMUg3Fqs1uoztpxi437gatRsC+dHZ9NPajm6UU81My9075KVVp4GzG7uu8pZjYtjWjeUdOrYpiQk15MmfrzM/ee/Hxe+/421//fvfDz7758RTmejJvg3tVRDHnq0w1lCJJznz9muO2WXnc/ANRqHONWHqj/c566Eu2Rivh1jcSUpHx39Bqxs1I9r180VaLD0a+hKxVkZ/NtexRE/5F0s28xZs8FYpKZliLxnqNTtqDRy4vaA1ZUBVBvoiGLFO0zr/pKW+S9GaMkXxgLpFqBOzLWCvm5Lu/Hz8AkKAi6LCIhgBgjhUv/oCtky8cAkE1Becw1Qp5x/aDAGRB0N+SBQBzbHfGDVf9cilAUVV5iFYnM29eQQAVQTVFFfkqqOygT+n14TZpZWgmqLJkmWhDUVnBmCbr1PjvhUVQdRFUWLE56zXxphCkatXOcBKtVjz57gj1diNTrdD4xQiR+hIJT9cNE2+D1pdisf/QasaNW0JrK2CF6fSaYeJbc6jWVYbtmFi7xmNQWwEns1lD/ulCIjUF3MhUP0z8NUI9CQa+Qqsh40cLQjsnWRDNtFvm/461bNy3HxT52iXLsab8RUWnFQM2Pvm83287D7QbFHvRa8kZV4B2RrHac2x9ewdoFwScTaslJp6GrCOCjfqYYoqRPBTaDfcz1VPk44NEOiBY9HNGJ8nE5oqQqgkGvVVXxq+XhHYg4FQm5idOUK1awJJf0OqJxnWRtScy6CUv4f8bgVCxDOsnek1F7o3QnmL4R7QC58xVu2B/RtbWidCOfNhdijPrK/E3nRAZ+LKnAuMnI6DVEoS7mOoq+rGdQIbTGQsSJ0BRtbn/Sa8t7oDQAcHiXzLlmMeVumBErC3ntKU6AsUGfXRL5uTBUFRcsS6dNR39qYEinYBilRedJP+zPVSqdxStrhJ3QUBnAxobnXHNuTvOAUXlFVfXVpO3B0GnFfmKbnihntwSn1wA2jFAsyxTQfUVc39URx5J3jA/FPUbsGwfvWbcEhmf3RwQ1NIOdNaqRZLfXL4hIII6buBkNmvEPZHx1UOGAaKoZ8WVNWKR5FdXbQBAA2paMOgxpprwSKbXDx4NQBW1LVjoP7Q6sETyi+vWVyAE1LlibGQNWiT5+qHjAKii3hWr0LrNzMnPblgnA4Ki9hW7dJtFki8fNhaAKnqg4qSucjPys5vXHAQERW9UXNRFKZF88cgxAIKiVwpu7xY3I7+4ec2hQFBB7xQ80x0pkXzh2FEAMkVPFbzbBW5GfnvbOrMDQQU9VvCvyiUj+cKJIwFkit4reKdiZmTfzevNAagKerHg4Qp5MpIv/GoEgEzQoxXneGWSkd/fuOFsgARBz1ZsSq+Cm5F8+dcjAGSCXi5Y8L9u/ebRyanXbTwYQBD0+IBTmPrHzUi+/sthAIKg9ysW+4zWDx5JTr1284EAMsEsoWJXRu+Qu5F8+6SRAIJgVlECzmPyTlgk+d0NWzUAyQSzkKLZ1TRrxy2R/t4JYwGoCGYtBfJnMqUSFp3kF9du0QAkE8x6imDLf5ApmblbSiT7Htx9FABVwaxpwJwnvc7iTyYcNgJACJiFVWCeDX535yvvvHrXHzcdBQCqmLWVDABCIwMAzQSzwBoUrRpU8H9dAQBWUDggihUAALBUAJ0BKrAAsAA+YSiRRSQioZdqBfhABgS2BDgAylEBfwHVAXh7B+TPsx1J+ifgH+0ft78oOz/q3zA/MP2H/if2r83fgz6mP0D/wP7Z8An6g/7D+4+uN6rP3K9Qv9O/v37be7t/pP2i91X9U9QD+if6z//+1J/0/YQ/yn/b9gD9pfVl/5f7kfA9/Uf9/+3PwB/r5/9vYA/83qAf871AOxp/pv43frX8q/Iv9R+N37ldZn27VwNBgXZ/WO/N1dL0701/x3iL+RewL/Iv65+uXuvf3njc/Pf9B7An8v/rH7D+2t7Ff2s9i79ef/m4EI8xoKrkv/Ytu2k5zkRVWvcLydzhZN5yBnHlSR8OMmgxdUrgJblbqn62MF/ri62NNfyFSAaZTJAjSYDUiCK67N12fVniv5h4zCGAf5nLOTb0TsXavQXEhE+mmo66Wgok3Go/qGsk5XfSv09WR44OlHj3VDWl2GCiXSRWZZM9SEkC0F+zk3r67e37RcEx8s2bI8Ag9ef66aMoP/1h+ND+3008U79EFul/Bcd5Cx2gF5BlU7vWCpqAcXGfRyhmSQ7v7+WOgq1WvzjX54r38/sOj8N9B57mhKuTlreGKECRHoX5vFxPrLHw4+H83N3mxQw6Rv7GET7Nqfc4Kqt4UxBhl1fwXsMrb5nmFv0ARXRN1axs5/FMa2SRGezsWMIAfu82L/6RHj7Lcuxs9Gw60cbnhsDXrtEcPMFJ/R1dTYZyTjNPTT4ULYLgyl4JabjX2IH929WxTpPaTVLYLxkv+X+aF0Kk1e1PiGUcOT5I/U/KI1YTGRAvQ8UddKE4CEtmzyPvuNdnK/qvC+D+P66BxjbZFEr9JfY81X/zgY3looD3euN7Iql5xwRoyNchtU7rAVtsxc0tu8Ydr5cwj1twx0brVeTwAP7uekYSd2XMCb31qS30kHQfoBGASC7OV9uXb24qEJjGwOL6YX+09+bTrJzN64ioKY92J1cCFzd2gvmZRg1O5Z9MKcmfe+cCCeV7xYK2DwOasJUjGZ10n8etr4FN/AekNR4odQ/0BOkgQrKDvvjd3ExdaB145vwVrA/JLsvh4g3rGNkgWNjdDsTuYUvJkvtN1O7h9pzk4/gue1P8J8LE1e6uQ5n5VvWgG3qhp0i7zQp6DoDLzxK/VxopyFPOz2fy9yafJxgOABMwukTOAoJSie3+dosrbJscErCw64N8LCxqR2RgU3UPt723qx2XZj1lwPxnBgADTcHhCnqu90bAsPMTuLaEuTfjn6BiUJ25Mvq1saXH/oluYZsZzuN6nLFiXL49oTyq9c3VukccdfxeBzc127nSWNGRr5/4grRDvNHmOeGIKLL1ix/Zn8Mf5SbPcHhvt2WB2Ubme5d/r26iHyTGVWcA4oP/YJm21VGUoyi2Z+izUI9m0E2Eyn93xsDOEmBl9EDC0B8ZOauCQBd1nmPDqT+pg98idNjjnRl1nKA7IeV6lna/NkedB5ppFGipuTSAqz3xpI/YkRl+s00+YMue2jKB/87ILK8Y1JBgcfOnfo5tLNN6ZYpaumDdxHd/EsFTjRIxR+5+dbHrXfKSuW++ovXONdA8m1+8BNF+/Sokn8MP+bW/JR97EF01jUWxN+Th3OtRFfzmF+K8dFaAt/Ne1GJdiaDLN/2v4OF5JD/3Ze4eA2zmr8XbzjQcLBOHSjr5XJ0v5JayWkx76HomwEM+WsONRGBdxmY9PvbR7E8yYmRN938l2Z02jxRVD3wayzVswdWrTuPFd88dNmBNfhG3aog22c1ei7UoHT9LSzC17ABWAWk6sgxEuT3ZqbglCOCb6NkuJBDTqJUCxBXZiy/SUT5H79zhbU24sYgNKI516vm0qevvV422uVVtQRXiPqzU/d4AaREdCZXlMAf6ulHkwme/Wcrz1vBkhpJsO75I/uXn4vC212s3mWAw/KuVUrD6ATe92qpO6/SzPXn0WS4iAzVWCQ6/M42aLGGI/H17imaVSk3HOx3n7U28GOTMVYNl3CMgNSyiiGaIN5elnx7qzvUBmX6WsdbqfmvyBDJ1v3TNObl9fvAguNWoWfR0tErLq6f2GyB2BUxYyI1NZINBT6KcEyoHkgJk8EFkMZhtYnpWHMxYnh7gbxL7Q3I9J0CPMhoIK2dVrSOBv4CzZ9JA1WtkqRTK9M2BVPVsvG+VsmW2dLTdl60xQInmEn/UrOECMTFWf58MHVCe7NHksaSeOleE9rSeAM/au26pts6GQ3OnDYkxbZe/OwJuXsxBlFDI65+ZB61Lg9zNF2IH6TmH5/AvrvX6Z46+rt0h4SXVKcq6pfI7m912i0qYXr5ySuBfyNqo8v7ld9ZyeaWxRQMP6BL9Z489nN/YScp2PSDVJzJO0DYDo50pn/FCE4oA265KuRUwfji0oVJdKbAHVU7s+cin+xhgjQBXac5eAhtQZp+vOeCrKvSPl8btM18IBNJhtQy+SqOxa0crLwITkK5EYr18lk+BWEk6nXMTgxVwV8xte/mO9NeQRIwZ3BCJgS64AS8xwuXP9I9+HaLhN/DK6Cq42gYYS3YxEvvfNavaa0a7PluOdvSVeYsxnrnH4gC/ufWkbvyw/9eIPk1eDriIsR++jqtf3eR8otWQ5RbySGTggUzwS6sr1QCEJ+jYqA643LUJTyrige/Rnqd971lEhZkBWxPFpdHvUwlG5ZXdknGwlguH/ZMcdfMoVbbFLf7YZbng++sacXIYoHRVk3KvGgp7sXM5yVKI1GOPJAUPDRoWNwdX/5m38s/q++U1vYTJk3H8J2n9g+8Bt2eMdrq/wMWV8HyXnfO7kqWAhOHLF8bD3hxXw+NFpYQ3eYlNTmfxo0fgwC0eI7hUAxWbUixV8TsILXIplYirCr27dE/yMGoHt6zEchmIlJyDun2+tPev6PD1IAdFNikjCIy3qAqsZl4fugMWb1sC//HE5vj1FLoOhHrC2nJsENjd6W1cx0oaG7VT/EP5gEjdKvmS28PNZgvkuExAU1RPnGWidq+YJprV4smRqYE2u/iENHHCHCftPR5+AKEy7gGQ1n3JUS6+0iqRq7Nagjq9egOouHsWlbRv+r8Gtln6AB+ycCd9p1mkPYJDkwT120CwUucOU3KXpqWOMwZBwNHmmUd2x9jfM+fuR8nhdcPfoTrlOFUHSV3H895VoL80aWq33bDNzT9mLnPQqtaJR1hWVWmJvW2jX6RSiNe93qfNZCmG+L1QcVko8vjjTgv4Ubxfw4Jb3PYoBBtLRqkqH6ZkIX7djPHeanC0MaVOvFHgIxD3wmwDX7WW9ZF1wOEF3z/ru/hnWthirN9Tb8RL28HyXhLYAoflrKZ5OpqXvqtOOvLklxySbP62njd2xOM2zWXZsRKivptDZrMW9S7aa2/HvOSx0kVVEjJ7nowahuq9iFL2UTJrTGKK3qgNJwLicWhV0DuKpKVg9IH/vJ5knTbi2p+co9iuqr9aK0YH4ZurDFV3CknhoViisoCYi+oObJebNVU+JLfxDQkBqWPL4Z4gsNqzkcIVUM16Hm3f+tYLeuVWh1V9+tT/tbMcyYrzAkrBkzvXRWxlm1QSUFSvzqmu6tgAuWZOOGhIHTRDfSGkMAJef+fJJExbiOfJp7g9aGWmWqR6R76BCK/gFecG3PrBfeZwfQbogSXibJQeN0IIn7bg1zqNQMJ8Ofnmyp2EEO+yWdnM1vCpMNaOGMlmAllZK++wBwlheOqpHFYHcdacApPmA5Z0B5TlK7TXU1iYWOeMGoU+mhJ7nlp3oCTmVPgBdsYpRYj/mDHZykoLxn0UVCVKQ3rtygh8vS8r23RV6u1WFKyeazTA3ZPO42Eu1LQ9EpTVjqqFpRIGehZhx0hZeHEWisUjtlaEC/v/bfaxrTKdO7+hOoOVHEemi+JT56vi8+Qbq0kPq4ZC+JXtthscMFDtxfsl4wp/hsTJoQo+sqYj1npqhQb/Ngej4nO2cshSDc3Pb3XrRCCkukj4J1Lpef0IyUIeSHleMLBV4SW7OsT+jIpnADw5mM95hCmzmWmkBm6Cbq2oxJM4W5iP/3lwVb05TUtIRz3hplEgE4OSzz5Dbpg2/HI2DUfwwpIb+zVD3zxJgkJ0+TJAKOpxdV1YSiTz4qo3rIz95OlzeKLPeQKdwJKP9GJY64klWQTxgtzDqN+d713zrrkYGudPpfKdTdKGw3CGPrVX2QDYA3pATyrflHD4ErP6aHy7u2lMKDAJ/PWBsyMP0TGTijpMsPHpmeQ0hffH/BHa9VedgtN6Lwj0nldiAosT1w49flakPpjp6RDYbI1PiJsi7j3S1f/0WbochwkeOuVjJvtgeRtmOxPUGfF1PRadmUh2fu9IuAG3KkZjj0YK7T7zDsXjF490K8Tcyk6dnUHNWeC1+CO9i9VG+4R+hvFbc0oqbzKTq/76lTm3BwAC6ICbAehJVvdEB9fupE2vqDA1ekAG76M22J9NYHdK2IKSxqXB1T7cI95rmG0HEQiC4Z7opT8rRilZds8UA0HyoDfWZn7Ud4yY+fUIMLjlLgWLcvzsvlmtNj81C2Qc4GJK6tqxnH88BOZ23Y0Dr28hDm0qyvRTpI5jOUtswJMZpmFiaj8vwDF2W6+aJCevrHPgPUUEyyqTiRHlB2ZdX0PXPeOdwiDXivQ3Ba3JPt23gKmI4zsmMw9t4muKk1bFKJKYEJhO+uBtOQkTeC26jtNIwr//l4P/8wM//+XhCQVt28bXpGZLXfxwOBRynh+Gv4dFf2Csqgrxb12psD/rIKACFAjSP5cQ6kGQ7wa6Uikp1eZShq9bvjTGxKxoUngV4uGxtsYS5rq8QMqSeVZLVJQDPKmPC1R7x+9wIqqCalA+AUunmATcsi/vLpgz96GZnnzioStU91tPFtnXI3Ppjjar4EjUlX8m6Mx4Aon3U6o4nvARMYnPZKX9k8+Tpq+pzaE1Cr9xMvtbt8e7vUgB2wryKtYs5q83Jr8alUUXrQXHbyBfrvpZBwTUe0eoq31bDv1esZzx0C5rdL3lEIHaPhhTePYoiaFNyd11z8WEoCPuCmff6V1K/ewnMAU2FCt0slzkvQb1vNg1Sre6YDpXQa3n+WzNGddi8U23Lj8JmEzdaEF2C57GRnbw0EhtTwV9y0Y3rJ07PMF9jx2Ql1nM7jnCUb8Df04vEw6biCdrOi66WkCg869SDoZp6Mi5fvr9nEI3WgMPrtbWvzued0y/7JfhBXjJQ6v4WUOVlfPxuyX9KpB75KecTAXXK7jSKOTBoPua4w1t76/dYIQAn/fvDG3eYq9zSeXO29zMrvGCJ6mr/wiECyIBqgBUk95vlemA5Mc18YwL1CRPIMDYpvWXVUUzyZFg9YKfA0acFZTuoElwy4MEkIpdVVJRNdb0SXiS7SVLYHxJ/KwQzBZmTQNFFx8aQIyY2PKEP5SiUwTR5O2BG6B29PQ0XNAtMskRJCyRvIKTRAyhvBjOmx7zV8L9G2LCl/4lXjfVZwCf8KmTcjggKDtrzk6l9UQa4Nn7052BKjS+SptP3jDN7Sll3QFZvlXojQY4SQ0uzcxp/sfLMxac5KjIfBpwszmT+hd2muELMT6r035wYH7kd6jsOEz6ebDLg3iOzKB88KzWrmIsBBiTBrHYp329b2kSeYDjHkPWkBpokwosh2Te9uQ12MJ7dcsYaSllvUpIDoYIxfl00oGzU6+/PVAJbUzoejmHpFp6WXPgXttZtBrzmN+TXZR9RNTFJFEVYPsjp/Z4/OsTBMGUDw9uPG5bXvFT5ZTa6nHGzApQZen0iB9mzOwYwMeRCY3HQdGuWk/f6/U+Fg25Zm0F+c+lMWFFsxHyHehIt/afBKiyd7f91U3L5X5bHt6iltLXhdlONU0dtYKL5yJlDztoQkg0WD8NeGRTqh0KUDhOVhkCv5sJhmZvkihvWFkw3VNLDlsQtUswW4Zw4b+FF6ya3oe0Ji+NVZooHVj3yIBDtmP4hZnHQG4XTl8zPijRmmAhznO1W7NV3ASQq1AQej7piT99hYdES6t5imjTsAtMRklZG9GyO9893fq7yw9uqT97Zbg6oAABZu0+P9xe9/bfPHfvpIjlgPnCozTVpnqmHn8WhCxq0gc+2zBiIDB0ednBqBZnMXQV6RYG+6+zTYQTMBIZeOYSJet838R8wIY0lnU9sI4w5w/2dMT0mw/Y9fk0duIubXBRX4gPFdSvkmBqE8eeRVg3i74zEtPFbUwYcVuRRxvdWLHoj6ihjjx5PD2F44QB8fZUGUdfrR7u8l+sjQvvWeZxHar/abXN0wkt2uW+U9z2uCw2KBnpLdOVqEIsYS1nh/rkCBAKz+5/Cfgpw139jiOOgAmATxp5owCimLC9ersuLRkwou5Mc1ed2gzzGg2j6xpKRhyFp/5NndAZczZS0aorNxvUYjPxM09r0dVFRS7CUS0R3sWVRqJuK+1AZ85GAX7eMTq15hUF6Dt4RCiJ0RbRl4C3xgoV8f3AgYJEFyAXUGgDHff6oOrgoakvirDxhXkkuuc7O8oEpwy3jBP7x2OqqnCP4dAmhTMevG07BfQ3s/TN9dgVb9eCgME7H1CzzB04AMz4oleJRkj5F4ZSaCOTXM6+HkpZQZvHXuZv2+J3c/supKeAi29cP2N5OCLaiOmauMPv5LawyFrTHQvvkihsWAmbx334gdGewjPJh9yxW2Z1vOPKchz5qmdL1qbxWx1u2Nvvk6dH4/pC+2NO/HHey3xg4kwR7DGYOP46OtGCqAIMTc6ShsKiFL+TiK9tIpTEZ1Yx99gQrwBAe9X43Mp+DzZO+hTS2Od+ZgBGf8BnedeiKeddzQmRPK1KFLsErWhHSL+yy3rmEHYsjrxb64XVOTj1zeLN856xUXiNESl5GD6HsU1S4RmOSmcwDfZnPMrghHnZF94CCugxzom7+L93T926I8FWlJylRhiJP6b3sxo4N+90MAUwjNtqZRMfoyHbLBitOC4skcJ88w78XBfQ2xJrPJubJFFT9vPIpPNvrVmy5zKthtASlKiIvWOVn6e05bZfOieGeWpV4TKTDdoUfJc2L4a/XwQL6UCshVIDHnqiSBTIItsB9jawF2lhnk1o8iGkiygoCfEw+4Tabvibl/JI3v4m1zQQBelpGH2BjJXxyyUGIbC+GezXPQvCPm/8y12EHpPYUAAEjebKdmCXZCaDV0fgMZMzwgD2ah7wzaX5A2cWgdXi04Ui8ZBpkI9G0D4FxA7X+Rp9aKejiGUfVs3oiPMiiZigtOd60cKNCbcpRD+jUW+uA9CHFF5vS2nJFq/1BQLS9TShgLGN3q3nLRc+w83bcvQIz0srhrjASian85KLfd5+5o7YHT8lsW/NyAWuw0LIjVKqoZyQp31VBgAAAAAAAA=='
  };
  const CK_DEFAULT = [
    { key:'gender',  q:'성별을 알려주세요',   sub:'오늘 오신 분 통계에만 쓰여요',
      cols:2, opts:[['남성','man'], ['여성','woman']] },
    { key:'age',     q:'나이대를 골라주세요', sub:'가장 가까운 걸 골라주세요',
      opts:[['10대 이하','num:10'], ['20대','num:20'], ['30대','num:30'], ['40대','num:40'], ['50대','num:50'], ['60대 이상','num:60']] },
    { key:'company', q:'누구와 함께 오셨나요?', sub:'함께 온 분을 골라주세요',
      opts:[['혼자','headphone'], ['가족(자녀 동반)','house'], ['가족(성인만)','hug'], ['연인','heart'], ['친구·지인','volleyball'], ['단체(직장·학교·동호회)','briefcase']] },
  ];
  const KNOWN_IC = { '남성':'man', '여성':'woman', '혼자':'headphone', '친구':'hug', '연인':'heart', '가족':'house', '동료':'briefcase', '기타':'volleyball',
                     '가족(자녀 동반)':'house', '가족(성인만)':'hug', '친구·지인':'volleyball', '단체(직장·학교·동호회)':'briefcase',
                     '10대 이하':'num:10', '20대':'num:20', '30대':'num:30', '40대':'num:40', '50대':'num:50', '60대 이상':'num:60' };
  function ckSteps(){
    const c = CONTENT.get().checkin;
    if(!Array.isArray(c) || !c.length) return CK_DEFAULT;
    const steps = c.slice(0, 3).map((x, i)=>{
      const opts = (x.opts || []).filter(o=> o && o.label).map(o=> [o.label, o.img || KNOWN_IC[o.label] || 'volleyball']);
      const def = CK_DEFAULT.find(d=> d.key === x.key);
      return { key:x.key || 'q' + (i + 1), q:x.q, sub:x.sub || (def ? def.sub : '가장 가까운 걸 골라주세요'), cols: opts.length === 2 ? 2 : 3, opts };
    }).filter(x=> x.q && x.opts.length >= 2);
    return steps.length ? steps : CK_DEFAULT;
  }
  let CK_STEPS = ckSteps();
  CONTENT.onChange(()=>{ if(!document.getElementById('ck').classList.contains('show')) CK_STEPS = ckSteps(); });
  const ck = document.getElementById('ck');
  const ckBody = document.getElementById('ck-body');
  const ckProg = document.getElementById('ck-prog');
  const ckBack = document.getElementById('ck-back');
  let ckStep = 0, ckAns = {}, ckBusy = false;

  function ckRender(dir){
    const st = CK_STEPS[ckStep];
    ckProg.style.width = `${(ckStep + 1) / CK_STEPS.length * 100}%`;
    ckBack.style.visibility = ckStep ? 'visible' : 'hidden';
    ckBody.innerHTML = `<div class="ck__step ${dir < 0 ? 'from-left' : ''}">
      <p class="ck__q" id="ck-q">${escHtml(st.q)}</p>
      <p class="ck__sub">${escHtml(st.sub)}</p>
      <div class="ck__grid${st.cols === 2 ? ' cols-2' : ''}">${st.opts.map(([label, ic], i)=> `
        <button class="ck__opt${ckAns[st.key] === label ? ' on' : ''}" data-v="${escHtml(label)}" style="--i:${i}">
          ${ic.startsWith('num:') ? `<b class="ck__num" aria-hidden="true">${ic.slice(4)}</b>` : `<img src="${CK_ICON[ic] || escHtml(ic)}" alt="" draggable="false">`}<span>${escHtml(label).replace(/\((.+)\)$/, '<small>$1</small>')}</span>
        </button>`).join('')}
      </div>
      <button class="ck__later" id="ck-later" type="button">다음에 할게요</button>
      <button class="data-link ck__pv" type="button" data-privacy>데이터 안내</button>
    </div>`;
  }
  function openCheckin(){
    LIVE.count('checkin');
    CK_STEPS = ckSteps();
    const d = LOCAL.checkin_draft || {};
    ckAns = {}; CK_STEPS.forEach(st=>{ if(d[st.key] && st.opts.some(o=> o[0] === d[st.key])) ckAns[st.key] = d[st.key]; });
    ckStep = Math.max(0, CK_STEPS.findIndex(st=> !ckAns[st.key]));
    if(ckStep < 0) ckStep = CK_STEPS.length - 1;
    ckBusy = false;
    ckRender(1);
    ck.classList.add('show'); document.body.classList.add('modal-open');
  }
  function closeCheckin(){ ck.classList.remove('show'); document.body.classList.remove('modal-open'); }
  document.getElementById('ck-close').addEventListener('click', closeCheckin);
  ckBack.addEventListener('click', ()=>{ if(ckStep && !ckBusy){ hapticTick(); ckStep--; ckRender(-1); } });
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && ck.classList.contains('show')) closeCheckin(); });

  ckBody.addEventListener('click', e=>{
    const ok = e.target.closest('#ck-ok'); if(ok){ closeCheckin(); return; }
    if(e.target.closest('#ck-later')){ hapticTick(); closeCheckin(); return; }
    const o = e.target.closest('.ck__opt'); if(!o || ckBusy) return;
    ckBusy = true; hapticTick();
    ckAns[CK_STEPS[ckStep].key] = o.dataset.v;
    LOCAL.checkin_draft = { ...ckAns }; saveLocal(LOCAL);
    ckBody.querySelectorAll('.ck__opt').forEach(x=> x.classList.toggle('on', x === o));
    setTimeout(()=>{
      ckBusy = false;
      if(ckStep < CK_STEPS.length - 1){ ckStep++; ckRender(1); }
      else ckFinish();
    }, 420);
  });

  function ckFinish(){
    LOCAL.checkin = { done:true, ts:Date.now(), ...ckAns }; delete LOCAL.checkin_draft; saveLocal(LOCAL);
    LIVE.submit('checkin', { ...ckAns });
    postData('checkin', LOCAL.checkin).catch(()=>{});
    if(canVibrate()) navigator.vibrate([20, 40, 20]);
    ckBack.style.visibility = 'hidden';
    ckBody.innerHTML = `<div class="ck__done">
      <img class="ck__done-ic" src="${CK_ICON.party}" alt="">
      <p class="ck__q">출석 완료!</p>
      <p class="ck__sub">오늘도 함께 응원해요</p>
      <button class="btn full" id="ck-ok">좋아요</button>
    </div>`;
    const r = ckBody.querySelector('.ck__done-ic').getBoundingClientRect();
    setTimeout(()=> burstConfettiAt(r.left + r.width / 2, r.top + r.height / 2), 250);
    render();
  }

  function markVisits(e){
    if(!document.getElementById('view-guide').classList.contains('active')) return render();
    const sub = e && e.detail ? e.detail.sub : null;
    if(sub !== 'lastrain' && !LOCAL.visited_seats){ LOCAL.visited_seats = true; saveLocal(LOCAL); }
    render();
  }
  document.addEventListener('wm:nav', markVisits);
  document.addEventListener('wm:toggle', markVisits);
  window.__missionState = ()=> {
    const done = MISSIONS.filter(m=> isDone(m.id)).length;
    return { done, total: MISSIONS.length };
  };

  setInterval(render, 1200);

  render();
})();
const ROULETTE_ASSETS = {
  "disc": "images/roulette/disc.svg",
  "bg": "images/roulette/bg.webp",
  "pointer": "images/roulette/pointer.webp",
  "mascot": "images/roulette/mascot.webp",
  "winbox": "images/roulette/winbox.webp",
  "losebox": "images/roulette/losebox.webp",
  "item_signball": "images/roulette/item-signball.webp",
  "item_soju": "images/roulette/item-soju.webp",
  "item_doll": "images/roulette/item-doll.webp",
  "item_miss": "images/roulette/item-miss.webp",
  "item_fan": "images/roulette/item-fan.webp",
  "item_ticket": "images/roulette/item-ticket.webp",
  "item_photo": "images/roulette/item-photo.webp"
};

/* ===== 홈 · 룰렛 ===== */
(function initRoulette(){
  const R = { ...CONFIG.ROULETTE };
  let prizes = R.PRIZES.slice();
  const A = ROULETTE_ASSETS;
  const wheelEl = document.getElementById('roulette-wheel');
  const wrap = document.getElementById('rl-wrap');
  const spinBtn = document.getElementById('roulette-spin');
  const chanceEl = document.getElementById('roulette-chance');
  const subEl = document.getElementById('roulette-sub');
  const lastBtn = document.getElementById('rl-last');
  const stage = document.querySelector('.rl-stage');
  const state = Object.assign({ used:0, rot:0, wins:[] }, LOCAL.roulette || {});
  let spinning = false;

  document.getElementById('rl-pointer').src = A.pointer;
  document.getElementById('rl-mascot').src = A.mascot;
  stage.style.setProperty('--rl-bg', `url("${new URL(A.bg, document.baseURI).href}")`);

  const N = prizes.length, SEG = 360 / N, ITEM_R = 25.56;
  const center = i => i * SEG + SEG / 2;
  const itemSrc = p => p.image || A['item_' + p.img] || '';
  function buildWheel(){
    wheelEl.innerHTML = `<img class="rl-wheel__disc" src="${A.disc}" alt="">` + prizes.map((p, i)=>{
      const a = center(i) * Math.PI / 180;
      const left = 50 + ITEM_R * Math.sin(a), top = 50 - ITEM_R * Math.cos(a);
      return `<span class="rl-item" style="left:${left.toFixed(3)}%; top:${top.toFixed(3)}%"><img src="${itemSrc(p)}" alt=""></span>`;
    }).join('');
    wheelEl.setAttribute('role', 'img');
    wheelEl.setAttribute('aria-label', '룰렛 경품: ' + prizes.map(p=> p.miss ? '꽝' : String(p.title || '').replace('\n', ' ')).join(', '));
  }
  buildWheel();
  let homeSig = '';
  LIVE.on('state', st=>{
    const r = st.home && st.home.roulette;
    if(!r || !Array.isArray(r.prizes) || r.prizes.length !== N) return;
    const sig = JSON.stringify(r); if(sig === homeSig || spinning) return;
    homeSig = sig;
    prizes = r.prizes.map(p=> ({ ...p }));
    if(typeof r.base === 'number') R.BASE_SPINS = r.base;
    if(typeof r.bonus === 'number') R.MISSION_BONUS = r.bonus;
    if(typeof r.onePerPerson === 'boolean') R.ONE_PER_PERSON = r.onePerPerson;
    if(r.notices && r.notices.length) document.getElementById('rlw-notice').innerHTML = r.notices.map(n=> `<li>${escHtml(n).replace(/\*\*(.+?)\*\*/g, '<em>$1</em>')}</li>`).join('');
    buildWheel(); renderChances();
  });
  wheelEl.style.transition = 'none';
  wheelEl.style.transform = `rotate(${state.rot}deg)`;

  function chances(){
    const m = window.__missionState ? window.__missionState() : { done:0, total:1 };
    const bonus = m.done >= m.total ? R.MISSION_BONUS : 0;
    const won = R.ONE_PER_PERSON && state.wins.some(w=> !w.miss);
    return { left: won ? 0 : Math.max(0, R.BASE_SPINS + bonus - state.used), bonusEarned: bonus > 0, won, m };
  }
  function voucherExpiry(ts){
    if(R.VOUCHER_HOURS) return ts + R.VOUCHER_HOURS * 3600000;
    const d = new Date(ts); d.setDate(d.getDate() + 1); d.setHours(23, 59, 59, 999); return d.getTime();
  }
  function validWins(){ return state.wins.filter(w=> !w.miss && Date.now() < voucherExpiry(w.ts)).slice().reverse(); }
  function lastValidWin(){
    for(let i = state.wins.length - 1; i >= 0; i--){
      const w = state.wins[i];
      if(!w.miss && Date.now() < voucherExpiry(w.ts)) return w;
    }
    return null;
  }
  function syncHomeSub(){
    const el = document.querySelector('#view-home .pagesub'); if(!el) return;
    const b = R.MISSION_BONUS;
    el.dataset.text = b > 0 ? `미션을 완료하면 룰렛 기회가 ${b === 1 ? '한 번' : b + '번'} 더 생겨요.` : '오늘의 직관 미션을 채우고 경품에 응모해보세요.';
    if(!document.body.classList.contains('no-game')) el.textContent = el.dataset.text;
  }
  function renderChances(){
    const c = chances();
    chanceEl.innerHTML = c.won ? '경품에 당첨됐어요! <b>1인 1회</b> 당첨이에요' : c.left > 0 ? `참여 기회 <b>${c.left}회</b>` : '오늘 기회를 모두 사용했어요';
    spinBtn.disabled = spinning || c.left === 0;
    subEl.textContent = c.won ? "교환권은 아래 '당첨 교환권 보기'에서 언제든 다시 볼 수 있어요." : c.bonusEarned
      ? '미션 보너스 기회까지 모두 받았어요.'
      : R.MISSION_BONUS > 0 ? `남은 미션 ${c.m.total - c.m.done}개를 모두 채우면 룰렛 기회 ${R.MISSION_BONUS}번 더!` : '';
    subEl.hidden = !subEl.textContent;
    syncHomeSub();
    const vw = validWins();
    lastBtn.hidden = spinning || !vw.length;
    lastBtn.textContent = vw.length > 1 ? `당첨 교환권 보기 (${vw.length}장)` : '지난 당첨 교환권 보기';
  }

  function pickIndex(){
    const total = prizes.reduce((s, p)=> s + (p.weight || 1), 0);
    let r = Math.random() * total;
    for(let i = 0; i < prizes.length; i++){ r -= (prizes[i].weight || 1); if(r < 0) return i; }
    return prizes.length - 1;
  }
  function makeCode(){
    const d = new Date();
    const md = String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
    return 'P' + md + String(Math.floor(Math.random() * 10000)).padStart(4, '0');
  }

  /* ---------- 결과 화면 ---------- */
  const winEl = document.getElementById('rl-win');
  const loseEl = document.getElementById('rl-lose');
  document.getElementById('rlw-box').src = A.winbox;
  document.getElementById('rll-img').src = A.losebox;
  document.getElementById('rlw-notice').innerHTML = (R.WIN_NOTICES || []).map(n=> `<li>${n}</li>`).join('');
  let shownWin = null;

  function openWin(w){
    const p = prizes.find(x=> x.id === w.id) || {};
    shownWin = w;
    const list = validWins(), at = list.findIndex(x=> x.code === w.code);
    document.getElementById('rlw-pager').hidden = list.length < 2 || at < 0;
    document.getElementById('rlw-page').textContent = `${at + 1} / ${list.length}`;
    document.getElementById('rlw-prev').disabled = at <= 0;
    document.getElementById('rlw-next').disabled = at >= list.length - 1;
    document.getElementById('rlw-code').textContent = w.code;
    document.getElementById('rlw-title').innerHTML = (p.title || '').split('\n').join('<br>');
    document.getElementById('rlw-desc').textContent = p.desc || '';
    const item = document.getElementById('rlw-item');
    item.src = itemSrc(p);
    item.style.animation = 'none'; void item.offsetWidth; item.style.animation = '';
    winEl.classList.add('show');
    document.documentElement.style.overflow = 'hidden';
    winEl.querySelector('.rl-win__body').scrollTop = 0;
    document.getElementById('rlw-close').focus({ preventScroll:true });
  }
  function openLose(){
    loseEl.classList.add('show');
    document.documentElement.style.overflow = 'hidden';
    const img = document.getElementById('rll-img');
    img.style.animation = 'none'; void img.offsetWidth; img.style.animation = '';
    document.getElementById('rll-close').focus({ preventScroll:true });
  }
  function closeResults(){
    winEl.classList.remove('show'); loseEl.classList.remove('show');
    document.documentElement.style.overflow = '';
  }
  document.getElementById('rlw-close').addEventListener('click', closeResults);
  document.getElementById('rll-close').addEventListener('click', closeResults);
  loseEl.addEventListener('click', e=>{ if(e.target === loseEl) closeResults(); });
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && (winEl.classList.contains('show') || loseEl.classList.contains('show'))) closeResults(); });
  lastBtn.addEventListener('click', ()=>{ const w = lastValidWin(); if(w){ hapticTick(); openWin(w); } });
  const flip = d=>{ const list = validWins(), at = list.findIndex(x=> shownWin && x.code === shownWin.code), nx = list[at + d]; if(nx){ hapticTick(); openWin(nx); } };
  document.getElementById('rlw-prev').addEventListener('click', ()=> flip(-1));
  document.getElementById('rlw-next').addEventListener('click', ()=> flip(1));

  /* ---------- 교환권 이미지 저장 ---------- */
  const loadImg = src => new Promise(res=>{ const i = new Image(); i.onload = ()=> res(i); i.onerror = ()=> res(null); i.src = src; });
  async function saveVoucher(){
    if(!shownWin) return;
    const p = prizes.find(x=> x.id === shownWin.id) || {};
    const S = 2, W = 360, H = 560;
    const cv = document.createElement('canvas'); cv.width = W * S; cv.height = H * S;
    const g = cv.getContext('2d'); g.scale(S, S);
    const grad = g.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, '#2E1507'); grad.addColorStop(1, '#1E1510');
    g.fillStyle = grad; g.fillRect(0, 0, W, H);
    const F = w => `${w} {s}px Pretendard, sans-serif`;
    if(document.fonts && document.fonts.load) await Promise.all([500,600,700].map(w=> document.fonts.load(`${w} 16px Pretendard`))).catch(()=>{});
    const font = (w, s)=> F(w).replace('{s}', s);
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
    g.font = font(600, 16); g.fillText('교환권', W / 2, 30);
    g.font = font(500, 14); const l1 = g.measureText('교환권번호').width;
    g.font = font(600, 18); const l2 = g.measureText(shownWin.code).width;
    const cw = l1 + l2 + 4 + 16, cx = (W - cw) / 2, cy = 72;
    g.fillStyle = 'rgba(255,255,255,.2)'; g.beginPath(); g.roundRect(cx, cy, cw, 30, 8); g.fill();
    g.fillStyle = '#fff'; g.textAlign = 'left';
    g.font = font(500, 14); g.fillText('교환권번호', cx + 8, cy + 15);
    g.font = font(600, 18); g.fillText(shownWin.code, cx + 8 + l1 + 4, cy + 15);
    g.textAlign = 'center'; g.font = font(700, 32);
    const lines = (p.title || '').split('\n');
    lines.forEach((ln, i)=> g.fillText(ln, W / 2, 138 + i * 40));
    let y = 138 + (lines.length - 1) * 40 + 34;
    if(p.desc){ g.font = font(500, 16); g.fillText(p.desc, W / 2, y); y += 18; }
    const [box, item] = await Promise.all([loadImg(A.winbox), loadImg(A['item_' + p.img])]);
    const bx = 24, by = y, bw = 312, bh = 238;
    if(box) g.drawImage(box, bx, by, bw, bh);
    if(item) g.drawImage(item, bx + 96, by + 59, 120, 120);
    g.font = font(500, 12); g.fillStyle = 'rgba(255,255,255,.65)';
    const exp = new Date(voucherExpiry(shownWin.ts));
    g.fillText(`발급 ${new Date(shownWin.ts).toLocaleString('ko-KR')}`, W / 2, by + bh + 22);
    g.fillText(`유효 ${exp.toLocaleString('ko-KR')}까지 · OK저축은행 읏맨`, W / 2, by + bh + 42);

    const blob = await new Promise(r=> cv.toBlob(r, 'image/png'));
    await saveImage(blob, `okman_voucher_${shownWin.code}.png`, '읏맨 교환권');
  }
  document.getElementById('rlw-save').addEventListener('click', ()=>{ hapticTick(); saveVoucher(); });

  /* ---------- 돌리기 ---------- */
  spinBtn.addEventListener('click', async ()=>{
    if(spinning || chances().left === 0) return;
    spinning = true; renderChances();
    if(canVibrate()) navigator.vibrate(15);

    let idx, serverWin = null;
    if(LIVE.demo) idx = pickIndex();
    else {
      spinBtn.textContent = '돌리는 중…';
      const res = await LIVE.spin(chances().bonusEarned);
      spinBtn.textContent = '룰렛 돌리기';
      if(!res.ok){
        spinning = false;
        if(res.error === 'already_won'){ R.ONE_PER_PERSON = true; if(!state.wins.some(w=> !w.miss)) state.used = Math.max(state.used, R.BASE_SPINS + R.MISSION_BONUS); LOCAL.roulette = state; saveLocal(LOCAL); renderChances(); subEl.textContent = '이 기기에서 이미 경품에 당첨됐어요. 당첨은 1인 1회예요.'; subEl.hidden = false; return; }
        if(res.error === 'no_spins'){ state.used = Math.max(state.used, R.BASE_SPINS + (chances().bonusEarned ? R.MISSION_BONUS : 0)); LOCAL.roulette = state; saveLocal(LOCAL); }
        renderChances();
        subEl.textContent = res.error === 'no_spins' ? '이 기기에선 오늘 기회를 모두 사용했어요.' : '연결이 불안정해요. 잠시 후 다시 눌러주세요. (기회는 그대로예요)';
        return;
      }
      serverWin = res.win;
      idx = prizes.findIndex(p=> p.id === serverWin.id);
      if(idx < 0) idx = Math.min(prizes.length - 1, Math.max(0, serverWin.idx || 0));
    }
    wrap.classList.add('rl-wrap-spin');
    const jitter = (Math.random() - 0.5) * SEG * 0.6;
    const current = ((state.rot % 360) + 360) % 360;
    const targetMod = ((360 - center(idx) - jitter) % 360 + 360) % 360;
    const calmSpin = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const finalRot = state.rot + 360 * (calmSpin ? 2 : 6) + ((targetMod - current + 360) % 360);

    wheelEl.style.transition = '';
    requestAnimationFrame(()=>{ wheelEl.style.transform = `rotate(${finalRot}deg)`; });

    const dur = calmSpin ? 1700 : 4900;
    setTimeout(()=>{
      spinning = false; wrap.classList.remove('rl-wrap-spin');
      const prize = prizes[idx];
      const win = serverWin ? { id:serverWin.id, miss:!!serverWin.miss, code:serverWin.code || '', ts:serverWin.ts || Date.now() }
                            : { id:prize.id, miss:!!prize.miss, code: prize.miss ? '' : makeCode(), ts:Date.now() };
      state.used += 1; state.rot = finalRot; state.wins.push(win);
      LOCAL.roulette = state; saveLocal(LOCAL);
      postData('roulette', state).catch(()=>{});
      if(!serverWin) LIVE.submit('roulette', { wins: state.wins.map(w=> ({ ...w, title: w.miss ? '꽝' : String((prizes.find(p=> p.id === w.id) || {}).title || w.id).replace(/\n/g, ' ') })) });
      if(canVibrate()) navigator.vibrate(win.miss ? 20 : [30, 40, 30]);
      renderChances();
      setTimeout(()=> win.miss ? openLose() : openWin(win), 350);
    }, dur);
  });

  renderChances();
  setInterval(()=>{ if(!spinning) renderChances(); }, 1500);
})();

/* ===== 홈 · 경품 응모 ===== */
(function initRaffleEntry(){
  const sheet = document.getElementById('rf-sheet');
  const input = document.getElementById('rf-nick');
  const checkBtn = document.getElementById('rf-check');
  const help = document.getElementById('rf-help');
  const submitBtn = document.getElementById('rf-submit');
  const cardPop = document.getElementById('rf-card');
  const cardImg = document.getElementById('rfc-img');
  const NICK_RE = /^[가-힣a-zA-Z0-9]{1,10}$/;
  const HELP = '한글 · 영문 · 숫자로 10글자까지 입력할 수 있어요';
  let checked = '', checking = false, cardBlob = null;

  function setHelp(text, cls){ help.textContent = text; help.className = 'nick-help' + (cls ? ' ' + cls : ''); }
  function open(){
    if(hasEnteredRaffle()){ showCard(); return; }
    const st = window.__raffleState ? window.__raffleState() : { open:true };
    if(!st.open) return;
    sheet.classList.add('show'); document.documentElement.style.overflow = 'hidden';
    setTimeout(()=> input.focus({ preventScroll:true }), 320);
  }
  function close(){ sheet.classList.remove('show'); document.documentElement.style.overflow = ''; input.blur(); }
  window.__openRaffle = open;
  window.__showRaffleCard = ()=> hasEnteredRaffle() && showCard();

  sheet.addEventListener('click', e=>{ if(e.target === sheet) close(); });
  document.getElementById('rf-later').addEventListener('click', ()=>{ hapticTick(); close(); });
  input.addEventListener('input', ()=>{
    if(checked && input.value.trim() !== checked){ checked = ''; submitBtn.disabled = true; setHelp(HELP); }
  });
  input.addEventListener('keydown', e=>{ if(e.key === 'Enter' && !e.isComposing){ e.preventDefault(); checked ? submit() : check(); } });
  checkBtn.addEventListener('click', ()=>{ hapticTick(); check(); });
  submitBtn.addEventListener('click', ()=>{ hapticTick(); submit(); });

  async function check(){
    const name = input.value.trim();
    if(checking) return;
    if(!name){ setHelp('닉네임을 입력해주세요.', 'err'); return; }
    if(!NICK_RE.test(name)){ setHelp('띄어쓰기·기호 없이 한글 · 영문 · 숫자 10글자까지 쓸 수 있어요.', 'err'); return; }
    checking = true; checkBtn.disabled = true; setHelp('확인하고 있어요…');
    const res = await LIVE.nickCheck(name);
    checking = false; checkBtn.disabled = false;
    if(input.value.trim() !== name) return;
    if(res.error === 'nickname_banned'){ checked = ''; submitBtn.disabled = true; setHelp('쓸 수 없는 단어가 들어 있어요. 전광판에 나가니 다른 닉네임으로 해주세요.', 'err'); return; }
    if(res.available === false){ checked = ''; submitBtn.disabled = true; setHelp('이미 다른 분이 쓰고 있는 닉네임이에요.', 'err'); return; }
    checked = name; submitBtn.disabled = false; setHelp('사용할 수 있는 닉네임이에요.', 'ok');
  }

  async function submit(){
    if(!checked || hasEnteredRaffle()) return;
    submitBtn.disabled = true; submitBtn.textContent = '응모하는 중…';
    const entry = { nickname:checked, source:'mission', predicted:!!LOCAL.predictions, surveyed:!!LOCAL.survey, round:window.__matchRound || '', at:Date.now() };
    const res = await LIVE.submit('raffle_entry', entry, { queue:false });
    submitBtn.textContent = '응모하기';
    if(!res.ok){
      if(res.error === 'nickname_taken'){ checked = ''; setHelp('방금 다른 분이 이 닉네임으로 응모했어요. 다른 닉네임을 써주세요.', 'err'); }
      else if(res.error === 'invalid_nickname'){ checked = ''; setHelp('띄어쓰기·기호 없이 한글 · 영문 · 숫자 10글자까지 쓸 수 있어요.', 'err'); }
      else if(res.error === 'nickname_banned'){ checked = ''; setHelp('쓸 수 없는 단어가 들어 있어요. 전광판에 나가니 다른 닉네임으로 해주세요.', 'err'); }
      else { submitBtn.disabled = false; setHelp('응모가 잘 안 됐어요. 잠시 후 다시 눌러주세요.', 'err'); }
      return;
    }
    LOCAL[RAFFLE_KEY] = entry; saveLocal(LOCAL);
    postData('raffle_entry', entry).catch(()=>{});
    if(canVibrate()) navigator.vibrate([20, 40, 20]);
    close();
    setTimeout(()=> showCard(true), 280);
  }

  /* ---------- 직관인증 카드 ---------- */
  const loadImg = src => new Promise(res=>{ if(!src) return res(null); const i = new Image(); i.onload = ()=> res(i); i.onerror = ()=> res(null); i.src = src; });
  function hash(str){ let h = 2166136261; for(const c of str){ h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
  function cardStats(nick){
    const m = window.__missionState ? window.__missionState() : { done:0, total:6 };
    const cheers = Number(LOCAL.cheer_count) || 0;
    return [
      ['팬심', Math.min(99, 60 + Math.round(39 * m.done / Math.max(1, m.total)))],
      ['응원', Math.min(99, 50 + Math.floor(cheers / 4))],
      ['함성', 70 + hash(nick + MATCH_KEY) % 30],
    ];
  }
  async function drawCard(){
    const e = LOCAL[RAFFLE_KEY];
    const S = 2, W = 320, H = 440;
    const cv = document.createElement('canvas'); cv.width = W * S; cv.height = H * S;
    const g = cv.getContext('2d'); g.scale(S, S);
    if(document.fonts && document.fonts.load) await Promise.all([500, 600, 700, 800].map(w=> document.fonts.load(`${w} 16px Pretendard`))).catch(()=>{});
    const font = (w, sz)=> `${w} ${sz}px Pretendard, sans-serif`;
    const rr = (x, y, w, h, r)=>{ g.beginPath(); g.roundRect(x, y, w, h, r); };
    rr(0, 0, W, H, 24); g.save(); g.clip();
    const bg = g.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#FF7A4E'); bg.addColorStop(.55, '#FF571F'); bg.addColorStop(1, '#E64813');
    g.fillStyle = bg; g.fillRect(0, 0, W, H);
    g.strokeStyle = 'rgba(255,255,255,.16)'; g.lineWidth = 2;
    g.strokeRect(20, 96, W - 40, 236); g.beginPath(); g.moveTo(20, 214); g.lineTo(W - 20, 214); g.stroke();
    g.beginPath(); g.moveTo(20, 175); g.lineTo(W - 20, 175); g.moveTo(20, 253); g.lineTo(W - 20, 253); g.stroke();
    const d = new Date(e.at || Date.now());
    const ymd = `${d.getFullYear()} ${String(d.getMonth() + 1).padStart(2, '0')} ${String(d.getDate()).padStart(2, '0')}`;
    g.fillStyle = '#fff'; g.textBaseline = 'alphabetic'; g.textAlign = 'left';
    g.font = font(600, 13); g.globalAlpha = .85; g.fillText(ymd, 22, 36); g.globalAlpha = 1;
    g.font = font(800, 24); g.fillText('직관인증', 22, 66);
    const round = e.round || window.__matchRound;
    if(round){
      const t = `${round}ROUND`; g.font = font(800, 13); const tw = g.measureText(t).width + 20;
      g.fillStyle = '#161C26'; rr(W - 22 - tw, 22, tw, 26, 13); g.fill();
      g.fillStyle = '#FFD339'; g.textAlign = 'center'; g.fillText(t, W - 22 - tw / 2, 40);
    }
    const mascot = await loadImg(typeof ROULETTE_ASSETS !== 'undefined' ? ROULETTE_ASSETS.mascot : '');
    g.fillStyle = 'rgba(255,255,255,.14)'; g.beginPath(); g.arc(W / 2, 212, 92, 0, Math.PI * 2); g.fill();
    if(mascot){
      const r = Math.min(170 / mascot.width, 170 / mascot.height);
      g.drawImage(mascot, W / 2 - mascot.width * r / 2, 212 - mascot.height * r / 2, mascot.width * r, mascot.height * r);
    } else { g.font = font(800, 40); g.textAlign = 'center'; g.fillStyle = '#fff'; g.fillText('읏맨', W / 2, 226); }
    g.fillStyle = '#fff'; rr(20, 318, W - 40, 58, 16); g.fill();
    g.fillStyle = '#8C94A2'; g.textAlign = 'center'; g.font = font(600, 11); g.fillText('닉네임', W / 2, 336);
    g.fillStyle = '#161C26'; let sz = 24; g.font = font(800, sz);
    while(g.measureText(e.nickname).width > W - 72 && sz > 14){ sz -= 1; g.font = font(800, sz); }
    g.fillText(e.nickname, W / 2, 364);
    cardStats(e.nickname).forEach(([label, v], i)=>{
      const cx = 20 + (W - 40) / 6 * (i * 2 + 1);
      g.fillStyle = '#fff'; g.font = font(800, 22); g.fillText(String(v), cx, 410);
      g.globalAlpha = .85; g.font = font(600, 11); g.fillText(label, cx, 426); g.globalAlpha = 1;
    });
    g.restore();
    return cv;
  }
  async function showCard(first){
    document.getElementById('rfc-title').textContent = first === true ? '응모 완료!' : '내 응모 카드';
    cardPop.classList.add('show'); document.documentElement.style.overflow = 'hidden';
    const cv = await drawCard();
    cardImg.src = cv.toDataURL('image/png');
    cardImg.alt = `직관인증 카드 — 닉네임 ${LOCAL[RAFFLE_KEY].nickname}`;
    cardBlob = await new Promise(r=> cv.toBlob(r, 'image/png'));
  }
  function closeCard(){ cardPop.classList.remove('show'); document.documentElement.style.overflow = ''; document.dispatchEvent(new CustomEvent('raffle:cardclose')); }
  document.getElementById('rfc-close').addEventListener('click', closeCard);
  cardPop.addEventListener('click', e=>{ if(e.target === cardPop) closeCard(); });
  document.addEventListener('keydown', e=>{
    if(e.key !== 'Escape') return;
    if(cardPop.classList.contains('show')) closeCard();
    else if(sheet.classList.contains('show')) close();
  });
  document.getElementById('rfc-save').addEventListener('click', async ()=>{
    hapticTick();
    if(!cardBlob) return;
    await saveImage(cardBlob, `okman_card_${Date.now()}.png`, '읏맨 직관인증 카드');
  });
})();

/* ===== 홈경기가 없는 날 ===== */
(function initDayMode(){
  const card = document.getElementById('no-game');
  const nextEl = document.getElementById('no-game-next');
  const sub = document.querySelector('#view-home .pagesub');
  const subText = sub ? sub.textContent : '';
  const urlDay = new URLSearchParams(location.search).get('day');
  function isOpen(){
    if(urlDay === 'on' || urlDay === 'off') return urlDay === 'on';
    const m = CONTENT.get().open || 'auto';
    if(m === 'on' || m === 'off') return m === 'on';
    if(TEST_MATCH) return true;
    return window.__homeToday !== false;
  }
  let lastOpen = null, inSchedule = false;
  window.__applyDayMode = ()=>{
    const open = isOpen();
    document.body.classList.toggle('no-game', !open);
    if(lastOpen !== null && lastOpen !== open && !inSchedule && window.__applySchedule && STATS.games){   // 운영 여부가 바뀌면 매치 카드도 다시
      inSchedule = true; try{ window.__applySchedule(STATS.games); } finally { inSchedule = false; }
    }
    lastOpen = open;
    card.hidden = open;
    if(sub) sub.textContent = open ? (sub.dataset.text || subText) : '선수 기록과 리그 순위는 언제든 볼 수 있어요.';
    const nh = window.__nextHome;
    nextEl.hidden = open || !nh;
    if(nh){
      const d = new Date(nh.date + 'T00:00:00');
      nextEl.textContent = `다음 홈경기 · ${d.getMonth() + 1}.${d.getDate()} (${'일월화수목금토'[d.getDay()]})${nh.time ? ' ' + nh.time : ''} vs ${nh.opponent}`;
    }
    if(!open){
      const v = document.querySelector('.view.active');
      if(v && v.id !== 'view-home' && v.id !== 'view-players') navigate('home');
    }
  };
  CONTENT.onChange(window.__applyDayMode);
  window.__applyDayMode();
})();

/* ===== 홈 · 굿즈샵 · 앱 배너 ===== */
(function initGoods(){
  const link = document.getElementById('goods-link');
  const app = document.getElementById('app-link');
  const ua = navigator.userAgent || '';
  const isIOS = /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && 'ontouchend' in document);
  function setLink(el, ctaId, url, label){
    const cta = document.getElementById(ctaId);
    if(url){ el.href = url; el.classList.remove('disabled'); el.removeAttribute('aria-disabled'); cta.firstChild.textContent = label + ' '; }
    else { el.classList.add('disabled'); el.removeAttribute('href'); el.setAttribute('aria-disabled', 'true'); cta.firstChild.textContent = '링크 준비 중 '; }
  }
  function apply(h){
    const G = { ...(CONFIG.GOODS || {}), ...Object.fromEntries(Object.entries((h && h.goods) || {}).filter(([, v])=> v)) };
    document.getElementById('goods-title').textContent = G.title || '굿즈샵';
    const gi = document.getElementById('goods-img');
    if(G.image && gi.getAttribute('src') !== G.image) gi.src = G.image;
    gi.onerror = ()=>{ gi.hidden = true; };
    document.getElementById('goods-desc').textContent = G.desc || '';
    setLink(link, 'goods-cta', G.url, '굿즈샵 가기');
    const P = { ...(CONFIG.APP || {}), ...Object.fromEntries(Object.entries((h && h.app) || {}).filter(([, v])=> v !== '' && v != null)) };
    app.hidden = P.on === false;
    appImgs = { light:P.image || '', dark:P.imageDark || '' };
    setAppImg();
    document.getElementById('app-title').textContent = P.title || 'OK저축은행 앱 다운로드';
    document.getElementById('app-desc').textContent = P.desc || '';
    setLink(app, 'app-cta', isIOS ? (P.ios || P.android) : (P.android || P.ios), '앱 다운로드');
  }
  // 앱 배너 — 라이트 / 다크 이미지 (한쪽만 있으면 두 모드 모두 그 이미지)
  let appImgs = { light:'', dark:'' };
  function setAppImg(){
    const ai = document.getElementById('app-img'); if(!ai) return;
    const dark = document.documentElement.dataset.theme === 'dark';
    const src = (dark ? appImgs.dark || appImgs.light : appImgs.light || appImgs.dark) || '';
    if(src){ if(ai.getAttribute('src') !== src) ai.src = src; ai.hidden = false; } else { ai.removeAttribute('src'); ai.hidden = true; }
    ai.onerror = ()=>{ ai.hidden = true; };
  }
  new MutationObserver(setAppImg).observe(document.documentElement, { attributes:true, attributeFilter:['data-theme'] });
  apply(null);
  let sig = '';
  LIVE.on('state', st=>{ const x = JSON.stringify(st.home ? { g:st.home.goods, a:st.home.app } : null); if(x !== sig){ sig = x; apply(st.home); } });
})();

/* ===== 플레이 · 경기 기록 ===== */
const STATS = { teams: CONFIG.TEAMS, results: CONFIG.RESULTS, games: CONFIG.GAMES || [], sample: true, seasonLabel: '' };
function currentSeasonLabel(){ const d = new Date(); const y = d.getMonth() >= 7 ? d.getFullYear() : d.getFullYear() - 1; return `${y}-${String(y + 1).slice(2)}`; }
function seasonLabel(code){ const n = parseInt(code, 10); if(!n || n >= 100) return ''; const y = 2003 + n; return `${y}-${String(y + 1).slice(2)}`; }
function chipRowSync(row, center){
  if(!row) return;
  const max = row.scrollWidth - row.clientWidth;
  if(center){
    const a = row.querySelector('.subtab__btn.active');
    if(a && max > 0){
      const to = Math.max(0, Math.min(max, a.offsetLeft - (row.clientWidth - a.offsetWidth) / 2));
      row.scrollTo({ left:to, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    }
  }
  const x = row.scrollLeft;
  const host = row.parentElement && row.parentElement.classList.contains('subtab-wrap') ? row.parentElement : row;
  host.style.setProperty('--fl', x > 2 ? '28px' : '0px');
  host.style.setProperty('--fr', x < max - 2 ? '40px' : '0px');
}
document.querySelectorAll('.subtab').forEach(row=>{
  // iOS Safari — 가로 스크롤 칸에 mask를 직접 걸면 손가락 스크롤이 막혀서, 양끝 흐림은 감싼 칸에 걸어요
  if(!row.parentElement.classList.contains('subtab-wrap')){ const w = document.createElement('div'); w.className = 'subtab-wrap'; row.before(w); w.appendChild(row); }
  row.addEventListener('scroll', ()=> chipRowSync(row), { passive:true });
  row.addEventListener('click', e=>{ if(e.target.closest('.subtab__btn')) setTimeout(()=> chipRowSync(row, true), 0); });
  chipRowSync(row);
  dragScroll(row);
});
function dragScroll(row){
  let down = false, sx = 0, sl = 0, moved = false;
  row.addEventListener('pointerdown', e=>{ if(e.pointerType !== 'mouse' || row.scrollWidth <= row.clientWidth) return; down = true; moved = false; sx = e.clientX; sl = row.scrollLeft; });
  addEventListener('pointermove', e=>{ if(!down) return; const dx = e.clientX - sx; if(Math.abs(dx) > 4){ moved = true; row.classList.add('dragging'); } row.scrollLeft = sl - dx; });
  addEventListener('pointerup', ()=>{ if(!down) return; down = false; setTimeout(()=> row.classList.remove('dragging'), 0); });
  row.addEventListener('click', e=>{ if(moved){ e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
  row.addEventListener('wheel', e=>{
    if(row.scrollWidth <= row.clientWidth || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    const max = row.scrollWidth - row.clientWidth, next = Math.max(0, Math.min(max, row.scrollLeft + e.deltaY));
    if(next !== row.scrollLeft){ row.scrollLeft = next; e.preventDefault(); }
  }, { passive:false });
}
addEventListener('resize', ()=> document.querySelectorAll('.subtab').forEach(r=> chipRowSync(r)));
if('ResizeObserver' in window){ const ro = new ResizeObserver(es=> es.forEach(e=> chipRowSync(e.target))); document.querySelectorAll('.subtab').forEach(r=> ro.observe(r)); }

(function initStats(){
  const grid = document.getElementById('squad-grid');
  const chips = document.getElementById('pos-chips');
  const noteEl = document.getElementById('stats-note');
  let posFilter = 'all';

  function renderChips(){
    const keys = ['all', ...Object.keys(POS).filter(k=> PLAYERS.some(p=> p.pos === k))];
    chips.innerHTML = `<ul class="subtab__list" role="tablist">${keys.map(k=> `<li role="presentation"><a href="#" role="tab" class="subtab__btn${k === posFilter ? ' active' : ''}" aria-selected="${k === posFilter}" data-pos="${k}" draggable="false">${k === 'all' ? '전체' : POS[k].chip}</a></li>`).join('')}</ul>`;
    chips.querySelectorAll('.subtab__btn').forEach(c=> c.addEventListener('click', e=>{
      e.preventDefault();
      if(c.dataset.pos === posFilter) return;
      hapticTick(); posFilter = c.dataset.pos; renderChips(); renderSquad();
      chipRowSync(chips, true);
    }));
    chipRowSync(chips);
  }
  function visiblePlayers(){ return posFilter === 'all' ? PLAYERS : PLAYERS.filter(p=> p.pos === posFilter); }
  function renderSquad(){
    grid.innerHTML = visiblePlayers().map(p=> `
      <button class="squad-tile tier-${playerTier(p)}${isRare(p) ? ' rare' : ''}${isMvpCard(p) ? ' mvp' : ''}" data-num="${p.num}" aria-label="${playerName(p)} 능력치 카드 열기">
        <span class="squad-tile__ovr"><b>${playerOvrToday(p)}</b><small>${p.pos}</small>${isMvpCard(p) ? `<em class="mvp-tag">${CONFIG.MVP_CARD.title || 'MVP'}</em>` : ''}</span>
        <span class="squad-tile__fig">${cardSrc(p) ? `<img src="${cardSrc(p)}" alt="" loading="lazy">` : ''}</span>
        <span class="squad-tile__name">${playerName(p)}</span>
      </button>`).join('');
    grid.querySelectorAll('.squad-tile').forEach(t=> t.addEventListener('click', ()=>{
      hapticTick(); window.__openPlayerCard(+t.dataset.num, visiblePlayers());
    }));
  }

  const teamName = id => (STATS.teams.find(t=> t.id === id) || { name:id }).name;
  function renderStandings(){
    const table = document.getElementById('stand-table');
    const teams = [...STATS.teams].sort((a, b)=> (a.rank && b.rank) ? a.rank - b.rank : (b.pts - a.pts || b.w - a.w || b.setRatio - a.setRatio));
    const avg = k => { const v = teams.map(t=> t[k]).filter(x=> x != null); return v.length ? v.reduce((s, x)=> s + x, 0) / v.length : 0; };
    const RANGE = { atk:[44, 58], blk:[1.6, 2.8], ace:[0.8, 1.6], rcv:[28, 44] };
    const LABEL = { atk:['공격성공률','%'], blk:['세트당 블로킹',''], ace:['세트당 서브',''], rcv:['리시브효율','%'] };
    const bar = (t, k)=>{
      if(t[k] == null) return '';
      const [lo, hi] = RANGE[k]; const pos = v => Math.max(4, Math.min(100, (v - lo) / (hi - lo) * 100));
      return `<div class="team-stat">
        <div class="team-stat__l">${LABEL[k][0]}<b>${t[k]}${LABEL[k][1]}</b></div>
        <div class="team-stat__bar"><div class="team-stat__fill" style="width:${pos(t[k])}%"></div><div class="team-stat__avg" style="left:${pos(avg(k))}%"></div></div>
      </div>`;
    };
    const topPts = Math.max(1, ...teams.map(t=> t.pts || 0));
    const ui = teams.findIndex(t=> t.us), usBox = document.getElementById('us-rank');
    if(ui >= 0){
      const u = teams[ui];
      usBox.hidden = false;
      usBox.innerHTML = `<div class="us-rank__rank"><b>${ui + 1}</b><span>위</span></div>
        <div class="us-rank__body"><p class="us-rank__name">${u.name}</p>
          <p class="us-rank__meta">승점 <b>${u.pts}</b> · ${u.w}승 ${u.l}패</p></div>
        <span class="us-rank__ps">${ui < 3 ? '봄배구권' : (ui === 3 ? '준PO 경쟁' : `3위와 ${Math.max(0, teams[2].pts - u.pts)}점 차`)}</span>`;
    } else usBox.hidden = true;

    table.innerHTML = `<thead><tr><th>순위</th><th>팀</th><th>경기</th><th>승점</th><th>승</th><th>패</th><th>세트득실</th></tr></thead><tbody>` +
      teams.map((t, i)=> `
        <tr class="row${t.us ? ' us' : ''}${i < 3 ? ' ps' : ''}" data-id="${t.id}">
          <td class="rank"><span>${i + 1}</span></td>
          <td class="team">${t.name}<i class="ptsbar" style="width:calc((100% - 12px) * ${((t.pts || 0) / topPts).toFixed(3)})"></i></td><td>${t.g}</td>
          <td class="pts">${t.pts}</td><td>${t.w}</td><td>${t.l}</td><td>${Number(t.setRatio || 0).toFixed(2)}</td>
        </tr>
        <tr class="detail" data-for="${t.id}" hidden><td colspan="7"><div class="team-detail">
          ${['atk','blk','ace','rcv'].map(k=> bar(t, k)).join('')}
          <p class="team-detail__note">검은 눈금은 리그 평균이에요.</p>
        </div></td></tr>`).join('') + `</tbody>`;
    table.querySelectorAll('tr.row').forEach(row=> row.addEventListener('click', ()=>{
      hapticTick();
      const d = table.querySelector(`tr.detail[data-for="${row.dataset.id}"]`);
      const willOpen = d.hidden;
      table.querySelectorAll('tr.detail').forEach(x=> x.hidden = true);
      d.hidden = !willOpen;
    }));
  }

  let resultFilter = 'all';
  function renderResults(){
    const us = (STATS.teams.find(t=> t.us) || {}).id;
    const items = STATS.results.filter(r=> resultFilter === 'all' || r.home === us || r.away === us);
    document.getElementById('results-list').innerHTML = items.length ? items.map(r=>{
      let hs = 0, as = 0;
      r.sets.forEach(s=>{ const [a, b] = s.split('-').map(Number); a > b ? hs++ : as++; });
      const hw = hs > as;
      const ours = r.home === us || r.away === us;
      const usWin = ours && ((r.home === us) === hw);
      return `<div class="card result-card${ours ? ' ours ' + (usWin ? 'won' : 'lost') : ''}">
        <p class="result-card__meta">${[r.round, r.date].filter(Boolean).join(' ')}${ours ? `<span class="wl">${usWin ? '승' : '패'}</span>` : ''}</p>
        <div class="result-card__row">
          <span class="result-card__team${hw ? ' win' : ''}${r.home === us ? ' us' : ''}">${teamName(r.home)}</span>
          <span class="result-card__score"><em class="${hw ? 'w' : ''}">${hs}</em><span>:</span><em class="${!hw ? 'w' : ''}">${as}</em></span>
          <span class="result-card__team right${!hw ? ' win' : ''}${r.away === us ? ' us' : ''}">${teamName(r.away)}</span>
        </div>
        <div class="result-card__sets">${r.sets.map(s=>{
          const [a, b] = s.split('-').map(Number);
          const usTook = ours && ((r.home === us) ? a > b : b > a);
          return `<span class="${usTook ? 'took' : ''}">${s.replace('-', ' : ')}</span>`;
        }).join('')}</div>
      </div>`;
    }).join('') : `<p class="empty-note">표시할 경기가 없어요.</p>`;
  }
  /* ---------- 경기 기록 서브탭 ---------- */
  (function initGamesTabs(){
    const row = document.getElementById('games-tabs'); if(!row) return;
    const secs = document.querySelectorAll('.games-sec');
    function show(key, user){
      const btns = [...row.querySelectorAll('.subtab__btn')];
      const prev = btns.findIndex(b=> b.classList.contains('active')), next = btns.findIndex(b=> b.dataset.games === key);
      panelSlide([...secs], [...secs].find(s=> s.dataset.games === key), user && prev >= 0 && prev !== next ? next - prev : 0);
      row.querySelectorAll('.subtab__btn').forEach(b=>{ const on = b.dataset.games === key; b.classList.toggle('active', on); b.setAttribute('aria-selected', on); });
      secs.forEach(sec=>{ const on = sec.dataset.games === key; sec.hidden = !on; sec.classList.toggle('active', on); });
      chipRowSync(row, true);
      if(user){ secs.forEach(sec=> sec.hidden || sec.querySelectorAll('.subtab').forEach(r=> chipRowSync(r))); }
    }
    row.addEventListener('click', e=>{
      const b = e.target.closest('.subtab__btn'); if(!b || b.classList.contains('active')) return;
      hapticTick(); show(b.dataset.games, true);
    });
    window.__gamesTab = show;
  })();

  document.querySelectorAll('#result-chips .subtab__btn').forEach(c=> c.addEventListener('click', ()=>{
    if(c.dataset.filter === resultFilter) return;
    hapticTick(); resultFilter = c.dataset.filter;
    document.querySelectorAll('#result-chips .subtab__btn').forEach(x=> x.classList.toggle('active', x === c));
    renderResults();
  }));

  /* ---------- 경기 일정 ---------- */
  let schedDate = null;
  function scheduleList(){
    if(STATS.schedule && STATS.schedule.length) return STATS.schedule;
    const usName = (STATS.teams.find(t=> t.us) || {}).name || 'OK저축은행';
    return (STATS.games || []).map(g=> ({
      round:g.round, date:g.date, time:g.time, us:true,
      home: g.home ? { id:'us', name:usName } : { id:g.opponentId, name:g.opponent },
      away: g.home ? { id:g.opponentId, name:g.opponent } : { id:'us', name:usName },
      score: g.score ? (g.home ? g.score : [g.score[1], g.score[0]]) : null,
      sets: g.score ? (g.home ? g.sets : g.sets.map(x=> x.split('-').reverse().join('-'))) : [],
    }));
  }
  function gameStatus(g){
    if(g.score) return { key:'done', label:'종료' };
    const start = new Date(`${g.date}T${g.time || '19:00'}:00`);
    if(g.date === todayStr() && Date.now() >= start.getTime()) return { key:'live', label:'경기 중' };
    return { key:'before', label: g.time || '경기 전' };
  }
  function renderSchedule(){
    const list = scheduleList();
    const strip = document.getElementById('date-strip');
    const box = document.getElementById('day-games');
    if(!list.length){
      strip.innerHTML = '';
      box.innerHTML = `<p class="empty-note">경기 일정이 아직 없어요.<br>기록 API를 연결하면 리그 일정이 자동으로 채워져요.</p>`;
      return;
    }
    const dates = [...new Set(list.map(g=> g.date))].sort();
    const usDates = new Set(list.filter(g=> g.us).map(g=> g.date));
    const today = todayStr();
    if(!schedDate || !dates.includes(schedDate)){
      schedDate = dates.includes(today) ? today : (dates.find(d=> d >= today) || dates[dates.length - 1]);
    }
    strip.innerHTML = dates.map(d=>{
      const dt = new Date(d + 'T00:00:00');
      return `<button class="ds-day${d === schedDate ? ' active' : ''}${d === today ? ' today' : ''}${d < today ? ' past' : ''}" data-date="${d}">
        <span class="ds-wd">${d === today ? '오늘' : WD[dt.getDay()]}</span>
        <b>${dt.getMonth() + 1}.${dt.getDate()}</b>
        ${usDates.has(d) ? '<i class="ds-us" aria-label="우리 경기"></i>' : '<i class="ds-none"></i>'}
      </button>`;
    }).join('');
    centerStrip(false);

    const games = list.filter(g=> g.date === schedDate).sort((a, b)=> (b.us - a.us) || String(a.time).localeCompare(String(b.time)));
    box.innerHTML = games.map(g=>{
      const st = gameStatus(g);
      const usSide = g.us ? (g.home.id === 'us' || (STATS.teams.find(t=> t.us) || {}).id === g.home.id ? 'home' : 'away') : null;
      const hw = g.score && g.score[0] > g.score[1];
      const usWin = g.score && usSide ? (usSide === 'home') === hw : null;
      const team = (t, side)=> `<span class="sg-team ${side}${g.score && ((side === 'home') === hw) ? ' win' : ''}${usSide === side ? ' us' : ''}">${t.name}</span>`;
      return `<div class="card sg-card${g.us ? ' ours' : ''}${usWin === true ? ' won' : (usWin === false ? ' lost' : '')}">
        <div class="sg-meta">
          <span class="sg-status ${st.key}">${st.label}</span>
          ${g.round ? `<span>${g.round}라운드</span>` : ''}
          ${g.us ? `<span class="sg-venue">${usSide === 'home' ? CONFIG.MATCH.venue : '원정'}</span>` : ''}
          ${usWin != null ? `<span class="wl">${usWin ? '승' : '패'}</span>` : ''}
        </div>
        <div class="sg-row">
          ${team(g.home, 'home')}
          <span class="sg-score">${g.score ? `<em class="${hw ? 'w' : ''}">${g.score[0]}</em><span>:</span><em class="${!hw ? 'w' : ''}">${g.score[1]}</em>` : '<span class="vs">VS</span>'}</span>
          ${team(g.away, 'away')}
        </div>
        ${g.sets && g.sets.length ? `<div class="result-card__sets">${g.sets.map(x=>{
          const [h, a] = x.split('-').map(Number);
          const took = usSide && (usSide === 'home' ? h > a : a > h);
          return `<span class="${took ? 'took' : ''}">${x.replace('-', ' : ')}</span>`;
        }).join('')}</div>` : ''}
      </div>`;
    }).join('');
  }
  function centerStrip(smooth){
    const strip = document.getElementById('date-strip');
    const sel = strip.querySelector('.ds-day.active');
    if(!sel || !strip.clientWidth) return;
    strip.scrollTo({ left: sel.offsetLeft - strip.clientWidth / 2 + sel.clientWidth / 2, behavior: smooth ? 'smooth' : 'auto' });
  }
  document.addEventListener('wm:toggle', e=>{ if(e.detail.toggle === 'players' && e.detail.key === 'games') requestAnimationFrame(()=> centerStrip(false)); });
  document.addEventListener('wm:nav', e=>{ if(e.detail.view === 'players') requestAnimationFrame(()=> centerStrip(false)); });
  document.getElementById('date-strip').addEventListener('click', e=>{
    const b = e.target.closest('.ds-day'); if(!b || b.dataset.date === schedDate) return;
    hapticTick(); schedDate = b.dataset.date; renderSchedule(); centerStrip(true);
  });

  const calModal = document.getElementById('cal-modal');
  function openCal(){ renderGames(); calModal.classList.add('show'); document.body.classList.add('modal-open'); }
  function closeCal(){ calModal.classList.remove('show'); document.body.classList.remove('modal-open'); }
  document.getElementById('cal-open').addEventListener('click', ()=>{ hapticTick(); openCal(); });
  document.getElementById('cal-close').addEventListener('click', closeCal);
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && calModal.classList.contains('show')) closeCal(); });

  /* ---------- 우리 경기 달력 ---------- */
  const SHORT = { '대한항공':'대한', '현대캐피탈':'현캐', 'KB손해보험':'KB', '우리카드':'우리', '한국전력':'한전', '삼성화재':'삼성' };
  const shortName = n=> SHORT[n] || String(n || '').replace(/(배구단|프로배구단)$/, '').slice(0, 2);
  const WD = '일월화수목금토';
  let calMonth = null;
  const ym = d=> d.slice(0, 7);
  function todayStr(){ const t = new Date(); return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; }

  function gameState(g){
    if(g.score){ const [u, o] = g.score.map(Number); return { done:true, win:u > o, label:(u > o ? '승' : '패') + ` ${u}:${o}` }; }
    const diff = Math.round((new Date(g.date + 'T00:00:00') - new Date(todayStr() + 'T00:00:00')) / 86400000);
    return { done:false, label: diff === 0 ? '오늘' : (diff > 0 ? `D-${diff}` : '결과 대기') };
  }

  function renderGames(){
    const games = STATS.games || [];
    const listEl = document.getElementById('games-list');
    const grid = document.getElementById('cal-grid');
    const title = document.getElementById('cal-title');
    if(!games.length){
      title.textContent = '경기 일정';
      grid.innerHTML = '';
      listEl.innerHTML = `<p class="empty-note">경기 일정이 아직 없어요.<br>기록 API를 연결하면 우리 경기 일정이 자동으로 채워져요.</p>`;
      return;
    }
    const months = [...new Set(games.map(g=> ym(g.date)))].sort();
    if(!calMonth || !months.includes(calMonth)){
      const next = games.find(g=> g.date >= todayStr());
      calMonth = ym((next || games[games.length - 1]).date);
    }
    const [Y, M] = calMonth.split('-').map(Number);
    title.textContent = `${Y}년 ${M}월`;
    document.getElementById('cal-prev').disabled = months.indexOf(calMonth) <= 0;
    document.getElementById('cal-next').disabled = months.indexOf(calMonth) >= months.length - 1;

    const byDate = {}; games.forEach(g=> (byDate[g.date] = byDate[g.date] || []).push(g));
    const firstDow = new Date(Y, M - 1, 1).getDay();
    const days = new Date(Y, M, 0).getDate();
    const today = todayStr();
    let cells = '';
    for(let i = 0; i < firstDow; i++) cells += '<span class="cal-day empty"></span>';
    for(let d = 1; d <= days; d++){
      const ds = `${calMonth}-${String(d).padStart(2, '0')}`;
      const g = (byDate[ds] || [])[0];
      const st = g ? gameState(g) : null;
      cells += `<button class="cal-day${g ? ' has ' + (g.home ? 'home' : 'away') : ''}${ds === today ? ' today' : ''}${st && st.done ? (st.win ? ' win' : ' lose') : ''}" ${g ? `data-date="${ds}"` : 'disabled'}>
        <b>${d}</b>${g ? `<small>${shortName(g.opponent)}</small>` : ''}
      </button>`;
    }
    grid.innerHTML = cells;

    const monthGames = games.filter(g=> ym(g.date) === calMonth);
    listEl.innerHTML = monthGames.map(g=>{
      const d = new Date(g.date + 'T00:00:00'), st = gameState(g);
      return `<div class="card game-card${g.date === today ? ' is-today' : ''}" id="game-${g.date}">
        <div class="game-card__date"><b>${d.getMonth() + 1}.${d.getDate()}</b><span>${WD[d.getDay()]}${g.time ? ' · ' + g.time : ''}</span></div>
        <div class="game-card__body">
          <p class="game-card__vs"><span class="ha ${g.home ? 'home' : 'away'}">${g.home ? '홈' : '원정'}</span>vs ${g.opponent}</p>
          <p class="game-card__meta">${g.round ? g.round + '라운드 · ' : ''}${g.home ? CONFIG.MATCH.venue : g.opponent + ' 홈'}</p>
          ${g.sets && g.sets.length ? `<div class="result-card__sets">${g.sets.map(x=> `<span>${x.replace('-', ' : ')}</span>`).join('')}</div>` : ''}
        </div>
        <span class="game-card__state${st.done ? (st.win ? ' win' : ' lose') : (st.label === '오늘' ? ' today' : '')}">${st.label}</span>
      </div>`;
    }).join('');
  }
  document.getElementById('cal-grid').addEventListener('click', e=>{
    const b = e.target.closest('.cal-day.has'); if(!b) return;
    const el = document.getElementById('game-' + b.dataset.date);
    if(el){ el.scrollIntoView({ behavior:'smooth', block:'center' }); el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
  });
  const stepMonth = dir=>{
    const months = [...new Set((STATS.games || []).map(g=> ym(g.date)))].sort();
    const i = months.indexOf(calMonth) + dir;
    if(i >= 0 && i < months.length){ calMonth = months[i]; hapticTick(); renderGames(); }
  };
  document.getElementById('cal-prev').addEventListener('click', ()=> stepMonth(-1));
  document.getElementById('cal-next').addEventListener('click', ()=> stepMonth(1));

  LIVE.on('state', st=>{
    if(st.mvp === undefined) return;
    const next = st.mvp ? { num:st.mvp.num, title:st.mvp.title || 'MVP', until:'' } : { num:null };
    if(String((CONFIG.MVP_CARD || {}).num) !== String(next.num)){ CONFIG.MVP_CARD = next; renderAll(); }
  });

  function renderAll(){
    renderChips(); renderSquad(); renderStandings(); renderResults(); renderSchedule(); renderGames();
    if(window.__applySchedule) window.__applySchedule(STATS.games);
    const past = !STATS.sample && STATS.seasonLabel && STATS.seasonLabel !== currentSeasonLabel();
    document.querySelectorAll('[data-season-banner]').forEach(b=>{
      b.hidden = !past;
      if(past) b.innerHTML = `<b>${STATS.seasonLabel} 시즌 정규리그 기록이에요</b><span>${currentSeasonLabel()} 시즌은 개막 전이라, 첫 경기가 끝나면 자동으로 바뀌어요.</span>`;
    });
    if(noteEl) noteEl.textContent = STATS.sample
      ? '지금 보이는 순위·기록은 화면 확인용 샘플이에요. 기록 API를 연결하면 실제 시즌 기록으로 바뀌어요.'
      : `${STATS.seasonLabel ? STATS.seasonLabel + ' 시즌 ' : ''}KOVO 공식 기록 기준이에요. 능력치는 리그 선수 대비 백분위이고, 출전 ${FULL_SETS}세트 전까지는 기본 능력치와 섞어서 계산해요.`;
  }
  renderAll();

  const statsBase = CONFIG.STATS_API || (CONFIG.DATA_MODE === 'api' ? CONFIG.API_BASE : '');
  if(statsBase){
    if(noteEl) noteEl.textContent = '기록을 불러오는 중이에요.';
    fetch(`${statsBase.replace(/\/$/, '')}/stats`).then(r=> r.ok ? r.json() : Promise.reject(r.status)).then(d=>{
      if(d.teams && d.teams.length) STATS.teams = d.teams;
      if(d.games && d.games.list) STATS.games = d.games.list;
      if(d.schedule && d.schedule.list) STATS.schedule = d.schedule.list;
      if(d.results) STATS.results = d.results;
      const ours = d.players || [], others = d.others || [];
      const teamName = id => (STATS.teams.find(t=> String(t.id) === String(id)) || {}).name || '';
      const used = new Set();
      PLAYERS.forEach(p=>{
        let x = ours.find(o=> o.name === p.name && String(o.num) === String(p.num))
             || ours.find(o=> o.name === p.name)
             || (!p.name && ours.find(o=> String(o.num) === String(p.num)));
        let from = '';
        if(!x){ x = others.find(o=> o.name === p.name); if(x) from = teamName(x.team); }
        if(!p.baseAbility) p.baseAbility = { ...(p.ability || {}) };   // 기본 능력치 (지난 기록 기준)
        if(x){
          used.add(x);
          Object.assign(p, { pos:x.pos || p.pos, season:x.season, ability:blendAbility(p.baseAbility, x.ability, x.season, x.sets), noRecord:false, prevTeam:from });
        } else {
          Object.assign(p, { season:{ g:0 }, ability:{ ...p.baseAbility }, noRecord:true, prevTeam:'' });
        }
      });
      STATS.sample = false;
      STATS.seasonLabel = seasonLabel(d.season);
      renderAll();
      window.__mvpRefresh && window.__mvpRefresh();
      window.__aiPredictRefresh && window.__aiPredictRefresh();
    }).catch(()=>{ STATS.sample = true; renderAll(); window.__aiPredictRefresh && window.__aiPredictRefresh(); });
  }
})();

/* ===== 이벤트 · AI 예측 ===== */
(function initAiPredict(){
  const box = document.getElementById('ai-predict');
  const list = document.getElementById('predict-list');
  if(!box || !list) return;
  const EVS = CONFIG.PREDICT_EVENTS;
  const pct = v => Math.round(v * 100);
  const clamp = (v, a, b)=> Math.max(a, Math.min(b, v));
  let rec = {};

  function teams(){
    const ts = STATS.teams || [];
    const us = ts.find(t=> t.us) || null;
    const oppName = (document.getElementById('mb-away') || {}).textContent || CONFIG.MATCH.away || '';
    const opp = ts.find(t=> !t.us && oppName && (oppName.includes(t.name) || t.name.includes(oppName.trim()))) || null;
    return { us, opp, oppName: opp ? opp.name : (oppName && oppName !== '상대팀' ? oppName : '') };
  }
  function avgTeam(){
    const ts = (STATS.teams || []).filter(t=> !t.us);
    const m = k => ts.length ? ts.reduce((a, t)=> a + (t[k] || 0), 0) / ts.length : 0;
    return { name:'리그 평균', g:m('g'), w:m('w'), l:m('l'), setRatio:m('setRatio') || 1, atk:m('atk'), blk:m('blk'), ace:m('ace'), rcv:m('rcv') };
  }
  function headToHead(us, opp){
    if(!us || !opp) return 0;
    let d = 0;
    (STATS.results || []).forEach(r=>{
      const ids = [r.home, r.away];
      if(!ids.includes(us.id) || !ids.includes(opp.id)) return;
      let a = 0, b = 0;
      (r.sets || []).forEach(sc=>{ const [h, w] = String(sc).split('-').map(Number); if(h > w) a++; else b++; });
      const usWon = r.home === us.id ? a > b : b > a;
      d += usWon ? 1 : -1;
    });
    return clamp(d * 0.03, -0.06, 0.06);
  }
  function h2hRecord(us, opp){
    if(!us || !opp) return null;
    let w = 0, l = 0;
    (STATS.results || []).forEach(r=>{
      if(![r.home, r.away].includes(us.id) || ![r.home, r.away].includes(opp.id)) return;
      let a = 0, b = 0;
      (r.sets || []).forEach(sc=>{ const [h, x] = String(sc).split('-').map(Number); if(h > x) a++; else b++; });
      ((r.home === us.id) ? a > b : b > a) ? w++ : l++;
    });
    return (w + l) ? { w, l } : null;
  }
  function matchWin(us, opp){
    const wp = t => clamp((t.w + 1) / ((t.w || 0) + (t.l || 0) + 2), 0.05, 0.95);
    const a = wp(us), b = wp(opp);
    let p = (a - a * b) / (a + b - 2 * a * b);
    p += clamp(Math.log((us.setRatio || 1) / (opp.setRatio || 1)) * 0.08, -0.06, 0.06);
    p += headToHead(us, opp);
    if(window.__matchHome !== false) p += 0.03;
    return clamp(p, 0.12, 0.88);
  }
  const matchFromSet = s => Math.pow(s, 3) * (1 + 3 * (1 - s) + 6 * Math.pow(1 - s, 2));
  function setProb(P){ let lo = 0.01, hi = 0.99; for(let i = 0; i < 40; i++){ const m = (lo + hi) / 2; matchFromSet(m) < P ? lo = m : hi = m; } return (lo + hi) / 2; }

  const KINDS = { team:['win','first_point','set1','set_score','none'], player:['attack','block','serve','dig','none'] };
  function guessKind(ev){
    const t = String(ev.q || '').replace(/\s/g, '');
    if(ev.type === 'player'){
      if(/블로킹|블록|가로막/.test(t)) return 'block';
      if(/서브|에이스/.test(t)) return 'serve';
      if(/디그|수비|리시브/.test(t)) return 'dig';
      return 'attack';
    }
    const opts = (ev.options || []).map(x=> String(x).trim()).filter(Boolean);
    if(opts.length && opts.filter(o=> /\d\s*:\s*\d/.test(o)).length >= Math.ceil(opts.length / 2) || /세트스코어|스코어/.test(t)) return 'set_score';
    if(/(1|첫|첫번째)세트/.test(t)) return 'set1';
    if(/첫득점|선취|첫점|먼저득점|첫포인트/.test(t)) return 'first_point';
    if(/이길|이기|승리|승자|승부|누가이/.test(t)) return 'win';
    return 'none';
  }
  const kindOf = ev=> KINDS[ev.type === 'player' ? 'player' : 'team'].includes(ev.aiKind) ? ev.aiKind : guessKind(ev);

  const PK = {
    block:  { ab:'blk', abL:'블로킹', stL:'세트당 블로킹', st:s=> s.blk, stF:x=> f2(x), per:s=> typeof s.blk === 'number' ? s.blk : 0.15,
              pos:{ MB:1, OP:0.75, OH:0.55, S:0.45, L:0 },
              intro:p=> p.pos === 'MB' ? '블로킹하면 미들 블로커! ' : '블로킹 능력치 1위가 나왔어요! ',
              line:s=> typeof s.blk === 'number' ? ` 세트마다 ${f2(s.blk)}개씩 상대 공격을 막아내고 있어요.` : '',
              duty:'네트 앞을 지켜요', cheer:'블로킹 성공할 때마다 이름 크게 불러 주세요!' },
    attack: { ab:'atk', abL:'공격', stL:'공격 성공률', st:s=> s.atk, stF:x=> typeof x === 'number' ? f1(x) + '%' : '-', per:s=> typeof s.atk === 'number' ? s.atk / 100 : 0.45,
              pos:{ OP:1, OH:0.9, MB:0.6, S:0.25, L:0 },
              intro:()=> '득점은 에이스의 몫! ',
              line:s=> typeof s.atk === 'number' ? ` 공격 성공률 ${f1(s.atk)}%로 결정력도 확실해요.` : '',
              duty:'코트를 책임져요', cheer:'득점 터지면 함성으로 답해 주세요!' },
    serve:  { ab:'srv', abL:'서브', stL:'세트당 서브 에이스', st:s=> s.ace, stF:x=> f2(x), per:s=> (typeof s.ace === 'number' ? s.ace : 0.12) * 1.5,
              pos:{ OP:1, OH:0.9, S:0.85, MB:0.8, L:0 },
              intro:()=> '서브 에이스는 강서버의 몫! ',
              line:s=> typeof s.ace === 'number' ? ` 세트마다 서브 에이스 ${f2(s.ace)}개를 꽂고 있어요.` : '',
              duty:'서브 라인에 서요', cheer:'서브 들어갈 때 함성으로 힘을 보태 주세요!' },
    dig:    { ab:'dig', abL:'디그', stL:'세트당 디그', st:s=> s.dig, stF:x=> f2(x), per:s=> (typeof s.dig === 'number' ? s.dig : 1) / 3,
              pos:{ L:1, OH:0.8, S:0.6, OP:0.5, MB:0.35 },
              intro:()=> '수비하면 디그! ',
              line:s=> typeof s.dig === 'number' ? ` 세트마다 디그 ${f2(s.dig)}개로 공을 살려내고 있어요.` : '',
              duty:'후위를 지켜요', cheer:'몸 날린 디그에 큰 박수 보내 주세요!' },
  };
  function playerPicks(ev, kind){
    const K = PK[kind];
    const cands = ev.candidates && ev.candidates.length ? PLAYERS.filter(p=> ev.candidates.includes(p.num)) : PLAYERS.filter(p=> p.pos !== 'L' || ev.pool === 'all' || isDefenseQ(ev));
    const maxG = Math.max(1, ...cands.map(p=> (p.season && p.season.g) || 0));
    const rows = cands.map(p=>{
      const ab = playerAbilityToday(p), s = p.season || {};
      const v = (ab[K.ab] || 0) / 100;
      const play = 0.35 + 0.65 * (((s.g || 0) / maxG));
      const f = FORTUNE.of(p);
      const luck = f ? 1 + (f.luck - 75) / 250 : 1;
      return { p, w: Math.pow(v, 2) * (0.4 + K.per(s)) * play * (K.pos[p.pos] ?? 0.5) * luck };
    }).filter(r=> r.w > 0);
    const sum = rows.reduce((a, r)=> a + r.w, 0) || 1;
    return rows.map(r=> ({ p:r.p, prob:r.w / sum })).sort((a, b)=> b.prob - a.prob);
  }
  function teamOpts(ev){
    const o = ev.options || [];
    let u = o.findIndex(x=> /읏맨|OK/i.test(x)); if(u < 0) u = 0;
    const t = o.findIndex((x, k)=> k !== u);
    return { us:o[u], opp:o[t < 0 ? u : t] };
  }

  function compute(){
    const t = teams();
    if(!t.us) return null;
    const opp = t.opp || avgTeam();
    const P = matchWin(t.us, opp);
    const s = setProb(P);
    const q = 1 - s;
    const dist = { '3:0':Math.pow(s, 3), '3:1':3 * Math.pow(s, 3) * q, '3:2':6 * Math.pow(s, 3) * q * q };
    dist['2:3 이하'] = Math.max(0, 1 - dist['3:0'] - dist['3:1'] - dist['3:2']);
    const edge = ((t.us.ace || 0) - (opp.ace || 0)) * 0.12 + ((t.us.rcv || 0) - (opp.rcv || 0)) * 0.004 + ((t.us.atk || 0) - (opp.atk || 0)) * 0.006 + (s - 0.5) * 0.25;
    const fp = clamp(0.5 + edge, 0.35, 0.65);
    return { P, s, dist, fp, us:t.us, opp, oppName: t.oppName || '상대팀', known: !!t.opp, h2h: h2hRecord(t.us, t.opp) };
  }

  const STAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l2.2 6.3L20.5 10l-6.3 2.2L12 18.5l-2.2-6.3L3.5 10l6.3-1.7z"/></svg>';
  const duel = (label, p, opp)=> `
    <p class="ai-win">${label} <b>${pct(p)}%</b></p>
    <div class="ai-bar" role="img" aria-label="${label} ${pct(p)}%"><i style="width:${pct(p)}%"></i></div>
    <div class="ai-bar-l"><span>읏맨 ${pct(p)}%</span><span>${escHtml(opp)} ${100 - pct(p)}%</span></div>`;
  const jp = (w, a, b)=>{ const c = String(w).trim().slice(-1).charCodeAt(0); if(!(c >= 0xAC00 && c <= 0xD7A3)) return `${a}(${b})`; return (c - 0xAC00) % 28 ? a : b; };
  const f2 = v => typeof v === 'number' ? v.toFixed(2) : '-';
  const f1 = v => typeof v === 'number' ? v.toFixed(1) : '-';
  function cmpTable(oppName, rows){
    return `<table class="pq-ai__cmp">
      <thead><tr><th></th><th>읏맨</th><th>${escHtml(oppName)}</th></tr></thead>
      <tbody>${rows.map(r=>{ const better = r.a == null || r.b == null ? 0 : (r.hi === false ? (r.a < r.b ? 1 : r.a > r.b ? -1 : 0) : (r.a > r.b ? 1 : r.a < r.b ? -1 : 0));
        return `<tr><th>${r.k}</th><td${better > 0 ? ' class="win"' : ''}>${r.fa}</td><td${better < 0 ? ' class="win"' : ''}>${r.fb}</td></tr>`; }).join('')}</tbody></table>`;
  }
  const more = (why, table)=> `<p class="pq-ai__why">${why}</p><details class="pq-ai__more"><summary>근거 숫자 보기<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></summary><div class="pq-ai__more-body">${table}</div></details>`;
  const ranks = rows=> `<ol class="pq-ai__rank">${rows.map((r, k)=> `<li${k === 0 ? ' class="top"' : ''}><span>${escHtml(r.l)}</span><i style="width:${Math.max(4, pct(r.v))}%"></i><b>${pct(r.v)}%</b></li>`).join('')}</ol>`;

  function aiPop(card, open){
    list.querySelectorAll('.predict-card.ai-open').forEach(c=>{ if(c !== card || !open){ c.classList.remove('ai-open'); const b = c.querySelector('.pq-ai-btn'); if(b) b.setAttribute('aria-expanded', 'false'); } });
    if(open && card){ card.classList.add('ai-open'); const b = card.querySelector('.pq-ai-btn'); if(b){ b.setAttribute('aria-expanded', 'true'); b.classList.add('seen'); } }
  }
  document.addEventListener('click', e=>{ if(!e.target.closest('.pq-ai, .pq-ai-btn')) aiPop(null, false); });
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape') aiPop(null, false); });
  new MutationObserver(()=>{ const c = list.querySelector('.predict-card.ai-open'); if(c && c.offsetParent === null) aiPop(null, false); }).observe(list, { attributes:true, subtree:true, attributeFilter:['class'] });
  function render(){
    const m = compute();
    if(!m){ box.hidden = true; list.querySelectorAll('.pq-ai').forEach(n=> n.remove()); return; }
    rec = {};
    EVS.forEach((ev, i)=>{
      const card = list.querySelectorAll('.predict-card')[i];
      if(!card) return;
      let pick = null, body = '';
      const kind = ev.ai === false ? 'none' : kindOf(ev);
      if(kind === 'none'){ }
      else if(ev.type === 'player'){
        const K = PK[kind];
        const top = playerPicks(ev, kind).slice(0, 3);
        if(top.length){
          pick = String(top[0].p.num);
          const p0 = top[0].p, s0 = p0.season || {}, ab0 = playerAbilityToday(p0), f0 = FORTUNE.of(p0);
          const gap = top[1] ? pct(top[0].prob) - pct(top[1].prob) : 99;
          const name0 = playerName(p0), name1 = top[1] ? playerName(top[1].p) : '';
          let why = K.intro(p0);
          why += `<b>${escHtml(name0)}</b> 선수는 ${K.abL} 능력치 <b>${ab0[K.ab] ?? '-'}</b>로 후보 중 최고예요.`;
          why += K.line(s0);
          if((s0.g || 0) >= 15) why += ` ${s0.g}경기를 뛴 주전으로 오늘도 ${K.duty}!`;
          if(f0){
            why += f0.luck >= 85 ? ` 오늘 운세도 ${f0.luck}점, 컨디션 최고조예요!`
                 : f0.luck < 72 ? ` 오늘 운세는 ${f0.luck}점이지만, 실력은 이미 증명됐어요!`
                 : ` 오늘 운세 ${f0.luck}점으로 컨디션도 좋아요.`;
          }
          why += gap <= 3 && name1 ? ` ${escHtml(name1)} 선수와 ${gap}%p 차 접전이라 누가 해내도 우리 팀이에요. ${K.cheer}`
               : ` 2위와 ${gap < 99 ? gap + '%p ' : ''}차이로 ${escHtml(name0)} 선수가 가장 유력해요. ${K.cheer}`;
          body = ranks(top.map(r=> ({ l:playerName(r.p), v:r.prob }))) + more(why, `<table class="pq-ai__cmp pq-ai__cmp--p">
                <thead><tr><th></th>${top.map(r=> `<th>${escHtml(playerName(r.p))}</th>`).join('')}</tr></thead>
                <tbody>
                  <tr><th>${K.abL} 능력치</th>${top.map((r, k)=> `<td${k === 0 ? ' class="win"' : ''}>${playerAbilityToday(r.p)[K.ab] ?? '-'}</td>`).join('')}</tr>
                  <tr><th>${K.stL}</th>${top.map(r=> `<td>${K.stF(K.st(r.p.season || {}))}</td>`).join('')}</tr>
                  <tr><th>출전 경기</th>${top.map(r=> `<td>${(r.p.season || {}).g || 0}</td>`).join('')}</tr>
                  <tr><th>포지션</th>${top.map(r=> `<td>${r.p.pos}</td>`).join('')}</tr>
                  <tr><th>오늘 운세</th>${top.map(r=>{ const f = FORTUNE.of(r.p); return `<td>${f ? f.luck + '점' : '-'}</td>`; }).join('')}</tr>
                </tbody></table>`);
        }
      } else if(kind === 'win' || kind === 'set1'){
        const o = teamOpts(ev), isWin = kind === 'win';
        const p = isWin ? m.P : clamp(0.5 + (m.s - 0.5) * 0.9, 0.2, 0.8);
        pick = p >= 0.5 ? o.us : o.opp;
        const us = m.us, op = m.opp, wr = t => Math.round(t.w / Math.max(1, t.w + t.l) * 100);
        const home = window.__matchHome !== false;
        let why = isWin ? '' : '1세트는 기선 제압 싸움! ';
        why += `읏맨은 올 시즌 <b>${us.w}승 ${us.l}패</b>, 승률 ${wr(us)}%. `;
        why += m.known ? `상대 ${escHtml(m.oppName)}${jp(m.oppName, '은', '는')} ${op.w}승 ${op.l}패예요. ` : '상대가 아직 정해지지 않아서 리그 평균 팀과 붙는다고 보고 계산했어요. ';
        if(m.h2h) why += m.h2h.w > m.h2h.l ? `맞대결은 ${m.h2h.w}승 ${m.h2h.l}패로 우리가 앞서 있어요! ` : m.h2h.w < m.h2h.l ? `맞대결은 ${m.h2h.w}승 ${m.h2h.l}패, 오늘은 설욕할 차례예요! ` : `맞대결은 ${m.h2h.w}승 ${m.h2h.l}패로 팽팽해요. `;
        why += isWin
          ? `세트 득실률 ${f2(us.setRatio)}${home ? '에 홈 팬들의 응원까지 더하면' : '까지 더하면'} 승리 확률 <b>${pct(p)}%</b>!`
          : `세트 하나를 따낼 힘을 계산하면 1세트를 가져올 확률은 <b>${pct(p)}%</b>예요.`;
        why += p >= 0.5 ? (isWin ? ' 끝까지 함성으로 힘을 보태 주세요!' : ' 첫 세트부터 분위기 확실히 가져와요!')
                        : ' 쉽지 않은 상대지만, 홈 코트의 함성은 숫자로 계산되지 않아요. 끝까지 함께 응원해요!';
        body = duel(isWin ? '읏맨 승리 확률' : '읏맨 1세트 승리 확률', p, m.oppName)
          + more(why, cmpTable(m.oppName, [
              { k:'시즌 성적', a:wr(us), b:wr(op), fa:`${us.w}승 ${us.l}패`, fb:m.known ? `${op.w}승 ${op.l}패` : '리그 평균' },
              { k:'세트 득실률', a:us.setRatio, b:op.setRatio, fa:f2(us.setRatio), fb:f2(op.setRatio) },
              { k:'공격 성공률', a:us.atk, b:op.atk, fa:f1(us.atk) + '%', fb:f1(op.atk) + '%' },
              { k:'세트당 블로킹', a:us.blk, b:op.blk, fa:f2(us.blk), fb:f2(op.blk) },
            ].concat(m.h2h ? [{ k:'맞대결', a:m.h2h.w, b:m.h2h.l, fa:`${m.h2h.w}승`, fb:`${m.h2h.l}승` }] : [])));
      } else if(kind === 'set_score'){
        const opts = ev.options.map(o=> ({ l:o, v: m.dist[o] ?? 0 })).sort((a, b)=> b.v - a.v);
        const wins = opts.filter(o=> /^3:/.test(o.l));
        const best = (m.P >= 0.5 && wins.length) ? wins[0] : opts[0];
        pick = best.l;
        const us = m.us, op = m.opp, wr = t => Math.round(t.w / Math.max(1, t.w + t.l) * 100);
        const home = window.__matchHome !== false;
        const FLAVOR = { '3:0':'세 세트를 내리 따내는 <b>셧아웃 승리</b>', '3:1':'한 세트를 내주더라도 끝내 웃는 <b>3:1 승리</b>', '3:2':'5세트 접전 끝에 거두는 <b>3:2 역전 드라마</b>' };
        let why = `읏맨은 올 시즌 <b>${us.w}승 ${us.l}패</b>, 승률 ${wr(us)}%. `;
        why += m.known ? `상대 ${escHtml(m.oppName)}${jp(m.oppName, '은', '는')} ${op.w}승 ${op.l}패예요. ` : '상대가 아직 정해지지 않아서 리그 평균 팀과 붙는다고 보고 계산했어요. ';
        if(m.h2h) why += m.h2h.w > m.h2h.l ? `맞대결은 ${m.h2h.w}승 ${m.h2h.l}패로 우리가 앞서 있어요! ` : m.h2h.w < m.h2h.l ? `맞대결은 ${m.h2h.w}승 ${m.h2h.l}패, 오늘은 설욕할 차례예요! ` : `맞대결은 ${m.h2h.w}승 ${m.h2h.l}패로 팽팽해요. `;
        why += `세트 득실률 ${f2(us.setRatio)}${home ? '에 홈 팬들의 응원까지 더하면' : '까지 더하면'} 승리 확률 <b>${pct(m.P)}%</b>!`;
        if(m.P >= 0.5){
          why += ` 가장 유력한 시나리오는 ${FLAVOR[best.l] || `<b>${best.l}</b>`}예요.`;
          const so = wins.find(w=> w.l === '3:0');
          if(best.l !== '3:0' && so) why += ` 셧아웃 승(3:0) 확률도 ${pct(so.v)}%!`;
          why += ' 세트마다 함성으로 힘을 보태 주세요!';
        } else {
          why += ` 이번 상대는 만만치 않아요. 하지만 홈 코트의 함성은 숫자로 계산되지 않아요. 끝까지 함께 응원해요!`;
        }
        body = duel('읏맨 승리 확률', m.P, m.oppName) + ranks((m.P >= 0.5 && wins.length ? wins : opts).slice(0, 3))
          + more(why, cmpTable(m.oppName, [
              { k:'시즌 성적', a:wr(us), b:wr(op), fa:`${us.w}승 ${us.l}패`, fb:m.known ? `${op.w}승 ${op.l}패` : '리그 평균' },
              { k:'세트 득실률', a:us.setRatio, b:op.setRatio, fa:f2(us.setRatio), fb:f2(op.setRatio) },
              { k:'공격 성공률', a:us.atk, b:op.atk, fa:f1(us.atk) + '%', fb:f1(op.atk) + '%' },
              { k:'세트당 블로킹', a:us.blk, b:op.blk, fa:f2(us.blk), fb:f2(op.blk) },
            ].concat(m.h2h ? [{ k:'맞대결', a:m.h2h.w, b:m.h2h.l, fa:`${m.h2h.w}승`, fb:`${m.h2h.l}승` }] : [])));
      } else if(kind === 'first_point'){
        const usFirst = m.fp >= 0.5, o = teamOpts(ev);
        pick = usFirst ? o.us : o.opp;
        const us = m.us, op = m.opp, opp = escHtml(m.oppName);
        const lead = [['서브', us.ace - op.ace], ['리시브', us.rcv - op.rcv], ['공격', us.atk - op.atk]];
        const ours = lead.filter(x=> x[1] > 0).map(x=> x[0]), theirs = lead.filter(x=> x[1] < 0).map(x=> x[0]);
        let why = '첫 점은 보통 <b>서브 에이스 한 방</b>, 아니면 <b>리시브 후 첫 공격</b>에서 나와요. ';
        const fpp = pct(usFirst ? m.fp : 1 - m.fp);
        if(ours.length === 3) why += `그런데 읏맨이 서브·리시브·공격 셋 다 앞서요. 첫 득점 확률 <b>${fpp}%</b>, 첫 점부터 읏맨의 흐름으로 가져옵니다!`;
        else if(usFirst) why += `읏맨은 ${ours.join('·')}, ${opp}${jp(m.oppName, '은', '는')} ${theirs.join('·')}${jp(theirs[theirs.length - 1], '이', '가')} 강점이에요. 팽팽한 가운데 읏맨이 <b>${fpp}%</b>로 한 발 앞서 있어요!`;
        else why += `${opp}${jp(m.oppName, '이', '가')} <b>${fpp}%</b>로 근소하게 앞서지만, 첫 점은 서브 한 번에 얼마든지 뒤집혀요!`;
        why += ' 첫 서브 들어갈 때 함성 크게 보내 주세요!';
        body = duel('읏맨 첫 득점 확률', m.fp, m.oppName)
          + more(why, cmpTable(m.oppName, [
              { k:'세트당 서브 에이스', a:us.ace, b:op.ace, fa:f2(us.ace), fb:f2(op.ace) },
              { k:'리시브 효율', a:us.rcv, b:op.rcv, fa:f1(us.rcv) + '%', fb:f1(op.rcv) + '%' },
              { k:'공격 성공률', a:us.atk, b:op.atk, fa:f1(us.atk) + '%', fb:f1(op.atk) + '%' },
            ]));
      }
      rec[ev.id] = pick;
      card.querySelectorAll('[data-opt]').forEach(o=> o.classList.toggle('ai-rec', pick != null && o.dataset.opt === pick));
      const old = card.querySelector('.ai-tip'); if(old) old.remove();
      const q = card.querySelector('.q');
      let row = card.querySelector('.pq-qrow');
      let aiEl = card.querySelector('.pq-ai');
      if(pick == null){ if(aiEl) aiEl.remove(); const b = row && row.querySelector('.pq-ai-btn'); if(b) b.remove(); return; }
      if(!row){ row = document.createElement('div'); row.className = 'pq-qrow'; q.before(row); row.appendChild(q); }
      let btn = row.querySelector('.pq-ai-btn');
      if(!btn){
        btn = document.createElement('button'); btn.type = 'button'; btn.className = 'pq-ai-btn';
        btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-controls', 'pq-ai-' + ev.id);
        btn.innerHTML = `${STAR}AI 예측`;
        row.appendChild(btn);
        btn.addEventListener('click', e=>{ e.stopPropagation(); aiPop(card, !card.classList.contains('ai-open')); });
      }
      if(!aiEl){ aiEl = document.createElement('div'); aiEl.className = 'pq-ai'; aiEl.id = 'pq-ai-' + ev.id; aiEl.setAttribute('role', 'dialog'); aiEl.setAttribute('aria-label', 'AI 예측'); row.after(aiEl); }
      const pickLabel = ev.type === 'player' ? playerName(playerByNum(Number(pick))) : pick;
      const wasOpen = !!(aiEl.querySelector('.pq-ai__more') || {}).open;
      aiEl.innerHTML = `
        <div class="pq-ai__head"><span class="pq-ai__pick">AI PICK · <b>${escHtml(String(pickLabel))}</b></span>
          <button class="pq-ai__x" type="button" aria-label="AI 예측 닫기"><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
        ${body}`;
      aiEl.querySelector('.pq-ai__x').addEventListener('click', ()=>{ aiPop(card, false); btn.focus(); });
      if(wasOpen){ const d = aiEl.querySelector('.pq-ai__more'); if(d) d.open = true; }
    });
    box.hidden = true; box.innerHTML = '';
  }

  window.__aiPredictRefresh = render;
  render();
  document.getElementById('predict-submit').addEventListener('click', ()=> setTimeout(()=>{ if(LOCAL['predictions']) render(); }, 50));
})();

/* ===== 플레이 · 선수 카드 ===== */
(function initPlayerCard(){
  const modal = document.getElementById('pcard-modal');
  const card = document.getElementById('pcard');
  const stage = document.getElementById('pc-stage');
  const shine = document.getElementById('pc-shine');
  const hint = document.getElementById('pc-hint');
  let list = PLAYERS, idx = 0;
  let ry = 0, rx = 0, vel = 0, dragging = false, lastX = 0, lastY = 0, raf = null, rot = null, t0 = 0;
  let flip = 0, fa = 0, moved = 0, sumDx = 0;
  let revealTimer = 0;
  const back = document.getElementById('pc-back');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  const AB_KEYS = ['atk','srv','blk','dig','rcv','set'];
  const AB_LABELS = { atk:'공격', srv:'서브', blk:'블로킹', dig:'디그', rcv:'리시브', set:'세트' };

  function radarSvg(ab){
    const cx = 150, cy = 140, R = 92;
    const pt = (i, r)=>{ const a = (-90 + i * 60) * Math.PI / 180; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; };
    const ring = f => AB_KEYS.map((_, i)=> pt(i, R * f).join(',')).join(' ');
    let s = `<svg viewBox="0 0 300 280" role="img" aria-label="능력치 ${AB_KEYS.map(k=> AB_LABELS[k] + ' ' + (ab[k] || 0)).join(', ')}">`;
    [0.25, 0.5, 0.75, 1].forEach(f=> s += `<polygon class="radar-grid" points="${ring(f)}"/>`);
    AB_KEYS.forEach((_, i)=>{ const [x, y] = pt(i, R); s += `<line class="radar-axis" x1="${cx}" y1="${cy}" x2="${x}" y2="${y}"/>`; });
    const pts = AB_KEYS.map((k, i)=> pt(i, R * Math.max(0.04, (ab[k] || 0) / 100)));
    s += `<polygon class="radar-poly" points="${pts.map(p=> p.join(',')).join(' ')}"/>`;
    pts.forEach(([x, y])=> s += `<circle class="radar-dot" cx="${x}" cy="${y}" r="3.2"/>`);
    AB_KEYS.forEach((k, i)=>{
      const [x, y] = pt(i, R + 26);
      const anchor = Math.abs(x - cx) < 4 ? 'middle' : (x > cx ? 'start' : 'end');
      const dy = i === 0 ? -6 : (i === 3 ? 14 : 4);
      s += `<text text-anchor="${anchor}" x="${x}" y="${y + dy}"><tspan class="radar-label">${AB_LABELS[k]} </tspan><tspan class="radar-val">${ab[k] ?? '-'}</tspan></text>`;
    });
    return s + `</svg>`;
  }

  function statsHtml(ab, lucky){
    const col = keys => `<ul>${keys.map(k=> `<li><b${k === lucky ? ' class="lucky"' : ''}>${ab[k] ?? '-'}</b><span>${AB_LABELS[k]}</span></li>`).join('')}</ul>`;
    return col(['atk','srv','blk']) + `<i aria-hidden="true"></i>` + col(['dig','rcv','set']);
  }

  function seasonHtml(p){
    const s = p.season || {};
    const f = (v, d, unit)=> v === null || v === undefined ? '-' : (d ? Number(v).toFixed(d) : v) + (unit || '');
    const items = [
      ['득점', f(s.pts)], ['공격성공률', f(s.atk, 1, '%')], p.pos === 'S' ? ['세트당 세트', f(s.set, 2)] : ['리시브효율', f(s.rcv, 1, '%')],
      ['세트당 블로킹', f(s.blk, 2)], ['세트당 서브', f(s.ace, 2)], ['세트당 디그', f(s.dig, 2)],
    ];
    const label = STATS.seasonLabel ? `${STATS.seasonLabel} 시즌` : '시즌 기록';
    document.getElementById('pc-season-title').textContent =
      p.noRecord ? `${label} · 출전 기록 없음`
      : (s.g ? `${label} · ${p.prevTeam ? p.prevTeam + ' 소속 · ' : ''}${s.g}경기 출전` : label);
    return items.map(([l, v])=> `<div class="pc-season__item"><div class="pc-season__v">${v}</div><div class="pc-season__l">${l}</div></div>`).join('');
  }

  let bdayShown = '';
  function birthdayFx(p, f){
    const on = !!(f && f.birthday);
    card.classList.toggle('is-bday', on);
    let rib = card.querySelector('.pcard__bday');
    if(on && !rib){ rib = document.createElement('span'); rib.className = 'pcard__bday'; rib.setAttribute('aria-hidden', 'true'); card.appendChild(rib); }
    if(rib) rib.innerHTML = on ? '🎂 HAPPY BIRTHDAY' : '';
    const key = on ? p.num + '|' + f.date : '';
    if(on && key !== bdayShown){ bdayShown = key; if(!reduce) setTimeout(confetti, 350); if(canVibrate()) navigator.vibrate([0, 40, 60, 40, 60, 120]); }
    if(!on) bdayShown = '';
  }
  function confetti(){
    const box = document.createElement('div'); box.className = 'bday-confetti'; box.setAttribute('aria-hidden', 'true');
    const colors = ['#FF571F', '#FFC27A', '#9C8CFF', '#6FB6FF', '#FF9CC8', '#FFFFFF'];
    box.innerHTML = Array.from({ length: 48 }, (_, i)=>{
      const x = Math.random() * 100, d = Math.random() * .5, dur = 1.6 + Math.random() * 1.2, rot = Math.random() * 720 - 360, w = 9 + Math.random() * 7;
      const dx = Math.round(Math.random() * 80 - 40);
      return `<i style="left:${x}%; --d:${d}s; --t:${dur}s; --r:${rot}deg; --x:${dx}px; width:${w}px; height:${w * .6}px; background:${colors[i % colors.length]}"></i>`;
    }).join('');
    modal.appendChild(box); setTimeout(()=> box.remove(), 3400);
  }
  function backHtml(p, f){
    if(!f) return `<p class="fb__label"><span class="fb__ai">✦ AI</span>오늘의 운세</p>
      <p class="fb__empty">생일 정보를 준비 중이에요<small>곧 ${playerName(p)} 선수의 운세를 볼 수 있어요</small></p>`;
    const [, m, d] = f.date.split('-');
    return `<p class="fb__label"><span class="fb__ai">✦ AI</span>오늘의 운세 · ${+m}.${+d}</p>
      <p class="fb__sign">${f.zodiac}${f.animal ? ' · ' + f.animal : ''}${f.birthday ? ' · 생일' : ''}</p>
      <div class="fb__score"><b>${f.luck}</b><em><span>${f.birthday ? '🎂 생일' : f.band.name}</span></em></div>
      <p class="fb__line">${(f.parts || [f.line]).join(' ')}</p>
      <p class="fb__note">재미로 보는 운세예요</p>`;
  }
  function setFlip(on, quiet){
    flip = on ? 180 : 0;
    card.setAttribute('aria-pressed', on ? 'true' : 'false');
    if(!quiet && canVibrate()) navigator.vibrate(10);
    if(on && FORTUNE.of(list[idx]) && !LOCAL.fortune_seen){ LOCAL.fortune_seen = true; saveLocal(LOCAL); }
    syncCta();
    if(rot) fortuneHint(list[idx]);
    if(on) revealFortune();
  }
  function revealFortune(){
    const f = FORTUNE.of(list[idx]); const b = back.querySelector('.fb__score b'); if(!f || !b) return;
    card.classList.remove('fb-reveal'); void card.offsetWidth; card.classList.add('fb-reveal');
    if(reduce){ b.textContent = f.luck; return; }
    const t0 = performance.now(), dur = 900, start = 260;
    b.textContent = '0';
    (function tick(now){
      const t = Math.min(1, Math.max(0, (now - t0 - start) / dur));
      b.textContent = Math.round(f.luck * (1 - Math.pow(1 - t, 3)));
      if(t < 1) requestAnimationFrame(tick);
    })(t0);
  }
  hint.addEventListener('click', e=>{ if(e.target.closest('.pc-fortune-btn')){ hapticTick(); setFlip(flip === 0); } });
  function syncCta(){
    const back = flip === 180;
    const live = window.__matchPhase && window.__matchPhase() === 'live';
    const mvpBtn = document.getElementById('pc-mvp'), evBtn = document.getElementById('pc-event');
    mvpBtn.hidden = back || !!LOCAL.mvp_voted;
    evBtn.hidden = !back || (live ? !!LOCAL.mvp_voted : !!LOCAL.predictions) || !CONFIG.PREDICT_EVENTS.some(ev=> ev.type === 'player') && !live;
    evBtn.textContent = live ? '이 선수에게 MVP 투표하기' : '이벤트 투표하러 가기';
  }

  let mvLoaded = false;
  function buildStage(p){
    stage.innerHTML = '';
    rot = null;
    if(p.model){
      if(!mvLoaded){
        const sc = document.createElement('script'); sc.type = 'module';
        sc.src = 'https://cdn.jsdelivr.net/npm/@google/model-viewer@3.5.0/dist/model-viewer.min.js';
        document.head.appendChild(sc); mvLoaded = true;
      }
      stage.innerHTML = `<model-viewer src="${p.model}" alt="${playerName(p)} 3D 모델" camera-controls auto-rotate auto-rotate-delay="0" rotation-per-second="24deg" shadow-intensity="1" exposure="1.05" interaction-prompt="none" disable-zoom></model-viewer>`;
      hint.textContent = '손가락으로 돌려보세요';
      return;
    }
    const src = cardSrc(p);
    if(!src){ hint.textContent = ''; return; }
    stage.innerHTML = `<img class="pcard__photo" src="${src}" alt="" draggable="false">`;
    rot = card;
    fortuneHint(p);
  }
  function fortuneHint(p){
    const f = FORTUNE.of(p);
    if(!f){ hint.textContent = '카드를 탭하면 뒤집혀요'; return; }
    const back = flip === 180;
    hint.innerHTML = `<button class="pc-fortune-btn${back ? ' is-back' : ''} band-${f.band.key}${f.birthday ? ' is-bday' : ''}" type="button">`
      + (back ? '카드 앞면 보기'
        : f.birthday ? `<span class="pc-fortune-btn__ic" aria-hidden="true">🎂</span>생일 축하 AI 운세 보기 <b>${f.luck}점</b>`
        : `<span class="pc-fortune-btn__ic" aria-hidden="true">✦</span>오늘의 AI 운세 보기 <b>${f.luck}점 · ${f.band.name}</b>`)
      + `</button>`;
  }

  function render(){
    const p = list[idx];
    const ovr = playerOvrToday(p);
    const fort = FORTUNE.of(p);
    const abToday = playerAbilityToday(p);
    card.dataset.tier = playerTier(p);
    card.dataset.rare = isRare(p) ? '1' : '';
    card.dataset.mvp = isMvpCard(p) ? '1' : '';
    modal.dataset.tier = 'base';
    birthdayFx(p, fort);
    document.getElementById('pc-ovr').textContent = ovr;
    const luckEl = document.getElementById('pc-luck');
    luckEl.hidden = !fort;
    luckEl.textContent = fort ? `운세 ${fort.luck}` : '';
    back.innerHTML = backHtml(p, fort);
    document.getElementById('pc-ab-title').textContent = fort ? `능력치 · 오늘의 AI 운세 반영 (${fort.luckyLabel} +${fort.boost})` : '능력치';
    document.getElementById('pc-pos').textContent = p.pos;
    document.getElementById('pc-tier').textContent = isMvpCard(p) ? (CONFIG.MVP_CARD.title || 'MVP') : '';
    document.getElementById('pc-num').textContent = p.num;
    document.getElementById('pc-stats').innerHTML = statsHtml(abToday, fort && fort.lucky);
    document.getElementById('pc-name').textContent = playerName(p);
    document.getElementById('pc-meta').textContent = POS[p.pos] ? POS[p.pos].ko : p.pos;
    document.getElementById('pc-count').textContent = `${idx + 1} / ${list.length}`;
    document.getElementById('pc-radar').innerHTML = radarSvg(abToday);
    document.getElementById('pc-season').innerHTML = seasonHtml(p);
    buildStage(p);
    ry = 0; vel = 0; rx = 0; t0 = performance.now();
    flip = 0; fa = 0; card.classList.remove('is-back'); card.setAttribute('aria-pressed', 'false');
    syncCta();
    if(rot) fortuneHint(p);
    card.classList.remove('reveal');
    clearTimeout(revealTimer);
    if(!reduce){
      void card.offsetWidth; card.classList.add('reveal');
      revealTimer = setTimeout(()=> card.classList.remove('reveal'), 1200);
    }
    if(canVibrate()) navigator.vibrate(12);
  }

  function loop(now){
    if(!dragging){
      const t = (now - t0) / 1000;
      const ty = reduce ? 0 : Math.sin(t * 0.9) * 7;
      const tx = reduce ? 0 : Math.cos(t * 0.7) * 3;
      ry += (ty - ry) * 0.08;
      rx += (tx - rx) * 0.08;
    }
    fa = fa + (flip - fa) * (reduce ? 0.24 : 0.14);
    if(Math.abs(flip - fa) < 0.2) fa = flip;
    card.classList.toggle('is-back', fa > 90);
    if((rot || fa) && !card.classList.contains('reveal')){
      card.style.transform = `perspective(900px) rotateX(${rx.toFixed(2)}deg) rotateY(${(ry + fa).toFixed(2)}deg)`;
    }
    card.style.setProperty('--mx', (50 + ry * 2.2).toFixed(1) + '%');
    card.style.setProperty('--my', (50 - rx * 3).toFixed(1) + '%');
    shine.style.setProperty('--shine', (ry * 4).toFixed(1) + '%');
    raf = requestAnimationFrame(loop);
  }
  card.addEventListener('animationend', e=>{ if(e.target === card) card.classList.remove('reveal'); });

  let axis = '';
  card.addEventListener('pointerdown', e=>{
    dragging = true; lastX = e.clientX; lastY = e.clientY; moved = 0; sumDx = 0; axis = '';
    try{ card.setPointerCapture(e.pointerId); }catch(err){}
  });
  let tsx = 0, tsy = 0;
  card.addEventListener('touchstart', e=>{ const t = e.touches[0]; tsx = t.clientX; tsy = t.clientY; }, { passive:true });
  card.addEventListener('touchmove', e=>{
    const t = e.touches[0], dx = Math.abs(t.clientX - tsx), dy = Math.abs(t.clientY - tsy);
    if(!axis && dx + dy > 6) axis = dx > dy ? 'x' : 'y';
    if(axis === 'x' && e.cancelable) e.preventDefault();
  }, { passive:false });
  card.addEventListener('pointermove', e=>{
    if(!dragging) return;
    const dx = e.clientX - lastX, dy = e.clientY - lastY;
    lastX = e.clientX; lastY = e.clientY;
    moved += Math.abs(dx) + Math.abs(dy); sumDx += dx;
    if(!axis && moved > 6) axis = Math.abs(sumDx) * 2 > moved ? 'x' : 'y';
    if(!rot || axis === 'y') return;
    ry = Math.max(-28, Math.min(28, ry + dx * 0.35));
    rx = Math.max(-18, Math.min(18, rx - dy * 0.3));
  });
  const endDrag = ()=>{ dragging = false; t0 = performance.now(); };
  card.addEventListener('pointerup', e=>{
    if(dragging && (moved < 12 || (axis === 'x' && Math.abs(sumDx) > 60))) setFlip(flip === 0);
    endDrag();
  });
  card.addEventListener('keydown', e=>{
    if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); setFlip(flip === 0); }
  });
  card.addEventListener('pointercancel', endDrag);

  function open(num, sourceList, opts){
    LIVE.count('card:' + num);
    list = (sourceList && sourceList.length) ? sourceList : PLAYERS;
    idx = Math.max(0, list.findIndex(p=> p.num === num));
    render();
    if(opts && opts.back) setTimeout(()=> setFlip(true, true), reduce ? 0 : 1150);
    modal.classList.add('show');
    document.documentElement.style.overflow = 'hidden';
    t0 = performance.now();
    if(!raf) raf = requestAnimationFrame(loop);
    document.getElementById('pc-close').focus({ preventScroll:true });
  }
  function close(){
    modal.classList.remove('show');
    document.documentElement.style.overflow = '';
    if(raf){ cancelAnimationFrame(raf); raf = null; }
    setTimeout(()=>{ if(!modal.classList.contains('show')) stage.innerHTML = ''; }, 400);
  }
  const step = d =>{ hapticTick(); idx = (idx + d + list.length) % list.length; render(); };

  document.getElementById('pc-close').addEventListener('click', close);
  document.getElementById('pc-prev').addEventListener('click', ()=> step(-1));
  document.getElementById('pc-next').addEventListener('click', ()=> step(1));
  document.addEventListener('keydown', e=>{
    if(!modal.classList.contains('show')) return;
    if(e.key === 'Escape') close();
    if(e.key === 'ArrowLeft') step(-1);
    if(e.key === 'ArrowRight') step(1);
  });
  document.getElementById('pc-event').addEventListener('click', ()=>{
    const num = list[idx].num;
    const live = window.__matchPhase && window.__matchPhase() === 'live';
    close();
    if(live){ navigate('pick', 'mvp'); window.__mvpPreselect && window.__mvpPreselect(num); }
    else { navigate('pick', 'predict'); window.__predictPreselect && window.__predictPreselect(num); }
  });
  document.getElementById('pc-mvp').addEventListener('click', ()=>{
    const num = list[idx].num;
    close();
    navigate('pick', 'mvp');
    if(window.__mvpPreselect) window.__mvpPreselect(num);
  });

  window.__openPlayerCard = open;
})();

(function(){
  var card = document.querySelector('#app .matchbar[data-float]');
  if(!card || !('IntersectionObserver' in window)) return;

  var bar = document.createElement('button');
  bar.type = 'button';
  bar.className = 'matchbar-float';
  bar.setAttribute('aria-label', '오늘의 매치 보기');
  bar.innerHTML =
    '<span class="mf-team"><b id="mf-home"></b></span>' +
    '<span class="mf-vs">VS</span>' +
    '<span class="mf-team away"><b id="mf-away"></b></span>' +
    '<span class="mf-date" id="mf-date"></span>';
  document.getElementById('app').appendChild(bar);

  var pairs = [['mb-home','mf-home'],['mb-away','mf-away'],['mb-date','mf-date']];
  function sync(){
    pairs.forEach(function(p){
      var from = document.getElementById(p[0]), to = document.getElementById(p[1]);
      if(from && to) to.textContent = from.textContent;
    });
  }
  sync();
  var mo = new MutationObserver(sync);
  pairs.forEach(function(p){
    var el = document.getElementById(p[0]);
    if(el) mo.observe(el, {childList:true, characterData:true, subtree:true});
  });

  var hdr = document.querySelector('.brand-header');
  var app = document.getElementById('app');
  var hh = hdr && getComputedStyle(hdr).position === 'sticky' ? Math.round(hdr.getBoundingClientRect().bottom)
         : Math.max(0, Math.round(app ? app.getBoundingClientRect().top : 0));
  new IntersectionObserver(function(entries){
    var e = entries[0];
    var gone = !e.isIntersecting && e.boundingClientRect.top < hh;
    bar.classList.toggle('show', gone);
  }, {threshold:0, rootMargin:'-' + hh + 'px 0px 0px 0px'}).observe(card);

  bar.addEventListener('click', function(){
    var smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    card.scrollIntoView({behavior: smooth ? 'smooth' : 'auto', block:'center'});
  });
})();

/* ===== 이벤트 · 띠 배너 ===== */
(function initCountdownBand(){
  const band = document.getElementById('cd-band'), src = document.getElementById('predict-countdown');
  if(!band || !src) return;
  const URGENT_SEC = 600;
  const startAt = ()=> (((document.getElementById('mb-date') || {}).textContent || '').match(/(\d{1,2}:\d{2})/) || [])[1] || '';
  const p2 = n => String(n).padStart(2, '0');
  function render(){
    const t = src.textContent.trim(), m = t.match(/(\d+)\s*:\s*(\d+)\s*:\s*(\d+)/);
    const left = m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : null;
    const closed = /예측 마감/.test(t), urgent = left != null && left <= URGENT_SEC;
    const at = startAt(), whistle = at ? `${at} 휘슬과 함께 예측 마감!` : '휘슬이 울리면 예측 마감!';
    const text = closed ? ['예측 마감!', '이제 목청껏 응원할 시간이에요']
      : urgent ? [`예측 마감 임박! <b>${p2(Math.floor(left / 60))} : ${p2(left % 60)}</b>`, '지금 바로 예측하세요!']
      : m ? [`경기 시작까지 <b>${t}</b>`, whistle]
      : ['오늘 경기 시작 전까지 예측할 수 있어요', whistle];
    band.classList.toggle('is-closed', closed);
    band.classList.toggle('is-urgent', urgent);
    band.querySelectorAll('[data-cd="main"]').forEach(el=> el.innerHTML = text[0]);
    band.querySelectorAll('[data-cd="p1"]').forEach(el=> el.textContent = text[1]);
  }
  new MutationObserver(render).observe(src, { childList:true, characterData:true, subtree:true });
  render();
})();

/* ===== 안내 · 지하철 안내 팝업 ===== */
(function(){
  var sheet=document.getElementById('subway-sheet'), openBtn=document.getElementById('subway-open'),
      closeBtn=document.getElementById('subway-close'), toast=document.getElementById('subway-toast'),
      toastDesc=document.getElementById('toast-desc'),
      cardTime=document.getElementById('subway-card-time'), cardDesc=document.getElementById('subway-card-desc');
  if(!sheet||!openBtn) return;
  var lastFocus=null;
  function open(){
    lastFocus=document.activeElement; sheet.classList.add('show'); document.body.classList.add('modal-open');
    document.dispatchEvent(new CustomEvent('subway:open'));
    setTimeout(function(){ closeBtn && closeBtn.focus(); }, 50);
  }
  function close(){
    sheet.classList.remove('show'); document.body.classList.remove('modal-open');
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  openBtn.addEventListener('click', open);
  closeBtn && closeBtn.addEventListener('click', close);
  document.addEventListener('keydown', function(e){ if(e.key==='Escape' && sheet.classList.contains('show')) close(); });
  window.__openSubway = open;
  function syncTime(){
    var m=(toastDesc && toastDesc.textContent || '').match(/(\d{1,2}:\d{2})/);
    if(m && cardTime){ cardTime.textContent=m[1]; }
  }
  function urgent(){
    var h=new Date().getHours(), late=(h>=22 || h<4) || (toast && toast.classList.contains('show'));
    openBtn.classList.toggle('urgent', !!late);
    if(cardDesc) cardDesc.textContent = late ? '경기가 길어지고 있어요. 막차 시간을 확인해 보세요.' : '';
  }
  syncTime(); urgent(); setInterval(urgent, 60000);
  if(toastDesc) new MutationObserver(syncTime).observe(toastDesc,{childList:true,characterData:true,subtree:true});
  if(toast) new MutationObserver(urgent).observe(toast,{attributes:true,attributeFilter:['class']});
})();

/* ===== 이벤트 · 예측 문항 넘기기 ===== */
(function(){
  var list=document.getElementById('predict-list'), head=document.getElementById('pq-head'), nav=document.getElementById('pq-nav'),
      fill=document.getElementById('pq-progress'), num=document.getElementById('pq-num'),
      prev=document.getElementById('pq-prev'), next=document.getElementById('pq-next'), submit=document.getElementById('predict-submit');
  if(!list||!nav) return;
  var panel=list.closest('.seatmode-panel'), idx=0;
  function cards(){ return Array.prototype.filter.call(list.children, function(c){ return c.classList.contains('predict-card') || c.querySelector('.opt, .pick-player'); }); }
  function answered(c){ return !!(c && c.querySelector('.opt.selected, .pick-player.selected, .selected')); }
  function render(scroll){
    var cs=cards(), n=cs.length, on=n>1;
    panel.classList.toggle('pq-mode', on); head.hidden=!on; nav.hidden=!on;
    if(!on){ cs.forEach(function(c){ c.classList.remove('pq-on'); }); if(submit && submit.parentNode===nav) nav.after(submit); return; }
    if(idx>n-1) idx=n-1; if(idx<0) idx=0;
    cs.forEach(function(c,i){ c.classList.toggle('pq-on', i===idx); });
    var last=idx===n-1; panel.classList.toggle('pq-last', last);
    fill.style.width=((idx+1)/n*100)+'%';
    num.textContent=(idx+1)+' / '+n;
    prev.hidden=idx===0;
    next.hidden=last;
    if(submit){ if(last){ if(submit.parentNode!==nav) nav.appendChild(submit); } else if(submit.parentNode===nav){ nav.after(submit); } }
    next.disabled=!answered(cs[idx]) && !panel.classList.contains('closed');
    if(scroll){
      // 다음 · 이전 — 화면을 문항 맨 위(진행 바)로 올리고, 화면 읽기 프로그램도 새 문항부터 읽게
      window.scrollTo({ top:0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
      var q=cs[idx] && cs[idx].querySelector('.q, .qtext, h3'); if(q){ q.setAttribute('tabindex','-1'); q.focus({ preventScroll:true }); }
    }
  }
  window.__pqGoto = function(i){
    var cs=cards(), first=-1;
    for(var k=0;k<i && k<cs.length;k++){ if(!answered(cs[k])){ first=k; break; } }
    idx = first>=0 ? first : i; render(true);
    if(first>=0){
      var h=document.getElementById('pq-hint'); if(!h){ h=document.createElement('p'); h.id='pq-hint'; h.className='pq-hint'; h.setAttribute('aria-live','polite'); head.appendChild(h); }
      h.textContent='앞 문항부터 골라 주세요. 선수는 미리 골라 뒀어요!'; h.classList.add('show');
      clearTimeout(h._t); h._t=setTimeout(function(){ h.classList.remove('show'); }, 3500);
    }
  };
  prev.addEventListener('click', function(){ idx--; render(true); });
  next.addEventListener('click', function(){ if(next.disabled) return; idx++; render(true); });
  list.addEventListener('click', function(){ setTimeout(function(){ render(false); }, 0); });
  new MutationObserver(function(){ render(false); }).observe(list,{childList:true});
  if(panel) new MutationObserver(function(){ render(false); }).observe(panel,{attributes:true,attributeFilter:['class']});
  var stEl=document.getElementById('predict-status'); if(stEl) new MutationObserver(function(){ render(false); }).observe(stEl,{attributes:true,attributeFilter:['class']});
  render(false);
})();

/* ===== 홈 히어로 ===== */
(function initHeroSlides(){
  const hero = document.getElementById('home-hero'); if(!hero) return;
  const imgs = [...hero.querySelectorAll('.hero__img')], dots = [...hero.querySelectorAll('.hero__dots i')];
  if(imgs.length < 2) return;
  const calmHero = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let i = 0;
  function show(n){
    i = (n + imgs.length) % imgs.length;
    imgs.forEach((im, k)=> im.classList.toggle('is-on', k === i));
    dots.forEach((d, k)=> d.classList.toggle('is-on', k === i));
  }
  setInterval(()=>{
    if(document.hidden || !document.getElementById('view-home').classList.contains('active')) return;
    show(i + 1);
  }, calmHero ? 7000 : 5000);
})();

/* ===== 다크 · 라이트 모드 ===== */
(function initThemeToggle(){
  const btn = document.getElementById('theme-toggle'); if(!btn) return;
  const root = document.documentElement, meta = document.querySelector('meta[name="theme-color"]');
  function apply(theme, save){
    root.dataset.theme = theme;
    const next = theme === 'dark' ? '라이트' : '다크';
    btn.setAttribute('aria-label', `${next} 모드로 바꾸기`); btn.title = `${next} 모드로 바꾸기`;
    if(meta) meta.setAttribute('content', theme === 'dark' ? '#0E0F12' : '#F7F7F9');
    if(save){ try{ localStorage.setItem('okman_theme', theme); }catch(e){} }
  }
  apply(root.dataset.theme === 'light' ? 'light' : 'dark', false);
  btn.addEventListener('click', ()=>{
    hapticTick();
    root.classList.add('theme-switching');
    apply(root.dataset.theme === 'dark' ? 'light' : 'dark', true);
    setTimeout(()=> root.classList.remove('theme-switching'), 350);
  });
})();

/* ===== 플레이 · 운세 TOP 3 ===== */
(function initFortuneTop(){
  const grid = document.getElementById('squad-grid'); if(!grid) return;
  const box = document.createElement('section');
  box.className = 'luck-top'; box.setAttribute('aria-label', '오늘의 AI 운세 TOP 3');
  const chips = document.getElementById('pos-chips');
  const anchor = chips ? (chips.parentElement && chips.parentElement.classList.contains('subtab-wrap') ? chips.parentElement : chips) : grid;
  anchor.before(box);
  function render(){
    const ranked = PLAYERS.map(p=> ({ p, f:FORTUNE.of(p) })).filter(x=> x.f).sort((a, b)=> b.f.luck - a.f.luck).slice(0, 3);
    if(!ranked.length){ box.hidden = true; return; }
    const d = new Date(), md = `${d.getMonth() + 1}.${d.getDate()}`;
    box.hidden = false;
    box.innerHTML = `<div class="luck-top__head"><p class="luck-top__t"><span class="luck-top__ai" aria-hidden="true">✦ AI</span>오늘의 운세 TOP 3</p><span class="luck-top__d">${md} · 카드를 눌러 확인</span></div>
      <ol class="luck-top__list">${ranked.map(({ p, f }, i)=> `
        <li><button type="button" class="luck-top__item rank-${i + 1}${f.birthday ? ' is-bday' : ''}" data-num="${p.num}" aria-label="${i + 1}위 ${playerName(p)} 운세 ${f.luck}점 ${f.band.name}">
          <span class="luck-top__rank">${f.birthday ? '🎂' : i + 1}</span>
          <span class="luck-top__face">${cardSrc(p) ? `<img src="${cardSrc(p)}" alt="" loading="lazy">` : `<i>${p.num}</i>`}</span>
          <span class="luck-top__name">${playerName(p)}</span>
          <span class="luck-top__score"><b>${f.luck}</b>점 <em>${f.birthday ? '생일' : f.band.name}</em></span>
        </button></li>`).join('')}</ol>`;
  }
  box.addEventListener('click', e=>{
    const b = e.target.closest('.luck-top__item'); if(!b) return;
    hapticTick(); window.__openPlayerCard && window.__openPlayerCard(+b.dataset.num, PLAYERS, { back:true });
  });
  render();
})();

/* ===== 화면 이용 횟수 ===== */
document.addEventListener('click', e=>{
  const t = e.target; if(!t.closest) return;
  const c = k=> LIVE.count(k);
  if(t.closest('#seat-guide-submit:not(:disabled)')) return c('seat_guide');
  if(t.closest('#seat-view-submit:not(:disabled)')) return c('seat_view');
  if(t.closest('.seatmode-btn[data-key="games"]')) return c('games');
  if(t.closest('.seatmode-btn[data-key="predict"]')) return c('predict');
  if(t.closest('.seatmode-btn[data-key="mvp"]:not(.locked)')) return c('mvp');
  if(t.closest('.tabbar__btn[data-view="survey"]')) return c('survey');
  const m = t.closest('.mission-item:not(.done):not(.locked)');
  if(m && ['predict', 'survey', 'mvp'].includes(m.dataset.mission)) return c(m.dataset.mission);
  if(t.closest('.tabbar__btn[data-view="pick"]')) setTimeout(()=>{
    const on = document.querySelector('#view-pick .seatmode-btn.active[data-key]');
    if(on && (on.dataset.key === 'predict' || on.dataset.key === 'mvp')) c(on.dataset.key);
  }, 0);
}, true);

/* ===== 응원 버튼 · 매치 카드 겹침 ===== */
(function tuckCheerFab(){
  const fab = document.getElementById('cheer-fab'); if(!fab) return;
  let raf = 0;
  function check(){
    raf = 0;
    const card = document.querySelector('.matchbar');
    if(!card){ fab.classList.remove('is-tucked'); return; }
    const a = fab.getBoundingClientRect(), b = card.getBoundingClientRect();
    const hit = a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
    fab.classList.toggle('is-tucked', hit);
  }
  const queue = ()=>{ if(!raf) raf = requestAnimationFrame(check); };
  addEventListener('scroll', queue, { passive:true }); addEventListener('resize', queue);
  document.addEventListener('click', ()=> setTimeout(queue, 400));
  setTimeout(check, 800);
})();

/* ===== 서브탭 손가락 밀기 (아이폰 대응) ===== */
// 일부 아이폰에서 가로 스크롤이 손가락에 반응하지 않아서, Swiper처럼 터치를 직접 받아 밀어요 (가로로 밀 때만 · 세로 스크롤은 그대로)
(function swipeTabs(){
  const scrollerOf = row => [row, ...row.querySelectorAll('ul')].find(el=> el.scrollWidth > el.clientWidth + 1) || null;
  function attach(row){
    if(row.dataset.swipe) return; row.dataset.swipe = '1';
    let sx = 0, sy = 0, sl = 0, dir = '', el = null, lastX = 0, lastT = 0, v = 0, raf = 0, moved = false;
    row.addEventListener('touchstart', e=>{
      el = scrollerOf(row); if(!el) return;
      cancelAnimationFrame(raf);
      const t = e.touches[0]; sx = lastX = t.clientX; sy = t.clientY; sl = el.scrollLeft; dir = ''; v = 0; lastT = performance.now(); moved = false;
    }, { passive:true });
    row.addEventListener('touchmove', e=>{
      if(!el) return;
      const t = e.touches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      if(!dir){ if(Math.abs(dx) < 6 && Math.abs(dy) < 6) return; dir = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y'; }
      if(dir !== 'x') return;
      e.preventDefault();
      moved = true;
      el.scrollLeft = sl - dx;
      const now = performance.now(); v = (t.clientX - lastX) / Math.max(1, now - lastT); lastX = t.clientX; lastT = now;
    }, { passive:false });
    row.addEventListener('touchend', ()=>{
      if(!el || dir !== 'x') return;
      let vel = -v * 16;
      const step = ()=>{ if(Math.abs(vel) < .5) return; el.scrollLeft += vel; vel *= .92; raf = requestAnimationFrame(step); };
      raf = requestAnimationFrame(step);
    }, { passive:true });
    row.addEventListener('click', e=>{ if(moved){ e.preventDefault(); e.stopPropagation(); moved = false; } }, true);
  }
  const run = ()=> document.querySelectorAll('.subtab').forEach(attach);
  run();
  document.addEventListener('click', e=>{ if(e.target.closest('.tabbar__btn, .seatmode-btn')) setTimeout(run, 50); });
})();

