/**
 * okman — 읏배구놀이터 (Worker 하나에 화면 + 서버)
 *
 *   /live/*, /admin/*   → live.js   (응원·이벤트·관리자 — Durable Object)
 *   /stats              → stats.js  (KOVO 기록 — Hyperdrive → MySQL)
 *   /tap/{경기ID} (POST) · /admin/{경기ID}/taps (GET) → taps.js (화면 이용 횟수 — Durable Object TapCounter)
 *   /seat-ocr (POST)    → seat-ocr.js (티켓 사진 → 좌석 구역, Claude API · 비밀값 ANTHROPIC_API_KEY)
 *   그 밖의 주소         → public/ 폴더의 화면 파일 (index.html · admin.html · board.html · css · js · images)
 *
 * 화면과 서버가 같은 주소라서 CORS 설정(ALLOW_ORIGIN)이 필요 없어요.
 */
import live from './live.js';
import stats from './stats.js';
import { handleSeatOcr } from './seat-ocr.js';
import { handleTap } from './taps.js';
export { TapCounter } from './taps.js';
export { LiveMatch } from './live.js';

export default {
  async fetch(req, env, ctx) {
    const { pathname, searchParams } = new URL(req.url);

    if (pathname === '/stats') {
      // 점검 화면(?check=1)은 DB 내용을 그대로 보여주니 관리자만 — admin.html과 같은 총괄 관리자 아이디·비밀번호
      if (searchParams.get('check') === '1' && !isOwner(req, env)) {
        return new Response('관리자 아이디·비밀번호가 필요해요', {
          status: 401, headers: { 'WWW-Authenticate': 'Basic realm="okman", charset="UTF-8"', 'Cache-Control': 'no-store' },
        });
      }
      return stats.fetch(req, env, ctx);
    }
    // 화면 이용 횟수 — 관람객이 보내기
    let m = pathname.match(/^\/tap\/([^/]+)$/);
    if (m && req.method === 'POST') return handleTap(req, env, decodeURIComponent(m[1]));
    // 화면 이용 횟수 — 관리자 보기 (관리자 로그인은 live.js가 확인: 같은 경기의 /visits를 먼저 물어봐서 통과하면 보여줘요)
    m = pathname.match(/^\/admin\/([^/]+)\/taps$/);
    if (m && (req.method === 'GET' || req.method === 'DELETE')) {
      const probe = await live.fetch(new Request(new URL(pathname.replace(/\/taps$/, '/visits'), req.url), { headers: req.headers }), env, ctx);
      if (!probe.ok) return probe;
      if (req.method === 'DELETE') {   // 지우기는 총괄 관리자만
        const me = await live.fetch(new Request(new URL('/admin/_/me', req.url), { headers: req.headers }), env, ctx);
        const u = me.ok ? await me.json() : {};
        if (u.role !== 'owner') return new Response(JSON.stringify({ error: 'forbidden' }), { status: 403, headers: { 'content-type': 'application/json' } });
      }
      return handleTap(req, env, decodeURIComponent(m[1]));
    }
    if (pathname.startsWith('/live/') || pathname.startsWith('/admin/')) return live.fetch(req, env, ctx);
    if (pathname === '/seat-ocr' && req.method === 'POST') return handleSeatOcr(req, env);   // 티켓 촬영 → 구역 인식

    return env.ASSETS.fetch(req);
  },
};

// 브라우저 기본 로그인 창(Basic) 또는 X-Admin-Id · X-Admin-Key 헤더
function isOwner(req, env) {
  if (!env.ADMIN_ID || !env.ADMIN_KEY) return false;
  let id = req.headers.get('X-Admin-Id') || '', key = req.headers.get('X-Admin-Key') || '';
  const auth = req.headers.get('Authorization') || '';
  if (auth.startsWith('Basic ')) {
    try {
      const bin = atob(auth.slice(6));
      const s = new TextDecoder().decode(Uint8Array.from(bin, c => c.charCodeAt(0)));
      const i = s.indexOf(':'); if (i > 0) { id = s.slice(0, i); key = s.slice(i + 1); }
    } catch (e) {}
  }
  return id === env.ADMIN_ID && key === env.ADMIN_KEY;
}
