/**
 * okman-live — 직관 가이드 서버 (Cloudflare Worker + Durable Object)
 *
 * 경기(matchId)마다 Durable Object 하나가 그 경기의 모든 데이터를 맡아요.
 * 요청을 한 줄로 세워 처리해서, 동시에 수천 명이 응원을 눌러도 '몇 번째'가 정확해요.
 *
 * ── 관람객 (index.html) ───────────────────────────────────────────
 *   GET  /live/:m                      → { events, cheer:{total}, phase, mvp, start, content }
 *   GET  /live/:m/nick?name=           → { available }   경품 응모 닉네임 중복확인
 *   POST /live/:m/visit                { device }   접속 기록 (관람객 화면이 브라우저 세션마다 한 번 보내요)
 *   POST /live/:m/cheer                { device, count }        → { total, from, to, win? }   (접수 창구 8곳이 묶어서 경기 서버로)
 *   POST /live/:m/checkin              { device, gender, age, company }
 *   POST /live/:m/submit/:type         { device, data }   type: predictions·survey·mvp·raffle_entry·roulette·checkin
 * ── 관리자 (admin.html, 헤더 X-Admin-Id · X-Admin-Key) ─────────────────────────
 *   GET  /admin/_/matches              → 데이터가 쌓인 경기 목록
 *   GET  /admin/_/surveys              → { surveys, defaultId }   설문 보관함 (시즌 전체 공통)
 *   PUT  /admin/_/surveys              { surveys, defaultId }    보관함 저장 · 기본 설문 지정
 *                                      경기에 따로 지정한 설문이 없으면 보관함의 기본 설문이 나가고,
 *                                      경기마다 '나간 설문'을 버전(v1, v2 …)으로 기록해요. 같은 설문이 다시 나가면 같은 버전으로 묶여요.
 *   GET  /admin/:m                     → 이 경기의 모든 데이터 (visits: 접속자 포함)
 *   GET  /admin/:m/visits              → { visits }  접속자만 가볍게 (경기별 접속자 표)
 *   PUT  /admin/:m/events              { events }
 *   PUT  /admin/:m/prizes              { prizes }   응원 이벤트 당첨 번호
 *   PUT  /admin/:m/settings            { phase, mvp, answers, start, content }
 *                                      content: 관리자가 등록한 예측 문항·설문·출석 질문·미션 순서·오늘 운영 (관람객 화면에 그대로 내려가요)
 *                                      설문·예측 문항이 바뀌면 서버가 버전을 하나 올려요(content.surveyVer / predictVer = { v, at }).
 *                                      관람객 응답에는 그때 본 버전(ver)이 같이 저장돼서, 관리자 화면에서 버전별로 따로 볼 수 있어요.
 *                                      버전마다 그때의 문항은 history 키에 남겨요 (관리자 화면에만 내려가요).
 *   PUT  /admin/:m/raffle              { winners }  경품 응모 추첨 결과 (닉네임 기준)
 *   POST /admin/:m/raffle-clear        응모 기록(닉네임) 삭제 (추첨 후)
 *   PUT  /admin/:m/redeem              { code, redeemed }  교환 코드 사용 처리
 *   POST /admin/:m/reset-cheer         응원 수·당첨 초기화 (리허설용)
 *   POST /admin/:m/reset               { parts:[…] }  이 경기 데이터 초기화 (관리자 › 설정)
 *   GET  /admin/:m?since=ms            응답(subs)은 since 이후 바뀐 것만 (관리자 5초 새로고침용) — 지운 적이 있으면 전체
 *   GET  /admin/:m/audit · /admin/_/audit   누가 언제 무엇을 했는지 (작업 기록)
 *   PUT  /admin/:m/raffle-hide         { device, hidden }  부적절한 닉네임을 추첨에서 빼기
 *   GET|PUT /admin/_/users             관리자 계정 (총괄 관리자만) · 권한: owner 총괄 · manager 일반 · staff 부스
 *   POST /admin/_/password             { current, next } 내 비밀번호 바꾸기
 *   GET  /admin/_/me                   로그인한 사람 { id, name, role }
 *   GET  /admin/_/locks · POST /admin/_/unlock { key }   잠긴 로그인 보기·풀기 (총괄)
 *   GET|PUT /admin/_/privacy           데이터 수집 안내 문구 (시즌 공통 · 관람객 화면 '데이터 안내')
 *   POST /live/:m/error                { device, msg, src, line, view, ua }  관람객 화면 오류 (관리자 대시보드에 모아 보여요)
 *   GET|PUT /admin/_/home              룰렛 경품(확률·수량) · 홈 배너 (시즌 공통)
 *   GET|PUT /admin/_/nickban           닉네임 금칙어 추가 목록 (시즌 공통)
 *   POST /live/:m/spin                 { device, bonus }  룰렛 — 서버가 확률·남은 수량으로 뽑고 교환 코드를 만들어요
 *   GET  /live/:m/board                전광판 화면용 (응원 수 · MVP · 발표한 당첨 닉네임)
 *   GET  /live/_/subway?scode=316      막차안내 — { lines:{ 0:[분…](수영 방면), 1:[분…](대저 방면) } }
 *                                      관리자가 붙여넣은 시간표(설정 › 막차 시간표)가 있으면 그걸, 없으면 부산교통공사 API를 (30분 동안 기억)
 *   GET|PUT /admin/_/subway            붙여넣은 시간표 { tt:{ wk|sa|su:{ 0:[분…], 1:[분…] } }, holidays:[YYYY-MM-DD…] } (시즌 공통)
 *                                      환경변수 SUBWAY_KEY(공공데이터포털 인증키), SUBWAY_URL(바꿀 때만). ?debug=1 이면 받은 원본 일부도 보여줘요
 *        parts: visits · cheer · checkin · predict · mvp · survey · raffle · roulette · config
 *        초기화하면 epoch가 바뀌고, 관람객 화면은 그걸 보고 휴대폰에 남은 이 경기 진행 기록(미션·답)도 지워요.
 *        설문 보관함(시즌 공통)은 지우지 않아요.
 */
// 서버 버전 — 관리자 화면이 이 값을 보고 '서버를 다시 배포해 주세요' 안내를 띄워요. 기능을 바꾸면 날짜·번호를 올려주세요.
const SERVER_VERSION = '2026-10-16.cheer';
// 응원 접수 창구 — 응원은 8개 창구가 먼저 받아 0.15초씩 모았다가 경기 서버에 한 묶음으로 넘겨요.
//  경기 서버(한 줄로 처리)에 닿는 응원 요청이 초당 수백 건 → 수십 건으로 줄어서 다른 요청(출석·설문 등)도 안 밀려요.
//  묶음 안에서는 들어온 순서대로 번호를 매기니 'n번째 당첨'은 그대로 정확해요.
const CHEER_SHARDS = 8, CHEER_BATCH_MS = 150;
// 로그인 잠금 — 같은 아이디로 5번 틀리면 10분, 같은 접속 주소(IP)에서 20번 틀리면 10분
const LOCK = { idFails: 5, ipFails: 20, ms: 10 * 60 * 1000 };
const SUB_TYPES = ['predictions', 'survey', 'mvp', 'raffle_entry', 'roulette', 'checkin', 'survey_progress'];
// 권한 3단계 — owner(총괄 관리자) · manager(일반 관리자) · staff(부스 담당)
//  · 부스 담당: 조회 + 교환 처리 + 내 비밀번호만
//  · 일반 관리자: 경기 운영 전부 (아래 OWNER_ONLY 빼고)
//  · 총괄 관리자: 전부 — 계정 관리 · 데이터 초기화 · 응모 삭제 · 룰렛·배너(시즌 경품·확률)
const ROLES = ['owner', 'manager', 'staff'];
const STAFF_WRITES = new Set(['redeem', 'password']);
const OWNER_ONLY = new Set(['users', 'reset', 'purge', 'reset-cheer', 'raffle-clear', 'home', 'unlock', 'privacy']);
// 룰렛 기본값 — 관리자 › 룰렛·배너에서 시즌 설정을 저장하기 전까지 써요 (index.html CONFIG.ROULETTE와 같아요)
const DEFAULT_ROULETTE = {
  base: 1, bonus: 1, onePerPerson: true,   // onePerPerson: 한 번 당첨되면 더 돌릴 수 없어요 (1인 1회 당첨)
  prizes: [
    { id:'soju', img:'soju', title:'읏맨 변온 소주잔', desc:'(경품 수령처에서 교환)', weight:14, stock:0 },
    { id:'doll', img:'doll', title:'25cm 읏맨 봉제인형', desc:'(경품 수령처에서 교환)', weight:6, stock:0 },
    { id:'miss1', img:'miss', miss:true, weight:20 },
    { id:'fan', img:'fan', title:'돈바람 부채', desc:'(경품 수령처에서 교환)', weight:14, stock:0 },
    { id:'ticket', img:'ticket', title:'일반석 티켓 교환권\n(1인 2매)', desc:'(다음 홈경기 사용 가능)', weight:10, stock:0 },
    { id:'photo', img:'photo', title:'지정 선수 사진 촬영권\n(1인 1회)', desc:'(평일 홈경기 한정, 직접 방문 수령)', weight:4, stock:0 },
    { id:'miss2', img:'miss', miss:true, weight:20 },
    { id:'signball', img:'signball', title:'선수 사인 배구공', desc:'(경품 수령처에서 교환)', weight:2, stock:0 },
  ],
};
// 닉네임 금칙어 — 전광판에 나가니까 기본으로 막아요. 관리자 › 설정에서 더 넣을 수 있어요.
const NICK_BAN = ['씨발','시발','씨빨','씌발','쓰발','썅','병신','븅신','빙신','좆','존나','졸라','개새','새끼','섀끼','지랄','미친','염병','엠창','니미','느금','애미','애비',
  '꺼져','닥쳐','섹스','보지','자지','창녀','걸레','등신','또라이','찐따','한남','김치녀','일베','홍어','운영자','관리자','fuck','shit','bitch','sex','tlqkf','qudtls','admin'];
const RESET_PARTS = ['visits', 'cheer', 'checkin', 'predict', 'mvp', 'survey', 'raffle', 'roulette', 'config'];
const REGISTRY = '__registry';

// 관람객 화면의 '이벤트 확인'(GET /live/:m) 응답을 3초 동안 재사용해요.
// 4,000명이 20~30초마다 확인해도 경기 서버(Durable Object)에는 3초에 한 번 정도만 닿아요.
const PUBLIC_CACHE_MS = 3000;
const publicCache = new Map();   // matchId → { at, body }

const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', ...headers } });

/* ---------- 관리자 로그인 ----------
   총괄 관리자 = Cloudflare 환경변수 ADMIN_ID · ADMIN_KEY (지금처럼).
   그 밖의 계정은 관리자 › 설정 › 계정에서 만들고, 레지스트리에 비밀번호 해시(PBKDF2)로 저장해요. */
const authCache = new Map();   // id+key → { at, user }  (같은 Worker 안에서 1분)
// 돌려주는 값: user · { locked:until } · null
async function authAdmin(env, id, key, ip) {
  if (!id || !key) return null;
  const ck = id + '\u0000' + key, hit = authCache.get(ck);
  if (hit && Date.now() - hit.at < 60000) return hit.user;          // 1분 안에 성공한 같은 로그인은 바로 통과
  const envOk = !!(env.ADMIN_ID && env.ADMIN_KEY && id === env.ADMIN_ID && key === env.ADMIN_KEY);
  let res = null;
  try {
    const r = await env.LIVE.get(env.LIVE.idFromName(REGISTRY)).fetch('https://do/reg/auth', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, key, envOk, ip }) });
    res = await r.json();
  } catch (e) {
    res = envOk ? { user: { id, name: '총괄 관리자', role: 'owner' } } : null;   // 레지스트리가 바쁘면 총괄 계정만 통과
  }
  if (res && res.locked) return { locked: res.locked };
  const user = (res && res.user) || null;
  if (user) authCache.set(ck, { at: Date.now(), user }); else authCache.delete(ck);
  return user;
}
async function hashPw(pw, salt) {
  const enc = new TextEncoder();
  const k = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 100000, hash: 'SHA-256' }, k, 256);
  return [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ---------- 막차안내 — 부산교통공사 '열차시각표 조회' ----------
   요청: serviceKey · act(json) · scode(역 외부코드) · day(1 평일 · 2 토 · 3 일·공휴일) · updown(0 상행 · 1 하행) · stime · etime · enum
   응답 모양을 미리 알 수 없어서, 항목마다 '시각처럼 보이는 값'을 찾아 읽어요 (hour+time 따로 · 1305 · 13:05 · 25:10 등).
   공휴일은 따로 알 수 없어서 평일·토·일만 구분해요 — 공휴일 경기면 SUBWAY_DAY=3 환경변수로 덮어쓸 수 있어요. */
const subwayCache = new Map();
const SUBWAY_URL = 'http://data.humetro.busan.kr/voc/api/open_api_process.tnn';
function hhmmToMin(v) {
  const s = String(v ?? '').trim();
  let m = s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/); if (m) return +m[1] * 60 + +m[2];
  m = s.match(/^(\d{3,4})$/); if (m) { const n = +m[1]; return Math.floor(n / 100) * 60 + n % 100; }
  m = s.match(/^(\d{2})(\d{2})\d{2}$/); if (m) return +m[1] * 60 + +m[2];
  return null;
}
function recordsOf(text) {
  try {   // JSON — 객체 배열을 다 모아요
    const out = [], walk = x => { if (Array.isArray(x)) x.forEach(walk); else if (x && typeof x === 'object') { if (Object.values(x).every(v => typeof v !== 'object' || v === null)) out.push(x); else Object.values(x).forEach(walk); } };
    walk(JSON.parse(text)); if (out.length) return out;
  } catch (e) {}
  // XML — <item>…</item> 안의 태그를 키로
  return [...String(text).matchAll(/<item>([\s\S]*?)<\/item>/gi)].map(([, body]) => Object.fromEntries([...body.matchAll(/<(\w+)>([^<]*)<\/\1>/g)].map(([, k, v]) => [k.toLowerCase(), v.trim()])));
}
function timeOf(rec) {
  const r = Object.fromEntries(Object.entries(rec).map(([k, v]) => [String(k).toLowerCase(), v]));
  const h = r.hour ?? r.hh ?? r.arrhour ?? r.dephour, mi = r.time ?? r.min ?? r.minute ?? r.mm;
  if (h != null && mi != null && /^\d{1,2}$/.test(String(h).trim()) && /^\d{1,2}$/.test(String(mi).trim())) return +h * 60 + +mi;
  for (const k of ['arrtime', 'arrivetime', 'deptime', 'depttime', 'stime', 'traintime', 'time', 'hhmm', 'arrivaltime', 'departuretime']) {
    if (r[k] != null) { const v = hhmmToMin(r[k]); if (v != null) return v; }
  }
  return null;
}
let pastedCache = null;   // { at, val } — 관리자가 붙여넣은 시간표 (10분 동안 기억)
async function subwayTimes(env, url, cors) {
  const scode = (url.searchParams.get('scode') || '316').replace(/\D/g, '').slice(0, 4);
  // 새벽 4시 전은 전날 운행으로 봐요
  const kst = new Date(Date.now() + 9 * 3600e3 - 4 * 3600e3), dow = kst.getUTCDay(), ymd = kst.toISOString().slice(0, 10);
  // ① 관리자가 붙여넣은 시간표
  if (!pastedCache || Date.now() - pastedCache.at > 10 * 60e3) {
    try { const r = await env.LIVE.get(env.LIVE.idFromName(REGISTRY)).fetch('https://do/reg/subway'); pastedCache = { at: Date.now(), val: (await r.json()).subway || null }; }
    catch (e) { pastedCache = pastedCache || { at: Date.now(), val: null }; }
  }
  const P = pastedCache.val;
  if (P && P.tt) {
    const holiday = (P.holidays || []).includes(ymd);
    const key = holiday || dow === 0 ? 'su' : dow === 6 ? 'sa' : 'wk';
    const lines = P.tt[key] || {};
    if ((lines[0] || []).length || (lines[1] || []).length)
      return json({ scode, day: key, holiday, source: 'pasted', lines: { 0: lines[0] || [], 1: lines[1] || [] }, updatedAt: P.updatedAt, at: Date.now() }, 200, { ...cors, 'Cache-Control': 'public, max-age=600' });
  }
  // ② 부산교통공사 API (인증키가 있을 때)
  if (!env.SUBWAY_KEY) return json({ error: 'not_configured' }, 200, { ...cors, 'Cache-Control': 'public, max-age=300' });
  const day = env.SUBWAY_DAY || (dow === 0 ? 3 : dow === 6 ? 2 : 1);
  const debug = url.searchParams.get('debug') === '1';
  const ck = `${scode}:${day}:${kst.toISOString().slice(0, 10)}`;
  const hit = subwayCache.get(ck);
  if (!debug && hit && Date.now() - hit.at < 30 * 60e3) return json(hit.body, 200, { ...cors, 'Cache-Control': 'public, max-age=600' });
  const key = /%/.test(env.SUBWAY_KEY) ? env.SUBWAY_KEY : encodeURIComponent(env.SUBWAY_KEY);
  const lines = {}, raw = {};
  for (const updown of [0, 1]) {
    try {
      const q = `serviceKey=${key}&act=json&scode=${scode}&day=${day}&updown=${updown}&stime=0400&etime=2700&enum=400`;
      const r = await fetch(`${env.SUBWAY_URL || SUBWAY_URL}?${q}`, { cf: { cacheTtl: 1800 } });
      const text = await r.text();
      const recs = recordsOf(text);
      const mins = [...new Set(recs.map(timeOf).filter(v => v != null).map(v => v < 240 ? v + 1440 : v))].sort((a, b) => a - b);   // 새벽 0~4시는 전날 운행의 연장(24:xx)
      lines[updown] = mins;
      if (debug) raw[updown] = { status: r.status, records: recs.length, sample: recs.slice(0, 3), head: text.slice(0, 600) };
    } catch (e) { lines[updown] = []; if (debug) raw[updown] = { error: String(e.message || e) }; }
  }
  const body = { scode, day, source: 'busan-timetable', lines, at: Date.now(), ...(debug ? { raw } : {}) };
  if (!debug && (lines[0].length || lines[1].length)) subwayCache.set(ck, { at: Date.now(), body });
  return json(body, 200, { ...cors, 'Cache-Control': debug ? 'no-store' : 'public, max-age=600' });
}

/* ===== 홈 배너 이미지 ===== */
const bannerCache = new Map();
async function bannerImage(env, k, cors) {
  if (!['goods', 'app', 'app-dark'].includes(k)) return json({ error: 'not_found' }, 404, cors);
  let hit = bannerCache.get(k);
  if (!hit || Date.now() - hit.at > 60000) {
    const r = await env.LIVE.get(env.LIVE.idFromName(REGISTRY)).fetch('https://do/reg/banner/' + k);
    hit = { at: Date.now(), image: ((await r.json()) || {}).image || '' };
    bannerCache.set(k, hit);
  }
  const m = /^data:(image\/(?:webp|png|jpeg));base64,(.+)$/.exec(hit.image);
  if (!m) return new Response(null, { status: 404, headers: cors });
  const bin = atob(m[2]); const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Response(bytes, { headers: { ...cors, 'Content-Type': m[1], 'Cache-Control': 'public, max-age=31536000, immutable' } });
}
const bannerUrl = (k, v) => v ? `/live/_/banner/${k}?v=${v}` : '';
function withBannerUrls(h) {
  if (!h) return h;
  const out = { ...h };
  for (const k of ['goods', 'app']) if (out[k]) { const { imageV, imageDarkV, ...rest } = out[k]; out[k] = { ...rest, image: bannerUrl(k, imageV), ...(k === 'app' ? { imageDark: bannerUrl('app-dark', imageDarkV) } : {}) }; }
  return out;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const allowed = String(env.ALLOW_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
    const origin = req.headers.get('Origin') || '';
    const cors = {
      'Access-Control-Allow-Origin': allowed.includes(origin) ? origin : (allowed[0] || '*'),
      'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Key, X-Admin-Id',
      'Access-Control-Expose-Headers': 'X-Server-Version',
      'Vary': 'Origin',
    };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });

    const m = url.pathname.match(/^\/(live|admin)\/([\w-]{1,64})(?:\/([\w-]+))?(?:\/([\w-]+))?\/?$/);
    if (!m) return json({ error: 'not_found' }, 404, cors);
    let [, scope, matchId, action = '', sub = ''] = m;

    let user = null;
    if (scope === 'admin') {
      const id = req.headers.get('X-Admin-Id') || '';
      const key = req.headers.get('X-Admin-Key') || '';
      user = await authAdmin(env, id, key, req.headers.get('CF-Connecting-IP') || '');
      if (user && user.locked) return json({ error: 'locked', until: user.locked }, 429, cors);
      if (!user) return json({ error: 'unauthorized' }, 401, cors);
      if (req.method !== 'GET') {
        if (user.role === 'staff' && !STAFF_WRITES.has(action)) return json({ error: 'forbidden' }, 403, cors);
        if (user.role !== 'owner' && OWNER_ONLY.has(action)) return json({ error: 'forbidden' }, 403, cors);
      }
      if (matchId === '_') {
        if (action === 'me') return json({ ...user, serverVersion: SERVER_VERSION }, 200, cors);
        if (action === 'matches') { matchId = REGISTRY; action = 'list'; }
        else if (['surveys', 'users', 'password', 'home', 'nickban', 'audit', 'locks', 'unlock', 'privacy', 'subway'].includes(action)) {
          if ((action === 'users' || action === 'locks') && user.role !== 'owner') return json({ error: 'forbidden' }, 403, cors);
          matchId = REGISTRY;
        }
        else return json({ error: 'not_found' }, 404, cors);
      }
    }
    if (matchId === REGISTRY && scope !== 'admin') return json({ error: 'not_found' }, 404, cors);

    if (scope === 'live' && matchId === '_' && action === 'subway' && req.method === 'GET') return subwayTimes(env, url, cors);
    if (scope === 'live' && matchId === '_' && action === 'banner' && req.method === 'GET') return bannerImage(env, sub, cors);
    const isPublicGet = scope === 'live' && req.method === 'GET' && (!action || action === 'board');
    const cacheKey = action + ':' + matchId;
    if (isPublicGet) {
      const hit = publicCache.get(cacheKey);
      if (hit && Date.now() - hit.at < PUBLIC_CACHE_MS) return json(hit.body, 200, { ...cors, 'Cache-Control': 'no-store' });
    }

    let res;
    try {
      const bodyText = ['POST', 'PUT'].includes(req.method) ? await req.text() : undefined;
      let objName = matchId, path = `https://do/${scope}/${action}/${sub}${url.search}`;
      if (scope === 'live' && action === 'cheer' && req.method === 'POST') {
        // 기기마다 정해진 창구로 (같은 사람은 늘 같은 창구 → 순서가 섞이지 않아요)
        let dev = ''; try { dev = String(JSON.parse(bodyText || '{}').device || ''); } catch (e) {}
        let h = 0; for (let i = 0; i < dev.length; i++) h = (h * 31 + dev.charCodeAt(i)) >>> 0;
        objName = `${matchId}~cheer~${h % CHEER_SHARDS}`; path = 'https://do/shard/cheer/';
      }
      const stub = env.LIVE.get(env.LIVE.idFromName(objName));
      res = await stub.fetch(path, {
        method: req.method,
        headers: { 'Content-Type': 'application/json', 'X-Match': matchId, ...(user ? { 'X-Admin-User': encodeURIComponent(JSON.stringify(user)) } : {}) },
        body: bodyText,
      });
    } catch (e) {
      // 경기 서버에 닿지 못했을 때 — 관람객 화면은 잠시 뒤 다시 보내요.
      // 진짜 이유(사용량 한도 초과·과부하·배포 직후 재시작 등)를 같이 돌려주고 로그에도 남겨요 → Cloudflare › okman-live › Logs
      const reason = String((e && e.message) || e).slice(0, 300);
      console.error('DO fetch failed', matchId, action, reason);
      return json({ error: 'busy', reason }, 503, { ...cors, 'Retry-After': '1' });
    }
    if (isPublicGet && res.ok) {
      const body = await res.json();
      publicCache.set(cacheKey, { at: Date.now(), body });
      return json(body, 200, { ...cors, 'Cache-Control': 'no-store' });
    }
    const out = new Response(res.body, res);
    Object.entries(cors).forEach(([k, v]) => out.headers.set(k, v));
    out.headers.set('Cache-Control', 'no-store');
    return out;
  },
};

/* ================================================================
   경기 하나 = Durable Object 하나
   키: events · prizes · total · winners · settings · raffleWinners · redeemed · registered
       sub:{type}:{device}[:{source}] → { data, at }
   ================================================================ */
export class LiveMatch {
  constructor(state, env) {
    this.state = state; this.env = env; this.store = state.storage;
    this.lastTap = new Map();
  }

  async fetch(req) {
    const url = new URL(req.url);
    const [, scope, action, sub] = url.pathname.split('/');
    this.matchId = req.headers.get('X-Match') || '';
    try { this.user = JSON.parse(decodeURIComponent(req.headers.get('X-Admin-User') || '')) || null; } catch (e) { this.user = null; }
    const body = ['POST', 'PUT'].includes(req.method) ? await req.json().catch(() => ({})) : {};
    try {
      if (scope === 'shard') {
        try { return json(await this.shardCheer(body)); }
        catch (e) { const m = String(e.message || e); return json({ error: m === 'device_required' ? m : 'busy' }, m === 'device_required' ? 400 : 503); }
      }
      if (scope === 'reg') {
        if (action === 'survey-default') return json({ survey: await this.libraryDefault() });
        if (action === 'season') return json(await this.seasonGet());
        if (action === 'subway') return json({ subway: (await this.store.get('subway')) || null });
        if (action === 'banner') return json({ image: (await this.store.get('banner:' + sub)) || '' });
        if (action === 'auth') return json(await this.authCheck(body));   // { user } · { locked } · { user:null }
        if (action === 'remove') return json(await this.regRemove(body));
        if (action === 'predict-default') { await this.store.put('predictDefault', { items: body.items, at: Date.now() }); return json({ ok: true }); }
        return json(await this.regAdd(body));
      }
      if (scope === 'live') {
        if (req.method === 'GET' && !action) return json(await this.publicState());
        if (req.method === 'GET' && action === 'nick') return json(await this.nickCheck(url.searchParams.get('name')));
        if (req.method === 'GET' && action === 'board') return json(await this.boardState());
        if (req.method === 'POST' && action === 'spin') return json(await this.spin(body));
        if (req.method === 'POST' && action === 'error') return json(await this.clientError(body));
        if (req.method === 'POST' && action === 'cheer') return json(await this.cheer(body));
        if (req.method === 'POST' && action === 'cheer-batch') return json(await this.cheerBatch(body));
        if (req.method === 'POST' && action === 'visit') return json(await this.visit(body));
        if (req.method === 'POST' && action === 'checkin') return json(await this.submit('checkin', { device: body.device, data: body }));
        if (req.method === 'POST' && action === 'submit') return json(await this.submit(sub, body));
      }
      if (scope === 'admin') {
        if (action === 'list') return json({ matches: (await this.store.get('matches')) || {} });
        if (req.method === 'GET' && action === 'surveys') return json(await this.libraryGet());
        if (req.method === 'GET' && action === 'users') return json(await this.usersGet());
        if (req.method === 'GET' && action === 'home') return json({ home: withBannerUrls((await this.store.get('home')) || null), defaults: { roulette: DEFAULT_ROULETTE } });
        if (req.method === 'GET' && action === 'nickban') return json({ words: (await this.store.get('nickBan')) || [], builtin: NICK_BAN });
        if (req.method === 'GET' && action === 'audit') return json({ audit: (await this.store.get('audit')) || [] });
        if (req.method === 'GET' && action === 'locks') return json({ locks: await this.locksGet() });
        if (req.method === 'GET' && action === 'privacy') return json({ privacy: (await this.store.get('privacy')) || null });
        if (req.method === 'GET' && action === 'subway') return json({ subway: (await this.store.get('subway')) || null });
        if (req.method === 'GET' && action === 'errors') return json({ errors: (await this.store.get('errors')) || [] });
        if (req.method === 'GET' && !action) return json(await this.adminState(Number(url.searchParams.get('since')) || 0));
        if (req.method === 'GET' && action === 'visits') return json({ visits: (await this.store.get('visits')) || emptyVisits() });
        if (req.method === 'PUT' || req.method === 'POST') {
          const res = await this.adminWrite(req.method, action, body);
          if (res !== undefined) { await this.audit(action, body, res); return json(res); }
        }
      }
      return json({ error: 'not_found' }, 404);
    } catch (e) {
      return json({ error: String(e.message || e) }, 400);
    }
  }

  /* ---------- 관리자 쓰기 — 성공하면 작업 기록을 남겨요 ---------- */
  async adminWrite(method, action, body) {
    if (method === 'PUT' && action === 'surveys') return await this.librarySet(body);
    if (method === 'PUT' && action === 'users') return await this.usersSet(body);
    if (method === 'POST' && action === 'password') return await this.passwordSet(body);
    if (method === 'PUT' && action === 'home') return await this.homeSet(body);
    if (method === 'POST' && action === 'unlock') return await this.unlock(body);
    if (method === 'PUT' && action === 'privacy') return await this.privacySet(body);
    if (method === 'PUT' && action === 'subway') return await this.subwaySet(body);
    if (method === 'POST' && action === 'errors-clear') { await this.store.delete('errors'); return { ok: true }; }
    if (method === 'PUT' && action === 'nickban') return await this.nickBanSet(body);
    if (method === 'PUT' && action === 'raffle-hide') return await this.raffleHide(body);
    if (method === 'PUT' && action === 'events') return await this.setEvents(body);
    if (method === 'PUT' && action === 'prizes') return await this.setPrizes(body);
    if (method === 'PUT' && action === 'settings') return await this.setSettings(body);
    if (method === 'PUT' && action === 'raffle') return await this.put('raffleWinners', cleanWinners(body.winners));
    if (method === 'POST' && action === 'raffle-clear') return await this.raffleClear();
    if (method === 'PUT' && action === 'redeem') return await this.redeem(body);
    if (method === 'POST' && action === 'reset-cheer') return await this.resetCheer();
    if (method === 'POST' && action === 'reset') return await this.reset(body);
    if (method === 'POST' && action === 'purge') return await this.purge();
    return undefined;
  }

  /* ---------- 경기 목록(레지스트리) ---------- */
  async touch() {
    if (this.registered || !this.matchId || this.matchId === REGISTRY) return;
    if (await this.store.get('registered')) { this.registered = true; return; }
    await this.env.LIVE.get(this.env.LIVE.idFromName(REGISTRY))
      .fetch('https://do/reg', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ matchId: this.matchId }) });
    await this.store.put('registered', true); this.registered = true;
  }
  async regRemove({ matchId }) {
    const all = (await this.store.get('matches')) || {};
    if (matchId && all[matchId]) { delete all[matchId]; await this.store.put('matches', all); }
    return { ok: true };
  }
  /* ---------- 경기 통째로 지우기 — 데이터 · 설정 모두 지우고 경기 목록에서도 빼요 ---------- */
  async purge() {
    await this.store.deleteAll();
    const epoch = Date.now();
    await this.store.put('epoch', epoch);        // 관람객 휴대폰에 남은 이 경기 기록도 지우게
    await this.store.put('subsResetAt', epoch);
    this.registered = false; this._svCache = null; this._predictChecked = false;
    await this.env.LIVE.get(this.env.LIVE.idFromName(REGISTRY))
      .fetch('https://do/reg/remove', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ matchId: this.matchId }) });
    return { ok: true, epoch };
  }
  async regAdd({ matchId }) {
    const all = (await this.store.get('matches')) || {};
    if (matchId && !all[matchId]) { all[matchId] = Date.now(); await this.store.put('matches', all); }
    return { ok: true };
  }

  /* ---------- 예측 문항 이어받기 ---------- */
  // 새 경기에 예측 문항이 없으면, 마지막으로 등록한 예측 문항(시즌 공통)을 이 경기 문항(v1)으로 옮겨 와요
  async ensurePredict() {
    if (this._predictChecked === true || !this.matchId || this.matchId === REGISTRY) return;
    // 이어받을 문항이 아직 없을 때는 20초 뒤에 다시 확인해요 (관리자가 다른 경기에서 막 등록한 경우)
    if (typeof this._predictChecked === 'number' && Date.now() - this._predictChecked < 20000) return;
    const settings = (await this.store.get('settings')) || {};
    if (settings.content && Array.isArray(settings.content.predict) && settings.content.predict.length) { this._predictChecked = true; return; }
    if (settings.predictCleared) { this._predictChecked = true; return; }
    const def = ((await this.seasonCached(true)) || {}).predictDefault;
    if (!def || !Array.isArray(def.items) || !def.items.length) { this._predictChecked = Date.now(); return; }
    this._predictChecked = true;
    const at = Date.now();
    const content = { ...(settings.content || {}), predict: def.items, predictVer: { v: 1, at } };
    const hist = (await this.store.get('history')) || { survey: [], predict: [] };
    if (!(hist.predict || []).length) { hist.predict = [{ v: 1, at, items: def.items }]; await this.store.put('history', hist); }
    await this.store.put('settings', { ...settings, content });
  }

  /* ---------- 관람객 ---------- */
  async publicState() {
    await this.ensurePredict();
    const [events = [], total = 0, settings = {}] = await Promise.all(['events', 'total', 'settings'].map(k => this.store.get(k)));
    return { events: events.filter(e => e.active !== false), cheer: { total }, phase: settings.phase || 'auto', mvp: settings.mvp || null, start: settings.start || '',
             content: await this.publicContent(settings), epoch: (await this.store.get('epoch')) || 0,
             opponent: settings.opponent || '', home: await this.publicHome(), privacy: ((await this.seasonCached()) || {}).privacy || null };
  }
  // 관람객 화면용 룰렛·배너 — 남은 수량·확률은 빼고 보내요(서버가 뽑아요)
  async publicHome() {
    const h = ((await this.seasonCached()) || {}).home;
    if (!h) return null;
    const R = h.roulette || {};
    return { roulette: { base: R.base, bonus: R.bonus, onePerPerson: R.onePerPerson !== false, notices: R.notices || [],
               prizes: (R.prizes || []).map(({ stock, weight, ...p }) => p) },
             goods: withBannerUrls(h).goods || null, app: withBannerUrls(h).app || null, updatedAt: h.updatedAt || 0 };
  }

  /* ---------- 지금 나가는 설문 ----------
     이 경기에 따로 지정한 설문(content.survey) → 없으면 보관함 기본 설문.
     나간 설문은 경기 history에 버전으로 남겨요. 내용이 같은 설문이 다시 나가면 예전 버전 번호를 그대로 써요. */
  async liveSurvey(settings, fresh) {
    settings = settings || (await this.store.get('settings')) || {};
    const c = settings.content || {};
    let items, title = '', lib = '', source;
    if (Array.isArray(c.survey) && c.survey.length) { items = c.survey; title = c.surveyTitle || ''; lib = c.surveyLib || ''; source = 'match'; }
    else {
      const d = await this.libDefaultCached(fresh);
      if (!d || !d.items || !d.items.length) return null;
      items = d.items; title = d.title || ''; lib = d.id || ''; source = 'library';
    }
    const key = JSON.stringify(items);
    if (this._svCache && this._svCache.key === key) return { ...this._svCache.val, title: title || this._svCache.val.title, lib, source };
    const hist = (await this.store.get('history')) || { survey: [], predict: [] };
    const list = hist.survey || [];
    let h = list.find(x => JSON.stringify(x.items) === key);
    if (!h) {
      h = { v: list.reduce((m, x) => Math.max(m, x.v), 0) + 1, at: Date.now(), items, title, lib };
      hist.survey = [...list, h].slice(-30);
      await this.store.put('history', hist);
    }
    const val = { v: h.v, at: h.at, items: h.items, title: title || h.title || '' };
    this._svCache = { key, val };
    return { ...val, lib, source };
  }
  async publicContent(settings) {
    const c = { ...(settings.content || {}) };
    delete c.survey; delete c.surveyVer; delete c.surveyTitle; delete c.surveyLib;
    const sv = await this.liveSurvey(settings);
    if (sv) { c.survey = sv.items; c.surveyVer = { v: sv.v, at: sv.at }; c.surveyTitle = sv.title; }
    return Object.keys(c).length ? c : null;
  }
  // 보관함 기본 설문 — 관람객 요청마다 묻지 않게 30초 동안 기억해요
  // 시즌 설정(기본 설문 · 룰렛·배너 · 금칙어) — 관리자 화면은 바로(fresh), 관람객 요청은 30초 동안 기억해요
  async seasonCached(fresh) {
    if (!fresh && this._season && Date.now() - this._season.at < 30000) return this._season.val;
    let val = null;
    try {
      const r = await this.env.LIVE.get(this.env.LIVE.idFromName(REGISTRY)).fetch('https://do/reg/season');
      val = await r.json();
    } catch (e) { val = this._season ? this._season.val : null; }
    this._season = { at: Date.now(), val: val || {} };
    return this._season.val;
  }
  async libDefaultCached(fresh) { return ((await this.seasonCached(fresh)) || {}).survey || null; }
  async rouletteCfg(fresh) { const h = ((await this.seasonCached(fresh)) || {}).home; return (h && h.roulette && h.roulette.prizes && h.roulette.prizes.length === 8) ? h.roulette : DEFAULT_ROULETTE; }

  /* ---------- 계정 (레지스트리) ---------- */
  async authCheck({ id, key, envOk, ip }) {
    const now = Date.now();
    const fails = (await this.store.get('authFails')) || {};
    const kId = 'id:' + String(id).slice(0, 40), kIp = ip ? 'ip:' + String(ip).slice(0, 60) : '';
    for (const k of [kId, kIp]) if (k && fails[k] && fails[k].until > now) return { locked: fails[k].until };
    let user = null;
    if (envOk) user = { id, name: '총괄 관리자', role: 'owner' };
    else {
      const u = ((await this.store.get('users')) || []).find(x => x.id === id);
      if (u && key && (await hashPw(String(key), u.salt)) === u.hash) user = { id: u.id, name: u.name, role: u.role };
    }
    if (user) {                                   // 성공하면 그 아이디의 실패 기록을 지워요
      if (fails[kId]) { delete fails[kId]; await this.store.put('authFails', fails); }
      return { user };
    }
    // 실패 — 10분 안의 실패만 세요
    const bump = (k, limit) => {
      if (!k) return false;
      const f = fails[k] && now - fails[k].first < LOCK.ms ? fails[k] : { n: 0, first: now };
      f.n += 1; f.last = now;
      if (f.n >= limit) { f.until = now + LOCK.ms; fails[k] = f; return true; }
      fails[k] = f; return false;
    };
    const lockedId = bump(kId, LOCK.idFails), lockedIp = bump(kIp, LOCK.ipFails);
    for (const k of Object.keys(fails)) if (now - (fails[k].last || 0) > 24 * 3600e3) delete fails[k];   // 하루 지난 기록은 정리
    await this.store.put('authFails', fails);
    if (lockedId || lockedIp) {
      const list = (await this.store.get('audit')) || [];
      list.push({ at: now, who: { id: String(id), name: String(id) }, action: 'login-lock', detail: `로그인 ${lockedId ? LOCK.idFails : LOCK.ipFails}번 실패 — ${lockedId ? '아이디' : '접속 주소'} 10분 잠금` });
      await this.store.put('audit', list.slice(-400));
      return { locked: fails[lockedId ? kId : kIp].until };
    }
    return { user: null };
  }
  async locksGet() {
    const now = Date.now(), fails = (await this.store.get('authFails')) || {};
    return Object.entries(fails).filter(([, f]) => f.until > now).map(([k, f]) => ({ key: k, n: f.n, until: f.until }));
  }
  async unlock({ key }) {
    const fails = (await this.store.get('authFails')) || {};
    delete fails[String(key)];
    await this.store.put('authFails', fails);
    return { ok: true };
  }
  /* 막차 시간표 — 관리자가 부산교통공사 홈페이지 표를 붙여넣어 만든 것 (평일 wk · 토 sa · 일/공휴일 su × 0 수영 방면 · 1 대저 방면) */
  async subwaySet(body) {
    const b = body.subway || {};
    const clean = a => [...new Set((Array.isArray(a) ? a : []).map(Number).filter(n => Number.isInteger(n) && n >= 240 && n <= 1740))].sort((x, y) => x - y).slice(0, 400);
    const tt = {};
    for (const d of ['wk', 'sa', 'su']) tt[d] = { 0: clean(b.tt && b.tt[d] && b.tt[d][0]), 1: clean(b.tt && b.tt[d] && b.tt[d][1]) };
    const holidays = (Array.isArray(b.holidays) ? b.holidays : []).map(x => String(x).trim()).filter(x => /^\d{4}-\d{2}-\d{2}$/.test(x)).slice(0, 60);
    const subway = { tt, holidays, updatedAt: Date.now() };
    await this.store.put('subway', subway);
    return { ok: true, subway };
  }
  /* 데이터 수집 안내 — 관람객 화면 '데이터 안내'에 나가요 */
  async privacySet(body) {
    const p = body.privacy || {};
    const privacy = { retention: str(p.retention, 120), contact: str(p.contact, 120), extra: str(p.extra, 600), updatedAt: Date.now() };
    await this.store.put('privacy', privacy);
    return { ok: true, privacy };
  }
  async usersGet() {
    return { users: ((await this.store.get('users')) || []).map(({ hash, salt, ...u }) => u) };
  }
  // { users:[{ id, name, role, password? }] } — 비밀번호를 비우면 그대로, 목록에서 빠지면 삭제
  async usersSet(body) {
    const cur = (await this.store.get('users')) || [];
    const next = [];
    for (const x of (Array.isArray(body.users) ? body.users : []).slice(0, 30)) {
      const id = String(x && x.id || '').trim().slice(0, 30);
      if (!/^[\w.@-]{3,30}$/.test(id)) throw new Error('bad_user_id');
      if (next.some(u => u.id === id)) throw new Error('duplicate_user');
      const old = cur.find(u => u.id === id);
      const u = { id, name: str(x.name, 20) || id, role: ROLES.includes(x.role) ? x.role : 'staff', at: old ? old.at : Date.now() };
      if (x.password) {
        if (String(x.password).length < 8) throw new Error('weak_password');
        u.salt = crypto.randomUUID(); u.hash = await hashPw(String(x.password), u.salt);
      } else if (old) { u.salt = old.salt; u.hash = old.hash; }
      else throw new Error('password_required');
      next.push(u);
    }
    await this.store.put('users', next);
    return { ok: true, users: next.map(({ hash, salt, ...u }) => u) };
  }
  async passwordSet({ current, next }) {
    const me = this.user || {};
    if (!me.id) throw new Error('unauthorized');
    const users = (await this.store.get('users')) || [];
    const u = users.find(x => x.id === me.id);
    if (!u) throw new Error('env_owner_password');   // 총괄 관리자 비밀번호는 Cloudflare 환경변수에서 바꿔요
    if ((await hashPw(String(current || ''), u.salt)) !== u.hash) throw new Error('wrong_password');
    if (String(next || '').length < 8) throw new Error('weak_password');
    u.salt = crypto.randomUUID(); u.hash = await hashPw(String(next), u.salt);
    await this.store.put('users', users);
    return { ok: true };
  }

  /* ---------- 작업 기록 ---------- */
  async audit(action, body, res) {
    if (!this.user) return;
    const d = auditDetail(action, body || {}, res || {});
    if (d === null) return;
    const list = (await this.store.get('audit')) || [];
    list.push({ at: Date.now(), who: { id: this.user.id, name: this.user.name }, action, detail: d });
    await this.store.put('audit', list.slice(-400));
  }

  /* ---------- 시즌 설정 (레지스트리) — 기본 설문 · 룰렛·배너 · 금칙어 ---------- */
  async seasonGet() {
    return { survey: await this.libraryDefault(), home: (await this.store.get('home')) || null, nickBan: (await this.store.get('nickBan')) || [],
             privacy: (await this.store.get('privacy')) || null, predictDefault: (await this.store.get('predictDefault')) || null };
  }
  async homeSet(body) {
    const h = body.home || {};
    const R = h.roulette || {};
    const imgOk = v => { v = String(v || ''); return /^data:image\/(webp|png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(v) && v.length <= 40000 ? v : ''; };
    const prizes = (Array.isArray(R.prizes) ? R.prizes : []).slice(0, 8).map((p, i) => {
      const miss = !!(p && p.miss);
      const x = { id: cleanId(p && p.id) || 'p' + (i + 1), img: cleanId(p && p.img) || (miss ? 'miss' : 'soju'), miss, weight: Math.max(0, Math.min(1000, Number(p && p.weight) || 0)) };
      if (!miss) { x.title = str(p.title, 40) || '경품'; x.desc = str(p.desc, 40); x.stock = (p.stock === '' || p.stock == null) ? null : Math.max(0, Math.floor(Number(p.stock) || 0)); const im = imgOk(p.image); if (im) x.image = im; }
      return x;
    });
    if (prizes.length !== 8) throw new Error('roulette_needs_8');
    if (!prizes.some(p => p.weight > 0)) throw new Error('roulette_all_zero');
    const link = v => { v = str(v, 300); return /^https?:\/\//.test(v) ? v : ''; };
    const prev = (await this.store.get('home')) || {};
    const bannerV = async (k, field = 'image', prevField = 'imageV') => {
      const g = k.replace('-dark', ''), v = String((h[g] && h[g][field]) || '');
      if (/^data:image\/(webp|png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(v)) {
        if (v.length > 120000) throw new Error('banner_too_large');
        await this.store.put('banner:' + k, v);
        return Date.now();
      }
      if (v.startsWith('/live/_/banner/')) return (prev[g] && prev[g][prevField]) || 0;
      await this.store.delete('banner:' + k);
      return 0;
    };
    const goodsV = await bannerV('goods'), appV = await bannerV('app'), appDarkV = await bannerV('app-dark', 'imageDark', 'imageDarkV');
    const home = {
      roulette: { base: Math.max(0, Math.min(5, Math.floor(Number(R.base) || 0))), bonus: Math.max(0, Math.min(5, Math.floor(Number(R.bonus) || 0))), prizes,
                  onePerPerson: R.onePerPerson !== false, stockV2: true,
                  notices: (Array.isArray(R.notices) ? R.notices : []).slice(0, 10).map(n => str(n, 200)).filter(Boolean) },
      goods: { title: str(h.goods && h.goods.title, 30), desc: str(h.goods && h.goods.desc, 60), url: link(h.goods && h.goods.url), imageV: goodsV },
      app: { title: str(h.app && h.app.title, 30), desc: str(h.app && h.app.desc, 60), ios: link(h.app && h.app.ios), android: link(h.app && h.app.android), on: !(h.app && h.app.on === false), imageV: appV, imageDarkV: appDarkV },
      updatedAt: Date.now(),
    };
    if (JSON.stringify(home).length > 200000) throw new Error('home_too_large');
    await this.store.put('home', home);
    return { ok: true, home: withBannerUrls(home) };
  }
  async nickBanSet(body) {
    const words = [...new Set((Array.isArray(body.words) ? body.words : []).map(w => String(w || '').toLowerCase().replace(/[^가-힣a-z0-9]/g, '')).filter(w => w.length >= 1))].slice(0, 300);
    await this.store.put('nickBan', words);
    return { ok: true, words };
  }

  /* ---------- 설문 보관함 (레지스트리에 하나) ---------- */
  async libraryGet() {
    return { surveys: (await this.store.get('surveys')) || [], defaultId: (await this.store.get('surveyDefault')) || '' };
  }
  async librarySet(body) {
    const surveys = (Array.isArray(body.surveys) ? body.surveys : []).slice(0, 30).map(x => ({
      id: cleanId(x && x.id) || crypto.randomUUID().slice(0, 8),
      title: str(x && x.title, 60) || '이름 없는 설문',
      items: (Array.isArray(x && x.items) ? x.items : []).slice(0, 25).map((q, i) => cleanSurveyQ(q, i)).filter(Boolean),
      at: Number(x && x.at) || Date.now(), updatedAt: Number(x && x.updatedAt) || Date.now(),
    })).filter(x => x.items.length);
    if (JSON.stringify(surveys).length > 120000) throw new Error('library_too_large');
    const defaultId = surveys.some(x => x.id === body.defaultId) ? body.defaultId : '';
    await this.store.put('surveys', surveys);
    await this.store.put('surveyDefault', defaultId);
    return { ok: true, surveys, defaultId };
  }
  async libraryDefault() {
    const { surveys, defaultId } = await this.libraryGet();
    return surveys.find(x => x.id === defaultId) || null;
  }

  /* ---------- 경품 응모 닉네임 ----------
     nick:{소문자 닉네임} → 기기. 응모할 때 서버에서 한 번 더 확인해서, 두 사람이 동시에 같은 닉네임으로 응모해도 한 명만 들어가요. */
  async nickCheck(name) {
    const k = nickKey(name);
    if (!k) return { available: false, error: 'invalid_nickname' };
    if (await this.nickBanned(name)) return { available: false, error: 'nickname_banned' };
    return { available: !(await this.store.get(k)) };
  }
  async nickBanned(name) {
    const n = String(name || '').toLowerCase().replace(/[^가-힣a-z]/g, '');
    const extra = ((await this.seasonCached()) || {}).nickBan || [];
    return [...NICK_BAN, ...extra].some(w => w && n.includes(w));
  }

  /* ---------- 접속자 ----------
     visit:{기기} 키로 기기당 한 번만 세요(고유 접속자). sessions는 브라우저를 새로 열 때마다(재방문 포함).
     hours: 처음 들어온 시각(한국 시간)별 고유 접속자 — 관리자 대시보드의 시간대 그래프용 */
  async visit({ device }) {
    device = cleanId(device);
    if (!device) throw new Error('device_required');
    const v = (await this.store.get('visits')) || emptyVisits();
    v.sessions += 1;
    if (!(await this.store.get('visit:' + device))) {
      const now = Date.now();
      await this.store.put('visit:' + device, now);
      v.unique += 1;
      const h = String(new Date(now + 9 * 3600e3).getUTCHours()).padStart(2, '0');
      v.hours[h] = (v.hours[h] || 0) + 1;
      if (!v.first) v.first = now;
      v.last = now;
    }
    await this.store.put('visits', v);
    return { ok: true };
  }

  /* ---------- 룰렛 — 서버가 확률·남은 수량으로 뽑아요 ----------
     기기당 횟수 = 기본(base) + 미션을 다 채웠으면 보너스(bonus). 수량(stock)이 비어 있으면 무제한 · 0이면 당첨 안 됨 · 다 나간 경품은 확률 0으로. */
  async spin({ device, bonus }) {
    device = cleanId(device);
    if (!device) throw new Error('device_required');
    const cfg = await this.rouletteCfg();
    const key = 'sub:roulette:' + device;
    const cur = (await this.store.get(key)) || { data: { wins: [] } };
    const wins = (cur.data && cur.data.wins) || [];
    const allowed = (cfg.base || 0) + (bonus ? (cfg.bonus || 0) : 0);
    if (cfg.onePerPerson !== false && wins.some(w => !w.miss)) throw new Error('already_won');
    if (wins.length >= allowed) throw new Error('no_spins');
    const issued = (await this.store.get('rlIssued')) || {};
    const unlimited = p => cfg.stockV2 ? p.stock == null : !p.stock;   // 예전 저장분은 0 = 무제한
    const pool = cfg.prizes.map((p, i) => ({ p, i, w: (p.miss || unlimited(p) || (issued[p.id] || 0) < p.stock) ? (Number(p.weight) || 0) : 0 }));
    let total = pool.reduce((a, x) => a + x.w, 0);
    let pick;
    if (total <= 0) pick = pool.find(x => x.p.miss) || { p: { id: 'miss', miss: true }, i: -1 };
    else {
      let r = (crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296) * total;
      pick = pool.find(x => x.w > 0 && (r -= x.w) < 0) || [...pool].reverse().find(x => x.w > 0);
    }
    const p = pick.p, now = Date.now();
    let code = '';
    if (!p.miss) {
      issued[p.id] = (issued[p.id] || 0) + 1;
      await this.store.put('rlIssued', issued);
      const codes = (await this.store.get('rlCodes')) || {};
      const md = new Date(now + 9 * 3600e3).toISOString().slice(5, 10).replace('-', '');
      do { code = 'P' + md + String(crypto.getRandomValues(new Uint32Array(1))[0] % 10000).padStart(4, '0'); } while (codes[code]);
      codes[code] = 1; await this.store.put('rlCodes', codes);
    }
    const win = { id: p.id, idx: pick.i, miss: !!p.miss, code, ts: now, title: p.miss ? '꽝' : String(p.title || p.id).replace(/\n/g, ' ') };
    await this.store.put(key, { data: { wins: [...wins, win] }, at: now });
    this.touch();
    return { ok: true, win, left: allowed - wins.length - 1 };
  }

  /* ---------- 관람객 화면 오류 ----------
     같은 오류(메시지·위치)는 한 줄로 묶어 횟수만 늘려요. 기기당 1분에 5건까지만 받아요. 최대 100종류. */
  async clientError(b) {
    const device = cleanId(b.device);
    if (!device) throw new Error('device_required');
    const now = Date.now();
    this.errRate = this.errRate || new Map();
    const r = this.errRate.get(device) || { at: now, n: 0 };
    if (now - r.at > 60000) { r.at = now; r.n = 0; }
    if (++r.n > 5) return { ok: true, dropped: true };
    this.errRate.set(device, r);
    const msg = str(b.msg, 300), src = str(b.src, 200), line = Math.floor(Number(b.line) || 0);
    if (!msg) return { ok: true };
    const key = msg + '|' + src + '|' + line;
    const list = (await this.store.get('errors')) || [];
    let e = list.find(x => x.key === key);
    if (!e) { e = { key, msg, src, line, n: 0, devices: [], first: now }; list.push(e); }
    e.n += 1; e.last = now; e.view = str(b.view, 20); e.ua = str(b.ua, 160);
    if (!e.devices.includes(device) && e.devices.length < 50) e.devices.push(device);
    list.sort((a, c) => c.last - a.last);
    await this.store.put('errors', list.slice(0, 100));
    return { ok: true };
  }

  async boardState() {
    const [total = 0, settings = {}, raffleWinners = [], visits] = await Promise.all(['total', 'settings', 'raffleWinners', 'visits'].map(k => this.store.get(k)));
    const b = settings.board || {};
    return { total, mvp: settings.mvp || null, opponent: settings.opponent || '', start: settings.start || '', board: { scene: b.scene || 'auto', message: b.message || '' },
             winners: b.announce ? raffleWinners.map(w => w.nickname || '').filter(Boolean) : [], visitors: (visits || {}).unique || 0, at: Date.now() };
  }

  async raffleHide({ device, hidden }) {
    device = cleanId(device);
    const h = (await this.store.get('raffleHidden')) || {};
    if (hidden) h[device] = Date.now(); else delete h[device];
    await this.store.put('raffleHidden', h);
    return { ok: true, raffleHidden: h };
  }

  /* ---------- 응원 접수 창구 (창구 객체에서 돌아요) ----------
     0.15초 동안 들어온 응원을 모아 경기 서버에 한 번에 넘기고, 받은 결과를 각자에게 돌려줘요. */
  shardCheer(body) {
    return new Promise((resolve, reject) => {
      if (!cleanId(body && body.device)) return reject(new Error('device_required'));
      (this.cq || (this.cq = [])).push({ device: body.device, count: body.count, resolve, reject });
      if (!this.cqTimer) this.cqTimer = setTimeout(() => this.flushCheer(), CHEER_BATCH_MS);
    });
  }
  async flushCheer() {
    const batch = this.cq || []; this.cq = []; this.cqTimer = null;
    if (!batch.length) return;
    try {
      const r = await this.env.LIVE.get(this.env.LIVE.idFromName(this.matchId)).fetch('https://do/live/cheer-batch/', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Match': this.matchId },
        body: JSON.stringify({ entries: batch.map(x => ({ device: x.device, count: x.count })) }),
      });
      const d = await r.json();
      if (!r.ok || !Array.isArray(d.results)) throw new Error(d.error || 'busy');
      batch.forEach((x, i) => { const res = d.results[i]; if (!res || res.error) x.reject(new Error((res && res.error) || 'busy')); else x.resolve(res); });
    } catch (e) { batch.forEach(x => x.reject(e)); }
  }

  /* ---------- 응원 (경기 서버) ---------- */
  async cheer({ device, count }) {
    const r = (await this.cheerBatch({ entries: [{ device, count }] })).results[0];
    if (r.error) throw new Error(r.error);
    return r;
  }
  // 묶음을 들어온 순서대로 — 저장은 묶음마다 한 번씩만
  async cheerBatch({ entries }) {
    const now = Date.now();
    let total = (await this.store.get('total')) || 0;
    let prizes = null, winners = null, pDirty = false, wDirty = false;
    const results = [];
    for (const e of (Array.isArray(entries) ? entries : []).slice(0, 5000)) {
      const device = cleanId(e && e.device);
      if (!device) { results.push({ error: 'device_required' }); continue; }
      // 관람객 화면이 1.5초씩 모아서 보내요. 사람 손으로 가능한 속도(초당 15번)까지만 인정해요 (매크로 방지)
      const prev = this.lastTap.get(device) || 0;
      const allowed = prev ? Math.max(3, Math.ceil((now - prev) / 1000 * 15)) : 40;
      const n = Math.max(1, Math.min(40, allowed, Number(e.count) || 1));
      this.lastTap.set(device, now);
      const from = total + 1, to = total + n;
      total = to;
      if (!prizes) { prizes = (await this.store.get('prizes')) || []; winners = (await this.store.get('winners')) || []; }
      let win = null;
      const hit = prizes.find(p => p.n >= from && p.n <= to && !winners.some(w => w.n === p.n));
      if (hit) {
        if (winners.some(w => w.device === device)) {
          prizes.forEach(p => { if (p.n === hit.n) p.n = to + 1; });   // 한 사람 한 번 — 다음 클릭으로 넘김
          pDirty = true;
        } else {
          win = { n: hit.n, prize: hit.prize, place: hit.place || '', code: claimCode(), at: now };
          winners.push({ ...win, device }); wDirty = true;
        }
      }
      results.push({ total: to, from, to, win });
    }
    await this.store.put('total', total);
    if (pDirty) await this.store.put('prizes', prizes);
    if (wDirty) await this.store.put('winners', winners);
    this.touch();
    return { results };
  }

  async submit(type, { device, data }) {
    device = cleanId(device);
    if (!device) throw new Error('device_required');
    if (!SUB_TYPES.includes(type)) throw new Error('unknown_type');
    const raw = JSON.stringify(data ?? null);
    if (raw.length > (type === 'survey' ? 16000 : 6000)) throw new Error('too_large');   // 설문은 문항·기타 의견이 많아 넉넉히
    const extra = type === 'raffle_entry' ? ':' + cleanId((data || {}).source || 'etc') : '';
    if (type === 'raffle_entry' && data && data.nickname != null) {
      const k = nickKey(data.nickname);
      if (!k) throw new Error('invalid_nickname');
      if (await this.nickBanned(data.nickname)) throw new Error('nickname_banned');
      const owner = await this.store.get(k);
      if (owner && owner !== device) throw new Error('nickname_taken');
      // 한 기기는 닉네임 하나만 — 다른 닉네임으로 다시 응모하면 예전 닉네임을 풀어줘요
      const prev = (await this.store.get(`sub:${type}:${device}${extra}`)) || null;
      const prevK = prev && prev.data && nickKey(prev.data.nickname);
      if (prevK && prevK !== k) await this.store.delete(prevK);
      await this.store.put(k, device);
    }
    await this.store.put(`sub:${type}:${device}${extra}`, { data: JSON.parse(raw), at: Date.now() });
    this.touch();
    return { ok: true };
  }

  /* ---------- 관리자 ---------- */
  async adminState(since) {
    await this.ensurePredict();
    const live = await this.liveSurvey(null, true);   // 먼저 — 새로 나간 설문이면 history에 버전이 생겨요
    const keys = ['events', 'prizes', 'total', 'winners', 'settings', 'raffleWinners', 'redeemed', 'history', 'visits'];
    const vals = await Promise.all(keys.map(k => this.store.get(k)));
    const out = Object.fromEntries(keys.map((k, i) => [k, vals[i]]));
    const subs = Object.fromEntries(SUB_TYPES.map(t => [t, []]));
    // since 이후에 바뀐 응답만 보내요 (관리자 5초 새로고침이 가벼워지게). 그 사이 지운 적이 있으면 전체.
    const resetAt = (await this.store.get('subsResetAt')) || 0;
    const delta = since > 0 && since > resetAt;
    const from = since - 5000;                        // 시계 차이·동시 저장 여유
    const list = await this.store.list({ prefix: 'sub:' });
    for (const [key, v] of list) {
      if (delta && !(v.at >= from)) continue;
      const [, type, device] = key.split(':');
      if (subs[type]) subs[type].push({ k: key, device, data: v.data, at: v.at });
    }
    return {
      serverVersion: SERVER_VERSION, subsMode: delta ? 'delta' : 'full', now: Date.now(),
      raffleHidden: (await this.store.get('raffleHidden')) || {}, rlIssued: (await this.store.get('rlIssued')) || {},
      rouletteCfg: await this.rouletteCfg(true), me: this.user || null,
      errors: ((await this.store.get('errors')) || []).map(({ devices, ...e }) => ({ ...e, devices: devices.length })),
      matchId: this.matchId,
      events: out.events || [], prizes: out.prizes || [], total: out.total || 0,
      winners: (out.winners || []).map(({ device, ...w }) => ({ ...w, device: device.slice(-4) })),
      settings: out.settings || {}, raffleWinners: out.raffleWinners || [], redeemed: out.redeemed || {},
      history: out.history || { survey: [], predict: [] },
      survey: live,   // 지금 이 경기에 나가는 설문 (버전·제목·출처)
      visits: out.visits || emptyVisits(),
      epoch: (await this.store.get('epoch')) || 0,
      subs,
    };
  }

  async put(k, v) { await this.store.put(k, v); return { ok: true, [k]: v }; }

  async setEvents({ events }) {
    if (!Array.isArray(events)) throw new Error('events_must_be_array');
    const clean = events.slice(0, 30).map(e => ({
      id: cleanId(e.id) || crypto.randomUUID().slice(0, 8),
      title: str(e.title, 40), place: str(e.place, 40), limit: str(e.limit, 20), desc: str(e.desc, 200),
      startsAt: str(e.startsAt, 25), endsAt: str(e.endsAt, 25),
      active: e.active !== false, createdAt: Number(e.createdAt) || Date.now(),
    })).filter(e => e.title);
    await this.store.put('events', clean); this.touch();
    return { ok: true, events: clean };
  }

  async setPrizes({ prizes }) {
    if (!Array.isArray(prizes)) throw new Error('prizes_must_be_array');
    const clean = prizes.slice(0, 50).map(p => ({ n: Math.floor(Number(p.n)), prize: str(p.prize, 40), place: str(p.place, 40) }))
      .filter(p => p.n > 0 && p.prize).sort((a, b) => a.n - b.n);
    await this.store.put('prizes', clean);
    return { ok: true, prizes: clean };
  }

  async setSettings(body) {
    const cur = (await this.store.get('settings')) || {};
    const next = { ...cur };
    if ('phase' in body) next.phase = ['auto', 'before', 'live'].includes(body.phase) ? body.phase : 'auto';
    if ('start' in body) next.start = str(body.start, 25);
    if ('opponent' in body) next.opponent = str(body.opponent, 20);
    if ('board' in body) {
      const b = body.board || {};
      next.board = { scene: ['auto', 'qr', 'cheer', 'mvp', 'winners', 'message'].includes(b.scene) ? b.scene : 'auto', announce: !!b.announce, message: str(b.message, 80) };
    }
    if ('mvp' in body) next.mvp = body.mvp && body.mvp.num != null ? { num: Number(body.mvp.num), title: str(body.mvp.title || 'MVP', 12), name: str(body.mvp.name, 20) } : null;
    // 정답 — 버전별 키(v2_first_point 등)가 쌓이니 넉넉히 받아요
    if ('answers' in body) next.answers = Object.fromEntries(Object.entries(body.answers || {}).slice(0, 120).map(([k, v]) => [cleanId(k), str(v, 40)]).filter(([, v]) => v));
    if ('content' in body) {
      const nc = cleanContent(body.content), oc = cur.content || {};
      const hist = (await this.store.get('history')) || { survey: [], predict: [] };
      let histChanged = false;
      for (const k of ['predict']) {      // 설문 버전은 liveSurvey에서 (보관함 기본 설문도 같이 다뤄야 해서)
        const verKey = k + 'Ver';
        const before = JSON.stringify(oc[k] || null), after = JSON.stringify((nc && nc[k]) || null);
        if (!nc) continue;
        if (before === after) { if (oc[verKey]) nc[verKey] = oc[verKey]; continue; }
        if (!nc[k]) continue;                                   // 등록을 지우면 관람객 화면은 기본 문항(v0)으로 돌아가요
        const list = hist[k] || [];
        const v = list.reduce((m, h) => Math.max(m, h.v), 0) + 1;
        nc[verKey] = { v, at: Date.now() };
        hist[k] = [...list, { v, at: nc[verKey].at, items: nc[k] }].slice(-30);
        histChanged = true;
      }
      next.content = nc;
      if (histChanged) await this.store.put('history', hist);
      // 등록한 예측 문항은 다음 경기에도 이어서 쓰게 시즌 공통으로도 저장해요
      if (nc && Array.isArray(nc.predict) && nc.predict.length) {
        delete next.predictCleared;
        await this.env.LIVE.get(this.env.LIVE.idFromName(REGISTRY)).fetch('https://do/reg/predict-default',
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: nc.predict }) });
      } else if (oc.predict && !(nc && nc.predict)) next.predictCleared = true;
    }
    await this.store.put('settings', next); this.touch();
    return { ok: true, settings: next };
  }

  async raffleClear() {
    const list = await this.store.list({ prefix: 'sub:raffle_entry:' });
    const nicks = await this.store.list({ prefix: 'nick:' });
    const keys = [...list.keys(), ...nicks.keys()];
    await this.store.delete([...list.keys()]);
    await this.store.put('subsResetAt', Date.now());
    const winners = ((await this.store.get('raffleWinners')) || []).map(w => (w.nickname && w.contact === w.nickname) || !w.contact ? w : { ...w, contact: maskContact(w.contact) });
    await this.store.put('raffleWinners', winners);
    return { ok: true, deleted: list.size };
  }

  async redeem({ code, redeemed }) {
    code = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
    if (!code) throw new Error('code_required');
    const all = (await this.store.get('redeemed')) || {};
    if (redeemed === false) delete all[code]; else all[code] = Date.now();
    await this.store.put('redeemed', all);
    return { ok: true, redeemed: all };
  }

  /* ---------- 데이터 초기화 ---------- */
  async reset({ parts }) {
    const P = new Set((Array.isArray(parts) ? parts : []).filter(x => RESET_PARTS.includes(x)));
    if (!P.size) throw new Error('nothing_to_reset');
    const keys = [], prefixes = [];
    const settings = (await this.store.get('settings')) || {};
    const hist = (await this.store.get('history')) || { survey: [], predict: [] };
    let sChanged = false, hChanged = false;
    if (P.has('visits')) { keys.push('visits'); prefixes.push('visit:'); }
    if (P.has('cheer')) keys.push('total', 'winners');
    if (P.has('checkin')) prefixes.push('sub:checkin:');
    if (P.has('predict')) {
      prefixes.push('sub:predictions:');
      delete settings.answers; sChanged = true;
      // 문항이 등록돼 있으면 그 문항을 v1로 다시 시작해요
      const c = settings.content || {};
      hist.predict = Array.isArray(c.predict) && c.predict.length ? [{ v: 1, at: Date.now(), items: c.predict }] : [];
      if (c.predictVer) c.predictVer = hist.predict.length ? { v: 1, at: hist.predict[0].at } : undefined;
      hChanged = true;
    }
    if (P.has('mvp')) { prefixes.push('sub:mvp:'); delete settings.mvp; sChanged = true; }
    if (P.has('survey')) { prefixes.push('sub:survey:', 'sub:survey_progress:'); hist.survey = []; hChanged = true; this._svCache = null; }
    if (P.has('raffle')) { prefixes.push('sub:raffle_entry:', 'nick:'); keys.push('raffleWinners', 'raffleHidden'); }
    if (P.has('roulette')) { prefixes.push('sub:roulette:'); keys.push('redeemed', 'rlIssued', 'rlCodes'); }
    if (P.has('config')) {
      // 현장 이벤트 · 응원 당첨 번호 · 경기 진행 · 시작 시각 · 이 경기에만 지정한 설문·예측 문항·운영 설정
      keys.push('events', 'prizes', 'errors');
      const keep = {};   // 다른 항목을 초기화하지 않았으면 정답·MVP는 남겨요
      if (!P.has('predict') && settings.answers) keep.answers = settings.answers;
      if (!P.has('mvp') && settings.mvp) keep.mvp = settings.mvp;
      // 예측 문항은 초기화해도 남겨요 (다시 등록하지 않아도 되게)
      const pc = settings.content || {};
      if (Array.isArray(pc.predict) && pc.predict.length) keep.content = { predict: pc.predict, ...(pc.predictVer ? { predictVer: pc.predictVer } : {}) };
      for (const k of Object.keys(settings)) delete settings[k];
      Object.assign(settings, keep); sChanged = true; this._svCache = null;
    }
    for (const pre of prefixes) {
      const list = await this.store.list({ prefix: pre });
      keys.push(...list.keys());
    }
    for (let i = 0; i < keys.length; i += 128) await this.store.delete(keys.slice(i, i + 128));   // 한 번에 128개까지
    if (sChanged) await this.store.put('settings', settings);
    if (hChanged) await this.store.put('history', hist);
    const epoch = Date.now();
    await this.store.put('epoch', epoch);
    await this.store.put('subsResetAt', epoch);      // 관리자 화면이 전체를 다시 받게
    publicCache.delete(':' + this.matchId); publicCache.delete('board:' + this.matchId);
    return { ok: true, deleted: keys.length, parts: [...P], epoch };
  }

  async resetCheer() {
    await Promise.all([this.store.put('total', 0), this.store.put('winners', [])]);
    return { ok: true };
  }
}

/* ---------- 관리자 콘텐츠 ---------- */
const MISSION_IDS = ['checkin', 'seats', 'fortune', 'survey', 'predict', 'raffle'];
function cleanImg(v) {
  v = String(v || '');
  if (/^data:image\/(webp|png|jpeg|gif);base64,[A-Za-z0-9+/=]+$/.test(v) && v.length <= 20000) return v;   // 관리자에서 96px로 줄여 올려요
  if (/^https:\/\/[^\s"'<>]+$/.test(v) && v.length <= 500) return v;
  return '';
}
function cleanContent(c) {
  if (!c || typeof c !== 'object') return null;
  const out = {};
  if (Array.isArray(c.predict)) out.predict = c.predict.slice(0, 5).map((q, i) => {
    const base = { id: cleanId(q && q.id) || 'q' + (i + 1), q: str(q && q.q, 40), ai: !q || q.ai !== false };
    return q && q.type === 'player' ? { ...base, type: 'player' }
      : { ...base, options: (Array.isArray(q && q.options) ? q.options : []).slice(0, 6).map(o => str(o, 20)).filter(Boolean) };
  }).filter(q => q.q && (q.type === 'player' || q.options.length >= 2));
  // 설문 — 단일·복수(max)·NPS(0~10)·행렬 척도(rows × cols), 기타 직접 입력(other), 자유 의견(comment), 앞 문항 조건(cond)
  if (Array.isArray(c.survey)) out.survey = c.survey.slice(0, 25).map((q, i) => cleanSurveyQ(q, i)).filter(Boolean);
  if (Array.isArray(c.checkin)) out.checkin = c.checkin.slice(0, 3).map((q, i) => ({
    key: cleanId(q && q.key) || 'q' + (i + 1), q: str(q && q.q, 30),
    opts: (Array.isArray(q && q.opts) ? q.opts : []).slice(0, 6).map(o => {
      const img = cleanImg(o && o.img);
      return img ? { label: str(o && o.label, 10), img } : { label: str(o && o.label, 10) };
    }).filter(o => o.label),
  })).filter(q => q.q && q.opts.length >= 2);
  if (Array.isArray(c.survey) && c.survey.length) { out.surveyTitle = str(c.surveyTitle, 60); out.surveyLib = cleanId(c.surveyLib); }
  if (Array.isArray(c.missions)) out.missions = [...new Set(c.missions.filter(id => MISSION_IDS.includes(id)))];
  if ('open' in c) out.open = ['auto', 'on', 'off'].includes(c.open) ? c.open : 'auto';
  if (JSON.stringify(out).length > 100000) throw new Error('content_too_large');   // 관람객이 20~30초마다 받으니 가볍게
  return out;
}
const SURVEY_TYPES = ['single', 'multi', 'nps', 'grid'];
function cleanSurveyQ(q, i) {
  if (!q || typeof q !== 'object') return null;
  const list = (a, n, max) => (Array.isArray(a) ? a : []).slice(0, n).map(o => str(o, max)).filter(Boolean);
  const type = SURVEY_TYPES.includes(q.type) ? q.type : 'single';
  const it = { id: str(q.id, 12).replace(/[^\w-]/g, '') || String(i + 1), q: str(q.q, 120), type };
  if (!it.q) return null;
  if (type === 'nps') { it.low = str(q.low, 30); it.high = str(q.high, 30); }
  else if (type === 'grid') {
    it.rows = list(q.rows, 15, 40); it.cols = list(q.cols, 7, 12);
    if (!it.rows.length || it.cols.length < 2) return null;
  } else {
    it.options = list(q.options, 25, 40);
    if (it.options.length < 2) return null;
    if (type === 'multi' && Number(q.max) > 0) it.max = Math.min(it.options.length, Math.floor(Number(q.max)));
    if (q.other) it.other = true;
    if (q.shuffle) it.shuffle = true;
  }
  if (type === 'grid' && q.shuffleRows) it.shuffleRows = true;
  if (q.comment && type !== 'grid') it.comment = true;
  if (q.cond && typeof q.cond === 'object' && q.cond.id) {
    const cid = str(q.cond.id, 12).replace(/[^\w-]/g, '');
    if (Array.isArray(q.cond.in)) it.cond = { id: cid, in: list(q.cond.in, 25, 40) };
    else if (Array.isArray(q.cond.notIn)) it.cond = { id: cid, notIn: list(q.cond.notIn, 25, 40) };
  }
  return it;
}

function cleanWinners(list) {
  return (Array.isArray(list) ? list : []).slice(0, 200).map(w => ({
    nickname: str(w && w.nickname, 20), contact: str(w && w.contact, 60), device: cleanId(w && w.device),
    route: str(w && w.route, 20), source: str(w && w.source, 20), at: Number(w && w.at) || Date.now(),
  }));
}
// 닉네임 — 한글·영문 10자 (영문은 대소문자 구분 없이 같은 닉네임으로 봐요)
function nickKey(v) {
  const n = String(v ?? '').trim();
  return /^[가-힣a-zA-Z0-9]{1,10}$/.test(n) ? 'nick:' + n.toLowerCase() : '';
}

/* ---------- 작업 기록 문장 ---------- */
const PART_NAME = { visits:'접속자', cheer:'응원', checkin:'출석', predict:'예측', mvp:'MVP', survey:'설문', raffle:'경품 응모', roulette:'룰렛', config:'경기 설정' };
function auditDetail(action, b, res) {
  switch (action) {
    case 'events': return `현장 이벤트 ${(b.events || []).length}개로 저장`;
    case 'prizes': return `응원 당첨 번호: ${(b.prizes || []).map(p => p.n + '번째').join(', ') || '없음'}`;
    case 'settings': {
      const out = [];
      if ('phase' in b) out.push(`경기 진행: ${{ auto:'자동', before:'시작 전', live:'경기 시작' }[b.phase] || b.phase}`);
      if ('start' in b) out.push(b.start ? `시작 시각: ${b.start}` : '시작 시각 지움');
      if ('opponent' in b) out.push(b.opponent ? `상대팀: ${b.opponent}` : '상대팀 지움');
      if ('mvp' in b) out.push(b.mvp ? `MVP 확정: ${b.mvp.name || '#' + b.mvp.num}` : 'MVP 해제');
      if ('answers' in b) out.push('예측 정답 저장');
      if ('board' in b) out.push(`전광판: ${(b.board || {}).scene || 'auto'}${(b.board || {}).announce ? ' · 당첨자 발표' : ''}`);
      if ('content' in b) {
        const c = b.content || {};
        out.push(Array.isArray(c.survey) && c.survey.length ? `이 경기 설문: ${c.surveyTitle || '지정'}` : '이 경기 설정(문항·운영·미션) 저장');
      }
      return out.join(' · ') || '설정 저장';
    }
    case 'raffle': return `당첨자 ${(b.winners || []).length}명으로 저장`;
    case 'raffle-clear': return `응모 닉네임 삭제 (${res.deleted || 0}건)`;
    case 'raffle-hide': return `${b.hidden ? '추첨에서 뺌' : '추첨에 다시 넣음'} · 기기 …${String(b.device || '').slice(-4)}`;
    case 'redeem': return `${b.redeemed === false ? '교환 취소' : '교환 처리'} · ${String(b.code || '').toUpperCase()}`;
    case 'reset-cheer': return '응원 수·당첨 초기화';
    case 'purge': return '경기 통째로 삭제 (데이터 · 설정 · 경기 목록)';
    case 'reset': return `데이터 초기화: ${(res.parts || []).map(x => PART_NAME[x] || x).join(', ')} (${res.deleted || 0}건)`;
    case 'surveys': return `설문 보관함 저장 (${(b.surveys || []).length}개)`;
    case 'users': return `관리자 계정 저장 (${(b.users || []).length}명)`;
    case 'password': return '내 비밀번호 변경';
    case 'home': return '룰렛 경품·홈 배너 저장';
    case 'nickban': return `닉네임 금칙어 ${(b.words || []).length}개로 저장`;
    case 'unlock': return `로그인 잠금 풀기 · ${String(b.key || '').replace(/^(id|ip):/, '')}`;
    case 'privacy': return '데이터 수집 안내 저장';
    case 'subway': return `막차 시간표 저장 (평일 ${((b.subway || {}).tt || {}).wk ? ((b.subway.tt.wk[0] || []).length + (b.subway.tt.wk[1] || []).length) : 0}편)`;
    case 'errors-clear': return '관람객 화면 오류 기록 비움';
    default: return action;
  }
}

/* ---------- util ---------- */
function emptyVisits() { return { unique: 0, sessions: 0, hours: {}, first: 0, last: 0 }; }
function str(v, max) { return String(v ?? '').trim().slice(0, max); }
function cleanId(v) { return String(v || '').replace(/[^\w-]/g, '').slice(0, 64); }
function maskContact(c) {
  c = String(c || '');
  if (c.includes('@')) { const [a, b] = c.split('@'); return a.slice(0, 2) + '***@' + b; }
  const d = c.replace(/\D/g, '');
  return d.length >= 8 ? `${d.slice(0, 3)}-****-${d.slice(-4)}` : c.replace(/\d/g, '*');
}
function claimCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = ''; for (const x of crypto.getRandomValues(new Uint8Array(4))) s += A[x % A.length];
  return s;
}
