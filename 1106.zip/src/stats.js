/**
 * okman-stats — KOVO 기록 DB(kovo_landing) → 직관가이드 기록 탭용 JSON
 * GET /stats → { season, players, others, teams, results, games, schedule, updated }
 *   players : OK저축은행 선수 (능력치 = 리그 백분위)
 *   others  : 다른 팀 선수 — 이적생(예: 새 외국인 선수)의 지난 시즌 기록을 이름으로 찾을 때 써요
 *   games   : OK저축은행 정규리그 일정 전체(끝난 경기 + 앞으로 할 경기) — '우리 경기' 달력·자동 경기 정보용
 *   schedule: 리그 전체 정규리그 일정(모든 팀) — '우리 경기' 날짜별 경기 목록용
 *
 * 컬럼 의미 (kovo_player_record 샘플 행으로 검증):
 *   point 득점 · att/ats/atf/ate 공격 시도/성공/실패/범실 · atsp 공격성공률(%)
 *   st/ss/sf 서브 시도/득점/범실 · ssp 세트당 서브득점
 *   bt/bs 블로킹 시도/성공 · bsp 세트당 블로킹
 *   dt/ds 디그 시도/성공 · dsp 세트당 디그
 *   sett/sets 세트 시도/성공 · setsp 세트당 세트
 *   rt/rs/rf 리시브 시도/정확/실패 · rsp 리시브효율(%) = (정확-실패)/시도
 */
import { createConnection } from 'mysql2/promise';

// position 코드 (022 시즌 확인) — OH 아웃사이드 · OP 아포짓 · MB 미들 · S 세터 · L 리베로
// Co(감독)·As(코치)·빈 값(스태프)은 선수 목록에서 빼요.
// ※ 초창기 시즌(001 등)은 L=레프트·R=라이트·C=센터 체계라, 현재 시즌만 조회하는 이 Worker에서는 L을 리베로로 봐요.
const POS = { OH: 'OH', OP: 'OP', MB: 'MB', S: 'S', L: 'L' };
const STAFF = new Set(['', 'Co', 'As']);

// 순위·기록은 경기 중에 바뀌지 않아서 5분 동안 같은 응답을 써요.
// 5분이 지나도 사람들에게는 바로 이전 기록을 보여주고, 뒤에서 한 번만 새로 읽어와요.
const MEMO_MS = 5 * 60 * 1000;
const memo = { at: 0, body: '', inflight: null };

// DB 조회는 한 번에 하나만 — 동시에 수백 명이 와도 같은 조회 결과를 함께 기다려요.
function refreshMemo(env) {
  if (!memo.inflight) {
    memo.inflight = buildStats(env)
      .then(body => { memo.body = body; memo.at = Date.now(); return body; })
      .finally(() => { memo.inflight = null; });
  }
  return memo.inflight;
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    // ALLOW_ORIGIN은 쉼표로 여러 개 넣을 수 있어요 (예: GitHub Pages, 로컬 테스트 주소)
    const allowed = String(env.ALLOW_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
    const origin = req.headers.get('Origin') || '';
    const cors = {
      'Access-Control-Allow-Origin': allowed.includes(origin) ? origin : (allowed[0] || ''),
      'Access-Control-Allow-Methods': 'GET',
      'Vary': 'Origin',
    };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (url.pathname !== '/stats') return new Response('Not found', { status: 404, headers: cors });

    const cache = caches.default;
    // 응답의 CORS 헤더가 요청 Origin마다 달라서, 캐시 키에 Origin을 넣어요.
    const cacheKey = new Request(url.origin + '/stats?o=' + encodeURIComponent(origin), { method: 'GET' });
    const check = url.searchParams.get('check') === '1';
    const hit = check ? null : await cache.match(cacheKey);
    if (hit) return hit;
    // workers.dev 주소에서는 위 캐시가 동작하지 않아서, 메모리에도 1분 동안 저장해둬요.
    // 4,000명이 동시에 앱을 열어도 KOVO DB 조회는 1분에 몇 번만 일어나요.
    const send = body => {
      const res = new Response(body, { headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=600' } });
      ctx.waitUntil(cache.put(cacheKey, res.clone()));
      return res;
    };
    if (!check) {
      if (memo.body) {
        // 5분이 지났으면 뒤에서 새로 읽고, 지금 온 사람에게는 기다림 없이 이전 기록을 줘요
        if (Date.now() - memo.at >= MEMO_MS) ctx.waitUntil(refreshMemo(env).catch(e => console.error(e)));
        return send(memo.body);
      }
      try {
        return send(await refreshMemo(env));
      } catch (e) {
        console.error(e);   // DB 오류 내용은 밖으로 보내지 않아요
        return Response.json({ error: 'stats_unavailable' }, { status: 502, headers: cors });
      }
    }

    let db;
    try {
      db = await createConnection({
        host: env.HYPERDRIVE.host, port: env.HYPERDRIVE.port,
        user: env.HYPERDRIVE.user, password: env.HYPERDRIVE.password,
        database: env.HYPERDRIVE.database, disableEval: true,
        dateStrings: true,   // DATE/DATETIME을 JS Date로 바꾸지 않고 DB에 저장된 글자 그대로 받아요 (시간대 밀림 방지)
      });
      const gPart = env.G_PART;
      const sp = env.S_PART || '';   // 남/여 구분 — 비우면 필터 안 함
      const season = await currentSeason(db, gPart, sp, String(env.SEASON || '').trim());
      const okCode = env.OK_TEAM_CODE || await findOkCode(db, season, gPart);
      const regRounds = Number(env.REG_ROUNDS) || 6;   // 정규리그 라운드 수 — 이보다 큰 라운드(포스트시즌)는 빼요

      const [teams, leaguePlayers, results, games, schedule] = await Promise.all([
        getTeams(db, season, gPart, env.TOTAL_ROUND, okCode, sp, regRounds),
        getPlayers(db, season, gPart, env.TOTAL_ROUND, sp),
        getResults(db, season, gPart, sp, regRounds),
        getGames(db, gPart, sp, okCode, regRounds),
        getSchedule(db, gPart, sp, okCode, regRounds),
      ]);
      if (check) {
        // 점검용 — 실제 DB에 무엇이 들어 있는지 그대로 보여줘요 (비밀번호·접속 정보는 안 나가요)
        const q = async (sql, args) => (await db.query(sql, args))[0];
        return Response.json({
          picked: { season, okCode, gPart, sPart: sp, totalRound: env.TOTAL_ROUND },
          seasons: await q(`SELECT season, g_part, s_part, MAX(round) AS max_round, COUNT(*) AS n
                              FROM kovo_ranking GROUP BY season, g_part, s_part ORDER BY season DESC LIMIT 12`),
          okRanking: await q(`SELECT * FROM kovo_ranking WHERE season = ? AND g_part = ? AND t_code = ?
                               ORDER BY round DESC LIMIT 2`, [season, gPart, okCode]),
          okPlayerRounds: await q(`SELECT round, COUNT(*) AS n, MAX(created_at) AS latest FROM kovo_total_player
                                    WHERE season = ? AND g_part = ? AND t_code = ? GROUP BY round ORDER BY round`,
                                  [season, gPart, okCode]),
          okPlayerSample: await q(`SELECT * FROM kovo_total_player WHERE season = ? AND g_part = ? AND t_code = ?
                                    ORDER BY created_at DESC LIMIT 2`, [season, gPart, okCode]),
          scheduleSample: await q(`SELECT season, g_part, s_part, round, g_num, g_date, h_code, a_code, h_spoint, a_spoint
                                     FROM kovo_game_schedule WHERE season = ? AND g_part = ?
                                     ORDER BY g_date DESC LIMIT 5`, [season, gPart]),
          games: { season: games.season, count: games.list.length, first: games.list.slice(0, 3) },
          schedule: { season: schedule.season, count: schedule.list.length, first: schedule.list.slice(0, 2) },
          output: { teams: teams.slice(0, 3), results: results.slice(0, 3),
                    players: leaguePlayers.filter(p => p.t_code === okCode).slice(0, 3) },
        }, { headers: { ...cors, 'Cache-Control': 'no-store' } });
      }
    } catch (e) {
      console.error(e);   // DB 오류 내용은 밖으로 보내지 않아요
      return Response.json({ error: 'stats_unavailable' }, { status: 502, headers: cors });
    } finally {
      if (db) ctx.waitUntil(db.end());
    }
  },
};

/* 일반 요청용 — DB에서 읽어 응답 본문(JSON 글자)을 만들어요. 동시에 여러 번 불리지 않게 refreshMemo가 묶어줘요. */
async function buildStats(env) {
  let db;
  try {
    db = await createConnection({
      host: env.HYPERDRIVE.host, port: env.HYPERDRIVE.port,
      user: env.HYPERDRIVE.user, password: env.HYPERDRIVE.password,
      database: env.HYPERDRIVE.database, disableEval: true,
      dateStrings: true,
    });
    const gPart = env.G_PART;
    const sp = env.S_PART || '';
    const season = await currentSeason(db, gPart, sp, String(env.SEASON || '').trim());
    const okCode = env.OK_TEAM_CODE || await findOkCode(db, season, gPart);
    const regRounds = Number(env.REG_ROUNDS) || 6;
    const [teams, leaguePlayers, results, games, schedule] = await Promise.all([
      getTeams(db, season, gPart, env.TOTAL_ROUND, okCode, sp, regRounds),
      getPlayers(db, season, gPart, env.TOTAL_ROUND, sp),
      getResults(db, season, gPart, sp, regRounds),
      getGames(db, gPart, sp, okCode, regRounds),
      getSchedule(db, gPart, sp, okCode, regRounds),
    ]);
    const rated = withAbility(leaguePlayers, Number(env.MIN_SETS) || 0);
    const players = rated.filter(p => p.t_code === okCode).map(({ t_code, ...p }) => p);
    const others = rated.filter(p => p.t_code !== okCode).map(({ t_code, ...p }) => ({ ...p, team: t_code }));
    return JSON.stringify({ season, players, others, teams, results, games, schedule, updated: new Date().toISOString() });
  } finally {
    if (db) await db.end().catch(() => {});
  }
}

/* ---------- 쿼리 ---------- */

// 시즌 코드: 001(2004-05) … 022(2025-26) · 023(2026-27).
// ⚠ 컵대회·기타 대회는 800·900번대 시즌 코드(…911)를 쓰는데 g_part만으로는 안 걸러져서,
//   정규시즌 코드(100 미만)만 봐요.
//   SEASON 값을 넣으면 그 시즌으로 고정해요 (예: "022").
async function currentSeason(db, gPart, sp, fixed) {
  if (fixed) return fixed;
  const [rows] = await db.query(
    `SELECT MAX(season) AS s FROM kovo_ranking
      WHERE g_part = ? ${sp ? 'AND s_part = ?' : ''} AND CAST(season AS UNSIGNED) < 100`,
    sp ? [gPart, sp] : [gPart]);
  return rows[0].s;
}

async function findOkCode(db, season, gPart) {
  const [rows] = await db.query(
    "SELECT t_code FROM kovo_ranking WHERE season = ? AND g_part = ? AND (t_sname LIKE '%OK%' OR t_sname LIKE '%읏맨%') LIMIT 1",
    [season, gPart]);
  return rows[0] ? rows[0].t_code : '';
}

// 팀 순위 = 정규리그 1~REG_ROUNDS 라운드 합계
// ⚠ kovo_ranking은 '라운드별' 성적이에요 (6라운드 행 = 6라운드 6경기만). 시즌 누적이 아니라서 직접 더해요.
//   컬럼: winp 승점 · win/lost 승패 · swin/slost 세트 득실 · point/lpoint 점수 득실
//   같은 팀·라운드 행이 갱신 날짜(udate)별로 여러 개면 가장 최근 것만 써요 (연기 경기 반영분).
// 순위 규칙(KOVO): 승점 → 승수 → 세트득실률 → 점수득실률
async function getTeams(db, season, gPart, totalRound, okCode, sp, regRounds) {
  const spSql = sp ? 'AND s_part = ?' : '';
  const [[rows], [totals]] = await Promise.all([
    db.query(
      `SELECT t_code, t_sname, round, winp, win, lost, swin, slost, point, lpoint, udate
         FROM kovo_ranking
        WHERE season = ? AND g_part = ? ${spSql} AND round BETWEEN 1 AND ?`,
      sp ? [season, gPart, sp, regRounds] : [season, gPart, regRounds]),
    db.query(
      `SELECT t_code, g_count, atsp, bsp, ssp, rsp
         FROM kovo_total_team
        WHERE season = ? AND g_part = ? AND round = ?`,
      [season, gPart, totalRound]),
  ]);

  // 팀·라운드별 최신 행 하나
  const latest = new Map();
  for (const r of rows) {
    const key = r.t_code + ':' + r.round;
    const prev = latest.get(key);
    const newer = !prev || String(r.udate) > String(prev.udate)
      || (String(r.udate) === String(prev.udate) && (r.win + r.lost) > (prev.win + prev.lost));
    if (newer) latest.set(key, r);
  }
  // 라운드 합계
  const sum = new Map();
  for (const r of latest.values()) {
    const t = sum.get(r.t_code) || { t_code: r.t_code, name: r.t_sname, winp: 0, win: 0, lost: 0, swin: 0, slost: 0, point: 0, lpoint: 0 };
    for (const k of ['winp', 'win', 'lost', 'swin', 'slost', 'point', 'lpoint']) t[k] += Number(r[k]) || 0;
    sum.set(r.t_code, t);
  }
  const tot = new Map(totals.map(t => [t.t_code, t]));
  const ratio = (a, b) => b ? a / b : (a ? Infinity : 0);

  return [...sum.values()]
    .sort((a, b) => b.winp - a.winp || b.win - a.win
      || ratio(b.swin, b.slost) - ratio(a.swin, a.slost)
      || ratio(b.point, b.lpoint) - ratio(a.point, a.lpoint))
    .map((t, i) => {
      const x = tot.get(t.t_code) || {};
      return {
        id: t.t_code, name: t.name, rank: i + 1,
        g: t.win + t.lost, w: t.win, l: t.lost, pts: t.winp,
        setRatio: t.slost ? round(t.swin / t.slost, 3) : t.swin,
        atk: round(x.atsp, 1), blk: round(x.bsp, 2), ace: round(x.ssp, 2), rcv: round(x.rsp, 1),
        us: t.t_code === okCode,
      };
    });
}

// 리그 전체 선수 시즌 누적 (능력치 백분위는 리그 전체 기준으로 계산)
// kovo_total_player는 같은 선수 행이 갱신 시점별로 여러 개 쌓일 수 있어서(created_at),
// 선수마다 가장 최근 행 하나만 남겨요.
async function getPlayers(db, season, gPart, totalRound, sp) {
  const spSql = sp ? 'AND s_part = ?' : '';
  const [[rows], [posRows]] = await Promise.all([
    db.query(
      `SELECT t_code, p_code, p_name, b_num, g_count, s_count, created_at,
              point, att, atsp, bsp, ssp, dsp, rt, rsp, setsp
         FROM kovo_total_player
        WHERE season = ? AND g_part = ? AND round = ? ${spSql}`,
      sp ? [season, gPart, totalRound, sp] : [season, gPart, totalRound]),
    db.query(
      `SELECT p_code, position, round, g_num
         FROM kovo_player_record
        WHERE season = ? AND g_part = ?`,
      [season, gPart]),
  ]);

  // 선수별 가장 최근 경기의 포지션
  const posOf = new Map();
  for (const r of posRows) {
    const prev = posOf.get(r.p_code);
    if (!prev || r.round > prev.round || (r.round === prev.round && r.g_num > prev.g_num)) posOf.set(r.p_code, r);
  }
  // 선수별 시즌 누적 행 — 경기 수가 가장 많은 행 (같으면 최근 행)
  // 누적 기록은 경기가 쌓일수록 커져요. 나중에 들어온 행이 포스트시즌 · 일부 경기만 담은 경우(예: 1경기)가 있어서
  // '가장 최근 행'으로 고르면 시즌 기록이 1경기로 줄어드는 문제가 있었어요 (러셀 2025-26: 35경기 → 1경기)
  const latest = new Map();
  for (const r of rows) {
    const key = r.t_code + ':' + r.p_code;
    const prev = latest.get(key);
    const better = !prev
      || (Number(r.g_count) || 0) > (Number(prev.g_count) || 0)
      || ((Number(r.g_count) || 0) === (Number(prev.g_count) || 0) && +new Date(r.created_at || 0) > +new Date(prev.created_at || 0));
    if (better) latest.set(key, r);
  }

  const out = [];
  for (const r of latest.values()) {
    const code = String(posOf.get(r.p_code)?.position ?? '').trim();
    if (STAFF.has(code) || !r.g_count) continue;      // 스태프·미출전 제외
    out.push({
      t_code: r.t_code, num: r.b_num, name: r.p_name, pos: POS[code] || 'OH',
      sets: r.s_count,
      season: {
        g: r.g_count, pts: r.point,
        atk: r.att ? round(r.atsp, 1) : null,
        blk: round(r.bsp, 2), ace: round(r.ssp, 2), dig: round(r.dsp, 2),
        rcv: r.rt ? round(r.rsp, 1) : null, set: round(r.setsp, 2),
      },
    });
  }
  return out.sort((a, b) => a.num - b.num);
}

// 정규리그(1~REG_ROUNDS 라운드) 끝난 경기 최근 20개 (세트 스코어 포함)
async function getResults(db, season, gPart, sp, regRounds) {
  const [rows] = await db.query(
    `SELECT round, g_num, g_date, h_code, a_code, h_spoint, a_spoint,
            h_s1point, h_s2point, h_s3point, h_s4point, h_s5point,
            a_s1point, a_s2point, a_s3point, a_s4point, a_s5point
       FROM kovo_game_schedule
      WHERE season = ? AND g_part = ? ${sp ? 'AND s_part = ?' : ''} AND (h_spoint + a_spoint) > 0
        AND round BETWEEN 1 AND ?
      ORDER BY g_date DESC, g_num DESC
      LIMIT 20`,
    sp ? [season, gPart, sp, regRounds] : [season, gPart, regRounds]);
  return rows.map(r => {
    const sets = [];
    for (let i = 1; i <= 5; i++) {
      const h = r[`h_s${i}point`], a = r[`a_s${i}point`];
      if (h || a) sets.push(`${h}-${a}`);
    }
    return { round: `${r.round}라운드`, date: fmtDate(r.g_date), home: r.h_code, away: r.a_code, sets };
  });
}

// 우리 팀 정규리그 일정 — 일정이 먼저 올라오는 경우가 많아서 '일정 테이블의 최신 정규시즌'을 따로 골라요.
// (예: 10월 개막 전에는 순위는 2025-26인데 일정은 2026-27이 이미 들어와 있을 수 있어요)
async function getGames(db, gPart, sp, okCode, regRounds) {
  const spSql = sp ? 'AND s_part = ?' : '';
  const [[{ s: season } = {}]] = await db.query(
    `SELECT MAX(season) AS s FROM kovo_game_schedule
      WHERE g_part = ? ${spSql} AND CAST(season AS UNSIGNED) < 100`, sp ? [gPart, sp] : [gPart]);
  if (!season) return { season: null, list: [] };
  const [rows] = await db.query(
    `SELECT round, g_num, g_date, g_stime, h_code, a_code, h_sname, a_sname, h_spoint, a_spoint,
            h_s1point, h_s2point, h_s3point, h_s4point, h_s5point,
            a_s1point, a_s2point, a_s3point, a_s4point, a_s5point
       FROM kovo_game_schedule
      WHERE season = ? AND g_part = ? ${spSql} AND (h_code = ? OR a_code = ?) AND round BETWEEN 1 AND ?
      ORDER BY g_date, g_stime, g_num`,
    sp ? [season, gPart, sp, okCode, okCode, regRounds] : [season, gPart, okCode, okCode, regRounds]);
  const seen = new Set();
  const list = rows.filter(r => !seen.has(r.g_num) && seen.add(r.g_num)).map(r => {
    const home = String(r.h_code) === String(okCode);
    const done = (Number(r.h_spoint) + Number(r.a_spoint)) > 0;
    const sets = [];
    for (let i = 1; i <= 5; i++) {
      const h = r[`h_s${i}point`], a = r[`a_s${i}point`];
      if (h || a) sets.push(`${h}-${a}`);
    }
    return {
      round: Number(r.round), date: isoDate(r.g_date), time: hhmm(r.g_stime),
      home, opponent: home ? r.a_sname : r.h_sname, opponentId: home ? r.a_code : r.h_code,
      score: done ? (home ? [r.h_spoint, r.a_spoint] : [r.a_spoint, r.h_spoint]) : null,   // [우리, 상대]
      sets: done ? (home ? sets : sets.map(x => x.split('-').reverse().join('-'))) : [],     // 우리 점수가 앞
    };
  });
  return { season, list };
}

// 리그 전체 정규리그 일정 — 네이버 일정표처럼 '날짜 → 그날 경기들'로 보여줄 때 써요.
async function getSchedule(db, gPart, sp, okCode, regRounds) {
  const spSql = sp ? 'AND s_part = ?' : '';
  const [[{ s: season } = {}]] = await db.query(
    `SELECT MAX(season) AS s FROM kovo_game_schedule
      WHERE g_part = ? ${spSql} AND CAST(season AS UNSIGNED) < 100`, sp ? [gPart, sp] : [gPart]);
  if (!season) return { season: null, list: [] };
  const [rows] = await db.query(
    `SELECT round, g_num, g_date, g_stime, h_code, a_code, h_sname, a_sname, h_spoint, a_spoint,
            h_s1point, h_s2point, h_s3point, h_s4point, h_s5point,
            a_s1point, a_s2point, a_s3point, a_s4point, a_s5point
       FROM kovo_game_schedule
      WHERE season = ? AND g_part = ? ${spSql} AND round BETWEEN 1 AND ?
      ORDER BY g_date, g_stime, g_num`,
    sp ? [season, gPart, sp, regRounds] : [season, gPart, regRounds]);
  const seen = new Set();
  const list = rows.filter(r => !seen.has(r.g_num) && seen.add(r.g_num)).map(r => {
    const done = (Number(r.h_spoint) + Number(r.a_spoint)) > 0;
    const sets = [];
    for (let i = 1; i <= 5; i++) {
      const h = r[`h_s${i}point`], a = r[`a_s${i}point`];
      if (h || a) sets.push(`${h}-${a}`);
    }
    return {
      round: Number(r.round), date: isoDate(r.g_date), time: hhmm(r.g_stime),
      home: { id: String(r.h_code), name: r.h_sname }, away: { id: String(r.a_code), name: r.a_sname },
      us: String(r.h_code) === String(okCode) || String(r.a_code) === String(okCode),
      score: done ? [Number(r.h_spoint), Number(r.a_spoint)] : null, sets: done ? sets : [],
    };
  });
  return { season, list };
}

/* ---------- 능력치: 리그 백분위(0~100) ---------- */
function withAbility(players, minSets) {
  const pool = players.filter(p => (p.sets || 0) >= minSets);
  const keys = { atk: 'atk', srv: 'ace', blk: 'blk', dig: 'dig', rcv: 'rcv', set: 'set' };
  const dist = {};
  for (const [ab, k] of Object.entries(keys)) {
    dist[ab] = pool.map(p => p.season[k]).filter(v => v != null).sort((a, b) => a - b);
  }
  const pct = (ab, v) => {
    const arr = dist[ab];
    if (v == null || !arr.length) return 0;
    let n = 0; for (const x of arr) if (x <= v) n++;
    return Math.round(n / arr.length * 100);
  };
  return players.map(({ sets, ...p }) => ({
    ...p,
    ability: Object.fromEntries(Object.entries(keys).map(([ab, k]) => [ab, pct(ab, p.season[k])])),
  }));
}

/* ---------- util ---------- */
function isoDate(s) {
  if (s instanceof Date) return s.toISOString().slice(0, 10);
  const m = String(s || '').replace(/\D/g, '').match(/^(\d{4})(\d{2})(\d{2})/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : '';
}
function hhmm(s) {   // '19:00', '1900', '19:00:00', '1400' → '19:00'
  const m = String(s || '').trim().match(/^(\d{1,2}):?(\d{2})/);
  return m ? `${m[1].padStart(2, '0')}:${m[2]}` : '';
}
function round(v, d) { return v == null ? null : Math.round(Number(v) * 10 ** d) / 10 ** d; }
function fmtDate(s) {
  if (s instanceof Date) s = s.toISOString().slice(0, 10);
  const m = String(s || '').replace(/\D/g, '').match(/^(\d{4})(\d{2})(\d{2})/);
  if (!m) return '';
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return `${+m[2]}.${+m[3]} (${'일월화수목금토'[d.getUTCDay()]})`;
}
