// src/seat-ocr.js — 티켓 사진 → 좌석 구역 인식 (Cloudflare Worker)
// POST /seat-ocr  (multipart/form-data, 필드 이름 'photo')
// 응답: { zone:'1-12', row:'3', seat:'7', confidence:'high' }   · 못 읽으면 { zone:null }
//
// 준비
//  1) Anthropic API 키를 Worker 비밀값으로 넣기:  npx wrangler secret put ANTHROPIC_API_KEY
//  2) 라우터(src/index.js 등)에 연결:
//       import { handleSeatOcr } from './seat-ocr.js';
//       if (url.pathname === '/seat-ocr' && request.method === 'POST') return handleSeatOcr(request, env);
//  ※ API 키는 이 Worker 안에서만 써요 — 화면 코드(index.js)에는 절대 넣지 마세요.

const MODEL = 'claude-haiku-5-5';            // 이미지 읽기 · 짧은 답이라 Haiku로 충분해요
const MAX_BYTES = 5 * 1024 * 1024;           // 화면에서 1600px JPEG로 줄여 보내서 보통 0.3~0.8MB

// 앱의 구역 목록과 같아야 해요 (배치도 기준)
const VALID = new Set([
  ...Array.from({ length: 18 }, (_, i) => `1-${i + 1}`),
  ...Array.from({ length: 23 }, (_, i) => `2-${i + 1}`),
  ...Array.from({ length: 14 }, (_, i) => `3-${i + 1}`),
  'HT', 'suite',
]);

const PROMPT = `이 사진은 배구 경기 입장권(종이 티켓 또는 모바일 티켓 화면)이에요.
좌석 정보를 읽어서 아래 JSON 한 줄로만 답하세요. 설명 · 마크다운 · 코드블록 없이 JSON만.
{"zone": "...", "row": "...", "seat": "...", "confidence": "high|low"}

규칙
- zone: 구역 번호를 "층-번호" 형식으로 (예: "1-12", "2-20", "3-8"). 티켓에 "1층 12구역", "112구역", "A-12"처럼 적혀 있어도
  층과 구역 번호가 분명하면 "1-12"처럼 바꿔 주세요. 확실하지 않으면 추측하지 말고 null.
- 하이테이블석이면 "HT", 스위트박스면 "suite".
- row(열) · seat(번호)는 숫자만, 없으면 null.
- 사진이 옆으로 누워 있거나(가로로 찍음) 거꾸로 있을 수 있어요. 글자 방향을 머릿속으로 바로 세워서 읽어 주세요.
- 티켓이 사진 일부만 차지하거나 비스듬해도 좌석 정보 부분(층 · 구역 · 열 · 번)을 찾아서 읽어 주세요.
- 티켓이 아니거나 글자를 읽을 수 없으면 {"zone": null}.`;

export async function handleSeatOcr(request, env) {
  const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
    status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });
  try {
    if (!env.ANTHROPIC_API_KEY) return json({ zone: null, error: 'not_configured' }, 503);
    const form = await request.formData();
    const file = form.get('photo');
    if (!file || typeof file === 'string') return json({ zone: null, error: 'no_photo' }, 400);
    if (file.size > MAX_BYTES) return json({ zone: null, error: 'too_large' }, 413);
    const type = /^image\/(jpeg|png|webp|gif)$/.test(file.type) ? file.type : 'image/jpeg';

    // 이미지를 base64로
    const bytes = new Uint8Array(await file.arrayBuffer());
    let bin = ''; for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    const data = btoa(bin);

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 200,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: type, data } },
          { type: 'text', text: PROMPT },
        ] }],
      }),
    });
    if (!res.ok) return json({ zone: null, error: 'ai_' + res.status }, 502);
    const out = await res.json();
    const text = (out.content || []).map(c => c.text || '').join('').trim();
    const m = text.match(/\{[\s\S]*\}/);
    const parsed = m ? JSON.parse(m[0]) : {};

    // 앱 구역 목록에 있는 값만 돌려줘요 (AI가 엉뚱한 값을 말해도 걸러요)
    let zone = typeof parsed.zone === 'string' ? parsed.zone.trim() : null;
    if (zone && /^HT\d?$/i.test(zone)) zone = 'HT';   // 예전 HT1 · HT2도 하나로
    if (zone && !VALID.has(zone)) zone = null;
    const clean = v => (v == null ? null : String(v).replace(/[^0-9]/g, '') || null);
    return json({ zone, row: zone ? clean(parsed.row) : null, seat: zone ? clean(parsed.seat) : null, confidence: zone ? (parsed.confidence === 'low' ? 'low' : 'high') : null });
  } catch (e) {
    return json({ zone: null, error: 'failed' }, 500);
  }
}
