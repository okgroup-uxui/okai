// src/taps.js — 화면 이용 횟수 (출석체크 · 좌석 안내 · 시야 보기 · 선수 카드 · 경기 기록 · 경기 예측 · MVP 투표 · 설문)
//
//  POST /tap/{경기ID}            관람객 화면이 10초마다 모아서 보내요  { device, taps:{ 이름:횟수 } }
//  GET  /admin/{경기ID}/taps     관리자 대시보드 — [{ key, total, people }]  (total = 누른 횟수 · people = 누른 사람 수)
//
//  · 경기마다 Durable Object 하나 (SQLite 저장) — 같은 기기 · 같은 항목은 한 줄에 횟수만 더해요
//  · 준비: wrangler.jsonc에 바인딩 TAPS(class TapCounter)와 migration(new_sqlite_classes) 추가 — 아래 README 참고

const KEY = /^(checkin|seat_guide|seat_view|games|predict|mvp|survey|card:\d{1,3})$/;
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });

export class TapCounter {
  constructor(ctx, env) {
    this.sql = ctx.storage.sql;
    this.sql.exec('CREATE TABLE IF NOT EXISTS taps (k TEXT NOT NULL, d TEXT NOT NULL, n INTEGER NOT NULL, PRIMARY KEY (k, d))');
  }
  async fetch(req) {
    if (req.method === 'POST') {
      let body; try { body = JSON.parse(await req.text()); } catch (e) { return json({ ok: false, error: 'bad_json' }, 400); }
      const device = String(body.device || '').replace(/[^\w-]/g, '').slice(0, 40);
      const taps = body.taps && typeof body.taps === 'object' ? body.taps : null;
      if (!device || !taps) return json({ ok: false, error: 'bad_request' }, 400);
      let rows = 0;
      for (const [k, v] of Object.entries(taps)) {
        const n = Math.floor(Number(v));
        if (!KEY.test(k) || !(n >= 1)) continue;
        this.sql.exec('INSERT INTO taps (k, d, n) VALUES (?, ?, ?) ON CONFLICT (k, d) DO UPDATE SET n = n + excluded.n', k, device, Math.min(n, 50));
        if (++rows >= 30) break;   // 한 번에 너무 많이 보내면 잘라요
      }
      return json({ ok: true });
    }
    if (req.method === 'GET') {
      const list = this.sql.exec('SELECT k AS key, SUM(n) AS total, COUNT(*) AS people FROM taps GROUP BY k ORDER BY total DESC').toArray();
      return json({ taps: list });
    }
    if (req.method === 'DELETE') { this.sql.exec('DELETE FROM taps'); return json({ ok: true }); }   // 리허설 정리용
    return json({ ok: false }, 405);
  }
}

// 라우터에서 부르는 함수
export async function handleTap(req, env, match) {
  if (!env.TAPS) return json({ ok: false, error: 'not_configured' }, 503);
  if (!/^[\w-]{1,64}$/.test(match)) return json({ ok: false, error: 'bad_match' }, 400);
  const stub = env.TAPS.get(env.TAPS.idFromName(match));
  return stub.fetch(new Request('https://taps/', { method: req.method, body: req.method === 'POST' ? await req.text() : undefined }));
}
