/* ===== 관리자 ===== */
const $ = id => document.getElementById(id);
const esc = v => String(v ?? '').replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));
const fmt = n => Number(n || 0).toLocaleString();
const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
const today = () => { const t = new Date(); return new Date(t.getTime() - t.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
const time = ts => ts ? new Date(ts).toLocaleString('ko-KR', { month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit' }) : '';
const fmtStart = v => { const d = new Date(v); if(isNaN(d)) return v; const p = n => String(n).padStart(2, '0'); return `${d.getMonth() + 1}.${d.getDate()} (${'일월화수목금토'[d.getDay()]}) ${p(d.getHours())}:${p(d.getMinutes())}`; };
const hm = v => v ? v.replace('T', ' ').slice(5, 16) : '';
const mask = c => { c = String(c || ''); if(c.includes('@')){ const [a, b] = c.split('@'); return a.slice(0, 2) + '***@' + b; } const d = c.replace(/\D/g, ''); return d.length >= 8 ? `${d.slice(0, 3)}-****-${d.slice(-4)}` : c.replace(/\d/g, '*'); };

let D = null, page = 'dash', timer = null, busy = false;
let MATCHES = [];
const ADMIN_API = location.origin;
const base = () => ADMIN_API;
const uid = () => sessionStorage.getItem('adm_id') || '';
const key = () => sessionStorage.getItem('adm_key') || '';
const mid = () => $('match').value || today();

function toast(msg, err){ const t = $('toast'); t.textContent = msg; t.className = 'toast show' + (err ? ' err' : ''); clearTimeout(t._t); t._t = setTimeout(()=> t.className = 'toast', 2200); }

const ERR_TEXT = {
  nothing_to_reset:'지울 항목을 골라주세요.', forbidden:'이 계정 권한으로는 할 수 없는 작업이에요. 총괄 관리자에게 부탁해주세요.',
  bad_user_id:'아이디는 영문·숫자 3~30자로 넣어주세요.', duplicate_user:'같은 아이디가 있어요.', weak_password:'비밀번호는 8자 이상으로 넣어주세요.',
  password_required:'새 계정은 비밀번호가 필요해요.', wrong_password:'지금 비밀번호가 맞지 않아요.', env_owner_password:'총괄 관리자 비밀번호는 Cloudflare 환경변수(ADMIN_KEY)에서 바꿔요.',
  roulette_needs_8:'룰렛은 8칸이 모두 있어야 해요.', roulette_all_zero:'확률이 모두 0이에요. 하나 이상 넣어주세요.', home_too_large:'이미지가 너무 커요. 더 작은 이미지를 써주세요.', busy:'서버가 잠시 바빠요. 조금 뒤 다시 눌러주세요.', content_too_large:'등록하려는 내용이 너무 커요. 출석 이미지 수를 줄여주세요.',
  library_too_large:'보관함이 너무 커요. 안 쓰는 설문을 지워주세요.', code_required:'코드를 입력해주세요.',
};
const SERVER_NEED = '2026-10-16.cheer';
async function call(method, path, body){
  const res = await fetch(`${base()}/admin/${path}`, {
    method, headers:{ 'Content-Type':'application/json', 'X-Admin-Id': uid(), 'X-Admin-Key': key() },
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await res.json().catch(() => ({}));
  if(res.status === 401) throw new Error('아이디 또는 비밀번호가 맞지 않아요. 5번 틀리면 10분 동안 잠겨요.');
  if(res.status === 429 && d.error === 'locked'){
    const t = new Date(d.until), p = n => String(n).padStart(2, '0');
    throw new Error(`로그인을 여러 번 틀려서 ${p(t.getHours())}:${p(t.getMinutes())}까지 잠겼어요. 급하면 총괄 관리자에게 잠금 풀기를 부탁해주세요.`);
  }
  if(res.status === 404 && d.error === 'not_found') throw new Error('서버(okman-live)가 아직 이 기능을 몰라요. Cloudflare에 최신 index.js를 다시 배포해 주세요.');
  if(!res.ok) throw new Error(ERR_TEXT[d.error] || d.error || `서버 오류 (${res.status})`);
  return d;
}
const mcall = (method, action, body) => call(method, encodeURIComponent(mid()) + (action ? '/' + action : ''), body);

/* ===== 관리자 콘텐츠 ===== */
const PRED_DEF = [
  { id:'first_point', q:'첫 득점 팀은 어디일까요?', options:['OK저축은행 읏맨', '상대팀'], ai:true, aiKind:'first_point' },
  { id:'first_block', q:'첫 블로킹을 성공시킬 선수는?', type:'player', ai:true, aiKind:'block' },
  { id:'set_score', q:'세트 스코어를 예측해보세요', options:['3:0', '3:1', '3:2', '2:3 이하'], ai:true, aiKind:'set_score' },
];
const DEFAULT_NOTICES = [
  '**당첨 즉시 하단 버튼을 눌러 이미지 저장 또는 캡처해주세요.** 교환권은 **다음 날 저녁 11시 59분까지 다시 볼 수 있으며, 이후 파기**돼요. (교환권 재발행 불가)',
  '경품 수령처에서 직원에게 교환권을 보여주세요. (교환권으로 입장 불가)',
  '**교환은 이벤트 기간 중 홈경기가 있는 날에 한해 가능**하며, 기간 연장 및 분실 시 재발행이 안 돼요.',
  '중복 수령이 불가하며, 부정 참여 시 당첨이 취소될 수 있어요.',
  '유효기간이 지난 교환권은 사용할 수 없어요.',
  '당첨된 경품의 타인 양도 및 판매는 원칙적으로 금지예요.',
];

const ROSTER = ["#1 김정호", "#3 정성현", "#4 배하준", "#5 김도훈", "#6 김대환", "#7 신장호", "#8 차지환", "#10 페이즈", "#11 박원빈", "#12 전광인", "#14 송희채", "#15 노재욱", "#16 진상헌", "#17 박창성", "#19 진성태", "#20 윤경", "#21 백창진", "#22 박인우", "#31 김준호", "#40 러셀"];

const AI_KIND = {
  team:   { win:'경기 승리 팀', first_point:'첫 득점 팀', set1:'1세트 승리 팀', set_score:'세트 스코어', none:'AI 추천 없음' },
  player: { attack:'공격 득점', block:'블로킹', serve:'서브 에이스', dig:'디그·수비', none:'AI 추천 없음' },
};
function guessAiKind(q){
  const t = String(q.q || '').replace(/\s/g, '');
  if(q.type === 'player'){
    if(/블로킹|블록|가로막/.test(t)) return 'block';
    if(/서브|에이스/.test(t)) return 'serve';
    if(/디그|수비|리시브/.test(t)) return 'dig';
    return 'attack';
  }
  const opts = (q.options || []).map(x => String(x).trim()).filter(Boolean);
  if(opts.length && opts.filter(o => /\d\s*:\s*\d/.test(o)).length >= Math.ceil(opts.length / 2) || /세트스코어|스코어/.test(t)) return 'set_score';
  if(/(1|첫|첫번째)세트/.test(t)) return 'set1';
  if(/첫득점|선취|첫점|먼저득점|첫포인트/.test(t)) return 'first_point';
  if(/이길|이기|승리|승자|승부|누가이/.test(t)) return 'win';
  return 'none';
}
const aiKindOf = q => (q.aiFix && q.aiKind) || guessAiKind(q);
const SURV_DEF = [{"id": "1", "q": "오늘 경기장 좌석 안내는 찾기 쉬웠나요?", "type": "single", "options": ["매우 쉬움", "쉬움", "보통", "어려움"]}, {"id": "2", "q": "오늘 응원 분위기는 어땠나요?", "type": "single", "options": ["최고였어요", "좋았어요", "보통이었어요", "아쉬웠어요"]}, {"id": "3", "q": "다음에도 직관하러 오실 의향이 있나요?", "type": "single", "options": ["꼭 다시 올게요", "아마도요", "잘 모르겠어요"]}, {"id": "4", "q": "경기장 내 편의시설(매점·화장실 등)은 만족스러웠나요?", "type": "single", "options": ["매우 만족", "만족", "보통", "불만족"]}];
const CK_DEF = [
  { key:'gender', q:'성별을 알려주세요', opts:['남성', '여성'].map(label => ({ label })) },
  { key:'age', q:'나이대를 골라주세요', opts:['10대 이하', '20대', '30대', '40대', '50대', '60대 이상'].map(label => ({ label })) },
  { key:'company', q:'누구와 함께 오셨나요?', opts:['혼자', '가족(자녀 동반)', '가족(성인만)', '연인', '친구·지인', '단체(직장·학교·동호회)'].map(label => ({ label })) },
];
const LIMIT = { predictQ:5, predictO:6, surveyQ:25, surveyO:25, gridRows:15, gridCols:7, ckQ:3, ckO:6 };
const SV_TYPE = { single:'단일 선택', multi:'복수 선택', nps:'NPS 0~10', grid:'행렬 척도' };
const canon = v => JSON.stringify(v, (k, x) => x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map(key => [key, x[key]])) : x);
const clone = v => JSON.parse(JSON.stringify(v));
const CT = () => ((D && D.settings) || {}).content || {};
let DR = {};
function saveContent(patch, msg){ return act(()=> mcall('PUT', 'settings', { content:{ ...CT(), ...patch } }), msg); }

/* ===== 설문 엑셀 ===== */
function parseSurveyRows(rows){
  const warn = [];
  const norm = v => String(v ?? '').replace(/\r/g, '').trim();
  const h = rows.findIndex(r => r.some(c => norm(c) === '번호') && r.some(c => norm(c).startsWith('문항')));
  if(h < 0) throw new Error("'번호'와 '문항' 머리글이 있는 줄을 찾지 못했어요.");
  const head = rows[h].map(c => norm(c).replace(/\s/g, ''));
  const col = k => head.findIndex(c => c.startsWith(k));
  const cN = col('번호'), cQ = col('문항'), cT = col('응답유형'), cO = col('선택지'), cE = col('기타');
  const items = [];
  for(const r of rows.slice(h + 1)){
    const q = norm(r[cQ]);
    if(!q) continue;
    const id = (norm(r[cN]).replace(/\.0+$/, '') || String(items.length + 1)).replace(/[^\w-]/g, '');
    const typeTxt = cT >= 0 ? norm(r[cT]) : '', optTxt = cO >= 0 ? norm(r[cO]) : '', note = cE >= 0 ? norm(r[cE]) : '';
    const lines = optTxt.split('\n').map(s => s.trim()).filter(Boolean);
    const it = { id, q };
    if(/NPS|0\s*~\s*10/i.test(typeTxt)){
      it.type = 'nps';
      const m = optTxt.match(/0\s*점?\s*\(([^)]*)\)\s*~\s*10\s*점?\s*\(([^)]*)\)/);
      it.low = m ? m[1].trim() : '전혀 아니다'; it.high = m ? m[2].trim() : '매우 그렇다';
    } else if(/척도|행렬|그리드/.test(typeTxt) || lines.some(l => /^\[행\]/.test(l))){
      it.type = 'grid';
      it.rows = lines.filter(l => /^\[행\]/.test(l)).map(l => l.replace(/^\[행\]\s*/, ''));
      const cl = lines.find(l => /^\[열\]/.test(l));
      it.cols = cl ? cl.replace(/^\[열\]\s*/, '').split('/').map(s => s.trim()).filter(Boolean) : ['매우 불만족', '불만족', '보통', '만족', '매우 만족'];
      if(!it.rows.length) warn.push(`${id}번: 행렬형인데 '[행]' 항목이 없어요.`);
    } else {
      it.type = /복수/.test(typeTxt) ? 'multi' : 'single';
      if(it.type === 'multi'){ const m = typeTxt.match(/최대\s*(\d+)/); if(m) it.max = Number(m[1]); }
      if(!typeTxt) warn.push(`${id}번: 응답 유형이 비어 있어서 단일 선택으로 넣었어요.`);
      it.options = lines.map(l => { if(/^기타\s*\(\s*직접\s*입력\s*\)$/.test(l)){ it.other = true; return '기타'; } return l; });
      if(/주관식/.test(typeTxt) && !it.other && it.options.includes('기타')) it.other = true;
      if(/주관식/.test(note) && !it.other) it.comment = true;
      if(it.options.length < 2) warn.push(`${id}번: 선택지가 2개보다 적어요.`);
      if(/\(1개\)/.test(q) && it.type === 'multi') warn.push(`${id}번: 문항엔 '(1개)'인데 응답 유형은 복수 선택(최대 ${it.max || '제한 없음'})이에요. 응답 유형대로 넣었어요.`);
    }
    const pm = id.match(/^(\d+)-\d+$/);
    if(pm){
      const parent = items.find(x => x.id === pm[1]);
      if(!parent || !parent.options) warn.push(`${id}번: 앞 문항 ${pm[1]}번을 찾지 못해 모두에게 보여요.`);
      else {
        const hit = parent.options.filter(o => o !== '기타' && note.includes(o));
        if(/이상/.test(note)) it.cond = { id:parent.id, notIn:[parent.options[0]] };
        else if(hit.length && /제외|이외|아닌|말고/.test(note)) it.cond = { id:parent.id, notIn:hit };
        else {
          if(hit.length) it.cond = { id:parent.id, in:hit };
          else { const sib = [...items].reverse().find(x => x.cond && x.cond.id === parent.id); if(sib) it.cond = JSON.parse(JSON.stringify(sib.cond)); }
        }
        const ref = note.match(/(\d+)\s*번에서/);
        if(ref && ref[1] !== parent.id) warn.push(`${id}번: 기타 칸엔 '${ref[1]}번에서'라고 돼 있지만, 번호가 ${id}라서 ${parent.id}번 답에 따라 보여줘요.`);
        if(!it.cond) warn.push(`${id}번: 보여줄 조건을 찾지 못해 모두에게 보여요.`);
      }
    }
    items.push(it);
  }
  if(!items.length) throw new Error('문항이 하나도 없어요.');
  return { items, warn };
}

function surveyToRows(items){
  const rows = [['읏배구놀이터 관람 설문'], ['응답 유형: 단일 선택 · 복수 가능(최대 N개) · NPS (0~10점) · 척도 (5점, 행렬형) · 단일 선택 + 기타 주관식  |  선택지는 줄바꿈으로 구분  |  1-1처럼 번호를 붙이면 앞 문항 답에 따라 보여요'],
                ['번호', '문항', '응답 유형', '선택지', '기타']];
  for(const it of items){
    let type, opts, note = [];
    if(it.type === 'nps'){ type = 'NPS (0~10점)'; opts = `0점(${it.low || ''}) ~ 10점(${it.high || ''})`; }
    else if(it.type === 'grid'){ type = `척도 (${it.cols.length}점, 행렬형)`; opts = [...it.rows.map(r => '[행] ' + r), '[열] ' + it.cols.join(' / ')].join('\n'); }
    else {
      type = it.type === 'multi' ? `복수 가능${it.max ? `(최대 ${it.max}개)` : ''}` : '단일 선택';
      if(it.other) type += ' + 기타 주관식';
      opts = it.options.map(o => it.other && o === '기타' ? '기타(직접 입력)' : o).join('\n');
    }
    if(it.cond) note.push(it.cond.in ? `${it.cond.id}번에서 ${it.cond.in.join(', ')}를 선택할 시` : `${it.cond.id}번에서 ${it.cond.notIn.join(', ')} 제외`);
    if(it.comment) note.push('주관식 의견칸');
    rows.push([it.id, it.q, type, opts, note.join(' / ')]);
  }
  return rows;
}

let xlsxLib = null;
function loadXlsx(){
  if(window.XLSX) return Promise.resolve(window.XLSX);
  if(xlsxLib) return xlsxLib;
  xlsxLib = new Promise((res, rej)=>{
    const sc = document.createElement('script');
    sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
    sc.onload = ()=> res(window.XLSX); sc.onerror = ()=>{ xlsxLib = null; rej(new Error('엑셀 도구를 불러오지 못했어요. 인터넷 연결을 확인해주세요.')); };
    document.head.appendChild(sc);
  });
  return xlsxLib;
}
async function readSurveyFile(file){
  const X = await loadXlsx();
  const wb = X.read(await file.arrayBuffer(), { type:'array' });
  let lastErr = null;
  for(const name of wb.SheetNames){
    const rows = X.utils.sheet_to_json(wb.Sheets[name], { header:1, defval:'', raw:false });
    try{ return { sheet:name, ...parseSurveyRows(rows) }; }catch(e){ lastErr = e; }
  }
  throw lastErr || new Error('읽을 시트가 없어요.');
}
async function downloadSurveyXlsx(items, title){
  const X = await loadXlsx();
  const ws = X.utils.aoa_to_sheet(surveyToRows(items));
  ws['!cols'] = [{ wch:7 }, { wch:46 }, { wch:24 }, { wch:34 }, { wch:30 }];
  const wb = X.utils.book_new(); X.utils.book_append_sheet(wb, ws, '설문지');
  X.writeFile(wb, `읏배구놀이터_설문_${String(title || mid()).replace(/[\\/:*?"<>|]/g, '_')}.xlsx`);
}
const condText = c => !c ? '' : `${c.id}번에서 ${c.in ? `'${c.in.join("', '")}' 고르면` : `'${c.notIn.join("', '")}' 말고 고르면`} 보여요`;
function svBadges(q){
  const b = [`<span class="chip off">${SV_TYPE[q.type] || '단일 선택'}${q.type === 'multi' && q.max ? ` · 최대 ${q.max}개` : ''}</span>`];
  if(q.other) b.push('<span class="chip off">기타 직접 입력</span>');
  if(q.comment) b.push('<span class="chip off">자유 의견칸</span>');
  if(q.shuffle || q.shuffleRows) b.push('<span class="chip off">순서 섞기</span>');
  if(q.cond) b.push(`<span class="chip">${esc(condText(q.cond))}</span>`);
  return b.join('');
}
function svOptsText(q){
  if(q.type === 'nps') return `0점(${q.low || ''}) ~ 10점(${q.high || ''})`;
  if(q.type === 'grid') return `${q.rows.join(' · ')}  ▸  ${q.cols.join(' / ')}`;
  return (q.options || []).join(' · ');
}

let MOD = null;
function openModal(html, dark){ $('modal-box').style.maxWidth = ''; $('modal-box').className = 'modal__box' + (dark ? ' dark' : ''); $('modal-box').innerHTML = html; $('modal').hidden = false; }
function closeModal(){ $('modal').hidden = true; MOD = null; }
$('modal').addEventListener('click', e=>{ if(e.target.id === 'modal' || e.target.closest('[data-act="modal-x"]')) closeModal(); });
document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && !$('modal').hidden) closeModal(); });

const SCALE = {
  easy: { 3:['쉬웠어요', '보통이에요', '어려웠어요'], 4:['매우 쉬움', '쉬움', '어려움', '매우 어려움'], 5:['매우 쉬움', '쉬움', '보통', '어려움', '매우 어려움'] },
  good: { 3:['좋았어요', '보통이에요', '아쉬웠어요'], 4:['최고였어요', '좋았어요', '보통이었어요', '아쉬웠어요'], 5:['최고였어요', '좋았어요', '보통이었어요', '아쉬웠어요', '별로였어요'] },
  sat:  { 3:['만족', '보통', '불만족'], 4:['매우 만족', '만족', '불만족', '매우 불만족'], 5:['매우 만족', '만족', '보통', '불만족', '매우 불만족'] },
  again:{ 3:['꼭 다시 올게요', '아마도요', '잘 모르겠어요'], 4:['꼭 다시 올게요', '아마도요', '잘 모르겠어요', '아닐 것 같아요'], 5:['다음 홈경기에 또 올게요', '이번 시즌 안에 올게요', '아마도요', '잘 모르겠어요', '아닐 것 같아요'] },
};
const SURVEY_BANK = [
  ['오늘 경기장 좌석 안내는 찾기 쉬웠나요?', 'easy'], ['오늘 응원 분위기는 어땠나요?', 'good'], ['다음에도 직관하러 오실 의향이 있나요?', 'again'],
  ['경기장 내 편의시설(매점·화장실 등)은 만족스러웠나요?', 'sat'], ['경기장까지 오는 길은 편했나요?', 'easy'], ['읏배구놀이터(이 화면)는 쓰기 편했나요?', 'easy'],
  ['오늘 현장 이벤트는 어땠나요?', 'good'], ['경기장 입장·퇴장은 원활했나요?', 'sat'], ['오늘 경기는 재미있었나요?', 'good'],
  ['응원 도구·굿즈는 만족스러웠나요?', 'sat'], ['막차·교통 안내가 도움이 됐나요?', 'sat'], ['친구에게 직관을 추천하고 싶나요?', 'again'],
];
function genSurvey(nq, na){
  const pool = SURVEY_BANK.slice(); const out = [];
  while(out.length < nq && pool.length){ const [q, sc] = pool.splice(Math.floor(Math.random() * pool.length), 1)[0]; out.push({ id:String(out.length + 1), q, type:'single', options:SCALE[sc][na].slice() }); }
  return out;
}
function shrinkImage(file, size){
  return new Promise((res, rej)=>{
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = ()=>{
      const S = size || 96, r = Math.min(S / img.width, S / img.height, 1);
      const cv = document.createElement('canvas'); cv.width = S; cv.height = S;
      const g = cv.getContext('2d'); const w = img.width * r, h = img.height * r;
      g.drawImage(img, (S - w) / 2, (S - h) / 2, w, h);
      URL.revokeObjectURL(url);
      let out = cv.toDataURL('image/webp', .8); if(!out.startsWith('data:image/webp')) out = cv.toDataURL('image/png');
      res(out);
    };
    img.onerror = ()=>{ URL.revokeObjectURL(url); rej(new Error('이미지를 읽지 못했어요.')); };
    img.src = url;
  });
}

/* ---------- 로그인 ---------- */
$('uid').value = uid();
async function login(){
  const id = $('uid').value.trim(), pw = $('key').value;
  if(!id || !pw){ $('gate-status').textContent = '아이디와 비밀번호를 입력해주세요.'; $('gate-status').className = 'status err'; return; }
  sessionStorage.setItem('adm_id', id);
  sessionStorage.setItem('adm_key', pw);
  $('gate-status').textContent = '연결하는 중…'; $('gate-status').className = 'status';
  try{ await start(); }
  catch(e){ $('gate-status').textContent = e.message === 'Failed to fetch' ? '서버에 연결하지 못했어요. 잠시 후 다시 시도해주세요.' : e.message; $('gate-status').className = 'status err'; sessionStorage.removeItem('adm_key'); }
}
$('login').addEventListener('click', login);
['uid','key'].forEach(id => $(id).addEventListener('keydown', e => { if(e.key === 'Enter' && !e.isComposing) login(); }));
$('logout').addEventListener('click', ()=>{ sessionStorage.removeItem('adm_id'); sessionStorage.removeItem('adm_key'); clearInterval(timer); location.reload(); });
if(uid() && key()) start().catch(()=>{});

let ME = { role:'owner', name:'' };
const ROLE_NAME = { owner:'총괄 관리자', manager:'일반 관리자', staff:'부스 담당' };
const ROLE_DESC = {
  owner:'전부 — 계정 관리 · 데이터 초기화 · 응모 삭제 · 룰렛·배너(경품·확률)까지',
  manager:'경기 운영 전부 — 경기 진행·설문·예측·MVP·추첨·금칙어 (초기화·계정·룰렛 경품은 빼고)',
  staff:'조회 + 교환 코드 처리만 (부스용)',
};
const isOwner = () => ME.role === 'owner';
const isStaff = () => ME.role === 'staff';
const isAdmin = () => !isStaff();
/* ===== 경기 선택 목록 ===== */
function fillMatches(matches, want){
  const ids = [...new Set([today(), ...Object.keys(matches || {})])].sort().reverse();
  MATCHES = ids;
  if(want && !ids.includes(want)) ids.unshift(want);
  $('match').innerHTML = ids.map(id => `<option value="${id}">${id}${id === today() ? ' (오늘)' : ''}</option>`).join('')
    + `<option value="__new">+ 다른 경기 ID 입력</option>`;
  $('match').value = want || today();
}
async function refreshMatches(want){
  const { matches } = await call('GET', '_/matches');
  fillMatches(matches, want);
  DR = {}; SUBC.mid = '';
  SEASON.at = 0; SEASON.rows = {}; SEASON.taps = {}; TAPS.for = '';
  await load();
}
async function start(){
  const { matches } = await call('GET', '_/matches');
  try{ ME = await call('GET', '_/me'); }catch(e){ ME = { id:uid(), name:uid(), role:'owner' }; }
  const nm = ME.name || ME.id, rn = ROLE_NAME[ME.role] || ME.role;
  $('who').textContent = nm === rn ? nm : `${nm} · ${rn}`;
  if(isStaff()) page = 'codes';
  fillMatches(matches, new URLSearchParams(location.search).get('match'));
  $('gate').hidden = true; $('app').hidden = false;
  await load();
  setAuto(AUTO);
}
$('match').addEventListener('change', ()=>{
  if($('match').value === '__new'){
    const raw = (prompt('경기 ID를 입력하세요 — 영문·숫자·_·- 만 (예: test-1, 2026-10-31)') || '').trim();
    const v = raw.replace(/[^\w-]/g, '').slice(0, 64);
    if(raw && v !== raw) alert(`경기 ID에는 영문·숫자·_·- 만 쓸 수 있어요.\n'${v || '(빈 값)'}'(으)로 바꿨어요.`);
    if(v){
      if(![...$('match').options].some(o => o.value === v)){ const o = document.createElement('option'); o.value = v; o.textContent = v + ' (테스트)'; $('match').insertBefore(o, $('match').firstChild); }
      $('match').value = v;
    }
    else $('match').value = today();
  }
  DR = {}; SUBC.mid = '';
  load();
});

function syncSiteLink(){ const id = mid(); $('open-site').href = 'index.html' + (id === today() ? '' : '?match=' + encodeURIComponent(id)); }
const SUBC = { mid:'', since:0, map:{} };
let AUTO = (()=>{ try{ return localStorage.getItem('adm_auto') === '1'; }catch(e){ return false; } })();
let LAST_LOAD = 0;
function setAuto(on){
  AUTO = !!on; try{ localStorage.setItem('adm_auto', AUTO ? '1' : '0'); }catch(e){}
  clearInterval(timer);
  if(AUTO) timer = setInterval(()=>{ if(!document.hidden && !busy && !document.activeElement.matches('input,textarea,select')) load(true); }, 30000);
  stampLoad();
}
function stampLoad(){
  const el = $('auto'); if(!el) return;
  const t = LAST_LOAD ? new Date(LAST_LOAD) : null, p = n => String(n).padStart(2, '0');
  el.classList.toggle('off', !AUTO);
  el.innerHTML = `<span class="auto__t" title="1분이 지나면 노랗게 바뀌어요 — 새로고침을 눌러 주세요">${t ? `${p(t.getHours())}:${p(t.getMinutes())}:${p(t.getSeconds())} 기준` : '불러오는 중…'}</span>
    <button type="button" class="btn small ghost" data-reload>새로고침</button>
    <label class="auto__sw" title="켜면 30초마다 자동으로 불러와요"><input type="checkbox" data-auto${AUTO ? ' checked' : ''}> 자동</label>`;
}
document.addEventListener('click', e=>{ if(e.target.closest('[data-reload]')){ load(); loadTaps(true); loadMatchVisits(true); toast('새로 불러왔어요'); } });
document.addEventListener('change', e=>{ if(e.target.matches('[data-auto]')) setAuto(e.target.checked); });

/* ---------- 결정 버튼 직전 새로고침 ---------- */
const FRESH_ACTS = new Set(['rf-draw', 'rf-save', 'mvp-set', 'mvp-clear', 'ans-save', 'save-start', 'clear-start', 'save-opp', 'rf-clear', 'rs-do', 'pred-save', 'home-save', 'reset-cheer', 'pz-add', 'ev-add']);
let FRESH_PASS = false;
function freshSelector(el){
  const attrs = [...el.attributes].filter(a => a.name.startsWith('data-')).map(a => `[${a.name}="${CSS.escape(a.value)}"]`).join('');
  const box = el.closest('#phase, #dayopen');
  return (box ? '#' + box.id + ' ' : '') + el.tagName.toLowerCase() + attrs;
}
document.addEventListener('click', async e=>{
  if(FRESH_PASS) return;
  const b = e.target.closest('[data-act], #phase [data-v], #dayopen [data-v]'); if(!b) return;
  const critical = b.matches('#phase [data-v], #dayopen [data-v]') || FRESH_ACTS.has(b.dataset.act);
  if(!critical || Date.now() - LAST_LOAD < 3000) return;
  e.preventDefault(); e.stopImmediatePropagation();
  const sel = freshSelector(b);
  b.classList.add('is-loading'); b.setAttribute('aria-busy', 'true');
  try{ await load(true); }catch(err){}
  const again = document.querySelector('#main ' + sel) || document.querySelector(sel) || (b.isConnected ? b : null);
  b.classList.remove('is-loading'); b.removeAttribute('aria-busy');
  if(!again){ toast('화면이 바뀌었어요. 다시 눌러 주세요.', true); return; }
  FRESH_PASS = true; try{ again.click(); } finally { FRESH_PASS = false; }
}, true);

/* ---------- 창으로 돌아오면 새로고침 ---------- */
function backToWindow(){ if(!document.hidden && LAST_LOAD && Date.now() - LAST_LOAD > 15000 && !busy) load(true); }
document.addEventListener('visibilitychange', backToWindow);
addEventListener('focus', backToWindow);

/* ---------- 오래된 데이터 표시 ---------- */
setInterval(()=>{ const t = document.querySelector('.auto__t'); if(t) t.classList.toggle('stale', !!LAST_LOAD && Date.now() - LAST_LOAD > 60000); }, 5000);

async function load(quiet){
  syncSiteLink();
  const m = mid();
  try{
    const fresh = SUBC.mid !== m || !SUBC.since;
    const d = await call('GET', encodeURIComponent(m) + (fresh ? '' : '?since=' + SUBC.since));
    if(mid() !== m) return;
    if(fresh || d.subsMode !== 'delta') SUBC.map = {};
    for(const [t, arr] of Object.entries(d.subs || {})){
      const mp = SUBC.map[t] || (SUBC.map[t] = new Map());
      arr.forEach(r => mp.set(r.k || t + ':' + r.device, r));
    }
    d.subs = Object.fromEntries(Object.entries(SUBC.map).map(([t, mp]) => [t, [...mp.values()]]));
    SUBC.mid = m; SUBC.since = d.now || 0;
    const sig = JSON.stringify([d.total, d.settings, d.content, d.visits, d.errors, d.winners, d.prizes, d.events, d.raffleWinners, d.redeemed,
      Object.fromEntries(Object.entries(d.subs || {}).map(([k, v]) => [k, v.length]))]);
    const changed = sig !== load.sig || mid() !== load.mid; load.sig = sig; load.mid = mid();
    D = d; LAST_LOAD = Date.now(); stampLoad();
    if(changed || !quiet) render();
  }
  catch(e){ if(!quiet) toast(e.message, true); }
}

/* ===== 집계 ===== */
/* ===== 설문 · 예측 버전 ===== */
function buildVersions(kind, rows){
  const hist = ((D.history || {})[kind]) || [];
  const live = kind === 'survey' ? D.survey : null;
  const curHas = kind === 'survey' ? !!live : Array.isArray(CT()[kind]) && CT()[kind].length;
  const cur = kind === 'survey' ? (live ? live.v : 0) : curHas ? (Number((CT()[kind + 'Ver'] || {}).v) || 0) : 0;
  const map = new Map();
  const add = (v, at, items, title) => { if(!map.has(v)) map.set(v, { v, at, items, title:'', rows:[] }); const x = map.get(v); if(items && !x.items) x.items = items; if(at && !x.at) x.at = at; if(title && !x.title) x.title = title; return x; };
  hist.forEach(h => add(h.v, h.at, h.items, h.title));
  add(cur, null, null);
  rows.forEach(r => { const d = r.data || {}; add(d.ver == null ? 'none' : Number(d.ver) || 0, null, null).rows.push(r); });
  if(map.has(0) && !map.get(0).items) map.get(0).items = clone(kind === 'survey' ? SURV_DEF : PRED_DEF);
  return [...map.values()].map(x => ({ ...x, current:x.v === cur }))
    .sort((a, b) => (a.v === 'none') - (b.v === 'none') || (b.v === 'none' ? 0 : b.v - a.v));
}
const vLabel = v => v === 'none' ? '이전 응답' : v === 0 ? '기본 문항' : 'v' + v;
const ansKey = (v, id) => (v === 'none' || v === 0) ? id : `v${v}_${id}`;
function derivePredQs(rows, fallback){
  const m = new Map();
  for(const r of rows) for(const q of ((r.data || {}).questions) || []) if(!m.has(q.id)) m.set(q.id, { id:q.id, q:q.q });
  if(!m.size && fallback) return fallback;
  return [...m.values()];
}
function deriveSurvQs(rows){
  const m = new Map();
  for(const r of rows) for(const a of (r.data || {}).answers || []) if(!m.has(a.q)) m.set(a.q, { q:a.q, type:'single', options:null });
  return [...m.values()];
}
const ansVals = a => Array.isArray(a.a) ? a.a.map(String) : a.a == null || a.a === '' ? [] : [typeof a.a === 'number' ? `${a.a}점` : String(a.a)];
function surveyAgg(it, rows){
  const out = { ...it, n:0, etc:[], memo:[] };
  const find = r => ((r.data || {}).answers || []);
  if(it.type === 'grid'){
    out.cells = it.rows.map(() => new Array(it.cols.length).fill(0));
    for(const r of rows){
      let any = false;
      for(const a of find(r)){
        if(a.group !== it.id) continue;
        const ri = Number(String(a.id).split(':')[1]), ci = it.cols.indexOf(a.a);
        if(out.cells[ri] && ci >= 0){ out.cells[ri][ci]++; any = true; }
      }
      if(any) out.n++;
    }
    return out;
  }
  const counts = {};
  if(it.type === 'nps') out.dist = new Array(11).fill(0);
  for(const r of rows){
    const a = find(r).find(x => it.id != null && x.id != null ? String(x.id) === String(it.id) : x.q === it.q);
    if(!a || a.a == null || a.a === '' || (Array.isArray(a.a) && !a.a.length)) continue;
    out.n++;
    if(it.type === 'nps'){ const v = Number(a.a); if(v >= 0 && v <= 10) out.dist[v]++; }
    else for(const x of ansVals(a)) counts[x] = (counts[x] || 0) + 1;
    if(a.etc) out.etc.push({ t:a.etc, at:r.at });
    if(a.memo) out.memo.push({ t:a.memo, at:r.at });
  }
  out.counts = counts;
  const o = it.options || null;
  out.order = o ? [...o, ...Object.keys(counts).filter(k => !o.includes(k))] : null;
  if(it.type === 'nps' && out.n){
    const d = out.dist, sum = d.reduce((acc, c, i) => acc + c * i, 0);
    const pro = d[9] + d[10], det = d.slice(0, 7).reduce((x, y) => x + y, 0);
    out.avg = sum / out.n; out.nps = Math.round((pro - det) / out.n * 100);
    out.pro = pro; out.det = det; out.pas = out.n - pro - det;
  }
  return out;
}
function textList(title, list, key){
  if(!list.length) return '';
  return `<details class="tlist" data-open-key="${esc(key || title)}"><summary>${title} ${list.length}건</summary>${list.slice().sort((a, b) => (b.at || 0) - (a.at || 0)).map(x => `<p>${esc(x.t)}<span>${time(x.at)}</span></p>`).join('')}</details>`;
}
function surveyCard(q){
  const head = `<h2 style="align-items:flex-start;"><span>${esc(q.id != null ? q.id + '. ' : '')}${esc(q.q)}</span><span class="muted" style="font-size:13px; font-weight:600; white-space:nowrap;">응답 ${fmt(q.n)}명</span></h2>
    <p class="m" style="margin:2px 0 12px;">${q.type ? svBadges(q) : ''}</p>`;
  let bodyHtml;
  if(!q.n) bodyHtml = '<p class="empty">아직 응답이 없어요.</p>';
  else if(q.type === 'nps'){
    const max = Math.max(1, ...q.dist);
    bodyHtml = `<div class="kpis" style="grid-template-columns:repeat(3,1fr); margin-bottom:12px;">
        <div class="kpi hot"><span>NPS</span><b>${q.nps > 0 ? '+' : ''}${q.nps}</b></div>
        <div class="kpi"><span>평균</span><b>${q.avg.toFixed(1)}점</b></div>
        <div class="kpi"><span>추천 9~10 · 중립 7~8 · 비추천 0~6</span><b style="font-size:18px;">${pct(q.pro, q.n)}% · ${pct(q.pas, q.n)}% · ${pct(q.det, q.n)}%</b></div></div>
      <div class="hours nps-d">${q.dist.map((c, i) => `<div class="${i >= 9 ? 'pro' : i >= 7 ? 'pas' : 'det'}" title="${i}점 ${c}명">${c ? `<b>${c}</b>` : ''}<i style="height:${c / max * 84}%"></i><em>${i}</em></div>`).join('')}</div>
      <p class="desc" style="margin-top:8px;">NPS = 9~10점 비율 − 0~6점 비율 · 0점 ${esc(q.low || '')} / 10점 ${esc(q.high || '')}</p>`;
  }
  else if(q.type === 'grid'){
    bodyHtml = `<div class="scroll"><table class="gtab"><thead><tr><th>항목</th><th>평균</th><th style="width:44%;">분포 (${q.cols.map(esc).join(' → ')})</th>${q.cols.map(c => `<th class="num">${esc(c)}</th>`).join('')}</tr></thead><tbody>
      ${q.rows.map((row, ri) => { const c = q.cells[ri], n = c.reduce((a, b) => a + b, 0), avg = n ? c.reduce((a, x, i) => a + x * (i + 1), 0) / n : 0;
        return `<tr><td><b>${esc(row)}</b></td><td><b>${n ? avg.toFixed(2) : '—'}</b><span class="muted"> / ${q.cols.length}</span></td>
          <td><span class="stack">${c.map((x, i) => x ? `<i style="width:${x / n * 100}%; opacity:${(0.25 + 0.75 * i / (q.cols.length - 1)).toFixed(2)}" title="${esc(q.cols[i])} ${x}명"></i>` : '').join('')}</span></td>
          ${c.map(x => `<td class="num muted">${x}</td>`).join('')}</tr>`; }).join('')}
    </tbody></table></div>`;
  }
  else bodyHtml = bars(q.counts, { order:q.order || undefined, base:q.n, multi:q.type === 'multi' })
    ;
  return `<section class="card">${head}${bodyHtml}${textList("'기타' 직접 입력", q.etc || [], 'etc:' + q.id)}${textList('자유 의견', q.memo || [], 'memo:' + q.id)}</section>`;
}
function vTabs(kind, list, extra){
  const sel = DR.tab && DR.tab[kind];
  const pick = list.some(v => String(v.v) === String(sel)) || (extra && sel === extra[0]) ? sel : String((list.find(v => v.current) || list[0] || {}).v);
  DR.tab = { ...(DR.tab || {}), [kind]:pick };
  return { pick, html:`<div class="seg vtabs">${list.map(v => `<button data-vtab="${kind}" data-v="${v.v}" class="${String(v.v) === pick ? 'on' : ''}">${vLabel(v.v)}${v.title ? ' ' + esc(v.title.length > 14 ? v.title.slice(0, 13) + '…' : v.title) : ''}${v.current ? ' · 지금' : ''} <em>${v.rows.length}</em></button>`).join('')}
    ${extra ? `<button data-vtab="${kind}" data-v="${extra[0]}" class="${pick === extra[0] ? 'on' : ''}">${extra[1]}</button>` : ''}</div>` };
}
const vMeta = (v, unit) => `${vLabel(v.v)}${v.title ? ` '${esc(v.title)}'` : ''}${v.at ? ` · ${time(v.at)} 등록` : ''} · ${unit} ${fmt(v.rows.length)}명${v.current ? ' · 지금 관람객에게 나가는 문항' : ''}${v.v === 'none' ? ' · 버전 기능을 넣기 전에 쌓인 응답이에요' : ''}`;

function downloadCsv(name, rows){
  const cell = v => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  const text = '\ufeff' + rows.map(r => r.map(cell).join(',')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type:'text/csv;charset=utf-8' }));
  a.download = `읏배구놀이터_${name}_${mid()}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=> URL.revokeObjectURL(a.href), 4000);
}
const csvTime = ts => { if(!ts) return ''; const d = new Date(ts); const p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };
function csvSurvey(){
  const S = stats(), out = [['버전', '설문 제목', '버전 등록 시각', '응답 시각', '기기', '문항 번호', '유형', '질문', '답변', '점수', '기타 직접 입력', '자유 의견']];
  const TY = { ...SV_TYPE, grid:'행렬 척도' };
  for(const v of S.sv) for(const r of v.rows) ((r.data || {}).answers || []).forEach((a, i) => out.push([
    vLabel(v.v), v.title || '', csvTime(v.at), csvTime(r.at), String(r.device || '').slice(-6), a.id != null ? String(a.id).replace(/:(\d+)$/, (m, n) => `-${Number(n) + 1}행`) : i + 1,
    TY[a.type] || '', a.q, Array.isArray(a.a) ? a.a.join(' / ') : a.a, a.score ?? (typeof a.a === 'number' ? a.a : ''), a.etc || '', a.memo || '']));
  if(out.length === 1) return toast('아직 설문 응답이 없어요.', true);
  downloadCsv('설문', out);
}
function csvPredict(){
  const S = stats(), ans = (D.settings || {}).answers || {}, out = [['버전', '버전 등록 시각', '응답 시각', '기기', '질문', '예측', '정답', '맞힘']];
  for(const v of S.pred.versions) for(const r of v.rows){
    const t = (r.data || {}).text || {};
    v.questions.forEach(q => { const a = ans[q.key] || ''; out.push([vLabel(v.v), csvTime(v.at), csvTime(r.at), String(r.device || '').slice(-6), q.q, t[q.id] || '', a, a ? (t[q.id] === a ? 'O' : 'X') : '']); });
  }
  if(out.length === 1) return toast('아직 예측 응답이 없어요.', true);
  downloadCsv('경기예측', out);
}

function stats(){
  const s = D.subs || {};
  const answers = (D.settings || {}).answers || {};
  const pv = buildVersions('predict', s.predictions || []);
  pv.forEach(v => {
    const qs = v.v === 'none' || !v.items ? derivePredQs(v.rows, v.items) : v.items;
    v.questions = qs.map(q => {
      const counts = {};
      for(const r of v.rows){ const x = ((r.data || {}).text || {})[q.id]; if(x) counts[x] = (counts[x] || 0) + 1; }
      const opts = q.type === 'player' ? ROSTER : (!q.options ? null : q.options);
      return { id:q.id, q:q.q, counts, key:ansKey(v.v, q.id), order: opts ? [...opts, ...Object.keys(counts).filter(k => !opts.includes(k))] : null };
    });
    const withAns = v.questions.filter(q => answers[q.key]);
    v.answered = withAns.length;
    v.allCorrect = new Set();
    if(withAns.length) for(const r of v.rows){ const t = (r.data || {}).text || {}; if(withAns.every(q => t[q.id] === answers[q.key])) v.allCorrect.add(r.device); }
  });
  const pred = { count:(s.predictions || []).length, versions:pv, allCorrect:new Set(pv.flatMap(v => [...v.allCorrect])) };
  const mvp = {};
  for(const r of s.mvp || []){ const d = r.data || {}; if(d.num == null) continue; const k = String(d.num); mvp[k] = mvp[k] || { num:d.num, name:d.name || '', n:0 }; mvp[k].n++; }
  const mvpRank = Object.values(mvp).sort((a, b) => b.n - a.n);
  const sq = new Map();
  for(const r of s.survey || []) for(const a of (r.data || {}).answers || []){
    if(!sq.has(a.q)) sq.set(a.q, {}); const c = sq.get(a.q);
    for(const x of ansVals(a)) c[x] = (c[x] || 0) + 1;
  }
  const sv = buildVersions('survey', s.survey || []);
  sv.forEach(v => { v.questions = (v.items || deriveSurvQs(v.rows)).map(it => surveyAgg(it, v.rows)); });
  const ck = { count:(s.checkin || []).length, by:{} };
  for(const r of s.checkin || []) for(const [k, v] of Object.entries(r.data || {})){
    if(typeof v !== 'string' || k === 'ts') continue;
    (ck.by[k] = ck.by[k] || {})[v] = (ck.by[k][v] || 0) + 1;
  }
  const rl = { spins:0, wins:[], byTitle:{} };
  for(const r of s.roulette || []) for(const w of (r.data || {}).wins || []){
    rl.spins++;
    if(w.miss) { rl.byTitle['꽝'] = (rl.byTitle['꽝'] || 0) + 1; continue; }
    rl.byTitle[w.title] = (rl.byTitle[w.title] || 0) + 1;
    rl.wins.push({ code:w.code, title:w.title, at:w.ts, device:r.device.slice(-4), type:'룰렛' });
  }
  const predDev = new Set((s.predictions || []).map(r => r.device)), survDev = new Set((s.survey || []).map(r => r.device));
  const raffle = (s.raffle_entry || []).map(r => {
    const d = r.data || {};
    return { ...d, at:r.at || d.at, device:r.device, name: d.nickname || mask(d.contact),
             viaPredict: !!d.predicted || predDev.has(r.device) || d.source === 'predict',
             viaSurvey: !!d.surveyed || survDev.has(r.device) || d.source === 'survey' };
  });
  return { pred, mvpRank, sq, sv, ck, rl, raffle };
}

/* ===== 화면 ===== */
const PAGES = [
  ['dash', '대시보드'], ['events', '현장 이벤트'], ['cheer', '응원 이벤트'], ['predict', '경기 예측'],
  ['mvp', 'MVP 투표'], ['survey', '설문'], ['raffle', '경품 응모·추첨'], ['codes', '룰렛·교환 코드'], ['checkin', '출석체크'],
  ['home', '룰렛·배너'], ['settings', '설정'],
];
const STAFF_PAGES = ['dash', 'codes', 'settings'];
function render(){
  const keep = {}, keepHtml = {};
  if(render.last === page){
    document.querySelectorAll('#main input[id], #main select[id], #main textarea[id]').forEach(el=> keep[el.id] = el.value);
    ['rf-result', 'code-result'].forEach(id=>{ if($(id)) keepHtml[id] = $(id).innerHTML; });
  }
  const openKeys = render.last === page ? [...document.querySelectorAll('#main details[open][data-open-key]')].map(d => d.dataset.openKey) : [];
  render.last = page;
  const S = stats(); window.__S = S;
  const count = { cheer:fmt(D.total), predict:S.pred.count, mvp:S.mvpRank.reduce((a, b) => a + b.n, 0), survey:(D.subs.survey || []).length,
                  raffle:S.raffle.length, codes:S.rl.wins.length + (D.winners || []).length, checkin:S.ck.count, events:(D.events || []).filter(e => e.active !== false).length };
  if(isStaff() && !STAFF_PAGES.includes(page)) page = 'codes';
  const GROUPS = [['경기 당일', ['dash', 'events', 'cheer']], ['참여 이벤트', ['predict', 'mvp', 'survey', 'checkin']], ['경품', ['raffle', 'codes', 'home']], ['관리', ['settings']]];
  const NAME = Object.fromEntries(PAGES);
  $('nav').innerHTML = GROUPS.map(([g, keys]) => {
    const ks = keys.filter(k => NAME[k] && (!isStaff() || STAFF_PAGES.includes(k)));
    if(!ks.length) return '';
    return `<div class="navbox"><p class="navgrp">${g}</p>`
      + ks.map(k => `<button class="${k === page ? 'on' : ''}" data-page="${k}">${NAME[k]}${count[k] != null ? `<em>${count[k]}</em>` : ''}</button>`).join('') + `</div>`;
  }).join('');
  const oldServer = D.serverVersion !== SERVER_NEED;
  $('main').innerHTML = (oldServer ? `<div class="winbox" style="background:#FFF1EC; color:#C2410C; margin:0 0 16px;"><b>서버(okman-live)가 최신 버전이 아니에요</b>
      <p style="font-size:13px; margin-top:4px;">지금 서버: ${esc(D.serverVersion || '버전 정보 없음(예전 버전)')} · 필요한 버전: ${SERVER_NEED}<br>설정 › 데이터 초기화, 설문 보관함, 접속자처럼 새로 넣은 기능이 '서버가 이 기능을 몰라요'로 실패해요. Cloudflare › okman-live › Edit code에 최신 index.js를 붙여넣고 Deploy해 주세요.</p></div>` : '')
    + (VIEWS[page] || VIEWS.dash)(S);
  Object.entries(keep).forEach(([id, v])=>{ const el = $(id); if(el) el.value = v; });
  Object.entries(keepHtml).forEach(([id, h])=>{ if($(id)) $(id).innerHTML = h; });
  openKeys.forEach(k => { const d = document.querySelector(`#main details[data-open-key="${CSS.escape(k)}"]`); if(d) d.open = true; });
  addPageHelp();
  (AFTER[page] || (()=>{}))(S);
}
$('nav').addEventListener('click', e=>{ const b = e.target.closest('[data-page]'); if(!b) return; page = b.dataset.page; render(); scrollTo(0, 0); load(true); });
$('main').addEventListener('click', e=>{ const b = e.target.closest('button[data-page]'); if(!b) return; page = b.dataset.page; render(); scrollTo(0, 0); });

const bars = (counts, opts = {}) => {
  const entries = (opts.order || Object.keys(counts)).map(k => [k, counts[k] || 0]);
  if(!opts.order) entries.sort((a, b) => b[1] - a[1]);
  const total = opts.base || entries.reduce((a, b) => a + b[1], 0), max = Math.max(1, ...entries.map(e => e[1]));
  return entries.map(([k, n], i) => `<div class="bar${i === 0 && !opts.order && n ? ' top' : ''}${opts.answer === k ? ' answer' : ''}">
    <span class="l" title="${esc(k)}">${opts.answer === k ? '✓ ' : ''}${esc(k)}</span>
    <span class="tr"><span class="f" style="width:${n / max * 100}%"></span></span>
    <span class="n">${n}명 · ${pct(n, total)}%</span></div>`).join('') || '<p class="empty">아직 응답이 없어요.</p>';
};

/* ---------- 설문 편집기 ---------- */
function chipList(i, k, list, max, min, ph){
  return list.map((o, j) => `<span class="ochip"><input data-ed="survey" data-i="${i}" data-j="${j}" data-f="${k}" value="${esc(o)}" maxlength="40" placeholder="${ph}" aria-label="${ph} ${j + 1}"><button data-act="ed-odel" data-ed="survey" data-k="${k}" data-i="${i}" data-j="${j}" aria-label="삭제"${list.length <= min ? ' disabled' : ''}>×</button></span>`).join('')
    + (list.length < max ? `<button class="btn small ghost" data-act="ed-oadd" data-ed="survey" data-k="${k}" data-i="${i}">추가</button>` : '');
}
function sEditor(){
  const list = DR.survey;
  return list.map((q, i) => `<div class="qed">
    <div class="qed__head"><b>${esc(q.id || i + 1)}번</b>
      <select class="in" style="width:auto; height:34px;" data-ed="survey" data-i="${i}" data-f="type" aria-label="응답 유형">${Object.entries(SV_TYPE).map(([k, t]) => `<option value="${k}"${q.type === k ? ' selected' : ''}>${t}</option>`).join('')}</select>
      ${q.type === 'multi' ? `<label class="chk">최대 <input class="in" type="number" min="0" max="25" style="width:64px; height:34px;" data-ed="survey" data-i="${i}" data-f="max" value="${q.max || ''}" placeholder="제한 없음">개</label>` : ''}
      <span style="flex:1"></span>
      <button class="btn small ghost" data-act="ed-del" data-ed="survey" data-i="${i}"${list.length <= 1 ? ' disabled' : ''}>삭제</button></div>
    ${condEditor(list, q, i)}
    <input class="in" data-ed="survey" data-i="${i}" data-f="q" value="${esc(q.q)}" maxlength="120" placeholder="질문을 입력해주세요">
    ${q.type === 'nps' ? `<div class="opts"><label class="chk">0점 <input class="in" style="width:160px; height:34px;" data-ed="survey" data-i="${i}" data-f="low" value="${esc(q.low || '')}" maxlength="30" placeholder="전혀 추천 안 함"></label>
        <label class="chk">10점 <input class="in" style="width:160px; height:34px;" data-ed="survey" data-i="${i}" data-f="high" value="${esc(q.high || '')}" maxlength="30" placeholder="적극 추천"></label></div>`
    : q.type === 'grid' ? `<p class="desc" style="margin:10px 0 0;">평가 항목 (행)</p><div class="opts" style="margin-top:6px;">${chipList(i, 'rows', q.rows, LIMIT.gridRows, 1, '평가 항목')}</div>
        <p class="desc" style="margin:10px 0 0;">척도 (열)</p><div class="opts" style="margin-top:6px;">${chipList(i, 'cols', q.cols, LIMIT.gridCols, 2, '척도')}</div>
        <div class="opts"><label class="chk"><input type="checkbox" data-ed="survey" data-i="${i}" data-f="shuffleRows"${q.shuffleRows ? ' checked' : ''}>평가 항목 순서 섞기 <span class="muted">(사람마다 다르게 · 척도는 고정)</span></label></div>`
    : `<div class="opts">${chipList(i, 'options', q.options, LIMIT.surveyO, 2, '선택 항목')}</div>
       <div class="opts"><label class="chk"><input type="checkbox" data-ed="survey" data-i="${i}" data-f="other"${q.other ? ' checked' : ''}>'기타' 고르면 직접 입력</label>
         <label class="chk"><input type="checkbox" data-ed="survey" data-i="${i}" data-f="comment"${q.comment ? ' checked' : ''}>아래 자유 의견칸 (선택)</label>
         <label class="chk"><input type="checkbox" data-ed="survey" data-i="${i}" data-f="shuffle"${q.shuffle ? ' checked' : ''}>보기 순서 섞기 <span class="muted">(사람마다 다르게)</span></label></div>`}
  </div>`).join('');
}
function condParents(list, i){ return list.slice(0, i).filter(x => (x.type === 'single' || x.type === 'multi' || !x.type) && (x.options || []).some(o => String(o).trim())); }
function condEditor(list, q, i){
  const parents = condParents(list, i);
  if(!q.cond) return parents.length ? `<p class="desc" style="margin:0 0 8px;"><button class="btn small ghost" data-act="sv-cond-add" data-i="${i}">+ 조건 추가</button></p>` : '';
  const c = q.cond, parent = parents.find(x => String(x.id) === String(c.id)) || parents[0];
  const mode = c.notIn ? 'notIn' : 'in', picked = new Set((c.in || c.notIn || []).map(String));
  const opts = parent ? (parent.options || []).map(o => String(o).trim()).filter(Boolean) : [];
  return `<div class="desc" style="margin:0 0 10px; padding:10px 12px; border-radius:10px; background:var(--fill, rgba(127,127,127,.08));">
    <div style="display:flex; flex-wrap:wrap; align-items:center; gap:6px;"><span class="chip">조건</span>
      <select class="in" style="width:auto; height:32px;" data-cond="id" data-i="${i}" aria-label="기준 문항">${parents.map(x => `<option value="${esc(x.id)}"${parent && String(x.id) === String(parent.id) ? ' selected' : ''}>${esc(x.id)}번 ${esc(String(x.q || '').slice(0, 18))}</option>`).join('')}</select>
      <span>에서</span>
      <select class="in" style="width:auto; height:32px;" data-cond="mode" data-i="${i}" aria-label="조건 방식"><option value="in"${mode === 'in' ? ' selected' : ''}>아래를 고르면</option><option value="notIn"${mode === 'notIn' ? ' selected' : ''}>아래 말고 고르면</option></select>
      <span>보여요</span><span style="flex:1"></span>
      <button class="btn small ghost" data-act="sv-nocond" data-i="${i}">조건 없애기</button></div>
    <div class="opts" style="margin-top:8px;">${opts.map(o => `<label class="chk"><input type="checkbox" data-cond="opt" data-i="${i}" value="${esc(o)}"${picked.has(o) ? ' checked' : ''}>${esc(o)}</label>`).join('')}</div>
    ${picked.size ? '' : '<p class="muted" style="margin:6px 0 0;">보기를 하나 이상 골라 주세요.</p>'}</div>`;
}
function setSvType(q, t){
  q.type = t;
  if((t === 'single' || t === 'multi') && !(q.options || []).length) q.options = ['', ''];
  if(t === 'grid'){ if(!(q.rows || []).length) q.rows = ['']; if(!(q.cols || []).length) q.cols = ['매우 불만족', '불만족', '보통', '만족', '매우 만족']; }
  if(t === 'nps'){ if(q.low == null) q.low = '전혀 추천 안 함'; if(q.high == null) q.high = '적극 추천'; }
}
function validSurvey(list){
  const ids = new Set();
  for(const [i, q] of list.entries()){
    const no = q.id || i + 1;
    if(ids.has(String(q.id))) return `${no}번 번호가 겹쳐요.`; ids.add(String(q.id));
    if(!String(q.q || '').trim()) return `${no}번 질문을 입력해주세요.`;
    const uniq = (arr, what, min) => { const o = (arr || []).map(x => String(x).trim()).filter(Boolean); if(o.length < min) return `${no}번 ${what}을 ${min}개 이상 넣어주세요.`; if(new Set(o).size !== o.length) return `${no}번에 같은 ${what}이 있어요.`; return ''; };
    let e = '';
    if(q.type === 'grid') e = uniq(q.rows, '평가 항목', 1) || uniq(q.cols, '척도', 2);
    else if(q.type !== 'nps') e = uniq(q.options, '선택 항목', 2);
    if(e) return e;
    if(q.cond && !(q.cond.in || q.cond.notIn || []).length) return `${no}번 조건의 보기를 하나 이상 골라주세요. 조건이 필요 없으면 '조건 없애기'를 눌러주세요.`;
    if(q.cond){
      const parent = list.slice(0, i).find(x => String(x.id) === String(q.cond.id));
      if(!parent) return `${no}번 조건의 ${q.cond.id}번 문항이 앞에 없어요. '조건 없애기'를 누르거나 문항을 다시 넣어주세요.`;
    }
  }
  return '';
}
function cleanSurvey(list){
  const t = arr => (arr || []).map(x => String(x).trim()).filter(Boolean);
  return list.map((q, i) => {
    const it = { id:String(q.id || i + 1), q:q.q.trim(), type:q.type || 'single' };
    if(it.type === 'nps'){ it.low = String(q.low || '').trim(); it.high = String(q.high || '').trim(); }
    else if(it.type === 'grid'){ it.rows = t(q.rows); it.cols = t(q.cols); }
    else {
      it.options = t(q.options);
      if(it.type === 'multi' && Number(q.max) > 0) it.max = Math.min(it.options.length, Math.floor(Number(q.max)));
      if(q.other){ it.other = true; if(!it.options.includes('기타')) it.options.push('기타'); }
      if(q.shuffle) it.shuffle = true;
    }
    if(it.type === 'grid' && q.shuffleRows) it.shuffleRows = true;
    if(q.comment && it.type !== 'grid') it.comment = true;
    if(q.cond) it.cond = q.cond;
    return it;
  });
}
/* ---------- 설문 보관함 ---------- */
const LIB = { surveys:[], defaultId:'', at:0, loading:false };
async function loadLib(){
  if(LIB.loading) return; LIB.loading = true;
  try{ const d = await call('GET', '_/surveys'); LIB.surveys = d.surveys || []; LIB.defaultId = d.defaultId || ''; LIB.at = Date.now(); }
  catch(e){ LIB.err = e.message; LIB.at = Date.now(); }
  finally{ LIB.loading = false; }
  if(page === 'survey') render();
}
function saveLib(next, msg){
  return act(()=> call('PUT', '_/surveys', next), msg).then(ok =>{ if(ok){ LIB.surveys = next.surveys; LIB.defaultId = next.defaultId; loadLib(); } return ok; });
}
const libIdx = i => LIB.surveys[i];
function svList(items){ return items.map(q => `<div class="row"><div class="main"><p class="t">${esc(q.id)}. ${esc(q.q)}</p><p class="m" style="margin-top:4px;">${svBadges(q)}</p><p class="m">${esc(svOptsText(q))}</p></div></div>`).join(''); }

function svNextId(){ return String(Math.max(0, ...DR.survey.map(q => parseInt(q.id, 10) || 0)) + 1); }

/* ---------- 문항 편집기 (예측) ---------- */
function qEditor(kind){
  const P = kind === 'predict';
  const list = DR[kind];
  const maxO = P ? LIMIT.predictO : LIMIT.surveyO;
  return list.map((q, i) => `<div class="qed">
    <div class="qed__head"><b>${P ? '예측 질문' : '설문'} ${i + 1}</b>
      ${P ? `<label class="chk"><input type="checkbox" data-ed="${kind}" data-i="${i}" data-f="ai"${q.ai !== false ? ' checked' : ''}>AI추천 사용</label>${aiKindSel(q, i)}` : ''}
      <button class="btn small ghost" data-act="ed-del" data-ed="${kind}" data-i="${i}"${list.length <= 1 ? ' disabled' : ''}>삭제</button></div>
    <input class="in" data-ed="${kind}" data-i="${i}" data-f="q" value="${esc(q.q)}" maxlength="40" placeholder="질문을 입력해주세요">
    <div class="opts">
      ${q.type === 'player'
        ? `<span class="seg seg--sm" role="group" aria-label="선수 범위">
             <button type="button" data-act="ed-pool" data-v="noL" data-ed="${kind}" data-i="${i}" class="${q.pool === 'all' ? '' : 'on'}">OK저축은행 선수 카드 (리베로 제외 전체)</button>
             <button type="button" data-act="ed-pool" data-v="all" data-ed="${kind}" data-i="${i}" class="${q.pool === 'all' ? 'on' : ''}">OK저축은행 선수 전체 (리베로 포함)</button></span>
           <button class="btn small ghost" data-act="ed-noplayer" data-ed="${kind}" data-i="${i}">직접 입력으로</button>`
        : q.options.map((o, j) => `<span class="ochip"><input data-ed="${kind}" data-i="${i}" data-j="${j}" data-f="opt" value="${esc(o)}" maxlength="20" placeholder="선택 항목" aria-label="선택 항목 ${j + 1}"><button data-act="ed-odel" data-ed="${kind}" data-i="${i}" data-j="${j}" aria-label="항목 삭제"${q.options.length <= 2 ? ' disabled' : ''}>×</button></span>`).join('')
          + (q.options.length < maxO ? `<button class="btn small ghost" data-act="ed-oadd" data-ed="${kind}" data-i="${i}">추가</button>` : '')
          + (P ? `<button class="btn small ghost" data-act="ed-player" data-ed="${kind}" data-i="${i}">선수불러오기</button>` : '')}
    </div></div>`).join('');
}
function aiKindSel(q, i){
  if(q.ai === false) return '';
  const kinds = AI_KIND[q.type === 'player' ? 'player' : 'team'], cur = aiKindOf(q);
  return `<label class="chk aikind">기준 <select class="in" data-ed="predict" data-i="${i}" data-f="aiKind" aria-label="AI 예측 기준">
    ${Object.entries(kinds).map(([k, l]) => `<option value="${k}"${k === cur ? ' selected' : ''}>${l}${!q.aiFix && k === cur ? ' (자동)' : ''}</option>`).join('')}
  </select></label>`;
}
function syncAiKind(q, i){
  const sel = document.querySelector(`select[data-ed="predict"][data-i="${i}"][data-f="aiKind"]`);
  if(!sel || q.aiFix) return;
  const k = guessAiKind(q);
  [...sel.options].forEach(o => { o.textContent = AI_KIND[q.type === 'player' ? 'player' : 'team'][o.value] + (o.value === k ? ' (자동)' : ''); });
  sel.value = k;
}
function validQs(list, kind){
  for(const [i, q] of list.entries()){
    if(!String(q.q || '').trim()) return `${i + 1}번 질문을 입력해주세요.`;
    if(q.type !== 'player'){
      const o = q.options.map(x => String(x).trim()).filter(Boolean);
      if(o.length < 2) return `${i + 1}번 질문의 선택 항목을 2개 이상 넣어주세요.`;
      if(new Set(o).size !== o.length) return `${i + 1}번 질문에 같은 선택 항목이 있어요.`;
    }
  }
  return '';
}
const aiPart = q => q.ai === false ? { ai:false } : { ai:true, aiKind:aiKindOf(q), ...(q.aiFix ? { aiFix:true } : {}) };
const cleanQs = list => list.map((q, i) => q.type === 'player'
  ? { id:q.id || 'q' + (i + 1), q:q.q.trim(), type:'player', ...(q.pool === 'all' ? { pool:'all' } : {}), ...aiPart(q) }
  : { ...(q.id ? { id:q.id } : {}), q:q.q.trim(), options:q.options.map(x => String(x).trim()).filter(Boolean), ...aiPart({ ...q, q:q.q.trim(), options:q.options }) });

function predResults(S){
  const list = S.pred.versions.filter(v => v.rows.length || v.current);
  if(!S.pred.count) return `<section class="card"><p class="empty">아직 예측에 참여한 사람이 없어요.</p></section>`;
  const ans = (D.settings || {}).answers || {};
  const { pick, html } = vTabs('predict', list);
  const v = list.find(x => String(x.v) === pick) || list[0];
  return `<section class="card"><h2>예측 결과</h2>${html}<p class="desc" style="margin:12px 0 0;">${vMeta(v, '참여')}</p></section>
    ${v.answered ? `<div class="kpis" style="grid-template-columns:1fr 1fr 1fr;"><div class="kpi hot"><span>이 버전 전부 맞힌 사람</span><b>${fmt(v.allCorrect.size)}</b></div><div class="kpi"><span>정답 입력</span><b>${v.answered} / ${v.questions.length}</b></div><div class="kpi"><span>전체 전부 맞힌 사람</span><b>${fmt(S.pred.allCorrect.size)}</b></div></div>` : ''}
    ${v.rows.length ? v.questions.map(q => {
      const right = ans[q.key] ? (q.counts[ans[q.key]] || 0) : null;
      const choices = q.order || Object.keys(q.counts).sort();
      return `<section class="card"><h2>${esc(q.q)}${right != null ? `<span class="chip ok">정답 ${right}명</span>` : ''}</h2>
        ${bars(q.counts, { answer:ans[q.key], order:q.order || undefined })}
        <div class="form" style="grid-template-columns:1fr auto;">
          <div class="field" style="grid-column:auto;"><label>정답</label><select data-ans="${esc(q.key)}"><option value="">— 아직 —</option>${choices.map(c => `<option${ans[q.key] === c ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
          <button class="btn dark" data-act="ans-save" style="grid-column:auto; align-self:end;">정답 저장</button>
        </div></section>`; }).join('')
    : `<section class="card"><p class="empty">이 버전에는 아직 참여한 사람이 없어요.</p></section>`}`;
}
function survResults(S){
  const n = (D.subs.survey || []).length;
  if(!n && !(D.subs.survey_progress || []).length) return `<section class="card"><p class="empty">아직 설문 응답이 없어요.</p></section>`;
  const list = S.sv.filter(v => v.rows.length || v.current);
  const { pick, html } = vTabs('survey', list, ['all', '전체 합산']);
  if(pick === 'all') return `<section class="card"><h2>설문 결과</h2>${html}<p class="meta" style="margin:12px 0 0;">응답 ${fmt(n)}명</p></section>
    ${[...S.sq].map(([q, c]) => `<section class="card"><h2>${esc(q)}</h2>${bars(c)}</section>`).join('')}`;
  const v = list.find(x => String(x.v) === pick) || list[0];
  return `<section class="card"><h2>설문 결과</h2>${html}<p class="desc" style="margin:12px 0 0;">${vMeta(v, '응답')}</p></section>
    ${dropoutCard(v)}
    ${v.rows.length ? v.questions.map(surveyCard).join('')
      : `<section class="card"><p class="empty">이 버전에는 아직 응답이 없어요.</p></section>`}`;
}

/* ===== 접속자 ===== */
const TAP_ITEMS = [
  ['checkin', '출석체크'], ['seat_guide', '좌석 안내'], ['seat_view', '시야 보기'], ['games', '경기 기록'],
  ['predict', '경기 예측'], ['mvp', 'MVP 투표'], ['survey', '설문조사'],
];
let TAPS = { for:'', at:0, list:null, error:'' };
async function loadTaps(force){
  const id = mid();
  if(!force && TAPS.for === id && (TAPS.list || TAPS.error) && (!AUTO || Date.now() - TAPS.at < 30000)) return;
  if(!force && TAPS.for === id && !TAPS.list && !TAPS.error && Date.now() - TAPS.at < 10000) return;
  TAPS = { ...TAPS, for:id, at:Date.now() };
  try{ const d = await call('GET', encodeURIComponent(id) + '/taps'); TAPS = { for:id, at:Date.now(), list:d.taps || [], error:'' }; }
  catch(e){ TAPS = { for:id, at:Date.now(), list:null, error:e.message || '불러오지 못했어요' }; }
  render();
}
function tapsBody(list, error, season){
  if(!list && !error) return `<p class="empty">불러오는 중…</p>`;
  if(!list) return `<p class="empty">서버에 '화면 이용' 기능(taps.js)을 배포하면 집계가 시작돼요. <span class="muted">(${esc(error)})</span></p>`;
  TAPS_VIEW = list;
  const by = Object.fromEntries(list.map(r => [r.key, r]));
  const GO = { checkin:'checkin', predict:'predict', mvp:'mvp', survey:'survey' };
  const tiles = TAP_ITEMS.map(([k, t]) => { const r = by[k] || { total:0, people:0 }; return kpi(t, fmt(r.total), '회', `${fmt(r.people)}명이 눌렀어요`, GO[k]); });
  const cards = list.filter(r => /^card:\d+$/.test(r.key)).map(r => {
    const num = r.key.slice(5), name = (ROSTER.find(x => x.startsWith('#' + num + ' ')) || '#' + num).replace(/^#\d+\s*/, '');
    return { num, name, total:r.total, people:r.people }; }).sort((a, b) => b.total - a.total);
  const max = Math.max(1, ...cards.map(c => c.total));
  return `${kpiGrid(tiles)}
    <details style="margin-top:16px;" data-open-key="taps-cards" open><summary style="cursor:pointer; font-weight:700; font-size:14px;">선수 카드 — 선수별로 카드를 연 횟수 (${cards.length}명)</summary>
      <div class="scroll" style="margin-top:8px;"><table class="mtable"><thead><tr><th>순위</th><th>선수</th><th></th><th>횟수</th><th>사람</th></tr></thead><tbody>
      ${cards.length ? cards.map((c, i) => `<tr><td class="muted">${i + 1}</td><td><b>#${esc(c.num)} ${esc(c.name)}</b></td>
        <td style="width:40%;"><span class="tr"><span class="f" style="width:${c.total / max * 100}%"></span></span></td>
        <td><b>${fmt(c.total)}</b>회</td><td class="muted">${fmt(c.people)}명</td></tr>`).join('') : '<tr><td colspan="5" class="empty">아직 선수 카드를 연 기록이 없어요.</td></tr>'}
      </tbody></table></div></details>
    <div class="edfoot" style="margin-top:10px;"><span></span><button class="btn small ghost" data-act="taps-csv" data-season="${season ? 1 : ''}">CSV 내려받기</button></div>`;
}
let TAPS_VIEW = [];
function visitCard(S){
  const v = D.visits;
  const title = '시간대별 접속';
  if(!v) return `<section class="card"><h2>${title}</h2><p class="empty">서버(okman-live)를 이번 버전으로 배포하면 집계가 시작돼요.</p></section>`;
  const hrs = Object.keys(v.hours || {}).map(Number);
  let chart = '<p class="empty" style="padding:40px 0 0;">아직 접속 기록이 없어요.</p>';
  if(hrs.length){
    let lo = Math.min(...hrs), hi = Math.max(...hrs);
    while(hi - lo < 5){ if(lo > 0) lo--; if(hi - lo < 5 && hi < 23) hi++; if(lo === 0 && hi === 23) break; }
    const vals = []; for(let h = lo; h <= hi; h++) vals.push([h, (v.hours || {})[String(h).padStart(2, '0')] || 0]);
    const max = Math.max(1, ...vals.map(x => x[1]));
    chart = `<div class="hours" role="img" aria-label="시간대별 첫 접속">${vals.map(([h, n]) => `<div class="${n === max && n ? 'peak' : ''}" title="${h}시 ${n}명">${n ? `<b>${n}</b>` : ''}<i style="height:${n / max * 84}%"></i><em>${h}시</em></div>`).join('')}</div>`;
  }
  return `<section class="card">
    <h2>시간대별 접속 <span class="muted" style="font-size:12px; font-weight:600;">처음 들어온 시각 기준 · 한국 시간 · 브라우저 연 횟수 ${fmt(v.sessions || 0)}회${v.last ? ` · 마지막 접속 ${time(v.last)}` : ''}</span></h2>
    ${chart}
  </section>`;
}

const MV = { at:0, data:{}, loading:false };
async function loadMatchVisits(force){
  if(MV.loading || (!force && MV.at && (!AUTO || Date.now() - MV.at < 60000))) return;
  MV.loading = true;
  try{
    const ids = MATCHES.filter(id => id && id !== '__new').slice(0, 40);
    const res = await Promise.all(ids.map(id => call('GET', encodeURIComponent(id) + '/visits').then(d => [id, d.visits]).catch(() => [id, null])));
    MV.data = Object.fromEntries(res); MV.at = Date.now();
  } finally { MV.loading = false; }
  if(page === 'dash') render();
}
function matchVisitsCard(){
  if(!D.visits) return '';
  setTimeout(() => loadMatchVisits(), 0);
  const rows = MATCHES.map(id => [id, MV.data[id]]).filter(([, v]) => v && v.unique);
  const max = Math.max(1, ...rows.map(([, v]) => v.unique || 0));
  return `<section class="card"><h2>경기별 접속자 <span class="muted" style="font-size:12px; font-weight:600;">${MV.at ? time(MV.at) + ' 기준 · 1분마다 갱신' : '불러오는 중…'}</span></h2>
    ${rows.length ? `<div class="scroll"><table class="mtable"><thead><tr><th>경기</th><th>접속자</th><th></th><th>브라우저 연 횟수</th><th>첫 접속 ~ 마지막</th></tr></thead><tbody>
      ${rows.map(([id, v]) => `<tr data-goto="${esc(id)}" class="${id === mid() ? 'cur' : ''}"><td><b>${esc(id)}</b>${id === today() ? ' <span class="chip">오늘</span>' : ''}</td>
        <td><b>${fmt(v.unique)}</b>명</td><td style="width:40%;"><span class="tr"><span class="f" style="width:${(v.unique || 0) / max * 100}%"></span></span></td>
        <td class="muted">${fmt(v.sessions)}회</td><td class="muted">${v.first ? time(v.first) + ' ~ ' + time(v.last) : '—'}</td></tr>`).join('')}
    </tbody></table></div>` : `<p class="empty">${MV.at ? '아직 접속 기록이 있는 경기가 없어요.' : '불러오는 중…'}</p>`}
  </section>`;
}
document.addEventListener('click', e=>{
  const r = e.target.closest('[data-goto]'); if(!r) return;
  $('match').value = r.dataset.goto; DR = {}; load(); scrollTo(0, 0);
});

/* ===== 설정 › 데이터 초기화 ===== */
function resetParts(S){
  const subN = t => (D.subs[t] || []).length;
  return [
    { k:'visits',   t:'접속자',                       n:(D.visits || {}).unique || 0, u:'명' },
    { k:'cheer',    t:'응원 수 · 응원 당첨',           n:D.total || 0, u:'회', m:`당첨 ${(D.winners || []).length}건` },
    { k:'checkin',  t:'출석체크 응답',                 n:subN('checkin'), u:'명' },
    { k:'predict',  t:'경기 예측 응답 · 입력한 정답 · 버전 기록', n:subN('predictions'), u:'명', m:'등록한 예측 문항은 남고 v1부터 다시 시작해요' },
    { k:'mvp',      t:'MVP 투표 · 확정한 MVP',          n:subN('mvp'), u:'표', m:D.settings && D.settings.mvp ? `확정: ${D.settings.mvp.name || '#' + D.settings.mvp.num}` : '' },
    { k:'survey',   t:'설문 응답 · 버전 기록',          n:subN('survey'), u:'명', m:'보관함 설문은 남아요' },
    { k:'raffle',   t:'경품 응모 닉네임 · 저장한 당첨자', n:subN('raffle_entry'), u:'건', m:`당첨자 ${(D.raffleWinners || []).length}명` },
    { k:'roulette', t:'룰렛 당첨 · 교환 처리 기록',     n:subN('roulette'), u:'건', m:`교환 처리 ${Object.keys(D.redeemed || {}).length}건` },
    { k:'config',   t:'이 경기 설정',                   n:null, cfg:true,
      m:'현장 이벤트 · 응원 당첨 번호 · 경기 진행/시작 시각 · 이 경기에만 지정한 설문 · 오늘 운영 (예측 문항은 남아요)' },
  ];
}
const DATA_PARTS = ['visits', 'cheer', 'checkin', 'predict', 'mvp', 'survey', 'raffle', 'roulette'];

/* ===== 경기 전 점검표 ===== */
function checklistCard(S){
  const st = D.settings || {}, c = CT();
  const responses = (D.subs.checkin || []).length + S.pred.count + (D.subs.survey || []).length + S.raffle.length + (D.total || 0);
  const started = st.start && Date.now() >= new Date(st.start).getTime();
  const items = [
    D.serverVersion === SERVER_NEED ? ['ok', '서버(okman-live) 최신 버전'] : ['bad', `서버가 예전 버전이에요 (${esc(D.serverVersion || '버전 정보 없음')}) — 최신 index.js를 배포해주세요`],
    D.survey ? ['ok', `설문: ${esc(D.survey.title || '제목 없음')} (${vLabel(D.survey.v)})`, 'survey'] : ['bad', '보관함 기본 설문이 없어서 비상용 문항이 나가요', 'survey'],
    st.start ? ['ok', `시작 시각 ${esc(fmtStart(st.start))}`] : ['info', '시작 시각 미입력 — 경기 일정표 기준으로 정해져요 (예측 마감 카운트다운)'],
    st.opponent ? ['ok', `상대팀 ${esc(st.opponent)}`] : ['info', '상대팀 미입력 — 경기 일정표 기준이에요'],
    (D.prizes || []).length ? ['ok', `응원 당첨 번호 ${D.prizes.length}개`, 'cheer'] : ['warn', '응원 당첨 번호가 없어요', 'cheer'],
    ['ok', `룰렛 경품 ${(D.rouletteCfg && D.rouletteCfg.prizes || []).filter(p => !p.miss).length}종 · 수량 제한 ${(D.rouletteCfg && D.rouletteCfg.prizes || []).filter(p => !p.miss && (D.rouletteCfg.stockV2 ? p.stock != null : p.stock)).length}종`, 'home'],
    c.open === 'off' ? ['warn', "오늘 운영이 '미운영'이에요 — 관람객 화면이 기록만 보여요"] : ['ok', `오늘 운영: ${({ auto:'자동(일정 기준)', on:'운영' })[c.open || 'auto']}`],
    !started && responses > 0 ? ['warn', `경기 전인데 응답·응원이 ${fmt(responses)}건 있어요 — 리허설 데이터면 설정 › 데이터 초기화`, 'settings'] : ['ok', '리허설 데이터 정리'],
  ];
  const bad = items.filter(x => x[0] === 'bad' || x[0] === 'warn').length;
  const IC = { ok:'✓', info:'i', warn:'!', bad:'!' };
  const list = `<div class="check">${items.map(([k, t, go]) => `<div class="check__i ${k}"><b>${IC[k]}</b><span>${t}</span>${go && k !== 'ok' ? `<button class="btn small ghost" data-page="${go}">바로가기</button>` : ''}</div>`).join('')}</div>`;
  if(!bad) return `<details class="card lv-ok" data-open-key="checklist"><summary><span class="chip ok">✓ 경기 전 점검</span> 모두 준비됐어요 <span class="muted">항목 보기</span></summary><div style="margin-top:12px;">${list}</div></details>`;
  return `<section class="card lv1 lv1--warn"><h2>경기 전 점검 <span class="chip">확인 필요 ${bad}</span></h2>${list}</section>`;
}

function errorsCard(){
  const list = D.errors || [];
  if(!list.length) return '';
  const total = list.reduce((a, e) => a + e.n, 0), recent = list.filter(e => Date.now() - e.last < 10 * 60e3).length;
  return `<section class="card lv1 lv1--warn"><h2><span>관람객 화면 오류 <span class="chip ${recent ? '' : 'off'}">${recent ? `최근 10분 ${recent}종` : '최근 10분 없음'}</span></span>
      ${isAdmin() ? '<button class="btn small ghost" data-act="err-clear">기록 비우기</button>' : ''}</h2>
    <p class="meta">${list.length}종 · 총 ${fmt(total)}건</p>
    <div class="scroll"><table><thead><tr><th>오류</th><th>위치</th><th>화면</th><th>횟수</th><th>기기</th><th>마지막</th></tr></thead><tbody>
      ${list.slice(0, 20).map(e => `<tr><td style="white-space:normal; min-width:240px;"><b>${esc(e.msg)}</b><br><span class="muted" style="font-size:11px;">${esc(e.ua || '')}</span></td>
        <td class="muted">${esc(String(e.src || '').split('/').pop())}${e.line ? ':' + e.line : ''}</td><td>${esc(e.view || '')}</td><td><b>${fmt(e.n)}</b></td><td>${fmt(e.devices)}대</td><td class="muted">${time(e.last)}</td></tr>`).join('')}
    </tbody></table></div></section>`;
}

function resetCard(S){
  const sel = new Set(DR.reset || []);
  const parts = resetParts(S);
  const busy = mid() === today() && ((D.visits || {}).unique || 0) > 0;
  return `<section class="card">
      <h2>데이터 초기화 <span class="muted" style="font-size:13px; font-weight:600;">${esc(mid())}</span></h2>
      
      ${busy ? `<div class="winbox" style="background:#FFF1EC; color:#C2410C; margin:12px 0 0;"><b>오늘 경기예요</b><p style="font-size:13px; margin-top:4px;">지금까지 ${fmt(D.visits.unique)}명이 접속했어요. 경기 중에 지우면 관람객의 미션·응모 기록이 사라져요.</p></div>` : ''}
      <div class="opts" style="margin:14px 0 6px;">
        <button class="btn small ghost" data-act="rs-all">응답 데이터 모두 고르기</button>
        <button class="btn small ghost" data-act="rs-none">선택 해제</button>
        <span style="flex:1"></span>
        <button class="btn small ghost" data-act="csv-survey">설문 CSV 받아두기</button>
        <button class="btn small ghost" data-act="csv-predict">예측 CSV 받아두기</button>
      </div>
      <div class="rslist">${parts.map(p => `
        <label class="rsrow${p.cfg ? ' cfg' : ''}${sel.has(p.k) ? ' on' : ''}">
          <input type="checkbox" data-rs="${p.k}"${sel.has(p.k) ? ' checked' : ''}>
          <span class="rsrow__t"><b>${p.t}</b>${p.m ? `<em>${esc(p.m)}</em>` : ''}</span>
          <span class="rsrow__n">${p.n == null ? '설정' : `${fmt(p.n)}${p.u}`}</span>
        </label>`).join('')}</div>
      <div class="edfoot"><span class="muted" style="font-size:13px; align-self:center;">${sel.size ? `${sel.size}개 항목을 지워요` : '지울 항목을 골라주세요'}</span>
        <button class="btn danger" data-act="rs-go"${sel.size ? '' : ' disabled'}>초기화</button></div>
    </section>
    ${isOwner() ? `<section class="card lv1 lv1--danger"><h2>시즌 전체 데이터 삭제</h2>
      <p class="meta">모든 경기(${MATCHES.filter(id => id && id !== '__new').length}경기)의 참여 데이터와 경기별 설정을 한 번에 지우고, 경기 선택 목록에서도 빼요 — 접속자 · 응원 · 출석 · 예측 · MVP · 설문 · 경품 응모 · 룰렛 · 화면 이용</p>
      <div class="edfoot"><span class="chip off">설문 보관함 · 룰렛·배너 · 계정은 남아요</span><button class="btn danger" data-act="season-wipe">시즌 전체 삭제</button></div>
    </section>
    <section class="card lv1 lv1--danger"><h2>이 경기 통째로 삭제</h2>
      <p class="meta">${esc(mid())} 경기의 참여 데이터와 이 경기 설정(현장 이벤트 · 응원 당첨 번호 · 시작 시각 등)을 모두 지우고, 위쪽 경기 선택 목록에서도 빼요</p>
      <div class="edfoot"><span></span><button class="btn danger" data-act="match-purge">경기 삭제</button></div>
    </section>` : ''}`;
}

/* ===== 설정 › 계정 · 내 비밀번호 · 닉네임 금칙어 · 작업 기록 ===== */
const EXTRA = { users:null, nick:null, audit:null, auditAt:0, home:null, locks:null, privacy:null };
const LOADING = new Set();
async function loadExtra(kind, force){
  if(LOADING.has(kind)) return;
  const need = force || (kind === 'audit' ? Date.now() - EXTRA.auditAt > 15000 : !EXTRA[kind]);
  if(!need) return;
  LOADING.add(kind);
  try{
    if(kind === 'users' && (force || !EXTRA.users)) EXTRA.users = (await call('GET', '_/users')).users || [];
    if(kind === 'nick' && (force || !EXTRA.nick)) EXTRA.nick = await call('GET', '_/nickban');
    if(kind === 'audit' && (force || Date.now() - EXTRA.auditAt > 15000)){
      EXTRA.auditAt = Date.now();
      const [a, b] = await Promise.all([mcall('GET', 'audit').catch(() => ({ audit:[] })), call('GET', '_/audit').catch(() => ({ audit:[] }))]);
      EXTRA.audit = [...(a.audit || []).map(x => ({ ...x, scope:mid() })), ...(b.audit || []).map(x => ({ ...x, scope:'시즌' }))].sort((x, y) => y.at - x.at);
    }
    if(kind === 'home' && (force || !EXTRA.home)) EXTRA.home = await call('GET', '_/home');
    if(kind === 'locks') EXTRA.locks = (await call('GET', '_/locks')).locks || [];
    if(kind === 'privacy') EXTRA.privacy = (await call('GET', '_/privacy')).privacy || {};
    if(kind === 'subway') EXTRA.subway = (await call('GET', '_/subway')).subway || {};
  }catch(e){ EXTRA[kind] = EXTRA[kind] || { error:e.message }; }
  finally{ LOADING.delete(kind); }
  render();
}
function accountCards(){
  const me = `<section class="card"><h2>내 계정 <span class="muted" style="font-size:13px; font-weight:600;">${esc($('who').textContent)}</span></h2>
    <p class="meta">할 수 있는 일: ${ROLE_DESC[ME.role] || ''}</p>
    <div class="form" style="grid-template-columns:1fr 1fr auto;">
      <div class="field" style="grid-column:auto;"><label for="pw-cur">지금 비밀번호</label><input id="pw-cur" type="password" autocomplete="current-password"></div>
      <div class="field" style="grid-column:auto;"><label for="pw-new">새 비밀번호 (8자 이상)</label><input id="pw-new" type="password" autocomplete="new-password"></div>
      <button class="btn dark" data-act="pw-save" style="grid-column:auto; align-self:end;">바꾸기</button>
    </div>
    </section>`;
  if(!isOwner()) return me;
  if(!EXTRA.users){ loadExtra('users'); return me + '<section class="card"><h2>관리자 계정</h2><p class="empty">불러오는 중…</p></section>'; }
  const list = EXTRA.users.error ? `<p class="empty">${esc(EXTRA.users.error)}</p>` : (EXTRA.users.length ? EXTRA.users.map(u => `<div class="row"><div class="main"><p class="t">${esc(u.name)} <span class="chip role-${esc(u.role)}">${ROLE_NAME[u.role] || u.role}</span></p><p class="m">아이디 ${esc(u.id)} · ${time(u.at)} 생성</p></div>
      <div class="acts"><select class="in" style="height:32px; width:auto;" data-urole="${esc(u.id)}" aria-label="${esc(u.name)} 권한">${Object.entries(ROLE_NAME).map(([k, t]) => `<option value="${k}"${u.role === k ? ' selected' : ''}>${t}</option>`).join('')}</select>
        <button class="btn small ghost" data-act="user-pw" data-id="${esc(u.id)}">비밀번호 재설정</button><button class="btn small danger" data-act="user-del" data-id="${esc(u.id)}">삭제</button></div></div>`).join('') : '<p class="empty">아직 만든 계정이 없어요.</p>');
  return me + `<section class="card"><h2>관리자 계정</h2>
    
    <div class="roles">${Object.entries(ROLE_NAME).map(([k, t]) => `<div><span class="chip role-${k}">${t}</span><p>${ROLE_DESC[k]}</p></div>`).join('')}</div>
    ${list}
    <div class="form" style="grid-template-columns:1fr 1fr 1fr 1fr auto; margin-top:12px;">
      <div class="field" style="grid-column:auto;"><label for="nu-id">아이디</label><input id="nu-id" maxlength="30" placeholder="booth1"></div>
      <div class="field" style="grid-column:auto;"><label for="nu-name">이름</label><input id="nu-name" maxlength="20" placeholder="1층 부스"></div>
      <div class="field" style="grid-column:auto;"><label for="nu-role">권한</label><select id="nu-role"><option value="staff">부스 담당</option><option value="manager">일반 관리자</option><option value="owner">총괄 관리자</option></select></div>
      <div class="field" style="grid-column:auto;"><label for="nu-pw">비밀번호 (8자 이상)</label><input id="nu-pw" type="password" autocomplete="new-password"></div>
      <button class="btn" data-act="user-add" style="grid-column:auto; align-self:end;">추가</button>
    </div></section>`;
}
/* ===== 설정 › 막차 시간표 ===== */
const TT_DAYS = [['wk', '평일'], ['sa', '토요일'], ['su', '일요일·공휴일']];
function parseHumetro(text){
  const out = { wk:[], sa:[], su:[] }, keys = ['wk', 'sa', 'su'];
  const add = (h, cell, k) => { for(const m of String(cell).matchAll(/(\d{1,2})\s*분/g)){ let t = h * 60 + Number(m[1]); if(h < 4) t += 1440; out[k].push(t); } };
  let hour = null, col = 0;
  for(const raw of String(text || '').replace(/\r/g, '').split('\n')){
    const line = raw.trim(); if(!line) continue;
    const cells = raw.split('\t').map(x => x.trim());
    const hm = cells[0].match(/^(\d{1,2})$/);
    if(hm && cells.length >= 2){ const h = Number(hm[1]); cells.slice(1, 4).forEach((c, i) => add(h, c, keys[i])); hour = null; continue; }
    if(/^\d{1,2}$/.test(line)){ hour = Number(line); col = 0; continue; }
    if(hour != null && /분/.test(line)){ if(col < 3) add(hour, line, keys[col]); col++; }
  }
  for(const k of keys) out[k] = [...new Set(out[k])].sort((a, b) => a - b);
  return out;
}
const ttm = t => { const h = Math.floor(t / 60), m = t % 60; return `${String(h >= 24 ? h - 24 : h).padStart(2, '0')}:${String(m).padStart(2, '0')}${h >= 24 ? '(익일)' : ''}`; };
function ttSummary(tt){
  return TT_DAYS.map(([k, t]) => { const a = tt[k] || []; return `${t} ${a.length}편${a.length ? ` · 첫차 ${ttm(a[0])} · 막차 <b>${ttm(a[a.length - 1])}</b>` : ''}`; }).join('<br>');
}
function subwayPreview(){
  const d = DR.sub || {};
  [0, 1].forEach(i => {
    const el = $('sub-pv' + i); if(!el) return;
    const t = parseHumetro(d['t' + i]);
    const n = t.wk.length + t.sa.length + t.su.length;
    el.innerHTML = !String(d['t' + i] || '').trim() ? '<span class="muted">붙여넣으면 여기서 읽은 결과를 보여줘요.</span>'
      : n ? ttSummary(t) + (t.sa.length && t.su.length ? '' : '<br><span style="color:#C2410C;">토요일·일요일 칸이 비었어요 — 표 전체(평일·토·일 세 칸)를 같이 복사해주세요.</span>')
          : '<span style="color:#C2410C;">시각을 하나도 못 읽었어요. 표에서 시(05, 06…)와 \'○○행 ○○분 출발\' 칸을 같이 복사해주세요.</span>';
  });
}
function subwayCard(){
  if(!EXTRA.subway){ loadExtra('subway'); return '<section class="card"><p class="empty">불러오는 중…</p></section>'; }
  const cur = EXTRA.subway.error ? {} : EXTRA.subway;
  DR.sub = DR.sub || { t0:'', t1:'', hol:(cur.holidays || []).join('\n') };
  setTimeout(subwayPreview, 0);
  const saved = cur.tt ? `<div class="grid2" style="margin-top:6px;">${[['0', '수영 방면'], ['1', '대저 방면']].map(([i, t]) => `<div class="rsrow" style="display:block; cursor:default;"><b>${t}</b><p class="muted" style="font-size:13px; line-height:20px; margin-top:4px;">${ttSummary({ wk:(cur.tt.wk || {})[i] || [], sa:(cur.tt.sa || {})[i] || [], su:(cur.tt.su || {})[i] || [] })}</p></div>`).join('')}</div>
      <p class="muted" style="font-size:12px; margin-top:8px;">${time(cur.updatedAt)} 저장 · 관람객 화면 막차안내에 10분 안에 반영돼요.</p>`
    : '<p class="empty">아직 저장한 시간표가 없어요. 관람객 화면엔 \'도착 정보 준비 중\'과 기본 막차 시각만 나와요.</p>';
  return `<section class="card"><h2>지금 쓰는 시간표 <span class="muted" style="font-size:12px; font-weight:600;">체육공원역 · 시즌 공통</span></h2>${saved}</section>
  <section class="card"><h2>시간표 붙여넣기</h2>
    
    <div class="grid2" style="margin-top:12px;">
      ${[['0', '수영 방면 (구포·연산·수영행)'], ['1', '대저 방면 (대저행)']].map(([i, t]) => `<div class="field"><label for="sub-t${i}">${t}</label>
        <textarea class="in" id="sub-t${i}" data-sub="t${i}" rows="8" style="height:auto; padding:10px 12px; font-family:inherit; font-size:12px;" placeholder="05	수영행05분 출발 …	…	…">${esc(DR.sub['t' + i])}</textarea>
        <p class="muted" id="sub-pv${i}" style="font-size:12px; line-height:19px; margin-top:6px;"></p></div>`).join('')}
    </div>
    <div class="field" style="margin-top:12px;"><label for="sub-hol">공휴일 (이날은 일요일 시간표 · 한 줄에 하나, 예: 2026-12-25)</label>
      <textarea class="in" id="sub-hol" data-sub="hol" rows="3" style="height:auto; padding:10px 12px; font-family:inherit;">${esc(DR.sub.hol)}</textarea></div>
    <div class="edfoot"><span></span><button class="btn" data-act="sub-save">저장</button></div>
  </section>`;
}
function locksCard(){
  if(!EXTRA.locks){ loadExtra('locks'); return ''; }
  if(EXTRA.locks.error) return '';
  return `<section class="card"><h2>잠긴 로그인 <span class="muted" style="font-size:12px; font-weight:600;">아이디 5번 · 접속 주소 20번 틀리면 10분</span></h2>
    ${EXTRA.locks.length ? EXTRA.locks.map(l => `<div class="row"><div class="main"><p class="t">${l.key.startsWith('ip:') ? '접속 주소' : '아이디'} ${esc(l.key.replace(/^(id|ip):/, ''))}</p>
      <p class="m">${l.n}번 실패 · ${time(l.until)}까지 잠김</p></div><button class="btn small ghost" data-act="lock-open" data-k="${esc(l.key)}">잠금 풀기</button></div>`).join('')
      : '<p class="empty">지금 잠긴 로그인이 없어요.</p>'}
    <div class="edfoot"><span></span><button class="btn small ghost" data-act="lock-refresh">새로 보기</button></div></section>`;
}
function privacyCard(){
  if(!EXTRA.privacy){ loadExtra('privacy'); return '<section class="card"><p class="empty">불러오는 중…</p></section>'; }
  const p = EXTRA.privacy.error ? {} : EXTRA.privacy;
  return `<section class="card"><h2>데이터 수집 안내 <span class="muted" style="font-size:12px; font-weight:600;">시즌 공통 · 관람객 화면 '데이터 안내'</span></h2>
    
    <div class="field" style="margin-top:10px;"><label for="pv-ret">보관 기간</label><input class="in" id="pv-ret" maxlength="120" value="${esc(p.retention || '')}" placeholder="예: 2026-27 시즌이 끝나면 30일 안에 지워요."></div>
    <div class="field" style="margin-top:10px;"><label for="pv-ext">덧붙일 말 (선택)</label><textarea class="in" id="pv-ext" maxlength="600" rows="3" style="height:auto; padding:10px 12px; font-family:inherit;">${esc(p.extra || '')}</textarea></div>
    <div class="edfoot"><span class="muted" style="font-size:12px; align-self:center;">${p.updatedAt ? time(p.updatedAt) + ' 저장' : '아직 저장 전 — 기본 문구가 나가요 (보관 기간: 시즌이 끝나면 지워요)'}</span><button class="btn" data-act="pv-save">저장</button></div></section>`;
}
function saveUsers(users, msg){
  return act(()=> call('PUT', '_/users', { users }), msg).then(ok => { if(ok) loadExtra('users', true); return ok; });
}
function nickBanCard(){
  if(!EXTRA.nick){ loadExtra('nick'); return '<section class="card"><h2>닉네임 금칙어</h2><p class="empty">불러오는 중…</p></section>'; }
  const n = EXTRA.nick, words = n.words || [];
  return `<section class="card"><h2>닉네임 금칙어 <span class="muted" style="font-size:12px; font-weight:600;">시즌 공통 · 추가 ${words.length}개</span></h2>
    
    <div class="opts" style="margin:0 0 12px;">${words.length ? words.map(w => `<span class="ochip" style="padding:0 4px 0 12px;"><b style="font-weight:600;">${esc(w)}</b><button data-act="nb-del" data-w="${esc(w)}" aria-label="${esc(w)} 지우기">×</button></span>`).join('') : '<p class="muted" style="margin:0;">추가한 금칙어가 없어요.</p>'}</div>
    <div class="form" style="grid-template-columns:1fr auto;">
      <div class="field" style="grid-column:auto;"><label for="nb-add">금칙어 추가 (쉼표로 여러 개)</label><input class="in" id="nb-add" maxlength="200" placeholder="예: 상대팀 비하 표현, 특정 선수 이름"></div>
      <button class="btn" data-act="nb-add" style="grid-column:auto; align-self:end;">추가</button></div>
    <details class="tlist" style="margin:12px 0 0;"><summary>기본 금칙어 보기</summary><p style="display:block;">${esc((n.builtin || []).join(', '))}</p></details></section>`;
}
const ACT_NAME = { events:'현장 이벤트', prizes:'응원 이벤트', settings:'경기 설정', raffle:'추첨', 'raffle-clear':'응모 삭제', 'raffle-hide':'추첨 제외', redeem:'교환',
  'reset-cheer':'초기화', reset:'초기화', subway:'막차 시간표', 'login-lock':'로그인 잠금', unlock:'잠금 풀기', privacy:'데이터 안내', 'errors-clear':'오류 기록', surveys:'설문 보관함', users:'계정', password:'비밀번호', home:'룰렛·배너', nickban:'금칙어' };
function auditCard(){
  if(!EXTRA.audit || Date.now() - EXTRA.auditAt > 15000) loadExtra('audit');
  const list = EXTRA.audit || [];
  return `<section class="card"><h2>작업 기록 <span class="muted" style="font-size:12px; font-weight:600;">${esc(mid())} 경기 + 시즌 공통 · 최근 ${Math.min(list.length, 100)}건</span></h2>
    ${list.length ? `<div class="scroll"><table><thead><tr><th>시각</th><th>누가</th><th>범위</th><th>무엇</th></tr></thead><tbody>
      ${list.slice(0, 100).map(a => `<tr><td class="muted">${time(a.at)}</td><td><b>${esc(a.who && (a.who.name || a.who.id))}</b></td><td class="muted">${esc(a.scope)}</td><td>${esc(ACT_NAME[a.action] || a.action)} · ${esc(a.detail)}</td></tr>`).join('')}
    </tbody></table></div>` : `<p class="empty">${EXTRA.audit ? '아직 기록이 없어요. (이번 서버 버전부터 남아요)' : '불러오는 중…'}</p>`}</section>`;
}

/* ===== 룰렛 · 배너 ===== */
const RL_IMGS = { soju:'변온 소주잔', doll:'봉제인형', fan:'부채', ticket:'티켓', photo:'사진 촬영권', signball:'사인볼', miss:'꽝' };
function homeDraft(){
  if(DR.home) return DR.home;
  const h = (EXTRA.home && EXTRA.home.home) || {}, def = (EXTRA.home && EXTRA.home.defaults) || {};
  const r = h.roulette && h.roulette.prizes && h.roulette.prizes.length === 8 ? h.roulette : { ...def.roulette, notices:[] };
  const prizes = (r.prizes || []).map(p => ({ ...p, stock: r.stockV2 ? (p.stock ?? null) : (p.stock ? p.stock : null) }));   // 예전 저장분은 0 = 무제한
  DR.home = clone({ roulette:{ base:r.base ?? 1, bonus:r.bonus ?? 1, onePerPerson:r.onePerPerson !== false, prizes, notices:r.notices || [] },
                    goods:h.goods || { title:'읏맨 공식 굿즈샵', desc:'유니폼과 응원 도구를 온라인에서 만나보세요.', url:'' },
                    app:h.app || { title:'OK저축은행 앱 다운로드', desc:'앱에서 더 많은 혜택을 만나보세요.', ios:'', android:'', on:true } });
  return DR.home;
}
function homeView(){
  if(!EXTRA.home){ loadExtra('home'); return '<p class="page-title">룰렛·배너</p><p class="empty">불러오는 중…</p>'; }
  if(EXTRA.home.error) return `<p class="page-title">룰렛·배너${saved ? '' : ' <span class="chip off">기본값 사용 중</span>'}</p><p class="empty">${esc(EXTRA.home.error)}</p>`;
  const H = homeDraft(), R = H.roulette, issued = D.rlIssued || {};
  const total = R.prizes.reduce((a, p) => a + (!p.miss && p.stock === 0 ? 0 : Number(p.weight) || 0), 0) || 1;   // 수량 0은 확률에서 빼요
  // 칸별 확률 — 0.1% 단위로 반올림하되 합계가 정확히 100.0%가 되게 (남는 자리는 소수점이 큰 칸부터)
  const raw = R.prizes.map(p => (!p.miss && p.stock === 0 ? 0 : Number(p.weight) || 0) / total * 1000);
  const PCT = raw.map(Math.floor);
  let rest = Math.round(raw.reduce((a, v) => a + v, 0)) - PCT.reduce((a, v) => a + v, 0);
  raw.map((v, i) => [v - Math.floor(v), i]).sort((a, b) => b[0] - a[0]).forEach(([, i]) => { if(rest > 0){ PCT[i]++; rest--; } });
  const saved = !!(EXTRA.home.home);
  return `<p class="page-title">룰렛·배너</p>
  <section class="card"><h2>룰렛 경품 ${(()=>{ const sum = R.prizes.reduce((a, p) => a + (Number(p.weight) || 0), 0);
      return sum === 100 ? '<span class="chip ok">가중치 합 100</span>' : `<span style="display:inline-flex; gap:8px; align-items:center;"><span class="chip off">가중치 합 ${sum}</span><button class="btn small ghost" data-act="rp-norm">합계 100으로 맞추기</button></span>`; })()}</h2>
    
    <div class="form" style="grid-template-columns:1fr 1fr 3fr; margin-bottom:6px;">
      <div class="field" style="grid-column:auto;"><label for="rl-base">기본 횟수</label><input id="rl-base" data-hf="base" type="number" min="0" max="5" value="${R.base}"></div>
      <div class="field" style="grid-column:auto;"><label for="rl-bonus">미션 완료 보너스</label><input id="rl-bonus" data-hf="bonus" type="number" min="0" max="5" value="${R.bonus}"></div>
      <label class="chk" style="grid-column:auto; align-self:end; padding-bottom:12px;"><input type="checkbox" data-hf="onePerPerson"${R.onePerPerson !== false ? ' checked' : ''}>1인 1회 당첨 — 당첨되면 남은 기회가 있어도 더 돌릴 수 없어요</label>
    </div>
    <div class="scroll"><table class="rltab"><thead><tr><th>칸</th><th>이미지</th><th>꽝</th><th>경품 이름</th><th>안내</th><th>가중치</th><th>확률</th><th>수량</th><th>${esc(mid())} 나감</th></tr></thead><tbody>
      ${R.prizes.map((p, i) => `<tr>
        <td><b>${i + 1}</b></td>
        <td><div style="display:flex; align-items:center; gap:6px;">${p.image ? `<img class="ckimg" src="${esc(p.image)}" alt="">` : ''}
          <select class="in" style="height:34px; width:auto;" data-rp="img" data-i="${i}">${Object.entries(RL_IMGS).map(([k, t]) => `<option value="${k}"${p.img === k ? ' selected' : ''}>${t}</option>`).join('')}</select>
          <button class="btn small ghost" data-act="rp-imgpick" data-i="${i}">${p.image ? '바꾸기' : '올리기'}</button>${p.image ? `<button class="btn small ghost" data-act="rp-imgdel" data-i="${i}">↺</button>` : ''}</div></td>
        <td><input type="checkbox" data-rp="miss" data-i="${i}"${p.miss ? ' checked' : ''} aria-label="꽝"></td>
        <td>${p.miss ? '<span class="muted">꽝</span>' : `<input class="in" style="height:34px; min-width:150px;" data-rp="title" data-i="${i}" maxlength="40" value="${esc(String(p.title || '').replace(/\n/g, ' / '))}">`}</td>
        <td>${p.miss ? '' : `<input class="in" style="height:34px; min-width:150px;" data-rp="desc" data-i="${i}" maxlength="40" value="${esc(p.desc || '')}">`}</td>
        <td><input class="in" style="height:34px; width:70px;" type="number" min="0" data-rp="weight" data-i="${i}" value="${Number(p.weight) || 0}"></td>
        <td>${!p.miss && p.stock === 0 ? '<span class="chip off">당첨 안 됨</span>' : `<b>${(PCT[i] / 10).toFixed(1)}%</b>`}</td>
        <td>${p.miss ? '' : `<input class="in" style="height:34px; width:70px;" type="number" min="0" data-rp="stock" data-i="${i}" value="${p.stock == null ? '' : p.stock}" placeholder="무제한">`}</td>
        <td class="muted">${p.miss ? '' : `${issued[p.id] || 0}${p.stock != null ? ' / ' + p.stock : ''}`}</td></tr>`).join('')}
    </tbody><tfoot><tr><th colspan="5" style="text-align:right;">합계</th>
        <th>${R.prizes.reduce((a, p) => a + (Number(p.weight) || 0), 0)}</th><th>100%</th><th colspan="2"></th></tr></tfoot></table></div>
    <div class="field" style="margin-top:12px;">
      <label for="rl-notices" style="display:flex; align-items:center; gap:8px;">당첨 화면 유의사항
        ${(R.notices || []).length ? '<span class="chip">수정됨</span>' : '<span class="chip off">기본 문구</span>'}
        ${(R.notices || []).length ? '<button type="button" class="btn small ghost" data-act="rl-notice-reset" style="margin-left:auto;">기본 문구로 되돌리기</button>' : ''}</label>
      <textarea class="in" id="rl-notices" data-hf="notices" rows="7" style="height:auto; padding:10px 12px; font-family:inherit; line-height:1.6;">${esc(((R.notices || []).length ? R.notices : DEFAULT_NOTICES).join('\n'))}</textarea></div>
  </section>
  <div class="grid2">
    <section class="card"><h2>굿즈샵 배너</h2>
      ${bannerImg('goods', H.goods.image, 'images/banners/goods-2026-27.webp')}
      ${['title:제목', 'desc:설명', 'url:링크 (https://…)'].map(x => { const i = x.indexOf(':'), k = x.slice(0, i), t = x.slice(i + 1); return `<div class="field" style="margin-top:8px;"><label>${t}</label><input class="in" data-hb="goods.${k}" value="${esc(H.goods[k] || '')}"></div>`; }).join('')}
    </section>
    <section class="card"><h2>앱 다운로드 배너 <label class="chk"><input type="checkbox" data-hb="app.on"${H.app.on !== false ? ' checked' : ''}>보이기</label></h2>
      <div class="seg seg--sm" id="app-mode" role="tablist" aria-label="화면 모드" style="margin:8px 0 0;">
        <button type="button" data-v="light" class="${APP_MODE === 'light' ? 'on' : ''}">라이트 모드</button>
        <button type="button" data-v="dark" class="${APP_MODE === 'dark' ? 'on' : ''}">다크 모드</button></div>
      ${APP_MODE === 'dark' ? bannerImg('app', H.app.imageDark, '', 'imageDark') : bannerImg('app', H.app.image, '', 'image')}
      ${['title:제목', 'desc:설명', 'ios:App Store 링크 (아이폰)', 'android:Play 스토어 링크 (안드로이드)'].map(x => { const i = x.indexOf(':'), k = x.slice(0, i), t = x.slice(i + 1); return `<div class="field" style="margin-top:8px;"><label>${t}</label><input class="in" data-hb="app.${k}" value="${esc(H.app[k] || '')}"></div>`; }).join('')}
    </section>
  </div>
  ${isOwner() ? `<div class="edfoot"><button class="btn ghost" data-act="home-reset">되돌리기</button><button class="btn" data-act="home-save">저장 (모든 경기)</button></div>`
               : `<div class="edfoot"><span class="chip off">총괄 관리자만 저장할 수 있어요</span></div>`}`;
}

// 앱 배너 — 라이트 / 다크 이미지 탭
let APP_MODE = 'light';
document.addEventListener('click', e=>{ const b = e.target.closest('#app-mode [data-v]'); if(!b) return; APP_MODE = b.dataset.v; render(); });
// 배너 이미지 칸 — 미리보기 · 이미지 선택 · 빼기 (관람객 화면과 같은 1440:346 비율)
function bannerImg(k, img, def, field = 'image'){
  const src = img || def;
  return `<div class="bimg${k === 'app' && APP_MODE === 'dark' ? ' bimg--dark' : ''}">
    ${src ? `<img class="bimg__img" src="${esc(src)}" alt="">` : '<div class="bimg__img bimg__img--empty">이미지 없음 · 글자만 보여요</div>'}
    <div class="bimg__bar"><span class="chip ${img ? '' : 'off'}">${img ? '올린 이미지' : def ? '기본 이미지' : '이미지 없음'}</span>
      <span style="flex:1"></span>
      <button type="button" class="btn small ghost" data-act="hb-imgpick" data-k="${k}" data-field="${field}">이미지 선택</button>
      ${img ? `<button type="button" class="btn small ghost" data-act="hb-imgdel" data-k="${k}" data-field="${field}">빼기</button>` : ''}</div></div>`;
}
// 배너용 — 비율을 지키며 가로 960px · WebP로 줄여요 (서버 저장 용량 때문에)
function shrinkBanner(file){
  return new Promise((res, rej)=>{
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = ()=>{
      const W = Math.min(960, img.width), H = Math.round(img.height * W / img.width);
      const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      cv.getContext('2d').drawImage(img, 0, 0, W, H); URL.revokeObjectURL(url);
      let out = cv.toDataURL('image/webp', .8); if(!out.startsWith('data:image/webp')) out = cv.toDataURL('image/jpeg', .82);
      if(out.length > 115000) out = cv.toDataURL('image/webp', .6);
      if(out.length > 115000){ const c2 = document.createElement('canvas'); c2.width = Math.round(W * .75); c2.height = Math.round(H * .75); c2.getContext('2d').drawImage(cv, 0, 0, c2.width, c2.height); out = c2.toDataURL('image/webp', .7); }
      if(out.length > 115000) return rej(new Error('이미지가 너무 커요. 더 단순한 이미지나 작은 파일로 올려주세요.'));
      res(out);
    };
    img.onerror = ()=>{ URL.revokeObjectURL(url); rej(new Error('이미지를 읽지 못했어요.')); };
    img.src = url;
  });
}

/* ===== 설문 이탈 지점 ===== */
function dropoutCard(v){
  if(!v || v.v === 'none') return '';
  const done = new Set(v.rows.map(r => r.device));
  const prog = (D.subs.survey_progress || []).filter(r => Number((r.data || {}).ver || 0) === Number(v.v) && !done.has(r.device));
  const started = done.size + prog.length;
  if(!started) return '';
  const items = v.items || [];
  const at = {}; prog.forEach(r => { const id = String((r.data || {}).last || ''); at[id] = (at[id] || 0) + 1; });
  const idx = Object.fromEntries(items.map((q, i) => [String(q.id), i]));
  const rows = items.map((q, i) => {
    const dropped = at[String(q.id)] || 0;
    const reached = done.size + prog.filter(r => (idx[String((r.data || {}).last)] ?? -1) >= i).length;
    return { q, i, dropped, reached };
  });
  const max = Math.max(1, ...rows.map(r => r.dropped));
  return `<section class="card"><h2>이탈 지점 <span class="muted" style="font-size:13px; font-weight:600;">시작 ${fmt(started)}명 · 완료 ${fmt(done.size)}명 · 완료율 ${pct(done.size, started)}%</span></h2>
    
    <div class="scroll"><table><thead><tr><th>문항</th><th>여기까지 온 사람</th><th style="width:40%;">여기서 그만둔 사람</th></tr></thead><tbody>
      ${rows.map(r => `<tr><td><b>${esc(r.q.id)}.</b> ${esc(String(r.q.q).slice(0, 34))}${String(r.q.q).length > 34 ? '…' : ''}</td><td>${fmt(r.reached)}명 <span class="muted">(${pct(r.reached, started)}%)</span></td>
        <td><div style="display:flex; align-items:center; gap:8px;"><span class="stack" style="flex:1;"><i style="width:${r.dropped / max * 100}%; opacity:${r.dropped ? 1 : 0}"></i></span><b style="min-width:42px; text-align:right;">${fmt(r.dropped)}명</b></div></td></tr>`).join('')}
    </tbody></table></div></section>`;
}

/* ===== 경기 리포트 (엑셀) ===== */
async function downloadReport(){
  toast('리포트를 만드는 중…');
  const X = await loadXlsx();
  const S = stats(), v = D.visits || {}, u = v.unique || 0, st = D.settings || {};
  const wb = X.utils.book_new();
  const sheet = (name, rows, cols) => { const ws = X.utils.aoa_to_sheet(rows); if(cols) ws['!cols'] = cols.map(w => ({ wch:w })); X.utils.book_append_sheet(wb, ws, name.slice(0, 31)); };
  const rate = n => u ? Math.round(n / u * 1000) / 10 + '%' : '';
  const nps = S.sv.flatMap(x => x.questions.filter(q => q.type === 'nps' && q.n).map(q => [vLabel(x.v), q.id, q.q, q.n, q.nps, Math.round(q.avg * 10) / 10]));
  sheet('요약', [
    ['읏배구놀이터 경기 리포트'], ['경기', mid()], ['상대팀', st.opponent || ''], ['시작 시각', st.start ? fmtStart(st.start) : ''], ['만든 시각', csvTime(Date.now())], [],
    ['항목', '수', '접속자 대비'],
    ['고유 접속자', u, ''], ['브라우저 연 횟수', v.sessions || 0, ''],
    ['출석체크', S.ck.count, rate(S.ck.count)], ['경기 예측', S.pred.count, rate(S.pred.count)], ['MVP 투표', S.mvpRank.reduce((a, b) => a + b.n, 0), ''],
    ['설문 완료', (D.subs.survey || []).length, rate((D.subs.survey || []).length)], ['경품 응모', S.raffle.length, rate(S.raffle.length)],
    ['전체 응원 수', D.total || 0, ''], ['응원 당첨', (D.winners || []).length, ''], ['룰렛 당첨', S.rl.wins.length, ''],
    ['교환 처리', Object.keys(D.redeemed || {}).length, ''], ['추첨 당첨자', (D.raffleWinners || []).length, ''],
    ['확정 MVP', st.mvp ? `#${st.mvp.num} ${st.mvp.name || ''}` : '', ''], [],
    ['NPS', '버전', '문항', '질문', '응답', 'NPS', '평균'], ...nps.map(r => ['', ...r]),
  ], [18, 16, 14, 40, 8, 8, 8]);
  sheet('시간대별 접속', [['시 (한국 시간)', '첫 접속 수'], ...Object.entries(v.hours || {}).sort().map(([h, n]) => [Number(h) + '시', n])], [16, 12]);
  const ckQs = (Array.isArray(CT().checkin) && CT().checkin.length) ? CT().checkin : CK_DEF;
  sheet('출석체크', [['질문', '답', '수', '비율'], ...ckQs.flatMap(q => { const c = S.ck.by[q.key] || {}, t = Object.values(c).reduce((a, b) => a + b, 0);
    return q.opts.map(o => [q.q, o.label, c[o.label] || 0, t ? Math.round((c[o.label] || 0) / t * 1000) / 10 + '%' : '']); })], [24, 14, 8, 8]);
  const ans = st.answers || {};
  sheet('경기 예측', [['버전', '질문', '선택', '수', '정답', '전부 맞힌 사람(버전)'], ...S.pred.versions.flatMap(x => x.questions.flatMap(q =>
    Object.entries(q.counts).map(([k, n]) => [vLabel(x.v), q.q, k, n, ans[q.key] === k ? 'O' : '', x.allCorrect.size])))], [10, 34, 18, 8, 6, 12]);
  sheet('MVP 투표', [['순위', '선수', '표'], ...S.mvpRank.map((m, i) => [i + 1, `#${m.num} ${m.name}`, m.n])], [6, 20, 8]);
  const svRows = [['버전', '설문 제목', '문항', '유형', '질문', '항목', '수', '비율(응답자 대비)', '평균']];
  for(const x of S.sv) for(const q of x.questions){
    if(q.type === 'nps') q.dist && q.dist.forEach((c, i) => svRows.push([vLabel(x.v), x.title || '', q.id, 'NPS', q.q, i + '점', c, q.n ? Math.round(c / q.n * 1000) / 10 + '%' : '', i === 0 && q.n ? Math.round(q.avg * 10) / 10 : '']));
    else if(q.type === 'grid') q.rows.forEach((row, ri) => { const c = q.cells[ri], n = c.reduce((a, b) => a + b, 0);
      svRows.push([vLabel(x.v), x.title || '', q.id, '행렬 척도', q.q, row, n, '', n ? Math.round(c.reduce((a, y, i) => a + y * (i + 1), 0) / n * 100) / 100 : '']); });
    else (q.order || Object.keys(q.counts)).forEach(k => svRows.push([vLabel(x.v), x.title || '', q.id, ({ single:'단일', multi:'복수' })[q.type] || '', q.q, k, q.counts[k] || 0, q.n ? Math.round((q.counts[k] || 0) / q.n * 1000) / 10 + '%' : '', '']));
  }
  sheet('설문 결과', svRows, [8, 22, 6, 8, 40, 22, 6, 10, 6]);
  const dRows = [['버전', '문항', '질문', '여기서 그만둔 사람']];
  for(const x of S.sv){ const done = new Set(x.rows.map(r => r.device));
    const prog = (D.subs.survey_progress || []).filter(r => Number((r.data || {}).ver || 0) === Number(x.v) && !done.has(r.device));
    (x.items || []).forEach(q => dRows.push([vLabel(x.v), q.id, q.q, prog.filter(r => String((r.data || {}).last) === String(q.id)).length])); }
  sheet('설문 이탈', dRows, [8, 6, 44, 12]);
  const fb = [['버전', '문항', '구분', '내용', '시각']];
  for(const x of S.sv) for(const q of x.questions){ (q.etc || []).forEach(t => fb.push([vLabel(x.v), q.id, '기타 직접 입력', t.t, csvTime(t.at)])); (q.memo || []).forEach(t => fb.push([vLabel(x.v), q.id, '자유 의견', t.t, csvTime(t.at)])); }
  sheet('설문 의견', fb, [8, 6, 12, 60, 16]);
  sheet('경품', [['구분', '경품·닉네임', '코드', '시각', '교환'],
    ...S.rl.wins.map(w => ['룰렛', w.title, w.code, csvTime(w.at), (D.redeemed || {})[w.code] ? 'O' : '']),
    ...(D.winners || []).map(w => ['응원 ' + w.n + '번째', w.prize, w.code, csvTime(w.at), (D.redeemed || {})[w.code] ? 'O' : '']),
    ...(D.raffleWinners || []).map(w => ['추첨 당첨', w.nickname || w.contact, '', csvTime(w.at), ''])], [12, 24, 12, 16, 6]);
  X.writeFile(wb, `읏배구놀이터_경기리포트_${mid()}.xlsx`);
}

/* ===== 대시보드 ===== */
let SCOPE = 'match';
document.addEventListener('click', e=>{
  const b = e.target.closest('#scope [data-v]'); if(!b) return;
  SCOPE = b.dataset.v; if(SCOPE === 'season') loadSeason(); render();
});
function kpi(label, value, unit, sub, go){
  const inner = `<span>${label}</span><b>${value}${unit ? `<small style="font-size:13px; font-weight:600; margin-left:2px;">${unit}</small>` : ''}</b>${sub ? `<span class="muted" style="font-size:12px;">${sub}</span>` : ''}`;
  return go ? `<button class="kpi" data-page="${go}" style="text-align:left; font:inherit; color:inherit; border:0; cursor:pointer; width:100%;" title="${label} 화면으로">${inner}</button>`
            : `<div class="kpi">${inner}</div>`;
}
const kpiGrid = tiles => `<div class="kpis" style="margin:0;">${tiles.join('')}</div>`;

function matchDash(S){
  return `<p class="lv-head lv-head--1">① 지금 확인할 것</p>
    ${isAdmin() ? checklistCard(S) : ''}
    ${errorsCard()}
    ${opsCard()}
    <p class="lv-head">② 숫자로 보기</p>
    ${statsTabs(S, false)}
    <p class="lv-head lv-head--3">③ 참고</p>
    <details class="card lv3" data-open-key="dash-ref"><summary>시간대별 접속 · 경기별 접속자 <span class="muted">펼쳐 보기</span></summary>
      <div class="lv3__body">${visitCard(S)}${matchVisitsCard()}</div></details>`;
}
let STAT_TAB = 'part';
document.addEventListener('click', e=>{ const b = e.target.closest('#stat-tab [data-v]'); if(!b) return; STAT_TAB = b.dataset.v; render(); });
function statsTabs(S, season){
  const tabs = `<div class="seg" id="stat-tab" role="tablist">
      <button data-v="part" role="tab" aria-selected="${STAT_TAB === 'part'}" class="${STAT_TAB === 'part' ? 'on' : ''}">참여 현황</button>
      <button data-v="taps" role="tab" aria-selected="${STAT_TAB === 'taps'}" class="${STAT_TAB === 'taps' ? 'on' : ''}">화면 이용</button></div>`;
  let body;
  if(STAT_TAB === 'part') body = season ? seasonPart() : matchPart(S);
  else body = season ? seasonTaps() : tapsBody(TAPS.for === mid() ? TAPS.list : null, TAPS.error, false);
  if(STAT_TAB === 'taps' && !season) loadTaps();
  return `<section class="card"><div class="stat-head">${tabs}</div>${body}</section>`;
}
function matchPart(S){
  const visits = (D.visits || {}).unique || 0;
  return kpiGrid([
    kpi('접속자', fmt(visits), '명', '같은 휴대폰은 1명'),
    kpi('전체 응원', fmt(D.total), '회', `당첨 ${fmt((D.winners || []).length)}명`, 'cheer'),
    kpi('출석체크', fmt(S.ck.count), '명', rateOf(S.ck.count, visits), 'checkin'),
    kpi('경기 예측', fmt(S.pred.count), '명', rateOf(S.pred.count, visits), 'predict'),
    kpi('MVP 투표', fmt(S.mvpRank.reduce((a, b) => a + b.n, 0)), '표', (D.settings || {}).mvp ? `확정 · ${esc(D.settings.mvp.name || '#' + D.settings.mvp.num)}` : '아직 확정 전', 'mvp'),
    kpi('설문 응답', fmt((D.subs.survey || []).length), '명', rateOf((D.subs.survey || []).length, visits), 'survey'),
    kpi('경품 응모', fmt(S.raffle.length), '건', rateOf(S.raffle.length, visits), 'raffle'),
    kpi('룰렛 당첨', fmt(S.rl.wins.length), '건', `돌린 횟수 ${fmt(S.rl.spins)}`, 'codes'),
  ]);
}
const rateOf = (n, total) => total ? `접속자의 ${pct(n, total)}%` : '';

function opsCard(){
  const st = D.settings || {}, phase = st.phase || 'auto', open = CT().open || 'auto';
  return `<section class="card lv1">
    <h2>경기 운영</h2>
    <div class="ops">
      <div class="ops__i"><p class="ops__t">오늘 운영</p>
        <div class="seg" id="dayopen">
          <button data-v="auto" class="${open === 'auto' ? 'on' : ''}">자동</button>
          <button data-v="on" class="${open === 'on' ? 'on live' : ''}">운영</button>
          <button data-v="off" class="${open === 'off' ? 'on' : ''}">미운영</button></div></div>
      <div class="ops__i"><p class="ops__t">경기 진행</p>
        <div class="seg" id="phase">
          <button data-v="auto" class="${phase === 'auto' ? 'on' : ''}">자동</button>
          <button data-v="before" class="${phase === 'before' ? 'on' : ''}">시작 전</button>
          <button data-v="live" class="${phase === 'live' ? 'on live' : ''}">경기 시작</button></div></div>
      <div class="ops__i"><label class="ops__t" for="start">경기 시작 시각 <span class="muted" style="font-weight:600;">· 비우면 경기 일정 기준</span></label>
        <div class="ops__row"><input id="start" type="datetime-local" value="${esc(st.start || '')}"><button class="btn dark small" id="save-start" data-act="save-start">저장</button></div>
        ${st.start ? `<p class="ops__d">저장됨 <b style="color:var(--ink);">${esc(fmtStart(st.start))}</b> <button class="btn small ghost" data-act="clear-start" style="height:24px; padding:0 8px; margin-left:4px;">지우기</button></p>` : ''}</div>
      <div class="ops__i"><label class="ops__t" for="opp">상대팀 <span class="muted" style="font-weight:600;">· 비우면 경기 일정 기준</span></label>
        <div class="ops__row"><input id="opp" list="opp-list" maxlength="20" value="${esc(st.opponent || '')}" placeholder="예: 대한항공">
          <datalist id="opp-list">${['대한항공', '현대캐피탈', 'KB손해보험', '우리카드', '한국전력', '삼성화재'].map(t => `<option value="${t}">`).join('')}</datalist>
          <button class="btn dark small" data-act="save-opp">저장</button></div></div>
    </div>
  </section>`;
}

/* ---------- 시즌 전체 ---------- */
const SEASON = { at:0, loading:false, rows:{}, taps:{}, done:0, total:0 };
function summarize(d){
  const s = d.subs || {}; let wins = 0, spins = 0;
  for(const r of s.roulette || []) for(const w of (r.data || {}).wins || []){ spins++; if(!w.miss) wins++; }
  return { visits:(d.visits || {}).unique || 0, cheer:d.total || 0, cheerWins:(d.winners || []).length,
    checkin:(s.checkin || []).length, predict:(s.predictions || []).length, mvp:(s.mvp || []).length,
    survey:(s.survey || []).length, raffle:(s.raffle_entry || []).length, rlWins:wins, spins };
}
async function loadSeason(force){
  if(SEASON.loading || (!force && Date.now() - SEASON.at < 300000)) return;
  SEASON.loading = true;
  const ids = MATCHES.filter(id => id && id !== '__new').slice(0, 40);
  SEASON.total = ids.length; SEASON.done = 0;
  try{
    for(let i = 0; i < ids.length; i += 4){
      await Promise.all(ids.slice(i, i + 4).map(async id => {
        try{ SEASON.rows[id] = summarize(id === mid() && D && D.subs ? D : await call('GET', encodeURIComponent(id))); }catch(e){ SEASON.rows[id] = null; }
        try{ SEASON.taps[id] = (await call('GET', encodeURIComponent(id) + '/taps')).taps || []; }catch(e){ SEASON.taps[id] = null; }
        SEASON.done++;
      }));
      if(page === 'dash' && SCOPE === 'season') render();
    }
    SEASON.at = Date.now();
  } finally { SEASON.loading = false; }
  if(page === 'dash' && SCOPE === 'season') render();
}
function seasonCalc(){
  const ids = Object.keys(SEASON.rows).filter(id => SEASON.rows[id]).sort().reverse();
  const used = ids.filter(id => { const r = SEASON.rows[id]; return r.visits || r.cheer || r.checkin || r.predict || r.survey || r.raffle; });
  const sum = k => used.reduce((a, id) => a + (SEASON.rows[id][k] || 0), 0);
  return { used, sum };
}
function seasonPart(){
  const { used, sum } = seasonCalc();
  return `${kpiGrid([
      kpi('접속자 합계', fmt(sum('visits')), '명', `경기당 평균 ${used.length ? fmt(Math.round(sum('visits') / used.length)) : 0}명`),
      kpi('전체 응원', fmt(sum('cheer')), '회', `당첨 ${fmt(sum('cheerWins'))}명`),
      kpi('출석체크', fmt(sum('checkin')), '명', rateOf(sum('checkin'), sum('visits'))),
      kpi('경기 예측', fmt(sum('predict')), '명', rateOf(sum('predict'), sum('visits'))),
      kpi('MVP 투표', fmt(sum('mvp')), '표', ''),
      kpi('설문 응답', fmt(sum('survey')), '명', rateOf(sum('survey'), sum('visits'))),
      kpi('경품 응모', fmt(sum('raffle')), '건', rateOf(sum('raffle'), sum('visits'))),
      kpi('룰렛 당첨', fmt(sum('rlWins')), '건', `돌린 횟수 ${fmt(sum('spins'))}`),
    ])}`;
}
function seasonTaps(){
  const tapSum = {};
  for(const id of Object.keys(SEASON.taps)) for(const r of SEASON.taps[id] || []){ const t = tapSum[r.key] || (tapSum[r.key] = { key:r.key, total:0, people:0 }); t.total += r.total; t.people += r.people; }
  const anyTaps = Object.values(SEASON.taps).some(x => x);
  return tapsBody(anyTaps ? Object.values(tapSum) : null, anyTaps ? '' : (SEASON.loading ? '' : '아직 집계된 경기가 없어요'), true);
}
function seasonDash(){
  if(!SEASON.at && !SEASON.loading) loadSeason();
  const { used, sum } = seasonCalc();
  const prog = SEASON.loading ? `불러오는 중 ${SEASON.done} / ${SEASON.total}경기…`
                              : `${SEASON.at ? time(SEASON.at) + ' 기준 · ' : ''}참여 기록이 있는 ${used.length}경기 <button class="btn small ghost" data-act="season-reload" style="height:24px; padding:0 8px; margin-left:4px;">새로 불러오기</button>`;
  return `<p class="lv-head">시즌 합계 <span class="muted" style="font-weight:600; letter-spacing:0;">${prog}</span></p>
    ${statsTabs(null, true)}
    <p class="lv-head">경기별</p>
    <section class="card"><h2>경기별 숫자</h2>
      ${used.length ? `<div class="scroll"><table class="mtable"><thead><tr><th>경기</th><th>접속자</th><th>응원</th><th>출석</th><th>예측</th><th>MVP</th><th>설문</th><th>응모</th><th>룰렛 당첨</th></tr></thead><tbody>
        ${used.map(id => { const r = SEASON.rows[id]; return `<tr data-goto="${esc(id)}" data-scope="match"><td><b>${esc(id)}</b>${id === today() ? ' <span class="chip">오늘</span>' : ''}</td>
          <td><b>${fmt(r.visits)}</b></td><td>${fmt(r.cheer)}</td><td>${fmt(r.checkin)}</td><td>${fmt(r.predict)}</td><td>${fmt(r.mvp)}</td><td>${fmt(r.survey)}</td><td>${fmt(r.raffle)}</td><td>${fmt(r.rlWins)}</td></tr>`; }).join('')}
        <tr class="sum"><td>합계</td><td>${fmt(sum('visits'))}</td><td>${fmt(sum('cheer'))}</td><td>${fmt(sum('checkin'))}</td><td>${fmt(sum('predict'))}</td><td>${fmt(sum('mvp'))}</td><td>${fmt(sum('survey'))}</td><td>${fmt(sum('raffle'))}</td><td>${fmt(sum('rlWins'))}</td></tr>
      </tbody></table></div>` : `<p class="empty">${SEASON.loading ? '불러오는 중…' : '아직 참여 기록이 있는 경기가 없어요.'}</p>`}
    </section>`;
}
document.addEventListener('click', e=>{
  const r = e.target.closest('tr[data-scope="match"]'); if(r) SCOPE = 'match';
}, true);

/* ===== 화면 안내 ===== */
const PAGE_HELP = {
  dash:{ sum:'오늘 경기를 한눈에 보고, 관람객 화면의 큰 흐름(운영 여부 · 예측 마감 · MVP 투표 열기)을 조절해요. 위에서부터 중요한 순서예요.',
    sec:[{ t:'경기 날 할 일', steps:['<b>① 지금 확인할 것</b>에 노란 · 주황 표시가 있으면 먼저 처리해요 (바로가기).', '<b>경기 운영</b>에서 오늘 운영(보통 자동)과 경기 진행을 정해요. 경기가 시작되면 <b>경기 시작</b>을 누르거나 자동으로 두세요.', '<b>경기 시작 시각</b>을 저장하면 그 시각에 예측이 마감돼요. 경기가 늦어지면 시각을 바꿔요.'] },
         { t:'숫자 보기', steps:['<b>② 숫자로 보기</b>에서 참여 현황 / 화면 이용 탭을 눌러요. 숫자 칸을 누르면 그 메뉴로 가요.', '위의 <b>시즌 전체</b>를 누르면 모든 경기 합계와 경기별 표가 나와요.'],
           notes:['숫자는 위쪽 <b>새로고침</b> · 메뉴를 바꿀 때 · 관리자 창으로 돌아올 때 불러와요. 1분이 지나면 \'○○ 기준\'이 노랗게 바뀌어요. 경기 중 계속 보려면 <b>자동</b>(30초마다)을 켜세요.', '추첨 · MVP 확정 · 정답 저장 · 경기 진행처럼 결정하는 버튼은 누르는 순간 최신 데이터를 먼저 불러온 뒤 처리돼요.', '경기 운영에서 바꾼 내용은 20초 안에 관람객 화면에 반영돼요.', '화면 이용은 관람객 화면이 10초마다 모아 보내서 15~25초 늦게 보여요. 선수 카드는 목록 · 운세 TOP 3 · 오늘의 선수 미션에서 연 횟수예요 (카드 안에서 넘겨 본 건 빼요).', '시즌 전체의 접속자 · 사람 수는 경기마다 센 값을 더한 거예요 (여러 경기에 온 사람은 경기마다 1명). 경기별 표의 줄을 누르면 그 경기로 가요.', '관람객 화면 오류가 생기면 ① 영역에 표로 나와요. 같은 오류가 계속 늘면 개발 담당에게 보내주세요.', '<b>경기 리포트 (엑셀)</b>로 이 경기 숫자를 한 번에 내려받아요.'] }] },
  events:{ sum:'경기장 현장 이벤트(예: 부스 선착순 증정)를 관람객 화면 홈 맨 위에 띄워요. 처음 들어온 사람에겐 팝업으로 알려줘요.',
    sec:[{ t:'올리는 방법', steps:['아래 칸에 <b>제목 · 인원·조건 · 장소 · 설명</b>을 넣어요.', '보일 시간을 정하려면 <b>보이기 시작 / 끝</b>을 넣어요 (비우면 바로 ~ 끌 때까지).', '<b>이벤트 올리기</b>를 눌러요.'],
           notes:['여러 개를 올릴 수 있고, 켜 둔 것만 보여요.', '잠깐 내리려면 스위치를 끄고, 끝난 이벤트는 <b>삭제</b>해요.'] }] },
  cheer:{ sum:'오늘 경기 전체 응원 클릭 중 n번째로 누른 사람에게 선물을 줘요. 번호는 관람객에게 보이지 않아요.',
    sec:[{ t:'당첨 번호 등록', steps:['<b>몇 번째 · 선물 · 수령 장소</b>를 넣고 <b>당첨 번호 추가</b>를 눌러요 (예: 1000번째 · 응원 티셔츠).', '그 번호를 누른 관람객 화면에 당첨 팝업과 교환 코드가 떠요.', '부스에서는 <b>룰렛·교환 코드</b> 메뉴에서 코드를 확인하고 교환 처리해요.'],
           notes:['한 사람은 한 번만 당첨돼요.', '리허설 뒤에는 <b>응원 수·당첨 초기화</b>로 0으로 돌려요. 실경기 중엔 누르지 마세요.'] }] },
  predict:{ sum:'경기 전 예측 문항을 관람객 화면 이벤트 › 경기 예측에 내보내고, 경기 뒤 정답을 넣어 맞힌 사람을 정리해요.',
    sec:[{ t:'예측 등록', steps:['질문과 보기를 넣어요. 선수 문항은 <b>선수불러오기</b> → 리베로 제외 / 포함을 골라요.', '<b>AI추천 사용</b>을 켜면 팀 · 선수 기록으로 계산한 추천이 함께 보여요. <b>기준</b>(승리 팀 · 첫 득점 · 세트 스코어 / 공격 · 블로킹 · 서브 · 디그)은 질문을 보고 자동으로 골라요. 안 맞으면 직접 바꾸고, 기록으로 계산할 수 없는 질문은 \'AI 추천 없음\'으로 둬요.', '<b>예측 등록하기</b>를 누르면 20초 안에 반영돼요. 이미 고르기 시작한 관람객 화면은 그대로 둬요.'] },
         { t:'경기 뒤', steps:['문항별 <b>정답</b>을 고르고 <b>정답 저장</b>을 눌러요. 전부 맞힌 사람이 자동으로 세져요.'],
           notes:['등록한 예측 문항은 <b>다음 경기에도 자동으로 이어져요</b>. 새 경기 날 처음 열 때 마지막으로 등록한 문항이 그 경기 문항(v1)으로 들어가요.', '경기 시작 시각이 지나면 예측은 자동으로 마감돼요.', '문항을 바꿀 때마다 버전이 따로 쌓여요. 정답은 버전마다 넣고, \'전부 맞힌 사람\'은 각자 예측한 버전 기준이에요.', '정답자만 추첨하려면 경품 응모·추첨에서 대상을 <b>전부 맞힌 사람</b>으로 골라요.'] }] },
  mvp:{ sum:'관람객 MVP 투표 결과를 보고 오늘의 MVP를 확정해요.',
    sec:[{ t:'확정하는 방법', steps:['경기가 시작되면 관람객 화면에 MVP 투표가 열려요.', '득표가 많은 순서로 보여요. 정할 선수의 <b>MVP로 확정</b>을 눌러요.', '바꾸려면 <b>MVP 카드 해제</b> 후 다른 선수를 확정해요.'],
           notes:['확정한 선수는 관람객 화면 플레이 탭에서 검정 · 금색 MVP 카드로 바뀌어요.', '관람객에게는 득표 수가 보이지 않아요.'] }] },
  survey:{ sum:'관람 설문을 보관함에 만들어 두고, 골라서 경기에 내보내고, 응답 결과를 봐요.',
    sec:[{ t:'설문 만들기', steps:['<b>새 설문 만들기</b> → 문항을 추가해요 (단일 · 복수 · 만족도 0~10 · 행렬). <b>엑셀로 불러오기</b>나 <b>AI로 설문 생성</b>도 돼요.', '앞 문항 답에 따라 보여줄 문항은 <b>+ 조건 추가</b>로 정해요.', '<b>보관함에 저장</b>해요.'] },
         { t:'내보내기 · 결과', steps:['<b>기본으로 지정</b>한 설문이 모든 경기에 나가요. 한 경기만 다르게 하려면 <b>이 경기에만 내보내기</b>.', '결과는 문항별로 보고 <b>응답 CSV</b>로 내려받아요.'],
           notes:['엑셀 열: 번호 · 문항 · 응답 유형 · 선택지 · 기타. 조건 문항은 번호를 \'1-1\'처럼 붙여요.', '나간 설문은 경기마다 버전(v1, v2…)으로 따로 집계돼요. 같은 설문이 다시 나가면 같은 버전으로 묶여요.', '\'중간에 멈춘 문항\'은 설문을 시작했지만 끝내지 않은 사람이 마지막으로 본 문항이에요 (실제보다 조금 적게 잡힐 수 있어요).', '\'전체 합산\'은 모든 버전 응답을 질문 문장이 같은 것끼리 합친 거예요. 복수 선택 문항은 비율 합이 100%를 넘을 수 있어요.', '지금 나가는 설문 문항은 보관함의 <b>미리보기</b>로 볼 수 있어요.'] }] },
  checkin:{ sum:'관람객 홈 \'출석체크\'에서 묻는 질문을 고치고, 오늘 온 사람들의 구성(성별 · 나이 · 누구와)을 봐요.',
    sec:[{ t:'질문 고치기', steps:['질문 옆 <b>편집하기</b>를 눌러 질문 · 답변을 고쳐요 (답변 추가 · 이미지 등록 가능).', '<b>등록</b>을 누르면 관람객 출석체크에 바로 반영돼요.'],
           notes:['답변에 이미지가 없으면 같은 이름의 기본 아이콘(없으면 배구공)이 보여요.', '출석 확인용이라 질문은 짧게 — 최대 3개 · 답변 6개까지예요.', '모든 질문에 답한 사람만, 한 기기에 한 번만 집계돼요.'] }] },
  raffle:{ sum:'홈 미션 5개를 채운 관람객이 닉네임으로 응모해요(연락처는 받지 않아요). 조건에 맞춰 추첨해 당첨자를 정해요.',
    sec:[{ t:'추첨하는 방법', steps:['응모 목록을 훑어보고 부적절한 닉네임은 <b>추첨에서 빼기</b>를 눌러요.', '<b>응모 경로</b>(전체 · 예측 · 설문) · <b>대상</b>(전체 · 예측 전부 맞힌 사람) · <b>뽑을 인원</b>을 골라 <b>추첨하기</b>.', '마음에 들지 않으면 <b>다시 뽑기</b> 또는 한 명만 <b>빼고 다시</b> → <b>이 결과 저장</b>.', '당첨자는 전광판에 닉네임으로 안내해요 (전광판 화면은 현장 운영팀이 띄워요).'],
           notes:['한 기기 · 한 닉네임은 한 번만 뽑혀요.', '금칙어가 들어간 닉네임은 응모 단계에서 막혀요 (설정 › 닉네임 금칙어).', '경기가 끝나면 <b>응모 닉네임 삭제</b>로 정리해요.'] }] },
  codes:{ sum:'부스에서 관람객이 보여준 교환 코드(룰렛 당첨 · 응원 당첨)를 확인하고 교환 처리해요.',
    sec:[{ t:'교환 처리', steps:['관람객 화면의 <b>교환 코드</b>를 입력하고 <b>확인</b>을 눌러요.', '경품 · 발급 시각이 맞으면 <b>교환 처리</b>를 눌러요.', '잘못 눌렀으면 <b>교환 완료 ✓</b>를 다시 눌러 되돌려요.'],
           notes:['한 코드는 한 번만 교환돼요.', '"이 경기에서 발급된 코드가 아니에요"가 뜨면 위쪽 경기 선택(날짜)을 확인해요.'] }] },
  home:{ sum:'관람객 홈 룰렛(경품 · 확률 · 기회 수 · 유의사항)과 아래 굿즈샵 · 앱 배너를 바꿔요. 시즌 공통이라 저장하면 모든 경기에 1분 안에 반영돼요.',
    sec:[{ t:'룰렛', steps:['<b>기본 횟수 · 미션 완료 보너스</b>를 정해요.', '휠 8칸(12시 오른쪽 칸부터 시계 방향)마다 경품 이름 · 이미지 · <b>가중치</b> · 수량을 넣어요.', '<b>당첨 화면 유의사항</b>은 기본 문구 그대로 두고, 바꿀 줄만 고쳐요 (한 줄에 하나).'],
           notes:['확률(%)은 가중치 비율로 자동 계산돼서 합이 100이 아니어도 확률 합은 늘 100%예요. %처럼 쓰고 싶으면 제목 옆 <b>합계 100으로 맞추기</b>.', '경품 이름에 \' / \'를 넣으면 당첨 화면에서 줄이 바뀌어요.', '이미지를 올리면 휠과 당첨 화면에 나와요 (정사각형 PNG 권장 · 자동으로 줄여요).', '당첨 화면 유의사항은 기본 문구가 채워져 있어요. 바꿀 때만 고치면 되고, <b>**두 별표**</b>로 감싼 부분은 주황색으로 강조돼요. <b>기본 문구로 되돌리기</b>로 언제든 원래대로.', '수량을 넣으면 <b>경기마다</b> 그 개수까지만 나가고, 다 나가면 그 칸은 당첨되지 않아요. <b>비우면 무제한 · 0이면 당첨 안 됨</b>.', '당첨은 서버가 뽑아서 휴대폰에서 조작할 수 없어요.'] },
         { t:'배너 · 저장', steps:['굿즈샵 · 앱 배너의 <b>이미지 선택</b>으로 배너 이미지를 넣어요 (가로로 긴 1440×346 비율 권장). 앱 배너는 <b>라이트 모드 / 다크 모드</b> 탭에서 각각 넣을 수 있어요 (한쪽만 넣으면 두 모드 모두 그 이미지).', '제목 · 설명 · 링크를 고쳐요.', '<b>저장 (모든 경기)</b>을 눌러요. 저장 전에는 <b>되돌리기</b>로 원래대로 돌릴 수 있어요.'],
           notes:['모든 경기에 영향을 줘서 총괄 관리자만 저장할 수 있어요.'] }] },
  'settings:reset':{ sum:'리허설 · 테스트 데이터를 지워요. 항목만 골라 지우거나, 경기를 통째로 지우거나(목록에서도 빠짐), 시즌 전체를 지울 수 있어요.',
    sec:[{ t:'지우는 방법', steps:['지울 항목을 골라요 (접속자 · 응원 · 출석 · 예측 · MVP · 설문 · 응모 · 룰렛 · 이 경기 설정).', '<b>초기화</b>를 누르고 경기 ID를 한 번 더 입력해요.'],
           notes:['지운 데이터는 되돌릴 수 없어요. 실경기 날엔 쓰지 마세요.', '관람객 휴대폰에 남은 이 경기 진행 기록(미션 · 설문 답 · 응모)도 20~30초 안에 같이 지워져요.', '설문 보관함(시즌 공통) · 다른 경기 데이터 · 관리자 계정 · 등록한 예측 문항은 그대로예요.'] }] },
  'settings:account':{ sum:'관리자 계정을 만들고 비밀번호를 관리해요. 사람마다 계정을 따로 만들면 작업 기록에 누가 했는지 남아요.',
    sec:[{ t:'계정', steps:['<b>계정 추가</b> — 아이디 · 이름 · 권한을 골라요.', '<b>비밀번호 재설정</b>으로 다른 사람 비밀번호를 바꾸고, 내 비밀번호는 <b>내 비밀번호 바꾸기</b>에서 바꿔요.', '로그인을 여러 번 틀려 잠긴 계정은 <b>잠금 풀기</b>.'],
           notes:['Cloudflare 환경변수(ADMIN_KEY)로 만든 총괄 관리자 계정은 여기서 바꿀 수 없어요.', '총괄 관리자 — 계정 · 초기화 · 룰렛 경품까지 전부', '일반 관리자 — 경기 운영 전부 (초기화 · 계정 · 룰렛 경품 제외)', '부스 담당 — 조회와 교환 코드 처리만'] }] },
  'settings:privacy':{ sum:'관람객 화면의 \'데이터 안내\'(홈 아래 · 출석체크 · 설문 첫 문항 · 경품 응모) 문구 중 세 가지를 정해요.',
    sec:[{ t:'정하는 방법', steps:['보관 기간 · 추가 안내를 넣어요.', '<b>저장</b>하면 관람객 데이터 안내에 반영돼요.'],
           notes:['모으는 정보 · 쓰는 곳 · 모으지 않는 것은 화면에 고정돼 있어요.', '준법 검토 결과에 맞게 고쳐주세요.'] }] },
  'settings:nickban':{ sum:'경품 응모 닉네임에 못 쓰는 말을 정해요. 당첨 닉네임은 경기장 전광판에 나가요.',
    sec:[{ t:'금칙어 관리', steps:['<b>금칙어 추가</b> 칸에 넣고 <b>추가</b> (쉼표로 여러 개).', '지우려면 칩의 <b>×</b>를 눌러요.'],
           notes:['욕설 · 비하 등 기본 금칙어는 늘 막아요 (기본 금칙어 보기).', '단어가 닉네임에 포함만 돼도 막아요.'] }] },
  'settings:subway':{ sum:'관람객 화면 막차안내에 쓰는 체육공원역 시간표를 넣어요. 시즌 공통이에요.',
    sec:[{ t:'시간표 붙여넣기', steps:['<a href="https://www2.humetro.busan.kr/homepage/english/stationtime/page/view.do?menu_no=10060102" target="_blank" rel="noopener">부산교통공사 열차시간표</a>에서 <b>3호선 → 체육공원(Sports Park)</b>을 골라요.', '방향(상행 · 하행)을 고르고, 표 맨 위 \'시\'부터 맨 아래 \'00\'까지 드래그해 복사(Ctrl+C) → 해당 방면 칸에 붙여넣기(Ctrl+V).', '반대 방향도 똑같이 하고 <b>저장</b>해요.'],
           notes:['평일 · 토요일 · 일요일 세 칸을 같이 읽어요. 붙여넣지 않은 방향은 지금 저장된 것을 그대로 둬요.', '시간표가 바뀌면 다시 붙여넣기만 하면 돼요. 관람객 화면엔 10분 안에 반영돼요.'] }] },
  'settings:audit':{ sum:'누가 언제 무엇을 바꿨는지 기록이 남아요.', sec:[{ t:'보는 방법', steps:['최근 작업부터 보여요. 이상한 변경이 있으면 해당 계정에 확인해요.'] }] },
};
const GUIDE_FOLD = (()=>{ try{ return JSON.parse(localStorage.getItem('adm_guide_fold2') || '{}'); }catch(e){ return {}; } })();
function addPageHelp(){
  const key = page === 'settings' ? 'settings:' + (window.__setTab || 'account') : page;
  const h = PAGE_HELP[key], t = document.querySelector('#main .page-title');
  if(!h || !t || document.querySelector('#main .guide')) return;
  const folded = GUIDE_FOLD[key] !== false;
  const secs = h.sec || [];
  const steps = secs.filter(x => x.steps && x.steps.length).map(x =>
    `<div class="gbox"><p class="gbox__h"><span class="gbox__n">${x.t}</span></p><ol class="gbox__ol">${x.steps.map(v => `<li>${v}</li>`).join('')}</ol></div>`).join('');
  const notes = secs.filter(x => x.notes && x.notes.length);
  const tip = notes.length ? `<div class="gbox gbox--tip"><p class="gbox__h">알아두면 좋아요</p><ul class="gbox__ul">${notes.flatMap(x => x.notes).map(v => `<li>${v}</li>`).join('')}</ul></div>` : '';
  const boxes = steps + tip;
  const html = `<section class="guide${folded ? ' is-folded' : ''}" data-key="${key}" aria-label="화면 안내">
    <div class="guide__top"><span class="guide__ic" aria-hidden="true">i</span><p class="guide__sum">${h.sum}</p>
      <button type="button" class="guide__fold" data-guide-fold aria-expanded="${!folded}">${folded ? '자세히' : '접기'}</button></div>
    <div class="guide__body">${boxes}</div></section>`;
  const anchor = document.querySelector('#main .settabs') || t;
  anchor.insertAdjacentHTML('afterend', html);
}
document.addEventListener('click', e=>{
  const b = e.target.closest('[data-guide-fold]'); if(!b) return;
  const g = b.closest('.guide'), k = g.dataset.key;
  const nowFolded = !g.classList.contains('is-folded');
  GUIDE_FOLD[k] = nowFolded;
  try{ localStorage.setItem('adm_guide_fold2', JSON.stringify(GUIDE_FOLD)); }catch(err){}
  g.classList.toggle('is-folded', nowFolded);
  b.textContent = nowFolded ? '자세히' : '접기'; b.setAttribute('aria-expanded', String(!nowFolded));
});
const VIEWS = {
  /* ---------- 대시보드 ---------- */
  dash: S => {
    const season = SCOPE === 'season';
    const nMatch = MATCHES.filter(id => id && id !== '__new').length;
    return `<p class="page-title">대시보드 <button class="btn small ghost" data-act="report" style="vertical-align:4px; margin-left:6px;">경기 리포트 (엑셀)</button></p>
    
    <div class="seg" id="scope" style="margin:0 0 16px;">
      <button data-v="match" class="${season ? '' : 'on'}">이 경기 · ${esc(mid())}</button>
      <button data-v="season" class="${season ? 'on' : ''}">시즌 전체 · ${nMatch}경기</button>
    </div>
    ${season ? seasonDash() : matchDash(S)}`;
  },

  /* ---------- 현장 이벤트 ---------- */
  events: () => {
    const evs = D.events || [];
    return `<p class="page-title">현장 이벤트</p>
    <section class="card">
      ${evs.length ? evs.map((e, i) => `<div class="row">
        <div class="main"><p class="t">${e.limit ? `<span class="chip${e.active === false ? ' off' : ''}">${esc(e.limit)}</span>` : ''}${esc(e.title)}</p>
        <p class="m">${esc(e.place)}${e.startsAt || e.endsAt ? ` · ${hm(e.startsAt) || '바로'} ~ ${hm(e.endsAt) || '끌 때까지'}` : ''}</p></div>
        <button class="toggle${e.active === false ? '' : ' on'}" data-act="ev-toggle" data-i="${i}" aria-label="보이기"></button>
        <button class="btn small ghost" data-act="ev-del" data-i="${i}">삭제</button></div>`).join('') : `<p class="empty">올린 이벤트가 없어요.</p>`}
      <div class="form">
        <div class="field"><label>제목</label><input id="ev-title" maxlength="40" placeholder="읏맨 티셔츠 증정"></div>
        <div class="field"><label>인원·조건</label><input id="ev-limit" maxlength="20" placeholder="선착순 3명"></div>
        <div class="field full"><label>장소</label><input id="ev-place" maxlength="40" placeholder="1층 OK저축은행 부스"></div>
        <div class="field full"><label>설명</label><textarea id="ev-desc" maxlength="200" placeholder="경기 시작 전까지 부스에 오셔서 이 화면을 보여주세요."></textarea></div>
        <div class="field"><label>보이기 시작 (비우면 바로)</label><input id="ev-start" type="datetime-local"></div>
        <div class="field"><label>보이기 끝 (비우면 끌 때까지)</label><input id="ev-end" type="datetime-local"></div>
        <button class="btn" data-act="ev-add">이벤트 올리기</button>
      </div>
    </section>`;
  },

  /* ---------- 응원 이벤트 ---------- */
  cheer: () => {
    const won = new Map((D.winners || []).map(w => [w.n, w]));
    const pz = D.prizes || [];
    const extra = (D.winners || []).filter(w => !pz.some(p => p.n === w.n));
    return `<p class="page-title">응원 이벤트</p>
    <div class="kpis" style="grid-template-columns:1fr 1fr;"><div class="kpi"><span>지금까지 전체 응원</span><b>${fmt(D.total)}</b></div><div class="kpi"><span>당첨</span><b>${(D.winners || []).length} / ${pz.length + extra.length}</b></div></div>
    <section class="card">
      ${(pz.length || extra.length) ? [...pz.map((p, i) => { const w = won.get(p.n); return `<div class="row">
        <div class="main"><p class="t"><span class="chip ${w ? 'gold' : 'off'}">${fmt(p.n)}번째</span>${esc(p.prize)}</p>
        <p class="m">${esc(p.place)}${w ? ` · ${time(w.at)} 당첨 · 기기 …${esc(w.device)}` : (D.total >= p.n ? ' · 지나감' : ` · ${fmt(p.n - D.total)}번 남음`)}</p></div>
        ${w ? `<span class="code">${esc(w.code)}</span>${redeemBtn(w.code)}` : `<button class="btn small ghost" data-act="pz-del" data-i="${i}">삭제</button>`}</div>`; }),
        ...extra.map(w => `<div class="row"><div class="main"><p class="t"><span class="chip gold">${fmt(w.n)}번째</span>${esc(w.prize)}</p><p class="m">${esc(w.place)} · ${time(w.at)}</p></div><span class="code">${esc(w.code)}</span>${redeemBtn(w.code)}</div>`)].join('')
        : `<p class="empty">등록한 당첨 번호가 없어요.</p>`}
      <div class="form">
        <div class="field"><label>몇 번째</label><input id="pz-n" type="number" min="1" placeholder="1000"></div>
        <div class="field"><label>선물</label><input id="pz-prize" maxlength="40" placeholder="읏맨 응원 티셔츠"></div>
        <div class="field full"><label>수령 장소</label><input id="pz-place" maxlength="40" placeholder="1층 OK저축은행 부스"></div>
        <button class="btn" data-act="pz-add">당첨 번호 추가</button>
      </div>
      <div style="margin-top:14px; display:flex; justify-content:flex-end;">${isOwner() ? '<button class="btn small danger" data-act="reset-cheer">응원 수·당첨 초기화 (리허설용)</button>' : ''}</div>
    </section>`;
  },

  /* ---------- 경기 예측 ---------- */
  predict: S => {
    const reg = Array.isArray(CT().predict) && CT().predict.length;
    if(!DR.predict) DR.predict = clone(reg ? CT().predict : PRED_DEF);
    const editor = `<section class="card">
      <h2>예측 등록하기 ${reg ? '<span class="chip ok">등록됨</span>' : '<span class="chip off">기본 문항이 나가는 중</span>'}</h2>
      
      ${qEditor('predict')}
      <div class="edfoot">${DR.predict.length < LIMIT.predictQ ? `<button class="btn ghost" data-act="ed-add" data-ed="predict">+ 질문 추가</button>` : '<span></span>'}
        <button class="btn" data-act="pred-save">예측 등록하기</button></div>
    </section>`;
    return `<p class="page-title">경기 예측 <button class="btn small ghost" data-act="csv-predict" style="vertical-align:4px; margin-left:6px;">CSV 내려받기</button></p>
    ${editor}
    ${predResults(S)}`;
  },

  /* ---------- MVP ---------- */
  mvp: S => {
    const total = S.mvpRank.reduce((a, b) => a + b.n, 0), max = Math.max(1, ...S.mvpRank.map(r => r.n));
    const cur = (D.settings || {}).mvp;
    return `<p class="page-title">MVP 투표</p>
    <section class="card">
      ${S.mvpRank.length ? S.mvpRank.map((r, i) => `<div class="row">
        <div class="main"><div class="bar${i === 0 ? ' top' : ''}" style="margin:0;"><span class="l"><b>${i + 1}</b> · #${esc(r.num)} ${esc(r.name)}</span><span class="tr"><span class="f" style="width:${r.n / max * 100}%"></span></span><span class="n">${r.n}표 · ${pct(r.n, total)}%</span></div></div>
        ${cur && String(cur.num) === String(r.num) ? `<span class="chip gold">MVP</span>` : `<button class="btn small ghost" data-act="mvp-set" data-num="${esc(r.num)}" data-name="${esc(r.name)}">MVP로 확정</button>`}
      </div>`).join('') : `<p class="empty">아직 투표가 없어요. MVP 투표는 경기가 시작되면 열려요.</p>`}
      ${cur ? `<div style="margin-top:12px; display:flex; justify-content:flex-end;"><button class="btn small ghost" data-act="mvp-clear">MVP 카드 해제</button></div>` : ''}
    </section>`;
  },

  /* ---------- 설문 ---------- */
  survey: S => {
    if(!LIB.at) loadLib();
    const n = (D.subs.survey || []).length;
    const live = D.survey;
    const results = survResults(S);
    const head = `<p class="page-title">설문 <button class="btn small ghost" data-act="csv-survey" style="vertical-align:4px; margin-left:6px;">응답 CSV 내려받기</button></p>`;

    if(DR.svEdit) return `${head}
      <section class="card">
        <h2>설문 편집 <span style="display:flex; gap:8px;"><button class="btn small ghost" data-act="sv-xlsx">엑셀 양식으로 내려받기</button><button class="btn small dark" data-act="sv-ai">AI로 설문 생성하기</button></span></h2>
        <div class="field"><label for="sv-title">설문 제목 (보관함·버전에 보이는 이름)</label><input class="in" id="sv-title" maxlength="60" value="${esc(DR.svEdit.title || '')}" placeholder="예: 26-27 시즌초반 관람객설문"></div>
        
        ${sEditor()}
        <div class="edfoot">${DR.survey.length < LIMIT.surveyQ ? `<button class="btn ghost" data-act="ed-add" data-ed="survey">+ 문항 추가</button>` : '<span></span>'}
          <span style="display:flex; gap:8px;"><button class="btn ghost" data-act="sv-cancel">취소</button><button class="btn" data-act="sv-save">보관함에 저장</button></span></div>
      </section>`;

    const liveCard = live
      ? `<section class="card"><h2><span>${esc(live.title || '제목 없는 설문')} <span class="chip">${vLabel(live.v)}</span> <span class="chip ${live.source === 'match' ? '' : 'ok'}">${live.source === 'match' ? '이 경기만 따로 지정' : '보관함 기본 설문'}</span></span>
          ${live.source === 'match' ? `<button class="btn small ghost" data-act="lib-match-reset">보관함 기본 설문으로 되돌리기</button>` : ''}</h2>
          <p class="meta">${esc(mid())} 경기에 지금 나가는 설문 · ${live.items.length}문항 · 응답 ${fmt(n)}명</p></section>`
      : `<section class="card"><h2>지금 나가는 설문 <span class="chip off">비상용 기본 문항</span></h2>
          <p class="meta">기본 문항 ${SURV_DEF.length}개가 나가는 중 — 보관함에서 설문을 '기본으로 지정'해 주세요</p></section>`;

    const rows = LIB.surveys.map((e, i) => {
      const isDef = e.id === LIB.defaultId, isLive = live && live.lib === e.id && canon(live.items) === canon(e.items);
      return `<div class="row"><div class="main">
          <p class="t">${esc(e.title)} ${isDef ? '<span class="chip ok">기본</span>' : ''} ${isLive ? '<span class="chip">지금 이 경기에 나가는 중</span>' : ''}</p>
          <p class="m">${e.items.length}문항 · ${time(e.updatedAt || e.at)} 수정</p></div>
        <div class="acts">
          <button class="btn small ghost" data-act="lib-preview" data-i="${i}">미리보기</button>
          ${isDef ? '' : `<button class="btn small ghost" data-act="lib-default" data-i="${i}">기본으로 지정</button>`}
          ${isLive ? '' : `<button class="btn small ghost" data-act="lib-use" data-i="${i}">이 경기에만 내보내기</button>`}
          <button class="btn small ghost" data-act="lib-edit" data-i="${i}">고치기</button>
          <button class="btn small ghost" data-act="lib-xlsx" data-i="${i}">엑셀</button>
          <button class="btn small danger" data-act="lib-del" data-i="${i}">삭제</button>
        </div></div>`; }).join('');
    const libCard = `<section class="card">
      <h2>설문 보관함 <span class="muted" style="font-size:12px; font-weight:600;">시즌 전체 공통</span></h2>
      <div class="opts" style="margin:0 0 6px;">
        <button class="btn small dark" data-act="sv-import">엑셀로 불러오기</button>
        <button class="btn small ghost" data-act="lib-new">새 설문 만들기</button>
      </div>
      
      ${!LIB.at ? '<p class="empty">불러오는 중…</p>' : LIB.err && !LIB.surveys.length ? `<p class="empty">보관함을 불러오지 못했어요 — 서버(okman-live)를 이번 버전으로 배포했는지 확인해주세요.</p>` : rows || '<p class="empty">보관함이 비어 있어요. 엑셀로 불러오기부터 해주세요.</p>'}
    </section>`;
    return `${head}
      ${liveCard}${libCard}${results}`;
  },

  home: () => homeView(),

  /* ---------- 설정 ---------- */
  settings: S => {
    const tabs = [
      isOwner() && ['reset', '데이터 초기화'],
      ['account', isOwner() ? '계정 관리' : '내 계정'],
      isOwner() && ['privacy', '데이터 안내'],
      isAdmin() && ['nickban', '닉네임 금칙어'],
      isAdmin() && ['subway', '막차 시간표'],
      ['audit', '작업 기록'],
    ].filter(Boolean);
    const tab = tabs.some(([k]) => k === DR.setTab) ? DR.setTab : tabs[0][0];
    window.__setTab = tab;
    const body = { reset:() => resetCard(S), account:() => accountCards() + (isOwner() ? locksCard() : ''), privacy:() => privacyCard(), nickban:() => nickBanCard(), subway:() => subwayCard(), audit:() => auditCard() }[tab]();
    return `<p class="page-title">설정</p>
      <div class="settabs" role="tablist">${tabs.map(([k, t]) => `<button role="tab" aria-selected="${k === tab}" class="${k === tab ? 'on' : ''}" data-settab="${k}">${t}</button>`).join('')}</div>
      ${body}`;
  },

  /* ---------- 경품 응모 · 추첨 ---------- */
  raffle: S => {
    const saved = D.raffleWinners || [];
    const route = r => [r.viaPredict ? '예측' : '', r.viaSurvey ? '설문' : ''].filter(Boolean).join(' · ') || '—';
    return `<p class="page-title">경품 응모 · 추첨</p>
    <section class="card">
      <h2>추첨하기</h2>
      <div class="form" style="grid-template-columns:1fr 1fr 1fr auto;">
        <div class="field" style="grid-column:auto;"><label>응모 경로</label><select id="rf-src"><option value="">전체</option><option value="predict">예측</option><option value="survey">설문</option></select></div>
        <div class="field" style="grid-column:auto;"><label>대상</label><select id="rf-only"><option value="">응모자 전체</option><option value="correct">예측 전부 맞힌 사람만</option></select></div>
        <div class="field" style="grid-column:auto;"><label>뽑을 인원</label><input id="rf-n" type="number" min="1" value="3"></div>
        <button class="btn" data-act="rf-draw" style="grid-column:auto; align-self:end;">추첨하기</button>
      </div>
    </section>
    <section class="card">
      <h2><span>저장한 당첨자 <span class="muted" style="font-size:13px; font-weight:600;">${saved.length}명</span></span></h2>
      ${saved.length ? saved.map(w => { const nm = w.nickname || w.contact; return `<div class="row"><div class="main"><p class="t">${esc(nm)}</p><p class="m">${esc(w.route || ({ predict:'예측', survey:'설문' })[w.source] || '')}${w.at ? ' · ' + time(w.at) + ' 응모' : ''}</p></div><button class="btn small ghost" data-copy="${esc(nm)}">복사</button></div>`; }).join('') : `<p class="empty">저장한 당첨자가 없어요.</p>`}
    </section>
    <section class="card">
      <h2>응모 목록 ${isOwner() ? '<button class="btn small danger" data-act="rf-clear">응모 닉네임 삭제</button>' : ''}</h2>
      
      ${S.raffle.length ? `<div class="scroll"><table><thead><tr><th>닉네임</th><th>경로</th><th>예측 정답</th><th>응모 시각</th><th></th></tr></thead><tbody>
        ${S.raffle.slice().sort((a, b) => (b.at || 0) - (a.at || 0)).map(r => { const hid = (D.raffleHidden || {})[r.device]; return `<tr class="${hid ? 'hid' : ''}"><td><b>${esc(r.name)}</b>${hid ? ' <span class="chip off">추첨 제외</span>' : ''}</td><td>${route(r)}</td><td>${S.pred.allCorrect.has(r.device) ? '<span class="chip ok">전부 정답</span>' : '<span class="muted">—</span>'}</td><td class="muted">${time(r.at)}</td><td><button class="btn small ghost" data-act="rf-hide" data-dev="${esc(r.device)}" data-h="${hid ? 0 : 1}">${hid ? '다시 넣기' : '추첨에서 빼기'}</button></td></tr>`; }).join('')}
      </tbody></table></div>` : `<p class="empty">아직 응모 내역이 없어요.</p>`}
    </section>`;
  },

  /* ---------- 룰렛 · 교환 코드 ---------- */
  codes: S => {
    const all = [...S.rl.wins, ...(D.winners || []).map(w => ({ code:w.code, title:w.prize, at:w.at, device:w.device, type:'응원' }))].sort((a, b) => b.at - a.at);
    const red = D.redeemed || {};
    return `<p class="page-title">룰렛 · 교환 코드</p>
    <section class="card">
      <h2>교환 코드 확인</h2>
      <div class="form" style="grid-template-columns:1fr auto; margin-top:0;">
        <div class="field" style="grid-column:auto;"><label>코드</label><input id="code-q" maxlength="12" placeholder="예: X7QK" style="text-transform:uppercase; font-size:18px; font-weight:800; letter-spacing:.12em;"></div>
        <button class="btn" data-act="code-find" style="grid-column:auto; align-self:end;">확인</button>
      </div>
      <div id="code-result"></div>
    </section>
    <div class="grid2">
      <section class="card"><h2>룰렛 결과 <span class="muted" style="font-size:13px; font-weight:600;">${fmt(S.rl.spins)}회</span></h2>${bars(S.rl.byTitle)}</section>
      <section class="card"><h2>교환 현황</h2>
        <div class="kpis" style="grid-template-columns:1fr 1fr; margin:0;"><div class="kpi"><span>발급</span><b>${all.length}</b></div><div class="kpi hot"><span>교환 완료</span><b>${all.filter(w => red[w.code]).length}</b></div></div></section>
    </div>
    <section class="card"><h2>발급된 코드</h2>
      ${all.length ? `<div class="scroll"><table><thead><tr><th>코드</th><th>구분</th><th>경품</th><th>발급</th><th>상태</th></tr></thead><tbody>
        ${all.map(w => `<tr><td><span class="code">${esc(w.code)}</span></td><td>${w.type}</td><td>${esc(w.title)}</td><td class="muted">${time(w.at)}</td><td>${redeemBtn(w.code)}</td></tr>`).join('')}
      </tbody></table></div>` : `<p class="empty">아직 발급된 코드가 없어요.</p>`}
    </section>`;
  },

  /* ---------- 출석체크 ---------- */
  checkin: S => {
    const qs = (Array.isArray(CT().checkin) && CT().checkin.length) ? CT().checkin : CK_DEF;
    return `<p class="page-title">출석체크</p>
    <div class="grid2">
      ${qs.map((q, i) => `<section class="card"><h2>${esc(q.q)} <button class="btn small ghost" data-act="ck-edit" data-i="${i}">편집하기</button></h2>
        ${bars(S.ck.by[q.key] || {}, { order:q.opts.map(o => o.label) })}</section>`).join('')}
    </div>
    ${qs.length < LIMIT.ckQ ? `<button class="btn ghost" data-act="ck-edit" data-i="new">+ 질문 추가</button>` : ''}`;
  },
};

function redeemBtn(code){
  const at = (D.redeemed || {})[code];
  return at ? `<button class="btn small ghost" data-act="redeem" data-code="${esc(code)}" data-v="0" title="${time(at)} 교환">교환 완료 ✓</button>`
            : `<button class="btn small" data-act="redeem" data-code="${esc(code)}" data-v="1">교환 처리</button>`;
}

const AFTER = {
  raffle: S => { window.__raffleS = S; },
};

/* ===== 동작 ===== */
async function act(fn, okMsg, keepForm){
  busy = true;
  try{ await fn(); if(!keepForm) render.last = null; await load(true); if(okMsg) toast(okMsg); return true; }
  catch(e){ toast(e.message, true); return false; }
  finally{ busy = false; }
}
const val = id => ($(id) || {}).value || '';

document.addEventListener('click', e=>{
  const cp = e.target.closest('[data-copy]');
  if(cp){ navigator.clipboard.writeText(cp.dataset.copy).then(()=> toast('복사했어요')); return; }
  const b = e.target.closest('[data-act]'); if(!b) return;
  const i = Number(b.dataset.i);
  switch(b.dataset.act){
    case 'ev-add': {
      const ev = { title:val('ev-title').trim(), limit:val('ev-limit').trim(), place:val('ev-place').trim(), desc:val('ev-desc').trim(),
                   startsAt:val('ev-start'), endsAt:val('ev-end'), active:true, createdAt:Date.now() };
      if(!ev.title) return toast('이벤트 제목을 넣어주세요.', true);
      return act(()=> mcall('PUT', 'events', { events:[...(D.events || []), ev] }), '이벤트를 올렸어요. 관람객 화면엔 20초 안에 보여요.');
    }
    case 'ev-toggle': return act(()=> mcall('PUT', 'events', { events:(D.events || []).map((x, j) => j === i ? { ...x, active:x.active === false } : x) }));
    case 'ev-del': if(!confirm('이 이벤트를 삭제할까요?')) return; return act(()=> mcall('PUT', 'events', { events:(D.events || []).filter((_, j) => j !== i) }), '삭제했어요.');
    case 'pz-add': {
      const p = { n:Number(val('pz-n')), prize:val('pz-prize').trim(), place:val('pz-place').trim() };
      if(!(p.n > 0) || !p.prize) return toast('몇 번째와 선물을 넣어주세요.', true);
      if((D.prizes || []).some(x => x.n === p.n)) return toast('이미 등록된 번호예요.', true);
      if(p.n <= (D.total || 0)) return toast(`이미 ${fmt(D.total)}번째까지 눌렸어요. 더 큰 번호를 넣어주세요.`, true);
      return act(()=> mcall('PUT', 'prizes', { prizes:[...(D.prizes || []), p] }), '당첨 번호를 추가했어요.');
    }
    case 'pz-del': return act(()=> mcall('PUT', 'prizes', { prizes:(D.prizes || []).filter((_, j) => j !== i) }));
    case 'reset-cheer': if(!confirm('이 경기의 응원 수와 응원 당첨 기록을 0으로 되돌릴까요? 리허설 때만 쓰세요.')) return; return act(()=> mcall('POST', 'reset-cheer'), '초기화했어요.');
    case 'mvp-set': if(!confirm(`#${b.dataset.num} ${b.dataset.name} 선수를 MVP로 확정할까요?`)) return;
      return act(()=> mcall('PUT', 'settings', { mvp:{ num:Number(b.dataset.num), name:b.dataset.name, title:'MVP' } }), 'MVP를 확정했어요.');
    case 'mvp-clear': return act(()=> mcall('PUT', 'settings', { mvp:null }), 'MVP 카드를 해제했어요.');
    case 'save-start': {
      const el = $('start');
      if(el.validity.badInput || !el.value) return toast('날짜와 시각(시·분, 오전/오후)을 모두 넣어주세요.', true);
      return act(()=> mcall('PUT', 'settings', { start:el.value }), `시작 시각을 ${fmtStart(el.value)}로 저장했어요.`);
    }
    case 'clear-start': if(!confirm('저장한 시작 시각을 지울까요? 경기 일정표 기준으로 돌아가요.')) return;
      return act(()=> mcall('PUT', 'settings', { start:'' }), '시작 시각을 지웠어요.');
    case 'ans-save': {
      const answers = { ...((D.settings || {}).answers || {}) };
      document.querySelectorAll('[data-ans]').forEach(s => { if(s.value) answers[s.dataset.ans] = s.value; else delete answers[s.dataset.ans]; });
      return act(()=> mcall('PUT', 'settings', { answers }), '정답을 저장했어요.');
    }
    case 'rf-draw': return drawRaffle();
    case 'rf-save': {
      const w = window.__draw || []; if(!w.length) return;
      closeModal();
      return act(()=> mcall('PUT', 'raffle', { winners:[...(D.raffleWinners || []), ...w.map(x => ({ nickname:x.name, contact:x.name, device:x.device, route:x.route, at:x.at }))] }), '당첨자를 저장했어요.');
    }
    case 'rf-clear': if(!confirm('응모 닉네임 목록을 모두 삭제할까요? 추첨이 끝난 뒤에 지워주세요. 되돌릴 수 없어요.')) return;
      return act(()=> mcall('POST', 'raffle-clear'), '응모 닉네임을 삭제했어요.');

    case 'ed-add': {
      const k = b.dataset.ed;
      DR[k].push(k === 'predict' ? { id:'q' + Date.now().toString(36), q:'', options:['OK저축은행 읏맨', '상대팀'], ai:true } : { id:svNextId(), q:'', type:'single', options:['', '', ''] });
      return render();
    }
    case 'ed-del': { const k = b.dataset.ed; if(DR[k].length > 1) DR[k].splice(i, 1); return render(); }
    case 'ed-oadd': { const k = b.dataset.k || 'options'; DR[b.dataset.ed][i][k].push(''); render(); const ins = document.querySelectorAll(`[data-ed="${b.dataset.ed}"][data-i="${i}"][data-f="${k === 'options' ? (b.dataset.ed === 'survey' ? 'options' : 'opt') : k}"]`); ins[ins.length - 1]?.focus(); return; }
    case 'ed-odel': { const k = b.dataset.k || 'options', arr = DR[b.dataset.ed][i][k], min = k === 'rows' ? 1 : 2; if(arr.length > min) arr.splice(Number(b.dataset.j), 1); return render(); }
    case 'sv-nocond': delete DR.survey[i].cond; return render();
    case 'sv-cond-add': { const par = condParents(DR.survey, i); if(!par.length) return; DR.survey[i].cond = { id:par[par.length - 1].id, in:[] }; return render(); }
    case 'sv-xlsx': return downloadSurveyXlsx(cleanSurvey(DR.survey), (DR.svEdit || {}).title).catch(e => toast(e.message, true));

    case 'lib-add': case 'lib-add-edit': {
      const imp = window.__svImport; if(!imp) return;
      const title = (val('imp-title') || '').trim() || imp.title;
      if(b.dataset.act === 'lib-add-edit'){ closeModal(); DR.svEdit = { id:'', title, makeDefault:$('imp-def') && $('imp-def').checked }; DR.survey = clone(imp.items); return render(); }
      const e = { id:'s' + Date.now().toString(36), title, items:imp.items, at:Date.now(), updatedAt:Date.now() };
      const makeDef = $('imp-def') && $('imp-def').checked;
      closeModal();
      return saveLib({ surveys:[...LIB.surveys, e], defaultId:makeDef ? e.id : LIB.defaultId }, makeDef ? `'${title}'을 보관함에 넣고 기본 설문으로 지정했어요. 관람객 화면엔 1분 안에 보여요.` : `'${title}'을 보관함에 넣었어요.`);
    }
    case 'sv-import': loadXlsx().catch(()=>{}); return $('sv-file').click();
    case 'lib-new': DR.svEdit = { id:'', title:'' }; DR.survey = [{ id:'1', q:'', type:'single', options:['', '', ''] }]; return render();
    case 'lib-edit': { const e = libIdx(i); if(!e) return; DR.svEdit = { id:e.id, title:e.title }; DR.survey = clone(e.items); scrollTo(0, 0); return render(); }
    case 'lib-preview': { const e = libIdx(i); if(!e) return;
      openModal(`<div class="modal__head"><h3>${esc(e.title)}</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
        <p class="desc">${e.items.length}문항</p><div style="max-height:60vh; overflow:auto;">${svList(e.items)}</div>`); $('modal-box').style.maxWidth = '640px'; return; }
    case 'lib-xlsx': { const e = libIdx(i); if(e) downloadSurveyXlsx(e.items, e.title).catch(err => toast(err.message, true)); return; }
    case 'lib-default': { const e = libIdx(i); if(!e) return;
      if(!confirm(`'${e.title}'을 기본 설문으로 지정할까요?
따로 설문을 내보낸 경기를 빼고, 모든 경기 관람객에게 1분 안에 이 설문이 나가요.
이미 답한 관람객은 다시 답하지 않아요.`)) return;
      return saveLib({ surveys:LIB.surveys, defaultId:e.id }, `'${e.title}'을 기본 설문으로 지정했어요.`); }
    case 'lib-use': { const e = libIdx(i); if(!e) return;
      const cv = S0().sv.find(v => v.current);
      if(!confirm(`'${e.title}'을 ${mid()} 경기에만 내보낼까요?${cv && cv.rows.length ? `
지금 설문에 ${cv.rows.length}명이 답했어요. 새 설문은 따로 집계되고, 이미 답한 분은 다시 답하지 않아요.` : ''}`)) return;
      return saveContent({ survey:e.items, surveyTitle:e.title, surveyLib:e.id }, `'${e.title}'을 이 경기에 내보냈어요. 관람객 화면엔 20초 안에 보여요.`); }
    case 'lib-match-reset': if(!confirm('이 경기에 따로 내보낸 설문을 빼고 보관함 기본 설문으로 되돌릴까요?')) return;
      return saveContent({ survey:undefined, surveyTitle:undefined, surveyLib:undefined }, '보관함 기본 설문으로 되돌렸어요.');
    case 'lib-del': { const e = libIdx(i); if(!e) return;
      if(!confirm(`'${e.title}'을 보관함에서 삭제할까요?${e.id === LIB.defaultId ? '\n기본 설문이라, 지우면 따로 지정하지 않은 경기엔 비상용 기본 문항이 나가요.' : ''}
이미 받은 응답과 버전 기록은 그대로 남아요.`)) return;
      return saveLib({ surveys:LIB.surveys.filter(x => x.id !== e.id), defaultId:e.id === LIB.defaultId ? '' : LIB.defaultId }, '보관함에서 삭제했어요.'); }
    case 'ed-player': { const q = DR[b.dataset.ed][i]; q._opts = q.options; q.type = 'player'; delete q.options; delete q.aiFix; delete q.aiKind; return render(); }
    case 'ed-pool': { DR[b.dataset.ed][i].pool = b.dataset.v === 'all' ? 'all' : undefined; return render(); }
    case 'ed-noplayer': { const q = DR[b.dataset.ed][i]; delete q.type; q.options = q._opts || ['', '']; delete q._opts; delete q.aiFix; delete q.aiKind; return render(); }
    case 'pred-save': {
      const err = validQs(DR.predict); if(err) return toast(err, true);
      { const cv = S0().pred.versions.find(v => v.current); const nv = Math.max(0, ...S0().pred.versions.map(v => v.v === 'none' ? 0 : v.v)) + 1;
        if(cv && cv.rows.length && canon(cleanQs(DR.predict)) !== canon(CT().predict || null)
           && !confirm(`지금 문항(${vLabel(cv.v)})에 ${cv.rows.length}명이 예측했어요.\n새로 등록하면 v${nv}로 따로 집계되고, 이미 예측한 분은 그대로예요. 등록할까요?`)) return; }
      const predict = cleanQs(DR.predict);
      return saveContent({ predict }, '예측을 등록했어요. 관람객 화면엔 20초 안에 보여요.').then(ok=>{ if(ok){ DR.predict = null; render(); } });
    }
    case 'sv-ai': return openModal(`<div class="modal__head"><h3>AI로 설문 생성하기</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
      <div class="field" style="margin-bottom:10px;"><label for="ai-nq">문항 수 (1~5개)</label><input class="in" id="ai-nq" type="number" min="1" max="5" value="4"></div>
      <div class="field"><label for="ai-na">답변 수 (3~5개)</label><input class="in" id="ai-na" type="number" min="3" max="5" value="4"></div>
      <p class="desc" style="margin:10px 0 0;">직관 경험(좌석·응원·편의시설·교통 등)에 맞춘 문항으로 채워요. 채운 뒤 고쳐서 등록하면 돼요.</p>
      <div class="modal__foot"><button class="btn" data-act="sv-gen">생성하기</button></div>`);
    case 'sv-gen': {
      const nq = Math.round(Number(val('ai-nq'))), na = Math.round(Number(val('ai-na')));
      if(!(nq >= 1 && nq <= 5)) return toast('문항 수는 1~5개로 넣어주세요.', true);
      if(!(na >= 3 && na <= 5)) return toast('답변 수는 3~5개로 넣어주세요.', true);
      DR.survey = genSurvey(nq, na); DR.svEdit = { ...(DR.svEdit || { id:'' }), title:(DR.svEdit && DR.svEdit.title) || 'AI 생성 설문' }; closeModal(); render(); return toast('설문을 채웠어요. 확인하고 보관함에 저장해주세요.');
    }
    case 'sv-cancel': DR.svEdit = null; DR.survey = null; return render();
    case 'sv-save': {
      const title = (DR.svEdit.title || '').trim();
      if(!title) return toast('설문 제목을 넣어주세요.', true);
      const err = validSurvey(DR.survey); if(err) return toast(err, true);
      const items = cleanSurvey(DR.survey), id = DR.svEdit.id;
      const surveys = id ? LIB.surveys.map(x => x.id === id ? { ...x, title, items, updatedAt:Date.now() } : x)
                         : [...LIB.surveys, { id:'s' + Date.now().toString(36), title, items, at:Date.now(), updatedAt:Date.now() }];
      const newId = id || surveys[surveys.length - 1].id;
      const defaultId = DR.svEdit.makeDefault ? newId : LIB.defaultId;
      const live = D.survey, pushMatch = live && live.source === 'match' && live.lib === id && id;
      const msg = id === LIB.defaultId && id ? `저장했어요. 기본 설문이라 모든 경기에 1분 안에 바뀐 설문(새 버전)이 나가요.` : '보관함에 저장했어요.';
      return saveLib({ surveys, defaultId }, msg).then(async ok =>{
        if(!ok) return;
        if(pushMatch && confirm('이 경기에 따로 내보낸 설문이에요. 이 경기에도 고친 설문을 바로 내보낼까요?')) await saveContent({ survey:items, surveyTitle:title, surveyLib:id }, '이 경기에도 내보냈어요.');
        DR.svEdit = null; DR.survey = null; render();
      });
    }

    case 'ck-edit': {
      const qs = (Array.isArray(CT().checkin) && CT().checkin.length) ? CT().checkin : CK_DEF;
      MOD = { kind:'ck', i:b.dataset.i === 'new' ? qs.length : i, qs:clone(qs) };
      if(b.dataset.i === 'new') MOD.qs.push({ key:'q' + Date.now().toString(36), q:'', opts:[{ label:'' }, { label:'' }] });
      return ckModal();
    }
    case 'ck-oadd': if(MOD.qs[MOD.i].opts.length < LIMIT.ckO){ MOD.qs[MOD.i].opts.push({ label:'' }); ckModal(); } return;
    case 'ck-odel': { const o = MOD.qs[MOD.i].opts; if(o.length > 2){ o.splice(Number(b.dataset.j), 1); ckModal(); } return; }
    case 'ck-imgdel': delete MOD.qs[MOD.i].opts[Number(b.dataset.j)].img; return ckModal();
    case 'ck-qdel': {
      if(MOD.qs.length <= 1) return toast('질문은 1개 이상 있어야 해요.', true);
      if(!confirm('이 질문을 삭제할까요?')) return;
      MOD.qs.splice(MOD.i, 1); const qs = MOD.qs; closeModal();
      return saveContent({ checkin:qs }, '질문을 삭제했어요.');
    }
    case 'ck-save': {
      const q = MOD.qs[MOD.i];
      q.q = q.q.trim(); q.opts = q.opts.map(o => ({ ...o, label:o.label.trim() })).filter(o => o.label);
      if(!q.q) return toast('질문을 입력해주세요.', true);
      if(q.opts.length < 2) return toast('답변을 2개 이상 넣어주세요.', true);
      if(new Set(q.opts.map(o => o.label)).size !== q.opts.length) return toast('같은 답변이 있어요.', true);
      const qs = MOD.qs.slice(0, LIMIT.ckQ); closeModal();
      return saveContent({ checkin:qs }, '출석 질문을 등록했어요.');
    }
    case 'redeem': return act(()=> mcall('PUT', 'redeem', { code:b.dataset.code, redeemed:b.dataset.v === '1' }), b.dataset.v === '1' ? '교환 완료로 처리했어요.' : '교환 처리를 취소했어요.', true).then(()=>{ if($('code-result') && $('code-result').innerHTML) findCode(); });
    case 'code-find': return load(true).then(findCode);
    case 'rf-swap': return swapDraw(i);
    case 'lock-refresh': return loadExtra('locks', true);
    case 'sub-save': {
      const cur = (EXTRA.subway && !EXTRA.subway.error && EXTRA.subway.tt) || {};
      const p0 = parseHumetro(DR.sub.t0), p1 = parseHumetro(DR.sub.t1);
      const has = p => p.wk.length + p.sa.length + p.su.length > 0;
      if(String(DR.sub.t0 || '').trim() && !has(p0)) return toast('수영 방면 칸에서 시각을 못 읽었어요. 표를 다시 복사해주세요.', true);
      if(String(DR.sub.t1 || '').trim() && !has(p1)) return toast('대저 방면 칸에서 시각을 못 읽었어요. 표를 다시 복사해주세요.', true);
      const tt = {};
      for(const [k] of TT_DAYS) tt[k] = { 0: has(p0) ? p0[k] : ((cur[k] || {})[0] || []), 1: has(p1) ? p1[k] : ((cur[k] || {})[1] || []) };
      const holidays = String(DR.sub.hol || '').split(/[\s,]+/).filter(Boolean);
      return act(()=> call('PUT', '_/subway', { subway:{ tt, holidays } }), '막차 시간표를 저장했어요. 관람객 화면엔 10분 안에 반영돼요.').then(ok => { if(ok){ DR.sub = null; loadExtra('subway', true); } });
    }
    case 'err-clear': if(!confirm('관람객 화면 오류 기록을 비울까요?')) return; return act(()=> mcall('POST', 'errors-clear'), '오류 기록을 비웠어요.');
    case 'lock-open': return act(()=> call('POST', '_/unlock', { key:b.dataset.k }), '잠금을 풀었어요.').then(ok => { if(ok) loadExtra('locks', true); });
    case 'pv-save': return act(()=> call('PUT', '_/privacy', { privacy:{ retention:val('pv-ret').trim(), contact:'', extra:val('pv-ext').trim() } }), '데이터 안내를 저장했어요. 관람객 화면엔 1분 안에 바뀌어요.').then(ok => { if(ok) loadExtra('privacy', true); });
    case 'pw-save': return act(()=> call('POST', '_/password', { current:val('pw-cur'), next:val('pw-new') }), '비밀번호를 바꿨어요. 다음 로그인부터 새 비밀번호를 쓰세요.').then(ok => { if(ok){ sessionStorage.setItem('adm_key', val('pw-new')); $('pw-cur').value = ''; $('pw-new').value = ''; } });
    case 'user-add': {
      const u = { id:val('nu-id').trim(), name:val('nu-name').trim(), role:val('nu-role'), password:val('nu-pw') };
      if(!u.id || !u.password) return toast('아이디와 비밀번호를 넣어주세요.', true);
      return saveUsers([...(EXTRA.users || []).map(x => ({ id:x.id, name:x.name, role:x.role })), u], `${u.name || u.id} 계정을 만들었어요.`);
    }
    case 'user-pw': { const id = b.dataset.id;
      openModal(`<h3 style="margin:0 0 6px;">비밀번호 재설정</h3><p class="desc" style="margin:0 0 12px;">${esc(id)} 계정의 새 비밀번호 (8자 이상)</p>
        <div class="field"><label for="upw-new">새 비밀번호</label><input id="upw-new" class="in" type="password" autocomplete="new-password"></div>
        <div class="field"><label for="upw-new2">한 번 더</label><input id="upw-new2" class="in" type="password" autocomplete="new-password"></div>
        <div class="edfoot" style="margin-top:14px;"><button class="btn ghost" data-act="modal-close">취소</button><button class="btn" data-act="user-pw-save" data-id="${esc(id)}">재설정</button></div>`);
      setTimeout(()=> $('upw-new') && $('upw-new').focus(), 30); return; }
    case 'user-pw-save': { const id = b.dataset.id, pw = val('upw-new'), pw2 = val('upw-new2');
      if(pw.length < 8) return toast('비밀번호는 8자 이상으로 넣어주세요.', true);
      if(pw !== pw2) return toast('두 비밀번호가 달라요.', true);
      closeModal();
      return saveUsers((EXTRA.users || []).map(x => ({ id:x.id, name:x.name, role:x.role, ...(x.id === id ? { password:pw } : {}) })), '비밀번호를 재설정했어요.'); }
    case 'modal-close': return closeModal();
    case 'season-reload': loadSeason(true); return render();
    case 'taps-csv': {
      const list = TAPS_VIEW || [], by = Object.fromEntries(list.map(r => [r.key, r]));
      const rows = [['항목', '누른 횟수', '누른 사람 수']];
      TAP_ITEMS.forEach(([k, t]) => rows.push([t, (by[k] || {}).total || 0, (by[k] || {}).people || 0]));
      list.filter(r => /^card:\d+$/.test(r.key)).sort((a, b) => b.total - a.total).forEach(r => { const num = r.key.slice(5); rows.push([`선수 카드 · ${(ROSTER.find(x => x.startsWith('#' + num + ' ')) || '#' + num)}`, r.total, r.people]); });
      const csv = '\ufeff' + rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type:'text/csv' })); a.download = `화면이용_${b.dataset.season ? '시즌' : mid()}.csv`; a.click();
      return; }
    case 'rp-norm': {
      const R = homeDraft().roulette; if(!R || !R.prizes) return;
      const sum = R.prizes.reduce((a, p) => a + (Number(p.weight) || 0), 0); if(!sum) return;
      R.prizes.forEach(p => p.weight = Math.round((Number(p.weight) || 0) * 100 / sum));
      const diff = 100 - R.prizes.reduce((a, p) => a + p.weight, 0);
      if(diff){ const big = R.prizes.reduce((m, p) => p.weight > m.weight ? p : m, R.prizes[0]); big.weight += diff; }
      toast('가중치를 합계 100으로 맞췄어요. 저장을 눌러야 반영돼요.'); return render(); }
    case 'user-del': { const id = b.dataset.id; if(!confirm(`${id} 계정을 삭제할까요?`)) return;
      return saveUsers((EXTRA.users || []).filter(x => x.id !== id).map(x => ({ id:x.id, name:x.name, role:x.role })), '계정을 삭제했어요.'); }
    case 'nb-add': { const add = val('nb-add').split(/[,\n]/).map(w => w.trim()).filter(Boolean); if(!add.length) return toast('추가할 금칙어를 넣어주세요.', true);
      const words = [...new Set([...((EXTRA.nick || {}).words || []), ...add])];
      return act(()=> call('PUT', '_/nickban', { words }), `금칙어 ${add.length}개를 추가했어요.`).then(ok => { if(ok){ $('nb-add').value = ''; loadExtra('nick', true); } }); }
    case 'nb-del': { const w = b.dataset.w; if(!confirm(`'${w}'를 금칙어에서 지울까요?`)) return;
      const words = ((EXTRA.nick || {}).words || []).filter(x => x !== w);
      return act(()=> call('PUT', '_/nickban', { words }), `'${w}'를 지웠어요.`).then(ok => { if(ok) loadExtra('nick', true); }); }
    case 'rp-imgdel': delete homeDraft().roulette.prizes[i].image; return render();
    case 'rp-imgpick': RP_PICK = i; return $('rp-file').click();
    case 'hb-imgpick': RP_PICK = 'banner:' + b.dataset.k + ':' + (b.dataset.field || 'image'); return $('rp-file').click();
    case 'hb-imgdel': { const H = homeDraft(); delete H[b.dataset.k][b.dataset.field || 'image']; toast('이미지를 뺐어요. 저장을 눌러야 반영돼요.'); return render(); }
    case 'home-reset': DR.home = null; render.last = null; toast('저장된 값으로 되돌렸어요.'); return render();   // 입력칸 값 지키기(새로고침용)를 건너뛰어 숫자 칸까지 되돌려요
    case 'home-save': {
      const H = homeDraft();
      const body = { home:{ ...H, roulette:{ ...H.roulette, prizes:H.roulette.prizes.map(p => ({ ...p, title:String(p.title || '').replace(/\s*\/\s*/g, '\n') })) } } };
      if(!confirm('룰렛·배너를 저장할까요? 모든 경기 관람객 화면에 1분 안에 반영돼요.')) return;
      return act(()=> call('PUT', '_/home', body), '룰렛·배너를 저장했어요.').then(ok => { if(ok){ DR.home = null; loadExtra('home', true); } });
    }
    case 'rl-notice-reset': { homeDraft().roulette.notices = []; if($('rl-notices')) $('rl-notices').value = DEFAULT_NOTICES.join('\n'); toast('기본 문구로 되돌렸어요. 저장을 눌러야 반영돼요.'); return render(); }
    case 'rf-hide': return act(()=> mcall('PUT', 'raffle-hide', { device:b.dataset.dev, hidden:b.dataset.h === '1' }), b.dataset.h === '1' ? '추첨에서 뺐어요.' : '추첨 대상에 다시 넣었어요.');
    case 'save-opp': return act(()=> mcall('PUT', 'settings', { opponent:val('opp').trim() }), val('opp').trim() ? `상대팀을 ${val('opp').trim()}(으)로 저장했어요.` : '상대팀을 지웠어요 (일정표 기준).');
    case 'report': return downloadReport().catch(e => toast(e.message, true));
    case 'csv-survey': return csvSurvey();
    case 'rs-all': DR.reset = [...DATA_PARTS]; return render();
    case 'rs-none': DR.reset = []; return render();
    case 'rs-go': {
      const parts = DR.reset || []; if(!parts.length) return;
      const names = resetParts(S0()).filter(p => parts.includes(p.k)).map(p => `· ${p.t}`).join('<br>');
      return openModal(`<div class="modal__head"><h3>데이터 초기화</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
        <p class="desc"><b style="color:var(--ink);">${esc(mid())}</b> 경기의 아래 항목을 지워요. 되돌릴 수 없어요.</p>
        <p style="font-size:14px; line-height:24px; margin:10px 0 14px;">${names}</p>
        <div class="field"><label for="rs-confirm">확인을 위해 경기 ID <b>${esc(mid())}</b>를 입력해주세요</label><input class="in" id="rs-confirm" autocomplete="off" placeholder="${esc(mid())}"></div>
        <div class="modal__foot"><button class="btn ghost" data-act="modal-x">취소</button><button class="btn danger" id="rs-do" data-act="rs-do" disabled>지우기</button></div>`);
    }
    case 'rs-do': {
      if(val('rs-confirm').trim() !== mid()) return toast('경기 ID가 맞지 않아요.', true);
      const parts = DR.reset || []; closeModal();
      return act(()=> mcall('POST', 'reset', { parts }).then(r =>{ DR.resetDone = r.deleted; }), '초기화했어요. 관람객 휴대폰 기록도 20~30초 안에 지워져요.').then(ok =>{ if(ok){ DR.reset = []; DR.predict = null; render(); } });
    }
    case 'csv-predict': return csvPredict();
    case 'match-purge': return openModal(`<div class="modal__head"><h3>이 경기 통째로 삭제</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
        <p class="desc"><b style="color:var(--ink);">${esc(mid())}</b> 경기의 데이터와 설정을 모두 지우고 경기 목록에서 빼요. 되돌릴 수 없어요.</p>
        <div class="field" style="margin-top:12px;"><label for="mp-confirm">확인을 위해 경기 ID <b>${esc(mid())}</b>를 입력해주세요</label><input class="in" id="mp-confirm" autocomplete="off" placeholder="${esc(mid())}"></div>
        <div class="modal__foot"><button class="btn ghost" data-act="modal-x">취소</button><button class="btn danger" id="mp-do" data-act="match-purge-do" disabled>경기 삭제</button></div>`);
    case 'match-purge-do': {
      const id = mid();
      if(val('mp-confirm').trim() !== id) return toast('경기 ID가 맞지 않아요.', true);
      closeModal();
      return (async ()=>{
        try{ await mcall('POST', 'purge'); }catch(err){ return toast(err.message || '지우지 못했어요.', true); }
        try{ await call('DELETE', encodeURIComponent(id) + '/taps'); }catch(err){}
        await refreshMatches(today());
        toast(`${id} 경기를 지웠어요.${id === today() ? ' 오늘 경기는 목록에 늘 보여요.' : ''}`);
      })();
    }
    case 'season-wipe': {
      const ids = MATCHES.filter(id => id && id !== '__new');
      return openModal(`<div class="modal__head"><h3>시즌 전체 데이터 삭제</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
        <p class="desc"><b style="color:var(--ink);">${ids.length}경기</b>의 참여 데이터와 경기별 설정을 모두 지우고 경기 목록에서도 빼요. 되돌릴 수 없어요.</p>
        <p style="font-size:13px; line-height:22px; margin:10px 0 14px; color:var(--ink-dim);">${ids.map(esc).join(' · ')}</p>
        <div class="field"><label for="sw-confirm">확인을 위해 <b>전체 삭제</b>를 입력해주세요</label><input class="in" id="sw-confirm" autocomplete="off" placeholder="전체 삭제"></div>
        <div class="modal__foot"><button class="btn ghost" data-act="modal-x">취소</button><button class="btn danger" id="sw-do" data-act="season-wipe-do" disabled>모두 지우기</button></div>`);
    }
    case 'season-wipe-do': {
      if(val('sw-confirm').trim() !== '전체 삭제') return toast('\'전체 삭제\'를 정확히 입력해주세요.', true);
      closeModal();
      return (async ()=>{
      const ids = MATCHES.filter(id => id && id !== '__new'), fail = [];
      for(const [n, id] of ids.entries()){
        toast(`지우는 중 ${n + 1} / ${ids.length}경기…`);
        try{ await call('POST', encodeURIComponent(id) + '/purge'); }catch(err){ fail.push(id); continue; }
        try{ await call('DELETE', encodeURIComponent(id) + '/taps'); }catch(err){}
      }
      await refreshMatches(today());
      return fail.length ? toast(`${fail.length}경기는 지우지 못했어요: ${fail.join(', ')}`, true) : toast(`${ids.length}경기의 참여 데이터를 모두 지웠어요.`);
      })();
    }
  }
});
document.addEventListener('click', e=>{
  const s = e.target.closest('#phase [data-v]'); if(!s) return;
  const v = s.dataset.v;
  if(v === 'live' && !confirm('경기 시작으로 바꿀까요? 관람객 화면의 경기 예측이 마감되고 MVP 투표가 열려요.')) return;
  act(()=> mcall('PUT', 'settings', { phase:v }), { auto:'자동으로 바꿨어요.', before:'시작 전으로 바꿨어요.', live:'경기 시작! MVP 투표가 열렸어요.' }[v]);
});
document.addEventListener('click', e=>{
  const t = e.target.closest('[data-settab]'); if(!t) return;
  DR.setTab = t.dataset.settab; render();
});
document.addEventListener('change', e=>{
  const sel = e.target.closest('[data-urole]'); if(!sel) return;
  const id = sel.dataset.urole, role = sel.value;
  if(!confirm(`${id} 계정을 '${ROLE_NAME[role]}'(으)로 바꿀까요?`)){ render(); return; }
  saveUsers((EXTRA.users || []).map(x => ({ id:x.id, name:x.name, role:x.id === id ? role : x.role })), '권한을 바꿨어요.');
});
document.addEventListener('click', e=>{
  const s = e.target.closest('#dayopen [data-v]'); if(!s) return;
  const v = s.dataset.v;
  if(v === 'off' && !confirm('미운영으로 바꿀까요? 관람객 화면이 홈·기록만 남은 화면으로 바뀌어요.')) return;
  saveContent({ open:v }, { auto:'경기 일정 기준으로 바꿨어요.', on:'오늘 운영으로 바꿨어요.', off:'미운영으로 바꿨어요.' }[v]);
});
document.addEventListener('keydown', e=>{ if(e.key === 'Enter' && e.target.id === 'code-q') load(true).then(findCode); });
document.addEventListener('click', e=>{
  const t = e.target.closest('[data-vtab]'); if(!t) return;
  DR.tab = { ...(DR.tab || {}), [t.dataset.vtab]:t.dataset.v }; render();
});

document.addEventListener('change', e=>{
  const t = e.target.closest('[data-cond]'); if(!t || !DR.survey) return;
  const q = DR.survey[+t.dataset.i]; if(!q || !q.cond) return;
  const c = q.cond, list = c.in || c.notIn || [];
  if(t.dataset.cond === 'id'){ q.cond = { id:t.value, in:[] }; }
  else if(t.dataset.cond === 'mode'){ q.cond = t.value === 'notIn' ? { id:c.id, notIn:list } : { id:c.id, in:list }; }
  else if(t.dataset.cond === 'opt'){ const set = new Set(list); t.checked ? set.add(t.value) : set.delete(t.value); const arr = [...set]; q.cond = c.notIn ? { id:c.id, notIn:arr } : { id:c.id, in:arr }; }
  render();
});
document.addEventListener('input', e=>{
  const t = e.target;
  if(t.dataset.ed){
    const q = DR[t.dataset.ed] && DR[t.dataset.ed][Number(t.dataset.i)]; if(!q) return;
    const f = t.dataset.f;
    if(f === 'q'){ q.q = t.value; if(t.dataset.ed === 'predict') syncAiKind(q, Number(t.dataset.i)); }
    else if(f === 'opt'){ q.options[Number(t.dataset.j)] = t.value; if(t.dataset.ed === 'predict') syncAiKind(q, Number(t.dataset.i)); }
    else if(f === 'aiKind'){ q.aiKind = t.value; q.aiFix = true; render(); }
    else if(['options', 'rows', 'cols'].includes(f)) q[f][Number(t.dataset.j)] = t.value;
    else if(f === 'ai'){ q.ai = t.checked; if(t.dataset.ed === 'predict') render(); }
    else if(f === 'other' || f === 'comment' || f === 'shuffle' || f === 'shuffleRows') q[f] = t.checked;
    else if(f === 'low' || f === 'high') q[f] = t.value;
    else if(f === 'max') q.max = Number(t.value) || 0;
    else if(f === 'type'){ setSvType(q, t.value); render(); }
  } else if(t.dataset.sub){
    DR.sub = DR.sub || {}; DR.sub[t.dataset.sub] = t.value; subwayPreview();
  } else if(t.dataset.rp != null){
    const p = homeDraft().roulette.prizes[Number(t.dataset.i)], f = t.dataset.rp;
    if(f === 'miss'){ p.miss = t.checked; if(p.miss) p.img = 'miss'; else if(p.img === 'miss') p.img = 'soju'; render(); }
    else if(f === 'stock'){ p.stock = t.value === '' ? null : Math.max(0, Math.floor(Number(t.value) || 0)); clearTimeout(window.__rpT); window.__rpT = setTimeout(render, 600); }
    else if(f === 'weight'){ p.weight = Math.max(0, Number(t.value) || 0); clearTimeout(window.__rpT); window.__rpT = setTimeout(render, 600); }
    else if(f === 'img'){ p.img = t.value; }
    else p[f] = t.value;
  } else if(t.dataset.hf != null){
    const R = homeDraft().roulette;
    if(t.dataset.hf === 'notices'){
      const lines = t.value.split('\n').map(x => x.trim()).filter(Boolean);
      R.notices = lines.join('\n') === DEFAULT_NOTICES.join('\n') ? [] : lines;
    }
    else if(t.dataset.hf === 'onePerPerson') R.onePerPerson = t.checked;
    else R[t.dataset.hf] = Math.max(0, Number(t.value) || 0);
  } else if(t.dataset.hb != null){
    const [g, k] = t.dataset.hb.split('.'); homeDraft()[g][k] = t.type === 'checkbox' ? t.checked : t.value;
  } else if(t.dataset.rs){
    const set = new Set(DR.reset || []); t.checked ? set.add(t.dataset.rs) : set.delete(t.dataset.rs); DR.reset = [...set]; render();
  } else if(t.id === 'mp-confirm'){ $('mp-do').disabled = t.value.trim() !== mid();
  } else if(t.id === 'sw-confirm'){ $('sw-do').disabled = t.value.trim() !== '전체 삭제';
  } else if(t.id === 'rs-confirm'){ $('rs-do').disabled = t.value.trim() !== mid();
  } else if(t.id === 'sv-title' && DR.svEdit){ DR.svEdit.title = t.value;
  } else if(t.dataset.ck && MOD){
    const q = MOD.qs[MOD.i];
    if(t.dataset.ck === 'q') q.q = t.value; else if(t.dataset.ck === 'o') q.opts[Number(t.dataset.j)].label = t.value;
  }
});
let RP_PICK = -1;
document.addEventListener('change', async e=>{
  if(e.target.id === 'rp-file' && e.target.files[0]){
    const f = e.target.files[0], idx = RP_PICK; e.target.value = '';
    if(typeof idx === 'string' && idx.startsWith('banner:')){
      const [, k, field = 'image'] = idx.split(':'), H = homeDraft();
      try{ H[k] = { ...(H[k] || {}), [field]: await shrinkBanner(f) }; render(); toast(`${k === 'goods' ? '굿즈샵' : '앱 다운로드'} 배너${field === 'imageDark' ? ' (다크 모드)' : k === 'app' ? ' (라이트 모드)' : ''} 이미지를 넣었어요. 아래 '저장'을 눌러야 관람객 화면에 반영돼요.`); }
      catch(err){ toast(err.message, true); }
      return;
    }
    const prize = homeDraft().roulette.prizes[idx]; if(!prize) return;
    try{ prize.image = await shrinkImage(f, 160); render(); toast(`${idx + 1}번 칸 이미지를 넣었어요. 아래 '저장'을 눌러야 관람객 화면에 반영돼요.`); }
    catch(err){ toast(err.message, true); }
    return;
  }
  if(e.target.id === 'sv-file' && e.target.files[0]){
    const f = e.target.files[0]; e.target.value = '';
    try{
      toast('엑셀을 읽는 중…');
      const r = await readSurveyFile(f);
      window.__svImport = { items:r.items, title:f.name.replace(/\.(xlsx|xls|csv)$/i, '').replace(/_/g, ' ').trim() };
      openModal(`<div class="modal__head"><h3>엑셀 미리보기</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
        <p class="desc">${esc(f.name)} · '${esc(r.sheet)}' 시트 · ${r.items.length}문항</p>
        ${r.warn.length ? `<div class="winbox" style="background:#FFF8E1; color:#7A5B00; margin:0 0 12px;"><b>확인해 주세요</b>${r.warn.map(w => `<p style="font-size:13px; margin-top:6px;">· ${esc(w)}</p>`).join('')}</div>` : ''}
        <div style="max-height:52vh; overflow:auto;">${r.items.map(q => `<div class="row"><div class="main"><p class="t">${esc(q.id)}. ${esc(q.q)}</p><p class="m" style="margin-top:4px;">${svBadges(q)}</p><p class="m">${esc(svOptsText(q))}</p></div></div>`).join('')}</div>
        <div class="field" style="margin-top:14px;"><label for="imp-title">설문 제목</label><input class="in" id="imp-title" maxlength="60" value="${esc(window.__svImport.title)}"></div>
        <label class="chk" style="margin-top:10px;"><input type="checkbox" id="imp-def"${LIB.defaultId ? '' : ' checked'}>기본 설문으로 지정 (모든 경기에 나가요)</label>
        <div class="modal__foot"><button class="btn ghost" data-act="lib-add-edit">고쳐서 넣기</button><button class="btn" data-act="lib-add">보관함에 넣기</button></div>`);
      $('modal-box').style.maxWidth = '640px';
    }catch(err){ toast(err.message, true); }
    return;
  }
  const t = e.target; if(t.dataset.ckimg == null || !MOD || !t.files[0]) return;
  try{ MOD.qs[MOD.i].opts[Number(t.dataset.ckimg)].img = await shrinkImage(t.files[0]); ckModal(); }
  catch(err){ toast(err.message, true); }
});
const S0 = () => window.__S || stats();

function ckModal(){
  const q = MOD.qs[MOD.i];
  openModal(`<div class="modal__head"><h3>출석 질문 ${MOD.i + 1}</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
    <div class="field"><label for="ck-q">질문</label><input class="in" id="ck-q" data-ck="q" value="${esc(q.q)}" maxlength="30" placeholder="질문을 입력해주세요"></div>
    <div class="field" style="margin-top:14px;"><label>답변</label>
      ${q.opts.map((o, j) => `<div class="ans">
        ${o.img ? `<img class="ckimg" src="${esc(o.img)}" alt="">` : `<span class="ckimg" aria-hidden="true"></span>`}
        <input class="in" data-ck="o" data-j="${j}" value="${esc(o.label)}" maxlength="10" placeholder="답변을 입력해주세요" aria-label="답변 ${j + 1}">
        <label class="btn small ghost" style="display:inline-flex; align-items:center; cursor:pointer;">이미지등록<input type="file" accept="image/*" data-ckimg="${j}" hidden></label>
        ${o.img ? `<button class="btn small ghost" data-act="ck-imgdel" data-j="${j}" aria-label="이미지 빼기">↺</button>` : ''}
        <button class="btn small ghost" data-act="ck-odel" data-j="${j}" aria-label="답변 삭제"${q.opts.length <= 2 ? ' disabled' : ''}>×</button></div>`).join('')}
      ${q.opts.length < LIMIT.ckO ? `<button class="btn small ghost" data-act="ck-oadd" style="margin-top:10px;">답변 추가</button>` : ''}
    </div>
    <div class="modal__foot">${MOD.qs.length > 1 && MOD.i < ((CT().checkin || CK_DEF).length) ? `<button class="btn danger" data-act="ck-qdel">질문 삭제</button>` : ''}
      <button class="btn ghost" data-act="modal-x">취소</button><button class="btn" data-act="ck-save">등록</button></div>`);
}

function drawRaffle(){
  const S = window.__raffleS || stats();
  const srcF = val('rf-src'), only = val('rf-only'), n = Math.max(1, Number(val('rf-n')) || 1);
  const done = D.raffleWinners || [];
  const doneDev = new Set(done.map(w => w.device).filter(Boolean)), doneName = new Set(done.map(w => w.nickname || w.contact));
  const seen = new Set();
  const pool = S.raffle.filter(r => (!srcF || (srcF === 'predict' ? r.viaPredict : r.viaSurvey)) && (!only || S.pred.allCorrect.has(r.device))
                                   && !doneDev.has(r.device) && !doneName.has(r.name) && !(D.raffleHidden || {})[r.device])
                       .filter(r => !seen.has(r.device + '|' + r.name) && !seen.has(r.name) && seen.add(r.name) && seen.add(r.device + '|' + r.name));
  const arr = pool.slice();
  const rnd = new Uint32Array(arr.length);
  crypto.getRandomValues(rnd);
  for(let k = arr.length - 1; k > 0; k--){ const j = rnd[k] % (k + 1); [arr[k], arr[j]] = [arr[j], arr[k]]; }
  const withRoute = r => ({ ...r, route:[r.viaPredict ? '예측' : '', r.viaSurvey ? '설문' : ''].filter(Boolean).join(' · ') });
  const pick = arr.slice(0, n).map(withRoute);
  window.__draw = pick; window.__drawRest = arr.slice(n).map(withRoute); window.__drawPool = pool.length;
  showDraw();
}
function swapDraw(i){
  const rest = window.__drawRest || [];
  if(!rest.length) return toast('더 뽑을 대상이 없어요.', true);
  window.__draw[i] = rest.shift();
  showDraw();
}
function showDraw(){
  const pick = window.__draw || [], pool = { length:window.__drawPool || 0 };
  openModal(`<div class="modal__head"><h3>추첨결과</h3><button class="modal__x" data-act="modal-x" aria-label="닫기">×</button></div>
    ${pick.length ? `<p style="font-size:14px; color:var(--gold); font-weight:700; margin-bottom:6px;">대상 ${pool.length}명 중 ${pick.length}명 당첨</p>
      ${pick.map((w, i) => `<div class="row"><div class="main"><p class="t">${esc(w.name)}</p><p class="m">${w.route || '—'} · ${time(w.at)} 응모</p></div><button class="btn small ghost" data-act="rf-swap" data-i="${i}" title="부적절한 닉네임이면 이 사람만 빼고 다시 뽑아요">빼고 다시</button><button class="btn small ghost" data-copy="${esc(w.name)}">복사</button></div>`).join('')}
      <div class="modal__foot"><button class="btn ghost" data-act="rf-draw">다시 뽑기</button><button class="btn" data-act="rf-save">이 결과 저장</button></div>`
    : `<p class="empty" style="color:rgba(255,255,255,.7);">조건에 맞는 응모자가 없어요.</p>`}`, true);
}

function findCode(){
  const q = val('code-q').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if(!q) return;
  const S = stats();
  const all = [...S.rl.wins, ...(D.winners || []).map(w => ({ code:w.code, title:w.prize, at:w.at, type:'응원' }))];
  const hit = all.find(w => w.code === q);
  const red = (D.redeemed || {})[q];
  $('code-result').innerHTML = !hit ? `<p class="status err">이 경기에서 발급된 코드가 아니에요. 경기 ID를 확인해주세요.</p>`
    : `<div class="row" style="border:0;"><div class="main"><p class="t"><span class="chip ${red ? 'off' : 'ok'}">${red ? '이미 교환됨' : '교환 가능'}</span>${esc(hit.title)}</p>
       <p class="m">${hit.type} · ${time(hit.at)} 발급${red ? ` · ${time(red)} 교환` : ''}</p></div>${redeemBtn(q)}</div>`;
}
